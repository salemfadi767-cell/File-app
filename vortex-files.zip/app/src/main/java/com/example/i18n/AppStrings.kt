package com.example.i18n

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf

enum class AppLanguage(val code: String, val displayName: String, val isRtl: Boolean) {
  AR("ar", "العربية", true),
  EN("en", "English", false),
  FR("fr", "Français", false),
  ES("es", "Español", false),
  DE("de", "Deutsch", false),
  TR("tr", "Türkçe", false),
  RU("ru", "Русский", false),
}

@Immutable
interface VortexStrings {
  val appTitle: String
  val subtitle: String
  val dualPane: String
  val singlePane: String
  val tabbedMode: String
  val leftPane: String
  val rightPane: String
  val paneLabel: (Int) -> String
  val activePane: String
  val storageInternal: String
  val storageAppSpace: String
  val storageRoot: String
  val storageSystem: String
  val storageAndroidData: String
  val downloads: String
  val bookmarks: String
  val recentFiles: String
  val converterHub: String
  val systemAccess: String
  val themeStudio: String
  val searchHint: String
  val deepSearch: String
  val searchContentToggle: String
  val searchRegexToggle: String
  val copy: String
  val cut: String
  val paste: String
  val copyToOtherPane: String
  val moveToOtherPane: String
  val rename: String
  val batchRename: String
  val delete: String
  val newFolder: String
  val newFile: String
  val compress: String
  val extractHere: String
  val convertFormat: String
  val inspectApk: String
  val openInEditor: String
  val openAsHex: String
  val properties: String
  val permissionsChmod: String
  val compare: String
  val selectAll: String
  val clearSelection: String
  val selectedCount: (Int) -> String
  val clipboardReady: (Int, Boolean) -> String
  val emptyFolderTitle: String
  val emptyFolderHint: String
  val permissionNeededTitle: String
  val permissionNeededBody: String
  val grantAllFilesAccess: String
  val openSystemGateway: String
  val addBookmark: String
  val removeBookmark: String
  val sortName: String
  val sortSize: String
  val sortDate: String
  val sortType: String
  val showHidden: String
  // Archive & Universal Size/Quality Reducer
  val archiveTitle: String
  val archiveNameLabel: String
  val archiveFormatLabel: String
  val compressionLevelLabel: String
  val levelStore: String
  val levelFast: String
  val levelBalanced: String
  val levelUltra: String
  val losslessModeTitle: String
  val losslessModeDesc: String
  val lossyModeTitle: String
  val lossyModeDesc: String
  val lossyWarningBanner: String
  val universalReducerTab: String
  val universalReducerDesc: String
  val imageQualityLabel: String
  val imageScaleLabel: String
  val videoResolutionLabel: String
  val audioBitrateLabel: String
  val pdfDpiScaleLabel: String
  val estimatedSizeText: (String, String) -> String
  val passwordOptional: String
  val startCompression: String
  val browseInsideArchive: String
  val extractToPane: String
  // Converter
  val converterTitle: String
  val videoToAudio: String
  val imagesToPdf: String
  val pdfToImages: String
  val imageConverter: String
  val textDataConverter: String
  val archiveConverter: String
  val pickFiles: String
  val sourceFileLabel: String
  val targetFormatLabel: String
  val startConversion: String
  val conversionHistory: String
  val conversionLosslessNote: String
  val conversionLossyNote: String
  // APK Inspector & App Manager
  val apkInspectorTitle: String
  val apkOverviewTab: String
  val apkManifestTab: String
  val apkDexTab: String
  val apkFilesTab: String
  val apkPackageName: String
  val apkVersion: String
  val apkSdkInfo: String
  val apkPermissionsCount: String
  val apkSignature: String
  val apkRepackage: String
  val appManagerTitle: String
  val extractApkAction: String
  val storageAnalyzerTitle: String
  // Code Editor & Runner & IDE Assistant
  val editorTitle: String
  val saveFile: String
  val runCode: String
  val formatCode: String
  val ideAssistant: String
  val symbolsOutline: String
  val diagnosticsLabel: String
  val consoleOutput: String
  val livePreview: String
  val undo: String
  val redo: String
  val findReplace: String
  val findHint: String
  val replaceHint: String
  val replaceAll: String
  val goToLine: String
  val wordWrap: String
  val hexMode: String
  val textMode: String
  val encodingLabel: String
  val savedSuccess: String
  // Advanced Video & Image Player
  val streamUrlTitle: String
  val streamUrlHint: String
  val playStream: String
  val enhancePicture: String
  val brightnessLabel: String
  val contrastLabel: String
  val saturationLabel: String
  val subtitlesTitle: String
  val addLocalSubtitle: String
  val searchOnlineSubtitles: String
  val subtitleStyleTitle: String
  val subtitleSyncDelay: String
  val subtitleFontSize: String
  val subtitleColor: String
  val audioDubbingTitle: String
  val addDubAudioFile: String
  val recordVoiceDub: String
  val stopRecordingDub: String
  val ttsAutoDub: String
  val originalVolume: String
  val dubVolume: String
  val screenCastTitle: String
  val castExternalDisplay: String
  val openSystemCast: String
  val playbackSpeed: String
  val takeScreenshot: String
  // Shizuku / System Access
  val accessModeStandard: String
  val accessModeAllFiles: String
  val accessModeShizuku: String
  val accessModeRoot: String
  val shizukuTitle: String
  val shizukuStatusConnected: String
  val shizukuStatusNeedsPermission: String
  val shizukuStatusNotRunning: String
  val shizukuStatusNotInstalled: String
  val shizukuRequestPerm: String
  val shizukuOpenApp: String
  val devOptionsButton: String
  val wirelessDebugButton: String
  val copyAdbCommand: String
  val adbCommandCopied: String
  val safAndroidDataButton: String
  val rootTestButton: String
  val rootAvailable: String
  val rootUnavailable: String
  val devGuideSteps: List<String>
  // Theme Studio & Settings
  val settingsTitle: String
  val languageSection: String
  val layoutSection: String
  val paneCountSection: String
  val paneCountHint: String
  val themePresetSection: String
  val accentColorSection: String
  val editorSettingsSection: String
  val editorFontSize: String
  val cancel: String
  val confirm: String
  val close: String
  val itemsCount: (Int) -> String
  val backgroundTasks: String
  val noTasksRunning: String
  // Music Hub, DSP, Animated Lyrics, Custom Order & Sleep Timer
  val musicHubTitle: String
  val tabNowPlaying: String
  val tabLyrics: String
  val tabFolders: String
  val tabPlaylists: String
  val soundBoosterTitle: String
  val loudnessBoostLabel: String
  val bassBoostLabel: String
  val equalizerTitle: String
  val sleepTimerTitle: String
  val sleepTimerOff: String
  val stopAfterTrack: String
  val lyricsSearching: String
  val lyricsNotFound: String
  val searchLyricsOnline: String
  val saveLyricsLocally: String
  val sortModeLabel: String
  val sortShuffle: String
  val sortAlphaAsc: String
  val sortAlphaDesc: String
  val sortNumeric: String
  val sortDateNewest: String
  val sortCustomOrder: String
  val createPlaylist: String
  val addToPlaylist: String
  val customOrderHint: String
  val playFolder: String
  val noCoverBadge: String
  // APK Inspector Extended
  val apkExtractManifest: String
  val apkCopyManifest: String
  val apkCopyPackage: String
  val apkManifestSearchHint: String
  val apkPermFilterHint: String
  val apkPermAll: String
  val apkPermDangerous: String
  val apkPermNormal: String
  val apkComponentsLabel: String
  val apkOpenExtractedManifest: String
  val apkExtractAllFiles: String
  // Open With External App, Read As..., Folder View Modes, Drag Select
  val openWithExternalApp: String
  val openBuiltinViewer: String
  val shareFileLabel: String
  val readAsTitle: String
  val readAsCode: String
  val readAsHex: String
  val readAsImage: String
  val readAsVideo: String
  val readAsAudio: String
  val readAsPdf: String
  val readAsDatabase: String
  val readAsArchive: String
  val readAsApk: String
  val fileViewModeTitle: String
  val viewModeNormal: String
  val viewModeGallery: String
  val viewModeMusic: String
  val viewModeVideo: String
  val viewModeCodeDocs: String
  val dragSelectHint: String
  // New Pro Suite Strings
  val downloadManagerTitle: String
  val torrentMagnetTitle: String
  val addDownloadUrl: String
  val resolveStreams: String
  val downloadActiveStream: String
  val drmProtectedNotice: String
  val detectOriginalFormat: String
  val detectedFormatLabel: String
  val headerHexLabel: String
  val fixExtensionAction: String
  val longFilenameSection: String
  val longFilenameEllipsis: String
  val longFilenameMultiLine: String
  val recycleBinTitle: String
  val recycleBinRetentionLabel: String
  val deletePermanentOption: String
  val moveToRecycleBin: String
  val restoreAction: String
  val emptyTrashAction: String
  val vaultTitle: String
  val lockWithPassword: String
  val unlockVault: String
  val recoveryKeyNotice: String
  val enterPasswordOrKey: String
  val cloudAccountsTitle: String
  val addCloudAccount: String
  val browseCloud: String
  val convertToSignedApk: String
  val officeSuiteTitle: String
  val exportPdf: String
  val aiPhotoStudioTitle: String
  val separateSubjectAi: String
  val colorMixerHsl: String
  val addImageOverlay: String
  val videoStudioTitle: String
  val trimRangeLabel: String
  val noiseReduction: String
  val reverbLabel: String
  val vinylDiscMode: String
  val batchPreviewTitle: String
  val adbPairAction: String
  val smartBrowserSniffer: String
  val webPlayerMode: String
  val resolvingStreamLabel: String
  val capturedStreamsCount: (Int) -> String
  val qualityLabel: String
  val conflictTitle: String
  val conflictReplace: String
  val conflictKeepBoth: String
  val conflictSkip: String
  val conflictApplyAll: String
  val sourceFileInfoLabel: String
  val existingFileInfoLabel: String
  val sharedLinkTitle: String
  val shareActionDownload: String
  val shareActionStream: String
  val shareActionBrowser: String
  val autoSubtitlesSection: String
  val autoSubtitlesToggle: String
  val autoSubtitlesHint: String
  val subtitlesFolderLabel: String
  val pickSubtitlesFolder: String
  val subtitleLanguagesLabel: String
  val subtitleLanguagesHint: String
  val rarNoteLabel: String
  // Studio 3D, Antivirus, .vortexbak Snapshots, Packages & Multi-OS Builder, TV Cast
  val studio3dTitle: String
  val antivirusSection: String
  val antivirusScanAction: String
  val antivirusAutoScanToggle: String
  val antivirusAutoScanHint: String
  val autoBackupSection: String
  val autoBackupToggle: String
  val autoBackupHint: String
  val restoreOriginalAction: String
  val packagesManagerLabel: String
  val buildMultiOsLabel: String
  val companionServerLabel: String
  val companionExportKit: String
  val castBackgroundNote: String
  val castToSmartTv: String
  val discoveredMediaTitle: String
}

object ArabicStrings : VortexStrings {
  override val appTitle = "Vortex Files"
  override val subtitle = "مدير الملفات، مشغل الأكواد والوسائط الاحترافي"
  override val dualPane = "لوحتان"
  override val singlePane = "لوحة واحدة"
  override val tabbedMode = "تبويبات"
  override val leftPane = "المكان 1"
  override val rightPane = "المكان 2"
  override val paneLabel: (Int) -> String = { "المكان $it" }
  override val activePane = "نشط"
  override val storageInternal = "التخزين الداخلي"
  override val storageAppSpace = "مساحة العمل الآمنة"
  override val storageRoot = "جذر النظام (/)"
  override val storageSystem = "ملفات النظام (/system)"
  override val storageAndroidData = "Android/data"
  override val downloads = "التنزيلات"
  override val bookmarks = "المفضلة"
  override val recentFiles = "الأخيرة"
  override val converterHub = "محول الصيغ"
  override val systemAccess = "بوابة النظام وShizuku"
  override val themeStudio = "الستايل والإعدادات"
  override val searchHint = "ابحث في الملفات أو المحتوى..."
  override val deepSearch = "بحث عميق"
  override val searchContentToggle = "بحث داخل المحتوى"
  override val searchRegexToggle = "تعبير نمطي Regex"
  override val copy = "نسخ"
  override val cut = "قص"
  override val paste = "لصق"
  override val copyToOtherPane = "نسخ للمكان المقابل"
  override val moveToOtherPane = "نقل للمكان المقابل"
  override val rename = "إعادة تسمية"
  override val batchRename = "تسمية جماعية"
  override val delete = "حذف"
  override val newFolder = "مجلد جديد"
  override val newFile = "ملف جديد"
  override val compress = "ضغط / تقليل الحجم"
  override val extractHere = "فك الضغط هنا"
  override val convertFormat = "تحويل الصيغة"
  override val inspectApk = "فحص APK من الداخل"
  override val openInEditor = "مشغل ومحرر الأكواد"
  override val openAsHex = "عارض Hex"
  override val properties = "الخصائص والبصمة"
  override val permissionsChmod = "الصلاحيات (chmod)"
  override val compare = "مقارنة"
  override val selectAll = "تحديد الكل"
  override val clearSelection = "إلغاء التحديد"
  override val selectedCount: (Int) -> String = { "$it محدد" }
  override val clipboardReady: (Int, Boolean) -> String = { count, isCut ->
    if (isCut) "جاهز للنقل ($count عناصر)" else "جاهز للنسخ ($count عناصر)"
  }
  override val emptyFolderTitle = "المجلد فارغ"
  override val emptyFolderHint = "يمكنك إنشاء ملفات أو نسخ عناصر من مكان آخر أو فك ضغط أرشيف هنا."
  override val permissionNeededTitle = "يلزم إذن الوصول الشامل للملفات"
  override val permissionNeededBody =
    "لتصفح كل مجلدات الجهاز وتعديلها، امنح إذن إدارة جميع الملفات أو استخدم بوابة Shizuku / SAF للوصول لمجلدات النظام."
  override val grantAllFilesAccess = "منح إذن جميع الملفات"
  override val openSystemGateway = "إعداد Shizuku ووضع المطور"
  override val addBookmark = "إضافة للمفضلة"
  override val removeBookmark = "إزالة من المفضلة"
  override val sortName = "الاسم"
  override val sortSize = "الحجم"
  override val sortDate = "التاريخ"
  override val sortType = "النوع"
  override val showHidden = "إظهار المخفية"
  override val archiveTitle = "مركز الضغط وتقليل الحجم الشامل"
  override val archiveNameLabel = "اسم الأرشيف الناتج"
  override val archiveFormatLabel = "صيغة الضغط"
  override val compressionLevelLabel = "مستوى الضغط"
  override val levelStore = "0 • بدون ضغط (Store - فوري)"
  override val levelFast = "1-3 • سريع"
  override val levelBalanced = "4-6 • متوازن"
  override val levelUltra = "7-9 • أقصى ضغط (Ultra)"
  override val losslessModeTitle = "ضغط بدون فقدان بيانات (Lossless)"
  override val losslessModeDesc = "يحفظ 100% من البيانات والبيكسلات الأصلية دون أي نقص في الجودة."
  override val lossyModeTitle = "تقليل الجودة لتصغير الحجم (Lossy)"
  override val lossyModeDesc = "يقلل جودة الوسائط/المستندات بنسبة يحددها المستخدم لتقليص الحجم لجميع الصيغ."
  override val lossyWarningBanner = "تنبيه الجودة: هذا الخيار يقلل الجودة الأصلية للملف (صورة/فيديو/صوت/PDF) لتصغير الحجم بشكل ملحوظ ولا يمكن استعادة التفاصيل المفقودة."
  override val universalReducerTab = "تقليل الجودة والحجم (كل الصيغ)"
  override val universalReducerDesc = "يدعم تصغير حجم الصور، الفيديوهات، الصوتيات، ملفات PDF، وتقليص الأكواد والنصوص."
  override val imageQualityLabel = "جودة الصورة / الضغط"
  override val imageScaleLabel = "مقياس الأبعاد"
  override val videoResolutionLabel = "دقة الفيديو المستهدفة"
  override val audioBitrateLabel = "معدل بت الصوت"
  override val pdfDpiScaleLabel = "دقة صفحات PDF"
  override val estimatedSizeText: (String, String) -> String = { orig, est -> "الحجم الأصلي: $orig  ←  التقديري: $est" }
  override val passwordOptional = "كلمة مرور اختيارية (تشفير AES-256 لملفات ZIP)"
  override val startCompression = "بدء المعالجة"
  override val browseInsideArchive = "استعراض داخل الأرشيف"
  override val extractToPane = "استخراج للمكان المقابل"
  override val converterTitle = "محول الصيغ الشامل"
  override val videoToAudio = "فيديو ← صوت"
  override val imagesToPdf = "صور ← PDF"
  override val pdfToImages = "PDF ← صور"
  override val imageConverter = "تحويل الصور"
  override val textDataConverter = "نصوص وبيانات"
  override val archiveConverter = "تحويل الأرشيفات"
  override val pickFiles = "اختيار ملفات"
  override val sourceFileLabel = "الملف المصدر"
  override val targetFormatLabel = "الصيغة المستهدفة"
  override val startConversion = "تنفيذ التحويل"
  override val conversionHistory = "سجل التحويلات"
  override val conversionLosslessNote = "تحويل غير فاقد للجودة (Lossless): يحافظ على الدقة الكاملة."
  override val conversionLossyNote = "تحويل مع ضغط الجودة (Lossy): يقلل حجم الملف مقابل نسبة من الجودة."
  override val apkInspectorTitle = "محلل APK الداخلي"
  override val apkOverviewTab = "نظرة عامة"
  override val apkManifestTab = "Manifest (AXML)"
  override val apkDexTab = "كلاسات DEX"
  override val apkFilesTab = "الملفات الداخلية"
  override val apkPackageName = "معرف الحزمة"
  override val apkVersion = "الإصدار"
  override val apkSdkInfo = "إصدارات SDK"
  override val apkPermissionsCount = "الصلاحيات المطلوبة"
  override val apkSignature = "بصمة التوقيع"
  override val apkRepackage = "استخراج / إعادة تغليف ZIP"
  override val appManagerTitle = "مدير التطبيقات واستخراج APK"
  override val extractApkAction = "استخراج APK"
  override val storageAnalyzerTitle = "محلل المساحة والملفات"
  override val editorTitle = "مشغل ومحرر الأكواد (IDE)"
  override val saveFile = "حفظ"
  override val runCode = "تشغيل الكود"
  override val formatCode = "تنسيق"
  override val ideAssistant = "مساعد التطوير (IDE)"
  override val symbolsOutline = "هيكل الدوال والرموز"
  override val diagnosticsLabel = "فحص الأخطاء"
  override val consoleOutput = "مخرجات التشغيل (Console)"
  override val livePreview = "معاينة حية"
  override val undo = "تراجع"
  override val redo = "إعادة"
  override val findReplace = "بحث واستبدال"
  override val findHint = "ابحث عن..."
  override val replaceHint = "استبدال بـ..."
  override val replaceAll = "استبدال الكل"
  override val goToLine = "الانتقال لسطر"
  override val wordWrap = "التفاف الأسطر"
  override val hexMode = "وضع Hex"
  override val textMode = "وضع الكود"
  override val encodingLabel = "الترميز"
  override val savedSuccess = "تم حفظ الملف بنجاح"
  override val streamUrlTitle = "بث رابط فيديو ويب"
  override val streamUrlHint = "أدخل رابط فيديو مباشر (MP4 / MKV / M3U8 / MPD)"
  override val playStream = "تشغيل البث"
  override val enhancePicture = "تحسين الصورة والألوان"
  override val brightnessLabel = "السطوع"
  override val contrastLabel = "التباين"
  override val saturationLabel = "التشبع اللوني"
  override val subtitlesTitle = "الترجمة (Subtitles)"
  override val addLocalSubtitle = "إضافة ملف ترجمة (.srt / .vtt)"
  override val searchOnlineSubtitles = "بحث عن ترجمة عبر الإنترنت"
  override val subtitleStyleTitle = "تعديل مظهر وتوقيت الترجمة"
  override val subtitleSyncDelay = "تزامن الترجمة (ثانية)"
  override val subtitleFontSize = "حجم خط الترجمة"
  override val subtitleColor = "لون النص"
  override val audioDubbingTitle = "دبلجة الأصوات والمسارات"
  override val addDubAudioFile = "إضافة ملف صوت مدبلج"
  override val recordVoiceDub = "تسجيل دبلجة بصوتك"
  override val stopRecordingDub = "إيقاف وحفظ الدبلجة"
  override val ttsAutoDub = "دبلجة فورية للترجمة صوتياً (TTS)"
  override val originalVolume = "صوت الفيديو الأصلي"
  override val dubVolume = "صوت الدبلجة"
  override val screenCastTitle = "بث الشاشة والعرض الخارجي"
  override val castExternalDisplay = "البث على الشاشة الخارجية (صوت + ترجمة)"
  override val openSystemCast = "فتح بث الشاشة اللاسلكي (Cast / Miracast)"
  override val playbackSpeed = "السرعة"
  override val takeScreenshot = "لقطة شاشة"
  override val accessModeStandard = "قياسي"
  override val accessModeAllFiles = "جميع الملفات"
  override val accessModeShizuku = "Shizuku نشط"
  override val accessModeRoot = "Root نشط"
  override val shizukuTitle = "الوصول لملفات النظام وShizuku"
  override val shizukuStatusConnected = "متصل بـ Shizuku — صلاحيات النظام وAndroid/data مفعّلة"
  override val shizukuStatusNeedsPermission = "Shizuku يعمل — اضغط لمنح صلاحية التطبيق"
  override val shizukuStatusNotRunning = "خدمة Shizuku غير مشغلة حالياً"
  override val shizukuStatusNotInstalled = "تطبيق Shizuku غير مثبت على الجهاز"
  override val shizukuRequestPerm = "طلب صلاحية Shizuku"
  override val shizukuOpenApp = "فتح تطبيق Shizuku"
  override val devOptionsButton = "فتح خيارات المطور"
  override val wirelessDebugButton = "إعدادات التصحيح اللاسلكي"
  override val copyAdbCommand = "نسخ أمر تشغيل ADB"
  override val adbCommandCopied = "تم نسخ أمر ADB"
  override val safAndroidDataButton = "منح وصول SAF لمجلد Android/data"
  override val rootTestButton = "فحص وتفعيل صلاحيات Root (su)"
  override val rootAvailable = "صيغة Root متوفرة ومفعّلة"
  override val rootUnavailable = "الجهاز لا يحتوي على Root أو تم رفض الإذن"
  override val devGuideSteps =
    listOf(
      "1. افتح الإعدادات ← حول الهاتف ← اضغط 7 مرات على (رقم الإصدار) لتفعيل خيارات المطور.",
      "2. من خيارات المطور، فعّل (تصحيح أخطاء USB) أو (تصحيح الأخطاء اللاسلكي Wireless Debugging).",
      "3. شغّل خدمة Shizuku عبر الاقتران اللاسلكي أو أمر ADB، ثم ارجع هنا واضغط «طلب صلاحية Shizuku».",
      "4. بعد الربط، ستتمكن من فتح وتعديل Android/data وAndroid/obb وملفات النظام مباشرة.",
    )
  override val settingsTitle = "تخصيص الستايل والإعدادات"
  override val languageSection = "لغة الواجهة"
  override val layoutSection = "نمط العرض"
  override val paneCountSection = "عدد أماكن الملفات المفتوحة"
  override val paneCountHint = "اختر كم مكاناً للملفات تريد فتحه في نفس الوقت (1 إلى 4 أماكن مستقلة)."
  override val themePresetSection = "الستايل والثيمات الجاهزة"
  override val accentColorSection = "لون التمييز المخصص"
  override val editorSettingsSection = "إعدادات محرر ومشغل الأكواد"
  override val editorFontSize = "حجم خط المحرر"
  override val cancel = "إلغاء"
  override val confirm = "تأكيد"
  override val close = "إغلاق"
  override val itemsCount: (Int) -> String = { "$it عنصر" }
  override val backgroundTasks = "المهام الجارية"
  override val noTasksRunning = "لا توجد مهام نشطة حالياً"
  override val musicHubTitle = "مركز الموسيقى"
  override val tabNowPlaying = "المشغل"
  override val tabLyrics = "الكلمات المتحركة"
  override val tabFolders = "المجلدات"
  override val tabPlaylists = "قوائمي والترتيب"
  override val soundBoosterTitle = "مكبر الصوت والمعادل"
  override val loudnessBoostLabel = "تضخيم الصوت (Loudness Boost)"
  override val bassBoostLabel = "تعزيز الجهير (Bass Boost)"
  override val equalizerTitle = "معادل الترددات (5 نطاقات)"
  override val sleepTimerTitle = "مؤقت إطفاء الأغاني"
  override val sleepTimerOff = "إيقاف المؤقت"
  override val stopAfterTrack = "إيقاف بعد الأغنية الحالية"
  override val lyricsSearching = "جاري البحث عن كلمات الأغنية عبر الإنترنت..."
  override val lyricsNotFound = "لم يتم العثور على كلمات تلقائياً، جرب تعديل اسم الأغنية"
  override val searchLyricsOnline = "بحث عن الكلمات عبر الإنترنت"
  override val saveLyricsLocally = "حفظ الكلمات (.lrc) مع الأغنية"
  override val sortModeLabel = "الترتيب"
  override val sortShuffle = "عشوائي"
  override val sortAlphaAsc = "بالأحرف (أ ← ي)"
  override val sortAlphaDesc = "بالأحرف (ي ← أ)"
  override val sortNumeric = "بالأرقام / الترتيب"
  override val sortDateNewest = "الأحدث تاريخاً"
  override val sortCustomOrder = "ترتيبي الخاص"
  override val createPlaylist = "قائمة جديدة"
  override val addToPlaylist = "إضافة لقائمتي"
  override val customOrderHint = "استخدم الأسهم لإعادة ترتيب الأغاني كما تحب"
  override val playFolder = "تشغيل المجلد"
  override val noCoverBadge = "بدون غلاف"
  override val apkExtractManifest = "استخراج Manifest"
  override val apkCopyManifest = "نسخ XML"
  override val apkCopyPackage = "نسخ الحزمة"
  override val apkManifestSearchHint = "بحث داخل Manifest..."
  override val apkPermFilterHint = "تصفية الصلاحيات..."
  override val apkPermAll = "الكل"
  override val apkPermDangerous = "حساسة"
  override val apkPermNormal = "قياسية"
  override val apkComponentsLabel = "المكوّنات المعلنة"
  override val apkOpenExtractedManifest = "فتح في المحرر"
  override val apkExtractAllFiles = "فك محتوى APK"
  override val openWithExternalApp = "فتح بتطبيق آخر (خارجي)"
  override val openBuiltinViewer = "فتح بالمشغل المدمج"
  override val shareFileLabel = "مشاركة الملف"
  override val readAsTitle = "قراءة / فتح كـ..."
  override val readAsCode = "نص / كود برمجي"
  override val readAsHex = "سداسي عشري (Hex)"
  override val readAsImage = "صورة"
  override val readAsVideo = "فيديو"
  override val readAsAudio = "صوت / موسيقى"
  override val readAsPdf = "مستند PDF"
  override val readAsDatabase = "قاعدة بيانات SQLite"
  override val readAsArchive = "أرشيف مضغوط"
  override val readAsApk = "حزمة تطبيق APK"
  override val fileViewModeTitle = "وضع القراءة"
  override val viewModeNormal = "عادي"
  override val viewModeGallery = "معرض الصور"
  override val viewModeMusic = "مشغل الموسيقى"
  override val viewModeVideo = "معرض الفيديو"
  override val viewModeCodeDocs = "الأكواد والمستندات"
  override val dragSelectHint = "اضغط مطولاً على الأيقونة واسحب لتحديد مجموعة"
  override val downloadManagerTitle = "مركز التنزيل والتورنت"
  override val torrentMagnetTitle = "تحميل تورنت / Magnet"
  override val addDownloadUrl = "أدخل رابط التحميل أو صفحة الفيديو أو Magnet"
  override val resolveStreams = "استخراج الصيغ"
  override val downloadActiveStream = "تنزيل البث الحالي"
  override val drmProtectedNotice = "البثوث المحمية بـ DRM غير مدعومة (يُسمح بالبث المفتوح فقط)"
  override val detectOriginalFormat = "كشف الصيغة الأصلية (Magic Bytes)"
  override val detectedFormatLabel = "الصيغة الحقيقية المكتشفة"
  override val headerHexLabel = "توقيع البايتات الأولي"
  override val fixExtensionAction = "إصلاح الامتداد تلقائياً"
  override val longFilenameSection = "طريقة عرض الأسماء الطويلة"
  override val longFilenameEllipsis = "اختصار الوسط مع إظهار .الامتداد"
  override val longFilenameMultiLine = "التفاف لسطور جديدة (دون تصغير الخط)"
  override val recycleBinTitle = "سلة المهملات"
  override val recycleBinRetentionLabel = "مدة الحفظ التلقائي في السلة"
  override val deletePermanentOption = "حذف نهائي فوري (دون السلة)"
  override val moveToRecycleBin = "نقل إلى سلة المهملات"
  override val restoreAction = "استعادة"
  override val emptyTrashAction = "إفراغ السلة"
  override val vaultTitle = "الخزنة المشفرة (AES-256)"
  override val lockWithPassword = "قفل وتشفير برمز سري"
  override val unlockVault = "فتح القفل المشفر"
  override val recoveryKeyNotice = "احتفظ بمفتاح الاسترداد الاحتياطي في مكان آمن"
  override val enterPasswordOrKey = "أدخل الرمز السري أو مفتاح الاسترداد"
  override val cloudAccountsTitle = "الحسابات السحابية (WebDAV/FTP)"
  override val addCloudAccount = "ربط حساب سحابي"
  override val browseCloud = "تصفح في اللوحة"
  override val convertToSignedApk = "تحويل وتوقيع APK (v1+v2)"
  override val officeSuiteTitle = "حزمة الأوفيس وPDF"
  override val exportPdf = "تصدير PDF"
  override val aiPhotoStudioTitle = "استوديو الصور والذكاء الاصطناعي"
  override val separateSubjectAi = "فصل الشخصية بالذكاء الاصطناعي"
  override val colorMixerHsl = "ميكسر الألوان (8 قنوات HSL)"
  override val addImageOverlay = "إضافة صورة ودمج الطبقات"
  override val videoStudioTitle = "استوديو مونتاج الفيديو"
  override val trimRangeLabel = "قص النطاق الزمني"
  override val noiseReduction = "عزل الضوضاء وتحسين الصوت"
  override val reverbLabel = "الصدى المحيطي (Reverb)"
  override val vinylDiscMode = "القرص الدوار"
  override val batchPreviewTitle = "معاينة الأسماء بعد التعديل"
  override val adbPairAction = "فتح اقتران ADB اللاسلكي"
  override val smartBrowserSniffer = "متصفح التقاط الفيديو"
  override val webPlayerMode = "مشغل الويب المدمج"
  override val resolvingStreamLabel = "جاري تحليل واستخراج روابط البث..."
  override val capturedStreamsCount: (Int) -> String = { "تم التقاط $it رابط فيديو" }
  override val qualityLabel = "الجودة"
  override val conflictTitle = "تعارض في اسم الملف"
  override val conflictReplace = "استبدال (حذف القديم)"
  override val conflictKeepBoth = "إضافة رقم (الاحتفاظ بالاثنين)"
  override val conflictSkip = "تخطي (إبقاء القديم)"
  override val conflictApplyAll = "تطبيق على جميع الملفات المتبقية"
  override val sourceFileInfoLabel = "الملف الجديد"
  override val existingFileInfoLabel = "الملف الموجود حالياً"
  override val sharedLinkTitle = "رابط مشارك مع التطبيق"
  override val shareActionDownload = "تنزيل الفيديو / الملف"
  override val shareActionStream = "تشغيل البث المباشر الآن"
  override val shareActionBrowser = "فتح في متصفح الالتقاط الذكي"
  override val autoSubtitlesSection = "الترجمة وكلمات الأغاني التلقائية"
  override val autoSubtitlesToggle = "الوضع التلقائي (يعمل مع الفيديو والأغاني)"
  override val autoSubtitlesHint = "عند التفعيل: يبحث في مجلد الترجمة عن اسم الملف أو رقم الحلقة وإلا ينزّل تلقائياً. عند الإطفاء: يدوي فقط."
  override val subtitlesFolderLabel = "مجلد الترجمة الخاص"
  override val pickSubtitlesFolder = "تغيير مجلد الترجمة"
  override val subtitleLanguagesLabel = "لغات الترجمة المفضلة (بالترتيب)"
  override val subtitleLanguagesHint = "اختر لغة أو أكثر ورتّب أولوية التحميل التلقائي."
  override val rarNoteLabel = "ملاحظة: يتم استخراج جميع صيغ RAR4 وRAR5، بينما الضغط متاح لـ ZIP و7z وTAR."
  override val studio3dTitle = "استوديو 3D والمجسمات (Blender)"
  override val antivirusSection = "الحماية ومضاد الفيروسات"
  override val antivirusScanAction = "فحص بمضاد الفيروسات"
  override val antivirusAutoScanToggle = "فحص تلقائي للتنزيلات والملفات المستخرجة"
  override val antivirusAutoScanHint = "يفحص البصمات الضارة، انتحال الصيغ، صلاحيات APK الخطرة، وقنابل الضغط."
  override val autoBackupSection = "النسخ الاحتياطي المضغوط للتعديلات (.vortexbak)"
  override val autoBackupToggle = "حفظ نسخة أصلية مضغوطة قبل تعديل أي ملف"
  override val autoBackupHint = "ينشئ ملفاً بامتداد .vortexbak قبل الحفظ لتتمكن من إرجاع الملف لحالته الأصلية بضغطة زر."
  override val restoreOriginalAction = "إرجاع إلى الحالة الطبيعية"
  override val packagesManagerLabel = "المكاتب والحزم (pip / npm / Maven / Cargo)"
  override val buildMultiOsLabel = "بناء وتصدير تطبيق للأنظمة"
  override val companionServerLabel = "رابط خادم FastAPI الخارق (اختياري)"
  override val companionExportKit = "تصدير حزمة خادم FastAPI (Python)"
  override val castBackgroundNote = "يستمر البث في الخلفية أثناء استخدامك للهاتف"
  override val castToSmartTv = "بث للتلفزيون عبر Wi-Fi (مع الترجمة)"
  override val discoveredMediaTitle = "المعرض الذكي المكتشف تلقائياً"
}

open class BaseEnglishStrings : VortexStrings {
  override val appTitle = "Vortex Files"
  override val subtitle = "Pro File, Code Runner & Media Suite"
  override val dualPane = "Split Panes"
  override val singlePane = "Single"
  override val tabbedMode = "Tabs"
  override val leftPane = "Pane 1"
  override val rightPane = "Pane 2"
  override val paneLabel: (Int) -> String = { "Pane $it" }
  override val activePane = "Active"
  override val storageInternal = "Internal Storage"
  override val storageAppSpace = "App Workspace"
  override val storageRoot = "System Root (/)"
  override val storageSystem = "System (/system)"
  override val storageAndroidData = "Android/data"
  override val downloads = "Downloads"
  override val bookmarks = "Bookmarks"
  override val recentFiles = "Recent"
  override val converterHub = "Converter"
  override val systemAccess = "System & Shizuku"
  override val themeStudio = "Style & Settings"
  override val searchHint = "Search files or content..."
  override val deepSearch = "Deep Search"
  override val searchContentToggle = "Search inside text"
  override val searchRegexToggle = "Regex"
  override val copy = "Copy"
  override val cut = "Cut"
  override val paste = "Paste"
  override val copyToOtherPane = "Copy to Target Pane"
  override val moveToOtherPane = "Move to Target Pane"
  override val rename = "Rename"
  override val batchRename = "Batch Rename"
  override val delete = "Delete"
  override val newFolder = "New Folder"
  override val newFile = "New File"
  override val compress = "Compress / Shrink"
  override val extractHere = "Extract Here"
  override val convertFormat = "Convert Format"
  override val inspectApk = "Inspect APK Internals"
  override val openInEditor = "Code IDE & Runner"
  override val openAsHex = "Hex Viewer"
  override val properties = "Properties & Hashes"
  override val permissionsChmod = "Permissions (chmod)"
  override val compare = "Compare"
  override val selectAll = "Select All"
  override val clearSelection = "Clear"
  override val selectedCount: (Int) -> String = { "$it selected" }
  override val clipboardReady: (Int, Boolean) -> String = { count, isCut ->
    if (isCut) "Ready to move ($count items)" else "Ready to copy ($count items)"
  }
  override val emptyFolderTitle = "Folder is Empty"
  override val emptyFolderHint = "Create files, copy items from another pane, or extract an archive here."
  override val permissionNeededTitle = "All Files Access Required"
  override val permissionNeededBody =
    "Grant All Files Access to browse and edit device folders, or use Shizuku / SAF for Android/data and system paths."
  override val grantAllFilesAccess = "Grant All Files Access"
  override val openSystemGateway = "Setup Shizuku & Dev Mode"
  override val addBookmark = "Add Bookmark"
  override val removeBookmark = "Remove Bookmark"
  override val sortName = "Name"
  override val sortSize = "Size"
  override val sortDate = "Date"
  override val sortType = "Type"
  override val showHidden = "Show Hidden"
  override val archiveTitle = "Compression & Size Reducer Studio"
  override val archiveNameLabel = "Output Archive Name"
  override val archiveFormatLabel = "Archive Format"
  override val compressionLevelLabel = "Compression Level"
  override val levelStore = "0 • Store (No Compression)"
  override val levelFast = "1-3 • Fast"
  override val levelBalanced = "4-6 • Balanced"
  override val levelUltra = "7-9 • Ultra Max"
  override val losslessModeTitle = "Lossless Compression (Zero Data Loss)"
  override val losslessModeDesc = "Preserves 100% of bytes and pixels with zero quality degradation."
  override val lossyModeTitle = "Reduce Quality & Size (Lossy)"
  override val lossyModeDesc = "Shrinks Videos, Audio, Images, PDFs & Code with configurable quality reduction."
  override val lossyWarningBanner = "Quality Warning: Lossy size reduction trades original visual/audio/PDF fidelity to shrink file size significantly."
  override val universalReducerTab = "Quality Reducer (All Formats)"
  override val universalReducerDesc = "Shrinks Images, Videos (bitrate/resolution), Audio, PDFs, and minifies Code/Text."
  override val imageQualityLabel = "Quality"
  override val imageScaleLabel = "Resolution Scale"
  override val videoResolutionLabel = "Target Video Resolution"
  override val audioBitrateLabel = "Audio Bitrate"
  override val pdfDpiScaleLabel = "PDF Render Scale"
  override val estimatedSizeText: (String, String) -> String = { orig, est -> "Original: $orig  ->  Estimated: $est" }
  override val passwordOptional = "Optional Password (AES-256 for ZIP)"
  override val startCompression = "Start Processing"
  override val browseInsideArchive = "Browse Inside Archive"
  override val extractToPane = "Extract to Target Pane"
  override val converterTitle = "Universal Format Converter"
  override val videoToAudio = "Video -> Audio"
  override val imagesToPdf = "Images -> PDF"
  override val pdfToImages = "PDF -> Images"
  override val imageConverter = "Image Formats"
  override val textDataConverter = "Text & Data"
  override val archiveConverter = "Archive Formats"
  override val pickFiles = "Pick Files"
  override val sourceFileLabel = "Source File"
  override val targetFormatLabel = "Target Format"
  override val startConversion = "Convert Now"
  override val conversionHistory = "Conversion History"
  override val conversionLosslessNote = "Lossless conversion: full fidelity preserved."
  override val conversionLossyNote = "Lossy conversion: trades some visual/audio fidelity for smaller size."
  override val apkInspectorTitle = "APK Internal Inspector"
  override val apkOverviewTab = "Overview"
  override val apkManifestTab = "Manifest (AXML)"
  override val apkDexTab = "DEX Classes"
  override val apkFilesTab = "Internal Tree"
  override val apkPackageName = "Package ID"
  override val apkVersion = "Version"
  override val apkSdkInfo = "SDK Levels"
  override val apkPermissionsCount = "Declared Permissions"
  override val apkSignature = "Signing Digest"
  override val apkRepackage = "Extract / Repackage ZIP"
  override val appManagerTitle = "Installed Apps & APK Extractor"
  override val extractApkAction = "Extract APK"
  override val storageAnalyzerTitle = "Storage Analyzer"
  override val editorTitle = "Pro Code IDE & Runner"
  override val saveFile = "Save"
  override val runCode = "Run Code"
  override val formatCode = "Format"
  override val ideAssistant = "IDE Assistant"
  override val symbolsOutline = "Symbol Outline"
  override val diagnosticsLabel = "Diagnostics"
  override val consoleOutput = "Run Console"
  override val livePreview = "Live Preview"
  override val undo = "Undo"
  override val redo = "Redo"
  override val findReplace = "Find & Replace"
  override val findHint = "Find..."
  override val replaceHint = "Replace with..."
  override val replaceAll = "Replace All"
  override val goToLine = "Go to Line"
  override val wordWrap = "Word Wrap"
  override val hexMode = "Hex Mode"
  override val textMode = "Code Mode"
  override val encodingLabel = "Encoding"
  override val savedSuccess = "File saved successfully"
  override val streamUrlTitle = "Stream Web Video URL"
  override val streamUrlHint = "Enter video stream URL (MP4 / MKV / M3U8 / MPD)"
  override val playStream = "Play Stream"
  override val enhancePicture = "Picture Enhancement"
  override val brightnessLabel = "Brightness"
  override val contrastLabel = "Contrast"
  override val saturationLabel = "Saturation"
  override val subtitlesTitle = "Subtitles"
  override val addLocalSubtitle = "Load Local Subtitle (.srt / .vtt)"
  override val searchOnlineSubtitles = "Search Subtitles Online"
  override val subtitleStyleTitle = "Subtitle Style & Sync"
  override val subtitleSyncDelay = "Subtitle Sync Offset (sec)"
  override val subtitleFontSize = "Subtitle Font Size"
  override val subtitleColor = "Text Color"
  override val audioDubbingTitle = "Audio Dubbing & Tracks"
  override val addDubAudioFile = "Load External Dub Audio"
  override val recordVoiceDub = "Record Voice Dubbing"
  override val stopRecordingDub = "Stop & Apply Dub"
  override val ttsAutoDub = "Live TTS Subtitle Auto-Dub"
  override val originalVolume = "Original Video Volume"
  override val dubVolume = "Dub Track Volume"
  override val screenCastTitle = "Screen Cast & External Display"
  override val castExternalDisplay = "Cast to External Display (Audio + Subtitles)"
  override val openSystemCast = "Open Wireless Cast Settings"
  override val playbackSpeed = "Speed"
  override val takeScreenshot = "Snapshot"
  override val accessModeStandard = "Standard"
  override val accessModeAllFiles = "All Files"
  override val accessModeShizuku = "Shizuku Active"
  override val accessModeRoot = "Root Active"
  override val shizukuTitle = "System Root & Shizuku Gateway"
  override val shizukuStatusConnected = "Shizuku Connected — System & Android/data unlocked"
  override val shizukuStatusNeedsPermission = "Shizuku Running — Tap to grant permission"
  override val shizukuStatusNotRunning = "Shizuku Service Not Running"
  override val shizukuStatusNotInstalled = "Shizuku App Not Installed"
  override val shizukuRequestPerm = "Request Shizuku Permission"
  override val shizukuOpenApp = "Open Shizuku App"
  override val devOptionsButton = "Open Developer Options"
  override val wirelessDebugButton = "Wireless Debugging Settings"
  override val copyAdbCommand = "Copy ADB Start Command"
  override val adbCommandCopied = "ADB command copied"
  override val safAndroidDataButton = "Grant SAF Access to Android/data"
  override val rootTestButton = "Test & Enable Root Shell (su)"
  override val rootAvailable = "Root access available and active"
  override val rootUnavailable = "Root unavailable or permission denied"
  override val devGuideSteps =
    listOf(
      "1. Open Settings -> About Phone -> Tap Build Number 7 times to unlock Developer Options.",
      "2. Enable USB Debugging or Wireless Debugging inside Developer Options.",
      "3. Start Shizuku via Wireless Pairing or ADB, then return and tap 'Request Shizuku Permission'.",
      "4. Once authorized, browse and edit Android/data, Android/obb, and system directories directly.",
    )
  override val settingsTitle = "Style Studio & Preferences"
  override val languageSection = "Interface Language"
  override val layoutSection = "Display Mode"
  override val paneCountSection = "Number of Simultaneous File Panes"
  override val paneCountHint = "Choose how many independent file locations to keep open side-by-side (1 to 4 panes)."
  override val themePresetSection = "Theme Presets"
  override val accentColorSection = "Custom Accent Color"
  override val editorSettingsSection = "Code IDE & Editor Settings"
  override val editorFontSize = "Editor Font Size"
  override val cancel = "Cancel"
  override val confirm = "Confirm"
  override val close = "Close"
  override val itemsCount: (Int) -> String = { "$it items" }
  override val backgroundTasks = "Background Tasks"
  override val noTasksRunning = "No active tasks"
  override val musicHubTitle = "Music Hub"
  override val tabNowPlaying = "Player"
  override val tabLyrics = "Live Lyrics"
  override val tabFolders = "Folders"
  override val tabPlaylists = "Custom Order"
  override val soundBoosterTitle = "Sound Booster & EQ"
  override val loudnessBoostLabel = "Volume Amplifier (Loudness)"
  override val bassBoostLabel = "Bass Boost"
  override val equalizerTitle = "5-Band Equalizer"
  override val sleepTimerTitle = "Sleep Timer"
  override val sleepTimerOff = "Cancel Timer"
  override val stopAfterTrack = "Stop after current track"
  override val lyricsSearching = "Searching synced lyrics online..."
  override val lyricsNotFound = "No lyrics found automatically. Edit title/artist to search."
  override val searchLyricsOnline = "Search Lyrics Online"
  override val saveLyricsLocally = "Save .lrc Locally"
  override val sortModeLabel = "Sort"
  override val sortShuffle = "Shuffle"
  override val sortAlphaAsc = "A -> Z"
  override val sortAlphaDesc = "Z -> A"
  override val sortNumeric = "Numeric / Track #"
  override val sortDateNewest = "Newest Date"
  override val sortCustomOrder = "My Custom Order"
  override val createPlaylist = "New Playlist"
  override val addToPlaylist = "Add to Playlist"
  override val customOrderHint = "Use arrows to arrange your custom track order"
  override val playFolder = "Play Folder"
  override val noCoverBadge = "No Cover"
  override val apkExtractManifest = "Extract Manifest"
  override val apkCopyManifest = "Copy XML"
  override val apkCopyPackage = "Copy Package"
  override val apkManifestSearchHint = "Search inside manifest..."
  override val apkPermFilterHint = "Filter permissions..."
  override val apkPermAll = "All"
  override val apkPermDangerous = "Sensitive"
  override val apkPermNormal = "Standard"
  override val apkComponentsLabel = "Declared Components"
  override val apkOpenExtractedManifest = "Open in Editor"
  override val apkExtractAllFiles = "Unpack APK"
  override val openWithExternalApp = "Open With External App"
  override val openBuiltinViewer = "Open Built-in Viewer"
  override val shareFileLabel = "Share File"
  override val readAsTitle = "Read / Open As..."
  override val readAsCode = "Text / Source Code"
  override val readAsHex = "Hexadecimal (Hex)"
  override val readAsImage = "Image"
  override val readAsVideo = "Video"
  override val readAsAudio = "Audio / Music"
  override val readAsPdf = "PDF Document"
  override val readAsDatabase = "SQLite Database"
  override val readAsArchive = "Archive Container"
  override val readAsApk = "APK Package"
  override val fileViewModeTitle = "View Mode"
  override val viewModeNormal = "Normal"
  override val viewModeGallery = "Gallery"
  override val viewModeMusic = "Music Mode"
  override val viewModeVideo = "Videos"
  override val viewModeCodeDocs = "Code & Docs"
  override val dragSelectHint = "Long-press icon & drag to multi-select"
  override val downloadManagerTitle = "Downloads & Torrent Hub"
  override val torrentMagnetTitle = "Torrent / Magnet Download"
  override val addDownloadUrl = "Enter direct URL, video page, HLS/DASH, or magnet:"
  override val resolveStreams = "Extract Formats"
  override val downloadActiveStream = "Download Active Stream"
  override val drmProtectedNotice = "DRM-protected streams are blocked (non-DRM only)"
  override val detectOriginalFormat = "Detect True Format (Magic Bytes)"
  override val detectedFormatLabel = "Detected True Format"
  override val headerHexLabel = "Header Byte Signature"
  override val fixExtensionAction = "Repair Extension"
  override val longFilenameSection = "Long Filename Display Mode"
  override val longFilenameEllipsis = "Prefix + … + .Extension"
  override val longFilenameMultiLine = "Wrap to New Lines (Keep Font Size)"
  override val recycleBinTitle = "Recycle Bin"
  override val recycleBinRetentionLabel = "Auto-Purge Retention"
  override val deletePermanentOption = "Delete Permanently (Bypass Bin)"
  override val moveToRecycleBin = "Move to Recycle Bin"
  override val restoreAction = "Restore"
  override val emptyTrashAction = "Empty Bin"
  override val vaultTitle = "Encrypted Vault (AES-256)"
  override val lockWithPassword = "Lock & Encrypt with Password"
  override val unlockVault = "Unlock Encrypted Item"
  override val recoveryKeyNotice = "Save your backup recovery key securely"
  override val enterPasswordOrKey = "Enter password or recovery key"
  override val cloudAccountsTitle = "Cloud Accounts (WebDAV/FTP)"
  override val addCloudAccount = "Connect Cloud Account"
  override val browseCloud = "Browse in Pane"
  override val convertToSignedApk = "Convert & Sign APK (v1+v2)"
  override val officeSuiteTitle = "Office & PDF Suite"
  override val exportPdf = "Export PDF"
  override val aiPhotoStudioTitle = "Adobe HSL & AI Photo Studio"
  override val separateSubjectAi = "AI Subject Separation"
  override val colorMixerHsl = "8-Channel HSL Color Mixer"
  override val addImageOverlay = "Add Image Overlay"
  override val videoStudioTitle = "Video Editor Studio"
  override val trimRangeLabel = "Trim Timeline Range"
  override val noiseReduction = "Audio Denoise & Boost"
  override val reverbLabel = "Spatial Reverb"
  override val vinylDiscMode = "Vinyl Disc Mode"
  override val batchPreviewTitle = "Live Rename Preview"
  override val adbPairAction = "Wireless ADB Pairing"
  override val smartBrowserSniffer = "Smart Browser Sniffer"
  override val webPlayerMode = "Built-in Web Player"
  override val resolvingStreamLabel = "Extracting playable video streams..."
  override val capturedStreamsCount: (Int) -> String = { "Captured $it video stream(s)" }
  override val qualityLabel = "Quality"
  override val conflictTitle = "File Name Conflict"
  override val conflictReplace = "Replace (Delete Old)"
  override val conflictKeepBoth = "Keep Both (Add Number)"
  override val conflictSkip = "Skip (Don't Copy)"
  override val conflictApplyAll = "Apply to all remaining conflicts"
  override val sourceFileInfoLabel = "Incoming File"
  override val existingFileInfoLabel = "Existing File"
  override val sharedLinkTitle = "Shared Link Action"
  override val shareActionDownload = "Download Video / File"
  override val shareActionStream = "Stream Live Now"
  override val shareActionBrowser = "Capture in Smart Browser"
  override val autoSubtitlesSection = "Auto Subtitles & Song Lyrics"
  override val autoSubtitlesToggle = "Automatic Subtitles & Lyrics Mode"
  override val autoSubtitlesHint = "When ON: checks dedicated folder by title or episode number, or auto-downloads. When OFF: manual only."
  override val subtitlesFolderLabel = "Dedicated Subtitles Folder"
  override val pickSubtitlesFolder = "Change Folder"
  override val subtitleLanguagesLabel = "Preferred Languages (Priority Order)"
  override val subtitleLanguagesHint = "Select one or more languages and arrange auto-fetch priority."
  override val rarNoteLabel = "Note: All RAR4/RAR5 archives can be extracted; archive creation uses ZIP, 7z, or TAR."
  override val studio3dTitle = "3D Studio (Blender Style)"
  override val antivirusSection = "Antivirus & File Shield"
  override val antivirusScanAction = "Scan with Antivirus"
  override val antivirusAutoScanToggle = "Auto-scan downloaded & extracted files"
  override val antivirusAutoScanHint = "Checks threat signatures, spoofed extensions, risky APK permissions, and archive bombs."
  override val autoBackupSection = "Compressed Edit Snapshots (.vortexbak)"
  override val autoBackupToggle = "Create compressed .vortexbak before editing files"
  override val autoBackupHint = "Saves an immutable compressed snapshot so you can restore any edited file to its original state."
  override val restoreOriginalAction = "Restore to Original State"
  override val packagesManagerLabel = "Packages (pip / npm / Maven / Cargo)"
  override val buildMultiOsLabel = "Build Multi-OS App Bundle"
  override val companionServerLabel = "Companion FastAPI Server URL (Optional)"
  override val companionExportKit = "Export Python FastAPI Server Kit"
  override val castBackgroundNote = "Playback continues in background while using your phone"
  override val castToSmartTv = "Cast to Smart TV (Wi-Fi + Subtitles)"
  override val discoveredMediaTitle = "Smart Auto-Discovered Media"
}

val EnglishStrings: VortexStrings = BaseEnglishStrings()

val LocalAppStrings = staticCompositionLocalOf<VortexStrings> { ArabicStrings }
