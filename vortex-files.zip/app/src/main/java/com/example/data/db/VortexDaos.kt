package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BookmarkDao {
  @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
  fun observeBookmarks(): Flow<List<BookmarkEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(bookmark: BookmarkEntity)

  @Query("DELETE FROM bookmarks WHERE path = :path")
  suspend fun deleteByPath(path: String)
}

@Dao
interface RecentFileDao {
  @Query("SELECT * FROM recent_files ORDER BY openedAt DESC LIMIT 40")
  fun observeRecent(): Flow<List<RecentFileEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(item: RecentFileEntity)

  @Query("DELETE FROM recent_files")
  suspend fun clearAll()
}

@Dao
interface TaskHistoryDao {
  @Query("SELECT * FROM task_history ORDER BY createdAt DESC LIMIT 50")
  fun observeHistory(): Flow<List<TaskHistoryEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(entry: TaskHistoryEntity)

  @Query("DELETE FROM task_history")
  suspend fun clearAll()
}

@Dao
interface PlaylistDao {
  @Query("SELECT * FROM music_playlists ORDER BY createdAt DESC")
  fun observePlaylists(): Flow<List<PlaylistEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPlaylist(playlist: PlaylistEntity): Long

  @Query("DELETE FROM music_playlists WHERE id = :playlistId")
  suspend fun deletePlaylist(playlistId: Long)

  @Query("SELECT * FROM music_playlist_tracks WHERE playlistId = :playlistId ORDER BY sortOrder ASC")
  fun observePlaylistTracks(playlistId: Long): Flow<List<PlaylistTrackEntity>>

  @Query("SELECT * FROM music_playlist_tracks WHERE playlistId = :playlistId ORDER BY sortOrder ASC")
  suspend fun getPlaylistTracksOnce(playlistId: Long): List<PlaylistTrackEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTrack(track: PlaylistTrackEntity): Long

  @Update
  suspend fun updateTracks(tracks: List<PlaylistTrackEntity>)

  @Query("DELETE FROM music_playlist_tracks WHERE id = :trackId")
  suspend fun deleteTrack(trackId: Long)
}

@Dao
interface TrashDao {
  @Query("SELECT * FROM trash_entries ORDER BY deletedAt DESC")
  fun observeAll(): Flow<List<TrashEntryEntity>>

  @Query("SELECT * FROM trash_entries ORDER BY deletedAt DESC")
  suspend fun getAllOnce(): List<TrashEntryEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(entry: TrashEntryEntity): Long

  @Query("DELETE FROM trash_entries WHERE id = :id")
  suspend fun deleteById(id: Long)

  @Query("SELECT * FROM trash_entries WHERE expiresAt <= :nowMillis")
  suspend fun findExpired(nowMillis: Long): List<TrashEntryEntity>

  @Query("DELETE FROM trash_entries")
  suspend fun clearAll()
}

@Dao
interface DownloadDao {
  @Query("SELECT * FROM download_tasks ORDER BY createdAt DESC")
  fun observeAll(): Flow<List<DownloadTaskEntity>>

  @Query("SELECT * FROM download_tasks WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): DownloadTaskEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(task: DownloadTaskEntity): Long

  @Update
  suspend fun update(task: DownloadTaskEntity)

  @Query("DELETE FROM download_tasks WHERE id = :id")
  suspend fun deleteById(id: Long)

  @Query("DELETE FROM download_tasks WHERE status IN ('COMPLETED', 'CANCELLED', 'FAILED')")
  suspend fun clearFinished()
}

@Dao
interface VaultDao {
  @Query("SELECT * FROM vault_entries ORDER BY lockedAt DESC")
  fun observeAll(): Flow<List<VaultEntryEntity>>

  @Query("SELECT * FROM vault_entries WHERE lockedPath = :lockedPath LIMIT 1")
  suspend fun findByLockedPath(lockedPath: String): VaultEntryEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(entry: VaultEntryEntity): Long

  @Query("DELETE FROM vault_entries WHERE id = :id")
  suspend fun deleteById(id: Long)

  @Query("DELETE FROM vault_entries WHERE lockedPath = :lockedPath")
  suspend fun deleteByLockedPath(lockedPath: String)
}

@Dao
interface CloudAccountDao {
  @Query("SELECT * FROM cloud_accounts ORDER BY createdAt DESC")
  fun observeAll(): Flow<List<CloudAccountEntity>>

  @Query("SELECT * FROM cloud_accounts WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): CloudAccountEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(account: CloudAccountEntity): Long

  @Update
  suspend fun update(account: CloudAccountEntity)

  @Query("DELETE FROM cloud_accounts WHERE id = :id")
  suspend fun deleteById(id: Long)
}
