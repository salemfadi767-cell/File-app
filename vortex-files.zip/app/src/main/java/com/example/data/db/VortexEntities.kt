package com.example.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
  @PrimaryKey val path: String,
  val label: String,
  val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "recent_files")
data class RecentFileEntity(
  @PrimaryKey val path: String,
  val name: String,
  val extension: String,
  val sizeBytes: Long,
  val openedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "task_history")
data class TaskHistoryEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val category: String,
  val sourcePath: String,
  val outputPath: String,
  val details: String,
  val success: Boolean,
  val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "music_playlists")
data class PlaylistEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
  tableName = "music_playlist_tracks",
  foreignKeys = [
    ForeignKey(
      entity = PlaylistEntity::class,
      parentColumns = ["id"],
      childColumns = ["playlistId"],
      onDelete = ForeignKey.CASCADE,
    )
  ],
  indices = [Index("playlistId")],
)
data class PlaylistTrackEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val playlistId: Long,
  val trackPath: String,
  val title: String,
  val artist: String,
  val durationMs: Long,
  val sortOrder: Int,
)

@Entity(tableName = "trash_entries")
data class TrashEntryEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val originalPath: String,
  val originalName: String,
  val trashPath: String,
  val isDirectory: Boolean,
  val sizeBytes: Long,
  val deletedAt: Long,
  val expiresAt: Long,
)

@Entity(tableName = "download_tasks")
data class DownloadTaskEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val sourceUrl: String,
  val fileName: String,
  val destinationPath: String,
  val downloadType: String, // HTTP, HLS, DASH, VIDEO_PAGE, TORRENT, MAGNET
  val status: String, // QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED, CANCELLED
  val bytesDownloaded: Long = 0L,
  val totalBytes: Long = 0L,
  val speedBytesPerSec: Long = 0L,
  val peersInfo: String = "",
  val errorMessage: String? = null,
  val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "vault_entries")
data class VaultEntryEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val originalPath: String,
  val displayName: String,
  val lockedPath: String,
  val wasDirectory: Boolean,
  val originalSizeBytes: Long,
  val recoveryKeyHash: String,
  val lockedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "cloud_accounts")
data class CloudAccountEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val label: String,
  val protocol: String, // WEBDAV, NEXTCLOUD, OWNCLOUD, FTP, HTTP_TOKEN
  val hostUrl: String,
  val username: String,
  val secretOrToken: String,
  val basePath: String = "/",
  val createdAt: Long = System.currentTimeMillis(),
)
