package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [
    BookmarkEntity::class,
    RecentFileEntity::class,
    TaskHistoryEntity::class,
    PlaylistEntity::class,
    PlaylistTrackEntity::class,
    TrashEntryEntity::class,
    DownloadTaskEntity::class,
    VaultEntryEntity::class,
    CloudAccountEntity::class,
  ],
  version = 3,
  exportSchema = false,
)
abstract class VortexDatabase : RoomDatabase() {
  abstract fun bookmarkDao(): BookmarkDao

  abstract fun recentFileDao(): RecentFileDao

  abstract fun taskHistoryDao(): TaskHistoryDao

  abstract fun playlistDao(): PlaylistDao

  abstract fun trashDao(): TrashDao

  abstract fun downloadDao(): DownloadDao

  abstract fun vaultDao(): VaultDao

  abstract fun cloudAccountDao(): CloudAccountDao

  companion object {
    @Volatile private var INSTANCE: VortexDatabase? = null

    fun getInstance(context: Context): VortexDatabase =
      INSTANCE
        ?: synchronized(this) {
          INSTANCE
            ?: Room.databaseBuilder(
                context.applicationContext,
                VortexDatabase::class.java,
                "vortex_files.db",
              )
              .fallbackToDestructiveMigration(dropAllTables = true)
              .build()
              .also { INSTANCE = it }
        }
  }
}
