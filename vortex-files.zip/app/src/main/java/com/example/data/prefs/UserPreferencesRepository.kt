package com.example.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.i18n.AppLanguage
import com.example.ui.theme.AccentStyle
import com.example.ui.theme.ThemePreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "vortex_prefs")

enum class LayoutMode(val id: String) {
  DUAL_PANE("dual_pane"),
  SINGLE_PANE("single_pane"),
  TABBED("tabbed"),
}

enum class SortField(val id: String) {
  NAME("name"),
  SIZE("size"),
  DATE("date"),
  TYPE("type"),
}

enum class LongFilenameMode(val id: String) {
  MIDDLE_ELLIPSIS("middle_ellipsis"),
  MULTI_LINE("multi_line"),
}

data class UserPreferences(
  val language: AppLanguage = AppLanguage.AR,
  val themePreset: ThemePreset = ThemePreset.CYBER_EMERALD,
  val accentStyle: AccentStyle = AccentStyle.DEFAULT,
  val layoutMode: LayoutMode = LayoutMode.DUAL_PANE,
  val paneCount: Int = 2,
  val showHiddenFiles: Boolean = true,
  val sortField: SortField = SortField.NAME,
  val sortAscending: Boolean = true,
  val editorFontSizeSp: Int = 13,
  val editorWordWrap: Boolean = false,
  val rootModeEnabled: Boolean = false,
  val longFilenameMode: LongFilenameMode = LongFilenameMode.MIDDLE_ELLIPSIS,
  val trashRetentionDays: Int = 7,
  val autoSubtitlesEnabled: Boolean = true,
  val subtitlesFolderPath: String = "",
  val subtitleLanguages: List<String> = listOf("ar", "en"),
  val autoBackupOnEditEnabled: Boolean = false,
  val antivirusAutoScanEnabled: Boolean = true,
  val companionDownloaderUrl: String = "",
)

class UserPreferencesRepository(private val context: Context) {
  private object Keys {
    val LANGUAGE = stringPreferencesKey("language")
    val THEME_PRESET = stringPreferencesKey("theme_preset")
    val ACCENT_STYLE = stringPreferencesKey("accent_style")
    val LAYOUT_MODE = stringPreferencesKey("layout_mode")
    val PANE_COUNT = intPreferencesKey("pane_count")
    val SHOW_HIDDEN = booleanPreferencesKey("show_hidden")
    val SORT_FIELD = stringPreferencesKey("sort_field")
    val SORT_ASC = booleanPreferencesKey("sort_asc")
    val EDITOR_FONT_SIZE = intPreferencesKey("editor_font_size")
    val EDITOR_WORD_WRAP = booleanPreferencesKey("editor_word_wrap")
    val ROOT_ENABLED = booleanPreferencesKey("root_enabled")
    val LONG_FILENAME_MODE = stringPreferencesKey("long_filename_mode")
    val TRASH_RETENTION_DAYS = intPreferencesKey("trash_retention_days")
    val AUTO_SUBTITLES = booleanPreferencesKey("auto_subtitles_enabled")
    val SUBTITLES_FOLDER = stringPreferencesKey("subtitles_folder_path")
    val SUBTITLE_LANGUAGES = stringPreferencesKey("subtitle_languages")
    val AUTO_BACKUP_ON_EDIT = booleanPreferencesKey("auto_backup_on_edit")
    val ANTIVIRUS_AUTO_SCAN = booleanPreferencesKey("antivirus_auto_scan")
    val COMPANION_DOWNLOADER_URL = stringPreferencesKey("companion_downloader_url")
  }

  val preferences: Flow<UserPreferences> =
    context.dataStore.data.map { prefs ->
      val rawLangs = prefs[Keys.SUBTITLE_LANGUAGES]
        ?.split(',')
        ?.map { it.trim().lowercase() }
        ?.filter { it.isNotBlank() }
        ?.distinct()
        ?.takeIf { it.isNotEmpty() }
        ?: listOf("ar", "en")
      UserPreferences(
        language =
          AppLanguage.entries.find { it.code == prefs[Keys.LANGUAGE] } ?: AppLanguage.AR,
        themePreset =
          ThemePreset.entries.find { it.id == prefs[Keys.THEME_PRESET] }
            ?: ThemePreset.CYBER_EMERALD,
        accentStyle =
          AccentStyle.entries.find { it.id == prefs[Keys.ACCENT_STYLE] } ?: AccentStyle.DEFAULT,
        layoutMode =
          LayoutMode.entries.find { it.id == prefs[Keys.LAYOUT_MODE] } ?: LayoutMode.DUAL_PANE,
        paneCount = (prefs[Keys.PANE_COUNT] ?: 2).coerceIn(1, 4),
        showHiddenFiles = prefs[Keys.SHOW_HIDDEN] ?: true,
        sortField = SortField.entries.find { it.id == prefs[Keys.SORT_FIELD] } ?: SortField.NAME,
        sortAscending = prefs[Keys.SORT_ASC] ?: true,
        editorFontSizeSp = prefs[Keys.EDITOR_FONT_SIZE] ?: 13,
        editorWordWrap = prefs[Keys.EDITOR_WORD_WRAP] ?: false,
        rootModeEnabled = prefs[Keys.ROOT_ENABLED] ?: false,
        longFilenameMode =
          LongFilenameMode.entries.find { it.id == prefs[Keys.LONG_FILENAME_MODE] }
            ?: LongFilenameMode.MIDDLE_ELLIPSIS,
        trashRetentionDays = (prefs[Keys.TRASH_RETENTION_DAYS] ?: 7).coerceIn(0, 90),
        autoSubtitlesEnabled = prefs[Keys.AUTO_SUBTITLES] ?: true,
        subtitlesFolderPath = prefs[Keys.SUBTITLES_FOLDER].orEmpty(),
        subtitleLanguages = rawLangs,
        autoBackupOnEditEnabled = prefs[Keys.AUTO_BACKUP_ON_EDIT] ?: false,
        antivirusAutoScanEnabled = prefs[Keys.ANTIVIRUS_AUTO_SCAN] ?: true,
        companionDownloaderUrl = prefs[Keys.COMPANION_DOWNLOADER_URL].orEmpty(),
      )
    }

  suspend fun setLanguage(language: AppLanguage) {
    context.dataStore.edit { it[Keys.LANGUAGE] = language.code }
  }

  suspend fun setThemePreset(preset: ThemePreset) {
    context.dataStore.edit { it[Keys.THEME_PRESET] = preset.id }
  }

  suspend fun setAccentStyle(accent: AccentStyle) {
    context.dataStore.edit { it[Keys.ACCENT_STYLE] = accent.id }
  }

  suspend fun setLayoutMode(mode: LayoutMode) {
    context.dataStore.edit { it[Keys.LAYOUT_MODE] = mode.id }
  }

  suspend fun setPaneCount(count: Int) {
    val clamped = count.coerceIn(1, 4)
    context.dataStore.edit {
      it[Keys.PANE_COUNT] = clamped
      it[Keys.LAYOUT_MODE] =
        if (clamped == 1) LayoutMode.SINGLE_PANE.id else LayoutMode.DUAL_PANE.id
    }
  }

  suspend fun setShowHiddenFiles(show: Boolean) {
    context.dataStore.edit { it[Keys.SHOW_HIDDEN] = show }
  }

  suspend fun setSort(field: SortField, ascending: Boolean) {
    context.dataStore.edit {
      it[Keys.SORT_FIELD] = field.id
      it[Keys.SORT_ASC] = ascending
    }
  }

  suspend fun setEditorFontSize(sizeSp: Int) {
    context.dataStore.edit { it[Keys.EDITOR_FONT_SIZE] = sizeSp.coerceIn(10, 24) }
  }

  suspend fun setEditorWordWrap(wrap: Boolean) {
    context.dataStore.edit { it[Keys.EDITOR_WORD_WRAP] = wrap }
  }

  suspend fun setRootModeEnabled(enabled: Boolean) {
    context.dataStore.edit { it[Keys.ROOT_ENABLED] = enabled }
  }

  suspend fun setLongFilenameMode(mode: LongFilenameMode) {
    context.dataStore.edit { it[Keys.LONG_FILENAME_MODE] = mode.id }
  }

  suspend fun setTrashRetentionDays(days: Int) {
    context.dataStore.edit { it[Keys.TRASH_RETENTION_DAYS] = days.coerceIn(0, 90) }
  }

  suspend fun setAutoSubtitlesEnabled(enabled: Boolean) {
    context.dataStore.edit { it[Keys.AUTO_SUBTITLES] = enabled }
  }

  suspend fun setSubtitlesFolderPath(path: String) {
    context.dataStore.edit { it[Keys.SUBTITLES_FOLDER] = path.trim() }
  }

  suspend fun setSubtitleLanguages(languages: List<String>) {
    val cleaned = languages.map { it.trim().lowercase() }.filter { it.isNotBlank() }.distinct()
    context.dataStore.edit {
      it[Keys.SUBTITLE_LANGUAGES] = (if (cleaned.isEmpty()) listOf("ar") else cleaned).joinToString(",")
    }
  }

  suspend fun setAutoBackupOnEditEnabled(enabled: Boolean) {
    context.dataStore.edit { it[Keys.AUTO_BACKUP_ON_EDIT] = enabled }
  }

  suspend fun setAntivirusAutoScanEnabled(enabled: Boolean) {
    context.dataStore.edit { it[Keys.ANTIVIRUS_AUTO_SCAN] = enabled }
  }

  suspend fun setCompanionDownloaderUrl(url: String) {
    context.dataStore.edit { it[Keys.COMPANION_DOWNLOADER_URL] = url.trim().trimEnd('/') }
  }
}

fun formatMiddleEllipsisFilename(name: String, maxChars: Int = 26): String {
  if (name.length <= maxChars || maxChars < 10) return name
  val dotIdx = name.lastIndexOf('.')
  val hasExt = dotIdx in 1 until name.lastIndex && (name.length - dotIdx) <= 8
  val ext = if (hasExt) name.substring(dotIdx) else ""
  val stem = if (hasExt) name.substring(0, dotIdx) else name
  val keepTail = if (hasExt) "" else stem.takeLast(4)
  val budget = (maxChars - ext.length - keepTail.length - 1).coerceAtLeast(4)
  return "${stem.take(budget)}…$keepTail$ext"
}
