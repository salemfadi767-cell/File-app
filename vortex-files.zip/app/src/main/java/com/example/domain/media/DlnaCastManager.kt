package com.example.domain.media

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.wifi.WifiManager
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

data class DlnaDevice(
  val usn: String,
  val friendlyName: String,
  val avTransportControlUrl: String,
  val hostAddress: String,
)

object DlnaCastManager {
  private val httpClient =
    OkHttpClient.Builder()
      .connectTimeout(6, TimeUnit.SECONDS)
      .readTimeout(10, TimeUnit.SECONDS)
      .build()

  private val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private var serverSocket: ServerSocket? = null
  private val serverRunning = AtomicBoolean(false)

  @Volatile
  private var servedVideoFile: File? = null
  @Volatile
  private var servedSubtitleFile: File? = null
  @Volatile
  private var servedRemoteStreamUrl: String? = null
  @Volatile
  var serverPort: Int = 0
    private set

  fun ensureServerStarted(videoPath: String, subtitlePath: String?): Pair<String, String?>? {
    val localIp = findLanIpv4Address() ?: return null
    if (videoPath.startsWith("http://", true) || videoPath.startsWith("https://", true)) {
      servedVideoFile = null
      servedRemoteStreamUrl = videoPath
    } else {
      val f = File(videoPath)
      if (!f.exists() || !f.isFile) return null
      servedVideoFile = f
      servedRemoteStreamUrl = null
    }
    servedSubtitleFile = subtitlePath?.let { File(it) }?.takeIf { it.exists() && it.isFile }

    if (!serverRunning.get()) {
      synchronized(this) {
        if (!serverRunning.get()) {
          val ss = ServerSocket(0)
          serverSocket = ss
          serverPort = ss.localPort
          serverRunning.set(true)
          serverScope.launch { acceptLoop(ss) }
        }
      }
    }

    val mediaUrl =
      servedRemoteStreamUrl
        ?: "http://$localIp:$serverPort/video.${servedVideoFile?.extension?.ifBlank { "mp4" } ?: "mp4"}"
    val subUrl =
      servedSubtitleFile?.let { sub ->
        "http://$localIp:$serverPort/subtitle.${sub.extension.ifBlank { "srt" }}"
      }
    return mediaUrl to subUrl
  }

  fun stopServer() {
    serverRunning.set(false)
    runCatching { serverSocket?.close() }
    serverSocket = null
    serverPort = 0
  }

  private fun acceptLoop(ss: ServerSocket) {
    while (serverRunning.get() && !ss.isClosed) {
      val client = runCatching { ss.accept() }.getOrNull() ?: break
      serverScope.launch { handleHttpClient(client) }
    }
  }

  private fun handleHttpClient(socket: Socket) {
    socket.use { sock ->
      runCatching {
        val reader = BufferedReader(InputStreamReader(sock.getInputStream()))
        val requestLine = reader.readLine() ?: return
        var rangeHeader: String? = null
        while (true) {
          val line = reader.readLine() ?: break
          if (line.isBlank()) break
          if (line.startsWith("Range:", ignoreCase = true)) {
            rangeHeader = line.substringAfter(':').trim()
          }
        }
        val path = requestLine.split(' ').getOrNull(1).orEmpty()
        val out = sock.getOutputStream()

        if (path.startsWith("/subtitle")) {
          val subFile = servedSubtitleFile
          if (subFile == null || !subFile.exists()) {
            writeStatus(out, "404 Not Found", "text/plain", "No subtitle".toByteArray())
          } else {
            val bytes = subFile.readBytes()
            val mime = if (subFile.extension.equals("vtt", true)) "text/vtt; charset=utf-8" else "application/x-subrip; charset=utf-8"
            writeStatus(out, "200 OK", mime, bytes)
          }
          return
        }

        val videoFile = servedVideoFile
        if (videoFile == null || !videoFile.exists()) {
          writeStatus(out, "404 Not Found", "text/plain", "Video unavailable".toByteArray())
          return
        }
        serveFileWithRange(videoFile, rangeHeader, out)
      }
    }
  }

  private fun writeStatus(out: OutputStream, status: String, contentType: String, body: ByteArray) {
    val hdr =
      "HTTP/1.1 $status\r\n" +
        "Content-Type: $contentType\r\n" +
        "Content-Length: ${body.size}\r\n" +
        "Access-Control-Allow-Origin: *\r\n" +
        "Connection: close\r\n\r\n"
    out.write(hdr.toByteArray())
    out.write(body)
    out.flush()
  }

  private fun serveFileWithRange(file: File, rangeHeader: String?, out: OutputStream) {
    val totalLen = file.length()
    val mime = when (file.extension.lowercase()) {
      "mkv" -> "video/x-matroska"
      "webm" -> "video/webm"
      "mov" -> "video/quicktime"
      else -> "video/mp4"
    }
    var start = 0L
    var end = (totalLen - 1).coerceAtLeast(0L)
    var isPartial = false
    if (rangeHeader != null && rangeHeader.startsWith("bytes=")) {
      val spec = rangeHeader.removePrefix("bytes=").trim()
      val parts = spec.split('-')
      start = parts.getOrNull(0)?.toLongOrNull() ?: 0L
      val parsedEnd = parts.getOrNull(1)?.toLongOrNull()
      if (parsedEnd != null && parsedEnd < totalLen) end = parsedEnd
      isPartial = true
    }
    val contentLen = (end - start + 1).coerceAtLeast(0L)
    val header = buildString {
      append(if (isPartial) "HTTP/1.1 206 Partial Content\r\n" else "HTTP/1.1 200 OK\r\n")
      append("Content-Type: $mime\r\n")
      append("Accept-Ranges: bytes\r\n")
      append("Content-Length: $contentLen\r\n")
      if (isPartial) append("Content-Range: bytes $start-$end/$totalLen\r\n")
      append("transferMode.dlna.org: Streaming\r\n")
      append("Access-Control-Allow-Origin: *\r\n")
      append("Connection: close\r\n\r\n")
    }
    out.write(header.toByteArray())
    RandomAccessFile(file, "r").use { raf ->
      raf.seek(start)
      val buf = ByteArray(64 * 1024)
      var remaining = contentLen
      while (remaining > 0) {
        val r = raf.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
        if (r <= 0) break
        out.write(buf, 0, r)
        remaining -= r
      }
    }
    out.flush()
  }

  suspend fun discoverTvRenderers(context: Context, timeoutMs: Int = 2400): List<DlnaDevice> =
    withContext(Dispatchers.IO) {
      val wifiMgr = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
      val lock = runCatching { wifiMgr?.createMulticastLock("vortex_ssdp")?.apply { acquire() } }.getOrNull()
      val foundLocations = LinkedHashSet<String>()
      try {
        val msg =
          "M-SEARCH * HTTP/1.1\r\n" +
            "HOST: 239.255.255.250:1900\r\n" +
            "MAN: \"ssdp:discover\"\r\n" +
            "MX: 2\r\n" +
            "ST: urn:schemas-upnp-org:service:AVTransport:1\r\n\r\n"
        DatagramSocket().use { sock ->
          sock.soTimeout = timeoutMs
          val group = InetAddress.getByName("239.255.255.250")
          val data = msg.toByteArray()
          sock.send(DatagramPacket(data, data.size, group, 1900))
          val deadline = System.currentTimeMillis() + timeoutMs
          val recvBuf = ByteArray(4096)
          while (System.currentTimeMillis() < deadline) {
            val pkt = DatagramPacket(recvBuf, recvBuf.size)
            val ok = runCatching { sock.receive(pkt); true }.getOrDefault(false)
            if (!ok) break
            val text = String(pkt.data, 0, pkt.length)
            val loc = text.lines()
              .firstOrNull { it.startsWith("LOCATION:", ignoreCase = true) }
              ?.substringAfter(':')
              ?.trim()
            if (!loc.isNullOrBlank()) foundLocations.add(loc)
          }
        }
      } catch (_: Throwable) {
      } finally {
        runCatching { lock?.release() }
      }

      foundLocations.mapNotNull { locUrl -> fetchDeviceMetadata(locUrl) }
    }

  private fun fetchDeviceMetadata(locationUrl: String): DlnaDevice? {
    return runCatching {
      val req = Request.Builder().url(locationUrl).get().build()
      val xml = httpClient.newCall(req).execute().use { if (it.isSuccessful) it.body?.string().orEmpty() else "" }
      if (xml.isBlank()) return null
      val friendly = Regex("""<friendlyName>([^<]+)</friendlyName>""").find(xml)?.groupValues?.getOrNull(1) ?: "Smart TV"
      val avBlock = Regex("""urn:schemas-upnp-org:service:AVTransport:1[\s\S]*?<controlURL>([^<]+)</controlURL>""")
        .find(xml)?.groupValues?.getOrNull(1) ?: return null
      val parsed = URL(locationUrl)
      val base = "${parsed.protocol}://${parsed.host}:${if (parsed.port > 0) parsed.port else 80}"
      val controlUrl = if (avBlock.startsWith("http", true)) avBlock else "$base/${avBlock.trimStart('/')}"
      DlnaDevice(
        usn = locationUrl,
        friendlyName = friendly,
        avTransportControlUrl = controlUrl,
        hostAddress = parsed.host,
      )
    }.getOrNull()
  }

  suspend fun castVideoToDevice(
    device: DlnaDevice,
    title: String,
    mediaUrl: String,
    subtitleUrl: String?,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val escapedUrl = escapeXml(mediaUrl)
        val escapedTitle = escapeXml(title)
        val captionTag =
          if (!subtitleUrl.isNullOrBlank()) {
            val subEsc = escapeXml(subtitleUrl)
            val subType = if (subtitleUrl.endsWith(".vtt", true)) "vtt" else "srt"
            "<sec:CaptionInfoEx sec:type=\"$subType\">$subEsc</sec:CaptionInfoEx>" +
              "<res protocolInfo=\"http-get:*:text/$subType:*\">$subEsc</res>"
          } else ""
        val didl =
          "&lt;DIDL-Lite xmlns=&quot;urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/&quot; " +
            "xmlns:dc=&quot;http://purl.org/dc/elements/1.1/&quot; " +
            "xmlns:upnp=&quot;urn:schemas-upnp-org:metadata-1-0/upnp/&quot; " +
            "xmlns:sec=&quot;http://www.sec.co.kr/&quot;&gt;" +
            "&lt;item id=&quot;0&quot; parentID=&quot;-1&quot; restricted=&quot;1&quot;&gt;" +
            "&lt;dc:title&gt;$escapedTitle&lt;/dc:title&gt;" +
            "&lt;upnp:class&gt;object.item.videoItem&lt;/upnp:class&gt;" +
            "&lt;res protocolInfo=&quot;http-get:*:video/mp4:*&quot;&gt;$escapedUrl&lt;/res&gt;" +
            escapeXml(captionTag) +
            "&lt;/item&gt;&lt;/DIDL-Lite&gt;"

        val setUriBody =
          """<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
  <s:Body>
    <u:SetAVTransportURI xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
      <InstanceID>0</InstanceID>
      <CurrentURI>$escapedUrl</CurrentURI>
      <CurrentURIMetaData>$didl</CurrentURIMetaData>
    </u:SetAVTransportURI>
  </s:Body>
</s:Envelope>"""
        sendSoap(device.avTransportControlUrl, "SetAVTransportURI", setUriBody)

        val playBody =
          """<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
  <s:Body>
    <u:Play xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
      <InstanceID>0</InstanceID>
      <Speed>1</Speed>
    </u:Play>
  </s:Body>
</s:Envelope>"""
        sendSoap(device.avTransportControlUrl, "Play", playBody)
      }
    }

  suspend fun stopDevice(device: DlnaDevice): Boolean =
    withContext(Dispatchers.IO) {
      runCatching {
        val stopBody =
          """<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
  <s:Body>
    <u:Stop xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
      <InstanceID>0</InstanceID>
    </u:Stop>
  </s:Body>
</s:Envelope>"""
        sendSoap(device.avTransportControlUrl, "Stop", stopBody)
        true
      }.getOrDefault(false)
    }

  private fun sendSoap(controlUrl: String, action: String, soapXml: String) {
    val req =
      Request.Builder()
        .url(controlUrl)
        .header("SOAPACTION", "\"urn:schemas-upnp-org:service:AVTransport:1#$action\"")
        .post(soapXml.toRequestBody("text/xml; charset=\"utf-8\"".toMediaType()))
        .build()
    httpClient.newCall(req).execute().use { resp ->
      if (!resp.isSuccessful) throw IllegalStateException("DLNA $action failed (${resp.code})")
    }
  }

  private fun escapeXml(input: String): String =
    input
      .replace("&", "&amp;")
      .replace("<", "&lt;")
      .replace(">", "&gt;")
      .replace("\"", "&quot;")

  private fun findLanIpv4Address(): String? {
    return runCatching {
      val interfaces = NetworkInterface.getNetworkInterfaces()
      while (interfaces.hasMoreElements()) {
        val nif = interfaces.nextElement()
        if (!nif.isUp || nif.isLoopback) continue
        val addrs = nif.inetAddresses
        while (addrs.hasMoreElements()) {
          val addr = addrs.nextElement()
          if (addr is Inet4Address && !addr.isLoopbackAddress) {
            return addr.hostAddress
          }
        }
      }
      null
    }.getOrNull()
  }
}
