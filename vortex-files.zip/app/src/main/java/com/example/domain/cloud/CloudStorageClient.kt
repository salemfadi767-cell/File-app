package com.example.domain.cloud

import com.example.data.db.CloudAccountDao
import com.example.data.db.CloudAccountEntity
import com.example.domain.fs.FileSourceType
import com.example.domain.fs.VirtualFileNode
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.PrintWriter
import java.io.StringReader
import java.net.Socket
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

enum class CloudProtocol(
  val id: String,
  val displayName: String,
  val defaultHost: String = "https://",
  val usesBearerToken: Boolean = false,
) {
  ONEDRIVE("ONEDRIVE", "OneDrive", "https://graph.microsoft.com/v1.0/me/drive", usesBearerToken = true),
  DROPBOX("DROPBOX", "Dropbox", "https://api.dropboxapi.com/2", usesBearerToken = true),
  YANDEX("YANDEX", "Yandex Disk", "https://cloud-api.yandex.net/v1/disk", usesBearerToken = true),
  NEXTCLOUD("NEXTCLOUD", "Nextcloud", "https://"),
  OWNCLOUD("OWNCLOUD", "OwnCloud", "https://"),
  WEBDAV("WEBDAV", "WebDAV", "https://"),
  FTP("FTP", "FTP Server", "ftp://"),
  HTTP_TOKEN("HTTP_TOKEN", "HTTP Bearer API", "https://", usesBearerToken = true),
}

class CloudStorageClient(private val accountDao: CloudAccountDao) {
  private val http =
    OkHttpClient.Builder()
      .connectTimeout(15, TimeUnit.SECONDS)
      .readTimeout(30, TimeUnit.SECONDS)
      .writeTimeout(30, TimeUnit.SECONDS)
      .build()

  companion object {
    fun buildCloudUri(accountId: Long, remotePath: String): String {
      val clean = "/" + remotePath.trimStart('/')
      return "cloud://$accountId$clean"
    }

    fun parseCloudUri(uri: String): Pair<Long, String>? {
      if (!uri.startsWith("cloud://")) return null
      val rest = uri.removePrefix("cloud://")
      val slashIdx = rest.indexOf('/')
      val idStr = if (slashIdx < 0) rest else rest.substring(0, slashIdx)
      val id = idStr.toLongOrNull() ?: return null
      val remotePath = if (slashIdx < 0) "/" else rest.substring(slashIdx)
      return id to remotePath
    }
  }

  suspend fun testConnection(account: CloudAccountEntity): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val items = listDirectory(account, account.basePath.ifBlank { "/" })
        "Connected (${items.size} items)"
      }
    }

  suspend fun listDirectoryUri(cloudUri: String): List<VirtualFileNode> =
    withContext(Dispatchers.IO) {
      val (id, remotePath) = parseCloudUri(cloudUri) ?: return@withContext emptyList()
      val acc = accountDao.getById(id) ?: return@withContext emptyList()
      listDirectory(acc, remotePath)
    }

  suspend fun listDirectory(account: CloudAccountEntity, remotePath: String): List<VirtualFileNode> =
    withContext(Dispatchers.IO) {
      when (account.protocol) {
        CloudProtocol.ONEDRIVE.id -> listOneDriveDirectory(account, remotePath)
        CloudProtocol.DROPBOX.id -> listDropboxDirectory(account, remotePath)
        CloudProtocol.YANDEX.id -> listYandexDirectory(account, remotePath)
        CloudProtocol.FTP.id -> listFtpDirectory(account, remotePath)
        CloudProtocol.HTTP_TOKEN.id -> listHttpTokenDirectory(account, remotePath)
        else -> listWebDavDirectory(account, remotePath)
      }
    }

  suspend fun readFileBytes(cloudUri: String): ByteArray =
    withContext(Dispatchers.IO) {
      val (id, remotePath) = parseCloudUri(cloudUri) ?: return@withContext ByteArray(0)
      val acc = accountDao.getById(id) ?: return@withContext ByteArray(0)
      when (acc.protocol) {
        CloudProtocol.ONEDRIVE.id -> readOneDriveBytes(acc, remotePath)
        CloudProtocol.DROPBOX.id -> readDropboxBytes(acc, remotePath)
        CloudProtocol.YANDEX.id -> readYandexBytes(acc, remotePath)
        CloudProtocol.FTP.id -> downloadFtpBytes(acc, remotePath)
        else -> {
          val url = resolveHttpUrl(acc, remotePath)
          val req = applyAuth(Request.Builder().url(url).get(), acc).build()
          http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) ByteArray(0) else resp.body?.bytes() ?: ByteArray(0)
          }
        }
      }
    }

  suspend fun writeFileBytes(cloudUri: String, bytes: ByteArray): Boolean =
    withContext(Dispatchers.IO) {
      val (id, remotePath) = parseCloudUri(cloudUri) ?: return@withContext false
      val acc = accountDao.getById(id) ?: return@withContext false
      when (acc.protocol) {
        CloudProtocol.ONEDRIVE.id -> writeOneDriveBytes(acc, remotePath, bytes)
        CloudProtocol.DROPBOX.id -> writeDropboxBytes(acc, remotePath, bytes)
        CloudProtocol.YANDEX.id -> writeYandexBytes(acc, remotePath, bytes)
        CloudProtocol.FTP.id -> uploadFtpBytes(acc, remotePath, bytes)
        else -> {
          val url = resolveHttpUrl(acc, remotePath)
          val body = bytes.toRequestBody("application/octet-stream".toMediaTypeOrNull())
          val req = applyAuth(Request.Builder().url(url).put(body), acc).build()
          http.newCall(req).execute().use { it.isSuccessful }
        }
      }
    }

  suspend fun createDirectory(cloudParentUri: String, name: String): Boolean =
    withContext(Dispatchers.IO) {
      val (id, remoteParent) = parseCloudUri(cloudParentUri) ?: return@withContext false
      val acc = accountDao.getById(id) ?: return@withContext false
      val childPath = "/" + (remoteParent.trim('/') + "/" + name.trim('/')).trimStart('/')
      when (acc.protocol) {
        CloudProtocol.ONEDRIVE.id -> createOneDriveDir(acc, remoteParent, name.trim())
        CloudProtocol.DROPBOX.id -> createDropboxDir(acc, childPath)
        CloudProtocol.YANDEX.id -> createYandexDir(acc, childPath)
        CloudProtocol.FTP.id -> ftpMkdir(acc, childPath)
        CloudProtocol.HTTP_TOKEN.id -> false
        else -> {
          val url = resolveHttpUrl(acc, childPath)
          val req = applyAuth(Request.Builder().url(url).method("MKCOL", null), acc).build()
          http.newCall(req).execute().use { it.isSuccessful || it.code == 201 }
        }
      }
    }

  suspend fun deleteUri(cloudUri: String): Boolean =
    withContext(Dispatchers.IO) {
      val (id, remotePath) = parseCloudUri(cloudUri) ?: return@withContext false
      val acc = accountDao.getById(id) ?: return@withContext false
      when (acc.protocol) {
        CloudProtocol.ONEDRIVE.id -> deleteOneDrive(acc, remotePath)
        CloudProtocol.DROPBOX.id -> deleteDropbox(acc, remotePath)
        CloudProtocol.YANDEX.id -> deleteYandex(acc, remotePath)
        CloudProtocol.FTP.id -> ftpDelete(acc, remotePath)
        else -> {
          val url = resolveHttpUrl(acc, remotePath)
          val req = applyAuth(Request.Builder().url(url).delete(), acc).build()
          http.newCall(req).execute().use { it.isSuccessful }
        }
      }
    }

  suspend fun renameUri(cloudUri: String, newName: String): Boolean =
    withContext(Dispatchers.IO) {
      val (id, remotePath) = parseCloudUri(cloudUri) ?: return@withContext false
      val acc = accountDao.getById(id) ?: return@withContext false
      val parent = remotePath.trimEnd('/').substringBeforeLast('/', "")
      val targetRemote = "$parent/$newName"
      when (acc.protocol) {
        CloudProtocol.ONEDRIVE.id -> renameOneDrive(acc, remotePath, newName)
        CloudProtocol.DROPBOX.id -> moveDropbox(acc, remotePath, targetRemote)
        CloudProtocol.YANDEX.id -> moveYandex(acc, remotePath, targetRemote)
        CloudProtocol.FTP.id -> ftpRename(acc, remotePath, targetRemote)
        CloudProtocol.HTTP_TOKEN.id -> false
        else -> {
          val srcUrl = resolveHttpUrl(acc, remotePath)
          val dstUrl = resolveHttpUrl(acc, targetRemote)
          val req =
            applyAuth(
              Request.Builder()
                .url(srcUrl)
                .method("MOVE", null)
                .header("Destination", dstUrl)
                .header("Overwrite", "T"),
              acc,
            ).build()
          http.newCall(req).execute().use { it.isSuccessful || it.code in setOf(201, 204) }
        }
      }
    }

  suspend fun downloadToLocal(cloudUri: String, localDest: File): Boolean =
    withContext(Dispatchers.IO) {
      val bytes = readFileBytes(cloudUri)
      if (bytes.isEmpty()) return@withContext false
      localDest.parentFile?.mkdirs()
      localDest.writeBytes(bytes)
      true
    }

  suspend fun uploadLocalFile(localFile: File, targetCloudDirUri: String): Boolean =
    withContext(Dispatchers.IO) {
      if (!localFile.exists() || !localFile.isFile) return@withContext false
      val (id, remoteDir) = parseCloudUri(targetCloudDirUri) ?: return@withContext false
      val targetUri = buildCloudUri(id, remoteDir.trimEnd('/') + "/" + localFile.name)
      writeFileBytes(targetUri, localFile.readBytes())
    }

  private fun resolveHttpUrl(account: CloudAccountEntity, remotePath: String): String {
    val base = account.hostUrl.trimEnd('/')
    val cleanRel = remotePath.trimStart('/')
    return if (account.protocol == CloudProtocol.NEXTCLOUD.id || account.protocol == CloudProtocol.OWNCLOUD.id) {
      val davBase =
        if ("/remote.php/" in base) base
        else "$base/remote.php/dav/files/${account.username}"
      if (cleanRel.isEmpty()) "$davBase/" else "$davBase/$cleanRel"
    } else {
      if (cleanRel.isEmpty()) "$base/" else "$base/$cleanRel"
    }
  }

  private fun applyAuth(builder: Request.Builder, account: CloudAccountEntity): Request.Builder {
    if (account.protocol == CloudProtocol.HTTP_TOKEN.id) {
      if (account.secretOrToken.isNotBlank()) {
        builder.header("Authorization", "Bearer ${account.secretOrToken}")
      }
    } else if (account.username.isNotBlank() || account.secretOrToken.isNotBlank()) {
      builder.header("Authorization", Credentials.basic(account.username, account.secretOrToken))
    }
    return builder
  }

  private fun listWebDavDirectory(account: CloudAccountEntity, remotePath: String): List<VirtualFileNode> {
    val url = resolveHttpUrl(account, remotePath)
    val propfindXml =
      """<?xml version="1.0" encoding="utf-8" ?>
      <D:propfind xmlns:D="DAV:">
        <D:prop>
          <D:displayname/>
          <D:getcontentlength/>
          <D:getlastmodified/>
          <D:resourcetype/>
        </D:prop>
      </D:propfind>"""
    val body = propfindXml.toRequestBody("application/xml; charset=utf-8".toMediaTypeOrNull())
    val req =
      applyAuth(
        Request.Builder()
          .url(url)
          .method("PROPFIND", body)
          .header("Depth", "1"),
        account,
      ).build()

    http.newCall(req).execute().use { resp ->
      if (!resp.isSuccessful && resp.code != 207) {
        throw IllegalStateException("WebDAV HTTP ${resp.code}: ${resp.message}")
      }
      val xml = resp.body?.string().orEmpty()
      return parseWebDavMultiStatus(account.id, remotePath, xml)
    }
  }

  private fun parseWebDavMultiStatus(
    accountId: Long,
    requestedRemotePath: String,
    xml: String,
  ): List<VirtualFileNode> {
    if (xml.isBlank()) return emptyList()
    val parser = XmlPullParserFactory.newInstance().apply { isNamespaceAware = true }.newPullParser()
    parser.setInput(StringReader(xml))

    val nodes = mutableListOf<VirtualFileNode>()
    var inResponse = false
    var currentTag = ""
    var href = ""
    var displayName = ""
    var size = 0L
    var isCol = false

    val cleanReq = "/" + requestedRemotePath.trim('/')
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
      when (event) {
        XmlPullParser.START_TAG -> {
          val local = parser.name.substringAfterLast(':')
          currentTag = local.lowercase()
          if (currentTag == "response") {
            inResponse = true
            href = ""
            displayName = ""
            size = 0L
            isCol = false
          } else if (inResponse && currentTag == "collection") {
            isCol = true
          }
        }
        XmlPullParser.TEXT -> {
          if (inResponse) {
            val txt = parser.text?.trim().orEmpty()
            if (txt.isNotEmpty()) {
              when (currentTag) {
                "href" -> href = txt
                "displayname" -> displayName = txt
                "getcontentlength" -> size = txt.toLongOrNull() ?: size
              }
            }
          }
        }
        XmlPullParser.END_TAG -> {
          val local = parser.name.substringAfterLast(':').lowercase()
          if (local == "response" && inResponse) {
            inResponse = false
            val decodedHref = java.net.URLDecoder.decode(href.trimEnd('/'), "UTF-8")
            val itemName =
              displayName.ifBlank { decodedHref.substringAfterLast('/') }
            val normalizedChild =
              if (cleanReq == "/") "/$itemName" else "${cleanReq.trimEnd('/')}/$itemName"
            val isSelf =
              itemName.isBlank() ||
                decodedHref.endsWith(cleanReq.trimEnd('/')) && cleanReq != "/" ||
                (cleanReq == "/" && decodedHref.isBlank())
            if (!isSelf && itemName.isNotBlank()) {
              nodes.add(
                VirtualFileNode(
                  name = itemName,
                  path = buildCloudUri(accountId, normalizedChild),
                  isDirectory = isCol,
                  size = if (isCol) 0L else size,
                  lastModified = System.currentTimeMillis(),
                  permissions = if (isCol) "cloud-dir" else "cloud-file",
                  sourceType = FileSourceType.CLOUD,
                )
              )
            }
          }
          currentTag = ""
        }
      }
      event = parser.next()
    }
    return nodes
  }

  private fun listHttpTokenDirectory(account: CloudAccountEntity, remotePath: String): List<VirtualFileNode> {
    val url = resolveHttpUrl(account, remotePath)
    val req = applyAuth(Request.Builder().url(url).get(), account).build()
    http.newCall(req).execute().use { resp ->
      if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
      val body = resp.body?.string().orEmpty().trim()
      val list = mutableListOf<VirtualFileNode>()
      if (body.startsWith("[")) {
        val arr = JSONArray(body)
        for (i in 0 until arr.length()) {
          val o = arr.optJSONObject(i) ?: continue
          val name = o.optString("name").ifBlank { continue }
          val isDir = o.optString("type") == "dir" || o.optBoolean("isDirectory", false)
          val sz = o.optLong("size", 0L)
          val child = if (remotePath == "/") "/$name" else "${remotePath.trimEnd('/')}/$name"
          list.add(
            VirtualFileNode(
              name = name,
              path = buildCloudUri(account.id, child),
              isDirectory = isDir,
              size = sz,
              lastModified = System.currentTimeMillis(),
              permissions = "http-cloud",
              sourceType = FileSourceType.CLOUD,
            )
          )
        }
      } else if (body.startsWith("{")) {
        val obj = JSONObject(body)
        val arr = obj.optJSONArray("items") ?: obj.optJSONArray("files") ?: JSONArray()
        for (i in 0 until arr.length()) {
          val o = arr.optJSONObject(i) ?: continue
          val name = o.optString("name").ifBlank { continue }
          val isDir = o.optBoolean("isDirectory", false) || o.optString("type") == "dir"
          val child = if (remotePath == "/") "/$name" else "${remotePath.trimEnd('/')}/$name"
          list.add(
            VirtualFileNode(
              name = name,
              path = buildCloudUri(account.id, child),
              isDirectory = isDir,
              size = o.optLong("size", 0L),
              lastModified = System.currentTimeMillis(),
              permissions = "http-cloud",
              sourceType = FileSourceType.CLOUD,
            )
          )
        }
      }
      return list
    }
  }

  // --- Microsoft OneDrive (Graph API) ---
  private fun oneDriveEndpoint(account: CloudAccountEntity, remotePath: String, suffix: String): String {
    val base = account.hostUrl.ifBlank { CloudProtocol.ONEDRIVE.defaultHost }.trimEnd('/')
    val clean = remotePath.trim('/')
    return if (clean.isEmpty()) "$base/root$suffix" else "$base/root:/$clean:$suffix"
  }

  private fun listOneDriveDirectory(account: CloudAccountEntity, remotePath: String): List<VirtualFileNode> {
    val url = oneDriveEndpoint(account, remotePath, "/children")
    val req = Request.Builder().url(url).header("Authorization", "Bearer ${account.secretOrToken}").get().build()
    http.newCall(req).execute().use { resp ->
      if (!resp.isSuccessful) throw IllegalStateException("OneDrive HTTP ${resp.code}: ${resp.message}")
      val arr = JSONObject(resp.body?.string().orEmpty()).optJSONArray("value") ?: return emptyList()
      return (0 until arr.length()).mapNotNull { i ->
        val o = arr.optJSONObject(i) ?: return@mapNotNull null
        val name = o.optString("name").ifBlank { return@mapNotNull null }
        val isDir = o.has("folder")
        val child = if (remotePath.trim('/') == "") "/$name" else "/${remotePath.trim('/')}/$name"
        VirtualFileNode(
          name = name,
          path = buildCloudUri(account.id, child),
          isDirectory = isDir,
          size = if (isDir) 0L else o.optLong("size", 0L),
          lastModified = System.currentTimeMillis(),
          permissions = "onedrive",
          sourceType = FileSourceType.CLOUD,
        )
      }
    }
  }

  private fun readOneDriveBytes(account: CloudAccountEntity, remotePath: String): ByteArray {
    val url = oneDriveEndpoint(account, remotePath, "/content")
    val req = Request.Builder().url(url).header("Authorization", "Bearer ${account.secretOrToken}").get().build()
    return http.newCall(req).execute().use { if (it.isSuccessful) it.body?.bytes() ?: ByteArray(0) else ByteArray(0) }
  }

  private fun writeOneDriveBytes(account: CloudAccountEntity, remotePath: String, bytes: ByteArray): Boolean {
    val url = oneDriveEndpoint(account, remotePath, "/content")
    val body = bytes.toRequestBody("application/octet-stream".toMediaTypeOrNull())
    val req = Request.Builder().url(url).header("Authorization", "Bearer ${account.secretOrToken}").put(body).build()
    return http.newCall(req).execute().use { it.isSuccessful }
  }

  private fun createOneDriveDir(account: CloudAccountEntity, parentPath: String, name: String): Boolean {
    val url = oneDriveEndpoint(account, parentPath, "/children")
    val json = JSONObject().put("name", name).put("folder", JSONObject()).toString()
    val req = Request.Builder().url(url).header("Authorization", "Bearer ${account.secretOrToken}")
      .post(json.toRequestBody("application/json".toMediaTypeOrNull())).build()
    return http.newCall(req).execute().use { it.isSuccessful }
  }

  private fun deleteOneDrive(account: CloudAccountEntity, remotePath: String): Boolean {
    val url = oneDriveEndpoint(account, remotePath, "")
    val req = Request.Builder().url(url).header("Authorization", "Bearer ${account.secretOrToken}").delete().build()
    return http.newCall(req).execute().use { it.isSuccessful || it.code == 204 }
  }

  private fun renameOneDrive(account: CloudAccountEntity, remotePath: String, newName: String): Boolean {
    val url = oneDriveEndpoint(account, remotePath, "")
    val json = JSONObject().put("name", newName).toString()
    val req = Request.Builder().url(url).header("Authorization", "Bearer ${account.secretOrToken}")
      .patch(json.toRequestBody("application/json".toMediaTypeOrNull())).build()
    return http.newCall(req).execute().use { it.isSuccessful }
  }

  // --- Dropbox API v2 ---
  private fun listDropboxDirectory(account: CloudAccountEntity, remotePath: String): List<VirtualFileNode> {
    val clean = remotePath.trimEnd('/').let { if (it == "/") "" else it }
    val body = JSONObject().put("path", clean).toString().toRequestBody("application/json".toMediaTypeOrNull())
    val req = Request.Builder().url("https://api.dropboxapi.com/2/files/list_folder")
      .header("Authorization", "Bearer ${account.secretOrToken}").post(body).build()
    http.newCall(req).execute().use { resp ->
      if (!resp.isSuccessful) throw IllegalStateException("Dropbox HTTP ${resp.code}: ${resp.message}")
      val arr = JSONObject(resp.body?.string().orEmpty()).optJSONArray("entries") ?: return emptyList()
      return (0 until arr.length()).mapNotNull { i ->
        val o = arr.optJSONObject(i) ?: return@mapNotNull null
        val name = o.optString("name").ifBlank { return@mapNotNull null }
        val isDir = o.optString(".tag") == "folder"
        val pathLower = o.optString("path_display", if (clean.isEmpty()) "/$name" else "$clean/$name")
        VirtualFileNode(
          name = name,
          path = buildCloudUri(account.id, pathLower),
          isDirectory = isDir,
          size = if (isDir) 0L else o.optLong("size", 0L),
          lastModified = System.currentTimeMillis(),
          permissions = "dropbox",
          sourceType = FileSourceType.CLOUD,
        )
      }
    }
  }

  private fun readDropboxBytes(account: CloudAccountEntity, remotePath: String): ByteArray {
    val arg = JSONObject().put("path", "/" + remotePath.trimStart('/')).toString()
    val req = Request.Builder().url("https://content.dropboxapi.com/2/files/download")
      .header("Authorization", "Bearer ${account.secretOrToken}")
      .header("Dropbox-API-Arg", arg)
      .post(ByteArray(0).toRequestBody(null)).build()
    return http.newCall(req).execute().use { if (it.isSuccessful) it.body?.bytes() ?: ByteArray(0) else ByteArray(0) }
  }

  private fun writeDropboxBytes(account: CloudAccountEntity, remotePath: String, bytes: ByteArray): Boolean {
    val arg = JSONObject().put("path", "/" + remotePath.trimStart('/')).put("mode", "overwrite").toString()
    val req = Request.Builder().url("https://content.dropboxapi.com/2/files/upload")
      .header("Authorization", "Bearer ${account.secretOrToken}")
      .header("Dropbox-API-Arg", arg)
      .post(bytes.toRequestBody("application/octet-stream".toMediaTypeOrNull())).build()
    return http.newCall(req).execute().use { it.isSuccessful }
  }

  private fun createDropboxDir(account: CloudAccountEntity, remotePath: String): Boolean {
    val body = JSONObject().put("path", "/" + remotePath.trimStart('/')).toString().toRequestBody("application/json".toMediaTypeOrNull())
    val req = Request.Builder().url("https://api.dropboxapi.com/2/files/create_folder_v2")
      .header("Authorization", "Bearer ${account.secretOrToken}").post(body).build()
    return http.newCall(req).execute().use { it.isSuccessful }
  }

  private fun deleteDropbox(account: CloudAccountEntity, remotePath: String): Boolean {
    val body = JSONObject().put("path", "/" + remotePath.trimStart('/')).toString().toRequestBody("application/json".toMediaTypeOrNull())
    val req = Request.Builder().url("https://api.dropboxapi.com/2/files/delete_v2")
      .header("Authorization", "Bearer ${account.secretOrToken}").post(body).build()
    return http.newCall(req).execute().use { it.isSuccessful }
  }

  private fun moveDropbox(account: CloudAccountEntity, fromPath: String, toPath: String): Boolean {
    val body = JSONObject().put("from_path", "/" + fromPath.trimStart('/')).put("to_path", "/" + toPath.trimStart('/'))
      .toString().toRequestBody("application/json".toMediaTypeOrNull())
    val req = Request.Builder().url("https://api.dropboxapi.com/2/files/move_v2")
      .header("Authorization", "Bearer ${account.secretOrToken}").post(body).build()
    return http.newCall(req).execute().use { it.isSuccessful }
  }

  // --- Yandex Disk REST API ---
  private fun listYandexDirectory(account: CloudAccountEntity, remotePath: String): List<VirtualFileNode> {
    val p = java.net.URLEncoder.encode("/" + remotePath.trimStart('/'), "UTF-8")
    val req = Request.Builder().url("https://cloud-api.yandex.net/v1/disk/resources?path=$p&limit=200")
      .header("Authorization", "OAuth ${account.secretOrToken}").get().build()
    http.newCall(req).execute().use { resp ->
      if (!resp.isSuccessful) throw IllegalStateException("Yandex HTTP ${resp.code}: ${resp.message}")
      val embedded = JSONObject(resp.body?.string().orEmpty()).optJSONObject("_embedded") ?: return emptyList()
      val items = embedded.optJSONArray("items") ?: return emptyList()
      return (0 until items.length()).mapNotNull { i ->
        val o = items.optJSONObject(i) ?: return@mapNotNull null
        val name = o.optString("name").ifBlank { return@mapNotNull null }
        val isDir = o.optString("type") == "dir"
        val child = if (remotePath.trim('/') == "") "/$name" else "/${remotePath.trim('/')}/$name"
        VirtualFileNode(
          name = name,
          path = buildCloudUri(account.id, child),
          isDirectory = isDir,
          size = if (isDir) 0L else o.optLong("size", 0L),
          lastModified = System.currentTimeMillis(),
          permissions = "yandex",
          sourceType = FileSourceType.CLOUD,
        )
      }
    }
  }

  private fun readYandexBytes(account: CloudAccountEntity, remotePath: String): ByteArray {
    val p = java.net.URLEncoder.encode("/" + remotePath.trimStart('/'), "UTF-8")
    val req = Request.Builder().url("https://cloud-api.yandex.net/v1/disk/resources/download?path=$p")
      .header("Authorization", "OAuth ${account.secretOrToken}").get().build()
    val href = http.newCall(req).execute().use {
      if (!it.isSuccessful) "" else JSONObject(it.body?.string().orEmpty()).optString("href", "")
    }
    if (href.isBlank()) return ByteArray(0)
    return http.newCall(Request.Builder().url(href).get().build()).execute().use {
      if (it.isSuccessful) it.body?.bytes() ?: ByteArray(0) else ByteArray(0)
    }
  }

  private fun writeYandexBytes(account: CloudAccountEntity, remotePath: String, bytes: ByteArray): Boolean {
    val p = java.net.URLEncoder.encode("/" + remotePath.trimStart('/'), "UTF-8")
    val req = Request.Builder().url("https://cloud-api.yandex.net/v1/disk/resources/upload?path=$p&overwrite=true")
      .header("Authorization", "OAuth ${account.secretOrToken}").get().build()
    val href = http.newCall(req).execute().use {
      if (!it.isSuccessful) "" else JSONObject(it.body?.string().orEmpty()).optString("href", "")
    }
    if (href.isBlank()) return false
    val putReq = Request.Builder().url(href).put(bytes.toRequestBody("application/octet-stream".toMediaTypeOrNull())).build()
    return http.newCall(putReq).execute().use { it.isSuccessful }
  }

  private fun createYandexDir(account: CloudAccountEntity, remotePath: String): Boolean {
    val p = java.net.URLEncoder.encode("/" + remotePath.trimStart('/'), "UTF-8")
    val req = Request.Builder().url("https://cloud-api.yandex.net/v1/disk/resources?path=$p")
      .header("Authorization", "OAuth ${account.secretOrToken}").put(ByteArray(0).toRequestBody(null)).build()
    return http.newCall(req).execute().use { it.isSuccessful || it.code == 201 }
  }

  private fun deleteYandex(account: CloudAccountEntity, remotePath: String): Boolean {
    val p = java.net.URLEncoder.encode("/" + remotePath.trimStart('/'), "UTF-8")
    val req = Request.Builder().url("https://cloud-api.yandex.net/v1/disk/resources?path=$p&permanently=true")
      .header("Authorization", "OAuth ${account.secretOrToken}").delete().build()
    return http.newCall(req).execute().use { it.isSuccessful || it.code == 204 || it.code == 202 }
  }

  private fun moveYandex(account: CloudAccountEntity, fromPath: String, toPath: String): Boolean {
    val from = java.net.URLEncoder.encode("/" + fromPath.trimStart('/'), "UTF-8")
    val path = java.net.URLEncoder.encode("/" + toPath.trimStart('/'), "UTF-8")
    val req = Request.Builder().url("https://cloud-api.yandex.net/v1/disk/resources/move?from=$from&path=$path&overwrite=true")
      .header("Authorization", "OAuth ${account.secretOrToken}").post(ByteArray(0).toRequestBody(null)).build()
    return http.newCall(req).execute().use { it.isSuccessful || it.code == 201 }
  }

  // Minimal pure-Kotlin FTP client over raw sockets (PASV mode)
  private fun parseFtpHostPort(account: CloudAccountEntity): Pair<String, Int> {
    val clean = account.hostUrl.removePrefix("ftp://").removePrefix("ftps://").substringBefore('/')
    val host = clean.substringBefore(':')
    val port = clean.substringAfter(':', "").toIntOrNull() ?: 21
    return host to port
  }

  private fun <T> withFtpSession(account: CloudAccountEntity, block: (FtpSession) -> T): T {
    val (host, port) = parseFtpHostPort(account)
    Socket(host, port).use { sock ->
      sock.soTimeout = 15000
      val session = FtpSession(sock, account)
      session.login()
      try {
        return block(session)
      } finally {
        runCatching { session.cmd("QUIT") }
      }
    }
  }

  private fun listFtpDirectory(account: CloudAccountEntity, remotePath: String): List<VirtualFileNode> =
    withFtpSession(account) { ftp ->
      ftp.cmd("CWD ${remotePath.ifBlank { "/" }}")
      val rawLines = ftp.pasvTransferText("LIST")
      rawLines.mapNotNull { line ->
        val parts = line.trim().split(Regex("\\s+"), limit = 9)
        if (parts.size < 9) return@mapNotNull null
        val perms = parts[0]
        val name = parts[8].substringBefore(" -> ")
        if (name == "." || name == "..") return@mapNotNull null
        val isDir = perms.startsWith("d")
        val sz = parts[4].toLongOrNull() ?: 0L
        val child = if (remotePath == "/") "/$name" else "${remotePath.trimEnd('/')}/$name"
        VirtualFileNode(
          name = name,
          path = buildCloudUri(account.id, child),
          isDirectory = isDir,
          size = if (isDir) 0L else sz,
          lastModified = System.currentTimeMillis(),
          permissions = perms,
          sourceType = FileSourceType.CLOUD,
        )
      }
    }

  private fun downloadFtpBytes(account: CloudAccountEntity, remotePath: String): ByteArray =
    withFtpSession(account) { ftp -> ftp.pasvDownloadBytes("RETR $remotePath") }

  private fun uploadFtpBytes(account: CloudAccountEntity, remotePath: String, bytes: ByteArray): Boolean =
    withFtpSession(account) { ftp -> ftp.pasvUploadBytes("STOR $remotePath", bytes) }

  private fun ftpMkdir(account: CloudAccountEntity, remotePath: String): Boolean =
    withFtpSession(account) { ftp -> ftp.cmd("MKD $remotePath").startsWith("2") }

  private fun ftpDelete(account: CloudAccountEntity, remotePath: String): Boolean =
    withFtpSession(account) { ftp ->
      ftp.cmd("DELE $remotePath").startsWith("2") || ftp.cmd("RMD $remotePath").startsWith("2")
    }

  private fun ftpRename(account: CloudAccountEntity, oldPath: String, newPath: String): Boolean =
    withFtpSession(account) { ftp ->
      ftp.cmd("RNFR $oldPath").startsWith("3") && ftp.cmd("RNTO $newPath").startsWith("2")
    }

  private class FtpSession(sock: Socket, private val account: CloudAccountEntity) {
    private val reader = BufferedReader(InputStreamReader(sock.getInputStream(), Charsets.UTF_8))
    private val writer = PrintWriter(OutputStreamWriter(sock.getOutputStream(), Charsets.UTF_8), true)

    fun readReply(): String {
      val sb = StringBuilder()
      while (true) {
        val line = reader.readLine() ?: break
        sb.appendLine(line)
        if (line.length >= 4 && line[0].isDigit() && line[1].isDigit() && line[2].isDigit() && line[3] == ' ') {
          return line
        }
      }
      return sb.toString()
    }

    fun cmd(command: String): String {
      writer.print("$command\r\n")
      writer.flush()
      return readReply()
    }

    fun login() {
      readReply() // 220 banner
      val user = account.username.ifBlank { "anonymous" }
      val pass = account.secretOrToken.ifBlank { "anonymous@vortex" }
      val rUser = cmd("USER $user")
      if (rUser.startsWith("331")) {
        val rPass = cmd("PASS $pass")
        require(rPass.startsWith("2")) { "FTP login rejected: $rPass" }
      }
      cmd("TYPE I")
    }

    private fun openPasvSocket(): Socket {
      val reply = cmd("PASV")
      val match = Regex("\\((\\d+),(\\d+),(\\d+),(\\d+),(\\d+),(\\d+)\\)").find(reply)
        ?: throw IllegalStateException("FTP PASV failed: $reply")
      val (a, b, c, d, p1, p2) = match.destructured
      val ip = "$a.$b.$c.$d"
      val port = p1.toInt() * 256 + p2.toInt()
      return Socket(ip, port).apply { soTimeout = 15000 }
    }

    fun pasvTransferText(command: String): List<String> {
      openPasvSocket().use { dataSock ->
        val r = cmd(command)
        if (!r.startsWith("1")) return emptyList()
        val lines = dataSock.getInputStream().bufferedReader().readLines()
        readReply()
        return lines
      }
    }

    fun pasvDownloadBytes(command: String): ByteArray {
      openPasvSocket().use { dataSock ->
        val r = cmd(command)
        if (!r.startsWith("1")) return ByteArray(0)
        val bytes = dataSock.getInputStream().readBytes()
        readReply()
        return bytes
      }
    }

    fun pasvUploadBytes(command: String, bytes: ByteArray): Boolean {
      openPasvSocket().use { dataSock ->
        val r = cmd(command)
        if (!r.startsWith("1")) return false
        dataSock.getOutputStream().use { it.write(bytes) }
      }
      return readReply().startsWith("2")
    }
  }
}
