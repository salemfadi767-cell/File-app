package com.example.domain.media

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.media.MediaMetadataRetriever
import android.util.LruCache
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import net.lingala.zip4j.ZipFile

data class AudioTrackMetadata(
  val title: String,
  val artist: String,
  val album: String,
  val durationMs: Long,
  val hasEmbeddedArt: Boolean,
)

class MediaThumbnailLoader {

  // 16 MB in-memory LRU cache keyed by "type|path|lastModified"
  private val cache: LruCache<String, Bitmap> =
    object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
      override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

  private val negativeCache = mutableSetOf<String>()

  suspend fun loadAudioAlbumArt(path: String, lastModified: Long = 0L, targetPx: Int = 160): Bitmap? {
    val key = "aud|$path|$lastModified|$targetPx"
    cache.get(key)?.let { return it }
    if (key in negativeCache) return null

    return withContext(Dispatchers.IO) {
      val bmp =
        runCatching {
          val file = File(path)
          if (!file.exists() || !file.canRead()) return@runCatching null
          val mmr = MediaMetadataRetriever()
          try {
            mmr.setDataSource(path)
            val pic = mmr.embeddedPicture ?: return@runCatching null
            decodeSampledBitmap(pic, targetPx, targetPx)
          } finally {
            runCatching { mmr.release() }
          }
        }.getOrNull()

      if (bmp != null) {
        cache.put(key, bmp)
      } else {
        synchronized(negativeCache) {
          if (negativeCache.size > 1500) negativeCache.clear()
          negativeCache.add(key)
        }
      }
      bmp
    }
  }

  suspend fun loadVideoFrame(path: String, lastModified: Long = 0L, targetPx: Int = 160): Bitmap? {
    val key = "vid|$path|$lastModified|$targetPx"
    cache.get(key)?.let { return it }
    if (key in negativeCache) return null

    return withContext(Dispatchers.IO) {
      val bmp =
        runCatching {
          val file = File(path)
          if (!file.exists() || !file.canRead()) return@runCatching null
          val mmr = MediaMetadataRetriever()
          try {
            mmr.setDataSource(path)
            val raw =
              mmr.getFrameAtTime(1_500_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: mmr.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: return@runCatching null
            scaleBitmap(raw, targetPx)
          } finally {
            runCatching { mmr.release() }
          }
        }.getOrNull()

      if (bmp != null) {
        cache.put(key, bmp)
      } else {
        synchronized(negativeCache) {
          if (negativeCache.size > 1500) negativeCache.clear()
          negativeCache.add(key)
        }
      }
      bmp
    }
  }

  suspend fun loadApkAppIcon(
    context: Context,
    path: String,
    lastModified: Long = 0L,
    targetPx: Int = 144,
  ): Bitmap? {
    val key = "apk|$path|$lastModified|$targetPx"
    cache.get(key)?.let { return it }
    if (key in negativeCache) return null

    return withContext(Dispatchers.IO) {
      val bmp =
        runCatching {
          val file = File(path)
          if (!file.exists() || !file.canRead()) return@runCatching null
          val ext = file.extension.lowercase(Locale.ROOT)
          var tempInnerApk: File? = null
          val inspectFile =
            if (ext in setOf("apks", "xapk", "apkm")) {
              val zf = ZipFile(file)
              val inner =
                zf.fileHeaders.firstOrNull { it.fileName.endsWith("base.apk", ignoreCase = true) }
                  ?: zf.fileHeaders.firstOrNull { it.fileName.endsWith(".apk", ignoreCase = true) }
              if (inner != null) {
                val tmp = File(context.cacheDir, "thumb_${file.name.hashCode()}.apk")
                zf.getInputStream(inner).use { inp ->
                  FileOutputStream(tmp).use { out -> inp.copyTo(out) }
                }
                tempInnerApk = tmp
                tmp
              } else {
                // Check for XAPK icon.png inside archive
                val iconPng = zf.fileHeaders.firstOrNull {
                  it.fileName.equals("icon.png", ignoreCase = true) ||
                    it.fileName.endsWith("/icon.png", ignoreCase = true)
                }
                if (iconPng != null) {
                  val bytes = zf.getInputStream(iconPng).use { it.readBytes() }
                  return@runCatching decodeSampledBitmap(bytes, targetPx, targetPx)
                }
                file
              }
            } else {
              file
            }

          try {
            val pm = context.packageManager
            @Suppress("DEPRECATION")
            val pkgInfo = pm.getPackageArchiveInfo(inspectFile.absolutePath, PackageManager.GET_META_DATA)
            val appInfo = pkgInfo?.applicationInfo
            if (appInfo != null) {
              appInfo.sourceDir = inspectFile.absolutePath
              appInfo.publicSourceDir = inspectFile.absolutePath
              val drawable = runCatching { appInfo.loadIcon(pm) }.getOrNull()
              if (drawable != null) {
                val raw =
                  if (drawable is BitmapDrawable && drawable.bitmap != null) {
                    drawable.bitmap
                  } else {
                    val w = drawable.intrinsicWidth.coerceIn(48, targetPx * 2)
                    val h = drawable.intrinsicHeight.coerceIn(48, targetPx * 2)
                    val canvasBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(canvasBmp)
                    drawable.setBounds(0, 0, canvas.width, canvas.height)
                    drawable.draw(canvas)
                    canvasBmp
                  }
                return@runCatching scaleBitmap(raw, targetPx)
              }
            }
            // Fallback: look for highest-res ic_launcher inside APK/ZIP resources
            val zf = runCatching { ZipFile(inspectFile) }.getOrNull()
            val iconHeader =
              zf?.fileHeaders?.filter { hdr ->
                val n = hdr.fileName.lowercase(Locale.ROOT)
                (n.contains("ic_launcher") && (n.endsWith(".png") || n.endsWith(".webp")))
              }?.maxByOrNull { it.uncompressedSize }
            if (iconHeader != null) {
              val bytes = zf.getInputStream(iconHeader).use { it.readBytes() }
              decodeSampledBitmap(bytes, targetPx, targetPx)
            } else {
              null
            }
          } finally {
            tempInnerApk?.delete()
          }
        }.getOrNull()

      if (bmp != null) {
        cache.put(key, bmp)
      } else {
        synchronized(negativeCache) {
          if (negativeCache.size > 1500) negativeCache.clear()
          negativeCache.add(key)
        }
      }
      bmp
    }
  }

  suspend fun extractAudioMetadata(path: String): AudioTrackMetadata =
    withContext(Dispatchers.IO) {
      val f = File(path)
      val fallbackTitle = f.nameWithoutExtension.ifBlank { f.name }
      runCatching {
        val mmr = MediaMetadataRetriever()
        try {
          mmr.setDataSource(path)
          val title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() } ?: fallbackTitle
          val artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.takeIf { it.isNotBlank() } ?: "Unknown Artist"
          val album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.takeIf { it.isNotBlank() } ?: (f.parentFile?.name ?: "Music")
          val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
          val hasArt = mmr.embeddedPicture != null
          AudioTrackMetadata(title, artist, album, dur, hasArt)
        } finally {
          runCatching { mmr.release() }
        }
      }.getOrElse {
        AudioTrackMetadata(fallbackTitle, "Unknown Artist", f.parentFile?.name ?: "Music", 0L, false)
      }
    }

  private fun decodeSampledBitmap(data: ByteArray, reqWidth: Int, reqHeight: Int): Bitmap? {
    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(data, 0, data.size, opts)
    var inSample = 1
    while (opts.outHeight / inSample > reqHeight * 2 || opts.outWidth / inSample > reqWidth * 2) {
      inSample *= 2
    }
    val finalOpts = BitmapFactory.Options().apply { inSampleSize = inSample }
    val raw = BitmapFactory.decodeByteArray(data, 0, data.size, finalOpts) ?: return null
    return scaleBitmap(raw, maxOf(reqWidth, reqHeight))
  }

  private fun scaleBitmap(src: Bitmap, maxDim: Int): Bitmap {
    if (src.width <= maxDim && src.height <= maxDim) return src
    val ratio = minOf(maxDim.toFloat() / src.width, maxDim.toFloat() / src.height)
    val w = (src.width * ratio).toInt().coerceAtLeast(1)
    val h = (src.height * ratio).toInt().coerceAtLeast(1)
    val scaled = Bitmap.createScaledBitmap(src, w, h, true)
    if (scaled !== src) src.recycle()
    return scaled
  }
}
