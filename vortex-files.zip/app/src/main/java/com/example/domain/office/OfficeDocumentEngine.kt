package com.example.domain.office

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.w3c.dom.Element

enum class DocParagraphStyle(val ooxmlStyle: String) {
  HEADING1("Heading1"),
  HEADING2("Heading2"),
  BODY("Normal"),
  BULLET("ListBullet"),
}

data class WordParagraph(
  val id: String,
  val text: String,
  val style: DocParagraphStyle = DocParagraphStyle.BODY,
)

data class WordDocumentModel(
  val title: String,
  val paragraphs: List<WordParagraph>,
)

data class ExcelSheetModel(
  val name: String,
  val rows: MutableList<MutableList<String>>, // raw text or "=SUM(A1:A5)"
)

data class ExcelWorkbookModel(
  val sheets: MutableList<ExcelSheetModel>,
)

data class PptSlideModel(
  val index: Int,
  val title: String,
  val body: String,
  val notes: String = "",
)

data class PptDeckModel(
  val slides: MutableList<PptSlideModel>,
)

data class PdfStrokeAnnotation(
  val pageIndex: Int,
  val points: List<Pair<Float, Float>>, // normalized 0..1 coordinates
  val colorArgb: Int,
  val strokeWidth: Float,
)

data class PdfTextAnnotation(
  val pageIndex: Int,
  val xNorm: Float,
  val yNorm: Float,
  val text: String,
  val colorArgb: Int,
)

class OfficeDocumentEngine {

  // =========================================================================
  // WORD (.DOCX) READER / WRITER / PDF EXPORTER
  // =========================================================================

  suspend fun readDocx(file: File): WordDocumentModel =
    withContext(Dispatchers.IO) {
      val xmlBytes = readZipEntry(file, "word/document.xml")
        ?: return@withContext WordDocumentModel(file.nameWithoutExtension, listOf(WordParagraph("p0", "")))
      val doc = parseXml(xmlBytes)
      val pNodes = doc.getElementsByTagName("w:p")
      val paragraphs = mutableListOf<WordParagraph>()
      for (i in 0 until pNodes.length) {
        val pEl = pNodes.item(i) as? Element ?: continue
        val pPr = pEl.getElementsByTagName("w:pPr").item(0) as? Element
        val styleVal = (pPr?.getElementsByTagName("w:pStyle")?.item(0) as? Element)
          ?.getAttribute("w:val").orEmpty()
        val hasNumPr = pPr?.getElementsByTagName("w:numPr")?.length ?: 0 > 0
        val style = when {
          styleVal.contains("Heading1", true) || styleVal == "Title" -> DocParagraphStyle.HEADING1
          styleVal.contains("Heading2", true) -> DocParagraphStyle.HEADING2
          hasNumPr || styleVal.contains("Bullet", true) -> DocParagraphStyle.BULLET
          else -> DocParagraphStyle.BODY
        }
        val tNodes = pEl.getElementsByTagName("w:t")
        val sb = StringBuilder()
        for (j in 0 until tNodes.length) {
          sb.append(tNodes.item(j).textContent.orEmpty())
        }
        paragraphs.add(WordParagraph("p_$i", sb.toString(), style))
      }
      if (paragraphs.isEmpty()) paragraphs.add(WordParagraph("p_0", ""))
      WordDocumentModel(file.nameWithoutExtension, paragraphs)
    }

  suspend fun saveDocx(model: WordDocumentModel, outputFile: File): File =
    withContext(Dispatchers.IO) {
      outputFile.parentFile?.mkdirs()
      val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"""
      val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

      val docXml = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>""")
        for (p in model.paragraphs) {
          append("<w:p><w:pPr><w:pStyle w:val=\"${p.style.ooxmlStyle}\"/></w:pPr><w:r>")
          if (p.style == DocParagraphStyle.HEADING1 || p.style == DocParagraphStyle.HEADING2) {
            append("<w:rPr><w:b/></w:rPr>")
          }
          val prefix = if (p.style == DocParagraphStyle.BULLET && !p.text.startsWith("• ")) "• " else ""
          append("<w:t xml:space=\"preserve\">${escapeXml(prefix + p.text)}</w:t></w:r></w:p>")
        }
        append("""<w:sectPr><w:pgSz w:w="11906" w:h="16838"/></w:sectPr></w:body></w:document>""")
      }

      ZipOutputStream(FileOutputStream(outputFile)).use { zos ->
        putZipEntry(zos, "[Content_Types].xml", contentTypes.toByteArray(Charsets.UTF_8))
        putZipEntry(zos, "_rels/.rels", rootRels.toByteArray(Charsets.UTF_8))
        putZipEntry(zos, "word/document.xml", docXml.toByteArray(Charsets.UTF_8))
      }
      outputFile
    }

  suspend fun exportDocxToPdf(model: WordDocumentModel, outputPdf: File): File =
    withContext(Dispatchers.IO) {
      outputPdf.parentFile?.mkdirs()
      val pdf = PdfDocument()
      val pageW = 1240
      val pageH = 1754
      var pageNum = 1
      var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum++).create())
      var canvas = page.canvas
      canvas.drawColor(Color.WHITE)
      var y = 110f

      val h1Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#111827"); textSize = 44f; isFakeBoldText = true }
      val h2Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1F2937"); textSize = 34f; isFakeBoldText = true }
      val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#374151"); textSize = 26f }

      for (p in model.paragraphs) {
        val paint = when (p.style) {
          DocParagraphStyle.HEADING1 -> h1Paint
          DocParagraphStyle.HEADING2 -> h2Paint
          else -> bodyPaint
        }
        val text = if (p.style == DocParagraphStyle.BULLET) "• ${p.text}" else p.text
        val wrapped = wrapText(text, paint, pageW - 180f)
        for (line in wrapped.ifEmpty { listOf("") }) {
          if (y > pageH - 100f) {
            pdf.finishPage(page)
            page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum++).create())
            canvas = page.canvas
            canvas.drawColor(Color.WHITE)
            y = 110f
          }
          canvas.drawText(line, 90f, y, paint)
          y += paint.textSize * 1.45f
        }
        y += 14f
      }
      pdf.finishPage(page)
      FileOutputStream(outputPdf).use { pdf.writeTo(it) }
      pdf.close()
      outputPdf
    }

  // =========================================================================
  // EXCEL (.XLSX) READER / FORMULA ENGINE / WRITER / PDF EXPORTER
  // =========================================================================

  suspend fun readXlsx(file: File): ExcelWorkbookModel =
    withContext(Dispatchers.IO) {
      val sharedStrings = mutableListOf<String>()
      readZipEntry(file, "xl/sharedStrings.xml")?.let { ssBytes ->
        val doc = parseXml(ssBytes)
        val siNodes = doc.getElementsByTagName("si")
        for (i in 0 until siNodes.length) {
          val el = siNodes.item(i) as? Element ?: continue
          val tNodes = el.getElementsByTagName("t")
          val sb = StringBuilder()
          for (j in 0 until tNodes.length) sb.append(tNodes.item(j).textContent.orEmpty())
          sharedStrings.add(sb.toString())
        }
      }

      val sheetNames = mutableListOf<String>()
      readZipEntry(file, "xl/workbook.xml")?.let { wbBytes ->
        val doc = parseXml(wbBytes)
        val sNodes = doc.getElementsByTagName("sheet")
        for (i in 0 until sNodes.length) {
          val el = sNodes.item(i) as? Element ?: continue
          sheetNames.add(el.getAttribute("name").ifBlank { "Sheet${i + 1}" })
        }
      }

      val sheets = mutableListOf<ExcelSheetModel>()
      var idx = 1
      while (true) {
        val sheetBytes = readZipEntry(file, "xl/worksheets/sheet$idx.xml") ?: break
        val doc = parseXml(sheetBytes)
        val cellMap = HashMap<Pair<Int, Int>, String>()
        var maxRow = 9
        var maxCol = 5
        val cNodes = doc.getElementsByTagName("c")
        for (i in 0 until cNodes.length) {
          val cEl = cNodes.item(i) as? Element ?: continue
          val ref = cEl.getAttribute("r")
          val rc = parseCellRef(ref) ?: continue
          maxRow = maxOf(maxRow, rc.first)
          maxCol = maxOf(maxCol, rc.second)
          val type = cEl.getAttribute("t")
          val formula = (cEl.getElementsByTagName("f").item(0) as? Element)?.textContent
          val valText = (cEl.getElementsByTagName("v").item(0) as? Element)?.textContent
          val inlineText = (cEl.getElementsByTagName("is").item(0) as? Element)?.textContent
          val display = when {
            !formula.isNullOrBlank() -> "=$formula"
            type == "s" && valText != null -> sharedStrings.getOrElse(valText.toIntOrNull() ?: -1) { "" }
            type == "inlineStr" -> inlineText.orEmpty()
            else -> valText.orEmpty()
          }
          cellMap[rc] = display
        }

        val grid = MutableList(maxRow + 1) { r ->
          MutableList(maxCol + 1) { c -> cellMap[r to c].orEmpty() }
        }
        sheets.add(ExcelSheetModel(sheetNames.getOrElse(idx - 1) { "Sheet$idx" }, grid))
        idx++
      }

      if (sheets.isEmpty()) {
        sheets.add(ExcelSheetModel("Sheet1", MutableList(10) { MutableList(6) { "" } }))
      }
      ExcelWorkbookModel(sheets)
    }

  suspend fun saveXlsx(workbook: ExcelWorkbookModel, outputFile: File): File =
    withContext(Dispatchers.IO) {
      outputFile.parentFile?.mkdirs()
      val contentTypes = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
        append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
        append("""<Default Extension="xml" ContentType="application/xml"/>""")
        append("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
        workbook.sheets.forEachIndexed { i, _ ->
          append("""<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
        }
        append("</Types>")
      }
      val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""
      val wbXml = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>""")
        workbook.sheets.forEachIndexed { i, s ->
          append("""<sheet name="${escapeXml(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>""")
        }
        append("</sheets></workbook>")
      }
      val wbRels = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
        workbook.sheets.forEachIndexed { i, _ ->
          append("""<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>""")
        }
        append("</Relationships>")
      }

      ZipOutputStream(FileOutputStream(outputFile)).use { zos ->
        putZipEntry(zos, "[Content_Types].xml", contentTypes.toByteArray(Charsets.UTF_8))
        putZipEntry(zos, "_rels/.rels", rootRels.toByteArray(Charsets.UTF_8))
        putZipEntry(zos, "xl/workbook.xml", wbXml.toByteArray(Charsets.UTF_8))
        putZipEntry(zos, "xl/_rels/workbook.xml.rels", wbRels.toByteArray(Charsets.UTF_8))

        workbook.sheets.forEachIndexed { idx, sheet ->
          val sheetXml = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
            append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
            sheet.rows.forEachIndexed { rIdx, row ->
              append("""<row r="${rIdx + 1}">""")
              row.forEachIndexed { cIdx, raw ->
                if (raw.isNotEmpty()) {
                  val ref = "${colIndexToLetter(cIdx)}${rIdx + 1}"
                  when {
                    raw.startsWith("=") -> {
                      val computed = evaluateCellDisplay(sheet, rIdx, cIdx)
                      val numTag = computed.toDoubleOrNull()?.let { "<v>$it</v>" } ?: ""
                      append("""<c r="$ref"><f>${escapeXml(raw.drop(1))}</f>$numTag</c>""")
                    }
                    raw.toDoubleOrNull() != null -> append("""<c r="$ref"><v>$raw</v></c>""")
                    else -> append("""<c r="$ref" t="inlineStr"><is><t>${escapeXml(raw)}</t></is></c>""")
                  }
                }
              }
              append("</row>")
            }
            append("</sheetData></worksheet>")
          }
          putZipEntry(zos, "xl/worksheets/sheet${idx + 1}.xml", sheetXml.toByteArray(Charsets.UTF_8))
        }
      }
      outputFile
    }

  fun evaluateCellDisplay(sheet: ExcelSheetModel, row: Int, col: Int, depth: Int = 0): String {
    if (depth > 8) return "#CYCLE!"
    val raw = sheet.rows.getOrNull(row)?.getOrNull(col).orEmpty()
    if (!raw.startsWith("=")) return raw
    val expr = raw.drop(1).trim().uppercase()

    val funcMatch = Regex("^(SUM|AVERAGE|AVG|MIN|MAX|COUNT)\\(([A-Z]+\\d+):([A-Z]+\\d+)\\)$").matchEntire(expr)
    if (funcMatch != null) {
      val fn = funcMatch.groupValues[1]
      val start = parseCellRef(funcMatch.groupValues[2]) ?: return "#REF!"
      val end = parseCellRef(funcMatch.groupValues[3]) ?: return "#REF!"
      val nums = mutableListOf<Double>()
      for (r in minOf(start.first, end.first)..maxOf(start.first, end.first)) {
        for (c in minOf(start.second, end.second)..maxOf(start.second, end.second)) {
          val v = evaluateCellDisplay(sheet, r, c, depth + 1).toDoubleOrNull()
          if (v != null) nums.add(v)
        }
      }
      val res = when (fn) {
        "SUM" -> nums.sum()
        "AVERAGE", "AVG" -> if (nums.isEmpty()) 0.0 else nums.sum() / nums.size
        "MIN" -> nums.minOrNull() ?: 0.0
        "MAX" -> nums.maxOrNull() ?: 0.0
        "COUNT" -> nums.size.toDouble()
        else -> 0.0
      }
      return formatNumber(res)
    }

    // Simple binary formula e.g. A1+B1, A1*2, A1-B1, A1/B1
    val binMatch = Regex("^([A-Z]+\\d+|\\d+(?:\\.\\d+)?)\\s*([+\\-*/])\\s*([A-Z]+\\d+|\\d+(?:\\.\\d+)?)$").matchEntire(expr)
    if (binMatch != null) {
      val left = resolveOperand(sheet, binMatch.groupValues[1], depth + 1) ?: return "#VALUE!"
      val op = binMatch.groupValues[2]
      val right = resolveOperand(sheet, binMatch.groupValues[3], depth + 1) ?: return "#VALUE!"
      val res = when (op) {
        "+" -> left + right
        "-" -> left - right
        "*" -> left * right
        "/" -> if (right == 0.0) return "#DIV/0!" else left / right
        else -> 0.0
      }
      return formatNumber(res)
    }
    return raw
  }

  private fun resolveOperand(sheet: ExcelSheetModel, token: String, depth: Int): Double? {
    token.toDoubleOrNull()?.let { return it }
    val rc = parseCellRef(token) ?: return null
    return evaluateCellDisplay(sheet, rc.first, rc.second, depth).toDoubleOrNull() ?: 0.0
  }

  suspend fun exportXlsxToPdf(sheet: ExcelSheetModel, outputPdf: File): File =
    withContext(Dispatchers.IO) {
      outputPdf.parentFile?.mkdirs()
      val pdf = PdfDocument()
      val pageW = 1680
      val pageH = 1240
      val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
      val canvas = page.canvas
      canvas.drawColor(Color.WHITE)

      val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 36f; isFakeBoldText = true }
      val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#111827"); textSize = 22f }
      val borderPaint = Paint().apply { color = Color.parseColor("#CBD5E1"); style = Paint.Style.STROKE; strokeWidth = 2f }
      val headerBg = Paint().apply { color = Color.parseColor("#E2E8F0"); style = Paint.Style.FILL }

      canvas.drawText(sheet.name, 60f, 70f, titlePaint)
      val cols = (sheet.rows.maxOfOrNull { it.size } ?: 1).coerceAtLeast(1).coerceAtMost(10)
      val cellW = (pageW - 120f) / cols
      val rowH = 44f
      var top = 110f

      for (rIdx in sheet.rows.indices.take(22)) {
        for (cIdx in 0 until cols) {
          val left = 60f + cIdx * cellW
          if (rIdx == 0) canvas.drawRect(left, top, left + cellW, top + rowH, headerBg)
          canvas.drawRect(left, top, left + cellW, top + rowH, borderPaint)
          val text = evaluateCellDisplay(sheet, rIdx, cIdx).take(18)
          canvas.drawText(text, left + 10f, top + 30f, cellPaint)
        }
        top += rowH
      }
      pdf.finishPage(page)
      FileOutputStream(outputPdf).use { pdf.writeTo(it) }
      pdf.close()
      outputPdf
    }

  // =========================================================================
  // POWERPOINT (.PPTX) READER / WRITER / PDF EXPORTER
  // =========================================================================

  suspend fun readPptx(file: File): PptDeckModel =
    withContext(Dispatchers.IO) {
      val slides = mutableListOf<PptSlideModel>()
      var idx = 1
      while (true) {
        val bytes = readZipEntry(file, "ppt/slides/slide$idx.xml") ?: break
        val doc = parseXml(bytes)
        val spNodes = doc.getElementsByTagName("p:sp")
        val textBlocks = mutableListOf<String>()
        for (i in 0 until spNodes.length) {
          val sp = spNodes.item(i) as? Element ?: continue
          val pList = sp.getElementsByTagName("a:p")
          val sb = StringBuilder()
          for (j in 0 until pList.length) {
            val pEl = pList.item(j) as? Element ?: continue
            val tNodes = pEl.getElementsByTagName("a:t")
            for (k in 0 until tNodes.length) sb.append(tNodes.item(k).textContent.orEmpty())
            if (j < pList.length - 1) sb.append("\n")
          }
          val txt = sb.toString().trim()
          if (txt.isNotEmpty()) textBlocks.add(txt)
        }
        val notes = readZipEntry(file, "ppt/notesSlides/notesSlide$idx.xml")?.let { nBytes ->
          val nd = parseXml(nBytes)
          val t = nd.getElementsByTagName("a:t")
          (0 until t.length).joinToString(" ") { t.item(it).textContent.orEmpty() }.trim()
        }.orEmpty()

        slides.add(
          PptSlideModel(
            index = idx,
            title = textBlocks.firstOrNull() ?: "Slide $idx",
            body = textBlocks.drop(1).joinToString("\n\n"),
            notes = notes,
          )
        )
        idx++
      }
      if (slides.isEmpty()) {
        slides.add(PptSlideModel(1, "New Presentation", "Add slide content here"))
      }
      PptDeckModel(slides)
    }

  suspend fun savePptx(deck: PptDeckModel, outputFile: File): File =
    withContext(Dispatchers.IO) {
      outputFile.parentFile?.mkdirs()
      val contentTypes = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
        append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
        append("""<Default Extension="xml" ContentType="application/xml"/>""")
        append("""<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>""")
        deck.slides.forEachIndexed { i, _ ->
          append("""<Override PartName="/ppt/slides/slide${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>""")
        }
        append("</Types>")
      }
      val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
</Relationships>"""
      val presXml = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><p:sldIdLst>""")
        deck.slides.forEachIndexed { i, _ -> append("""<p:sldId id="${256 + i}" r:id="rId${i + 1}"/>""") }
        append("</p:sldIdLst><p:sldSz cx=\"9144000\" cy=\"6858000\"/></p:presentation>")
      }
      val presRels = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
        deck.slides.forEachIndexed { i, _ ->
          append("""<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${i + 1}.xml"/>""")
        }
        append("</Relationships>")
      }

      ZipOutputStream(FileOutputStream(outputFile)).use { zos ->
        putZipEntry(zos, "[Content_Types].xml", contentTypes.toByteArray(Charsets.UTF_8))
        putZipEntry(zos, "_rels/.rels", rootRels.toByteArray(Charsets.UTF_8))
        putZipEntry(zos, "ppt/presentation.xml", presXml.toByteArray(Charsets.UTF_8))
        putZipEntry(zos, "ppt/_rels/presentation.xml.rels", presRels.toByteArray(Charsets.UTF_8))

        deck.slides.forEachIndexed { idx, slide ->
          val bodyParas = slide.body.lines().joinToString("") { line ->
            "<a:p><a:r><a:t>${escapeXml(line)}</a:t></a:r></a:p>"
          }
          val slideXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
  <p:cSld><p:spTree>
    <p:sp><p:txBody><a:bodyPr/><a:p><a:r><a:t>${escapeXml(slide.title)}</a:t></a:r></a:p></p:txBody></p:sp>
    <p:sp><p:txBody><a:bodyPr/>$bodyParas</p:txBody></p:sp>
  </p:spTree></p:cSld>
</p:sld>"""
          putZipEntry(zos, "ppt/slides/slide${idx + 1}.xml", slideXml.toByteArray(Charsets.UTF_8))
        }
      }
      outputFile
    }

  suspend fun exportPptxToPdf(deck: PptDeckModel, outputPdf: File): File =
    withContext(Dispatchers.IO) {
      outputPdf.parentFile?.mkdirs()
      val pdf = PdfDocument()
      val w = 1600
      val h = 900
      val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F8FAFC"); textSize = 54f; isFakeBoldText = true }
      val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CBD5E1"); textSize = 32f }
      val accentPaint = Paint().apply { color = Color.parseColor("#38BDF8") }

      deck.slides.forEachIndexed { idx, slide ->
        val page = pdf.startPage(PdfDocument.PageInfo.Builder(w, h, idx + 1).create())
        val canvas = page.canvas
        canvas.drawColor(Color.parseColor("#0F172A"))
        canvas.drawRect(0f, 0f, w.toFloat(), 16f, accentPaint)
        canvas.drawText(slide.title, 90f, 140f, titlePaint)
        var y = 240f
        for (line in slide.body.lines()) {
          for (wrapped in wrapText(line, bodyPaint, w - 180f)) {
            if (y < h - 80f) canvas.drawText(wrapped, 90f, y, bodyPaint)
            y += 46f
          }
        }
        pdf.finishPage(page)
      }
      FileOutputStream(outputPdf).use { pdf.writeTo(it) }
      pdf.close()
      outputPdf
    }

  // =========================================================================
  // PDF RENDER / ANNOTATE / REORDER / EXPORT
  // =========================================================================

  suspend fun renderPdfPages(pdfFile: File, scale: Float = 1.6f): List<Bitmap> =
    withContext(Dispatchers.IO) {
      val list = mutableListOf<Bitmap>()
      ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
        PdfRenderer(pfd).use { renderer ->
          for (i in 0 until renderer.pageCount) {
            renderer.openPage(i).use { page ->
              val w = (page.width * scale).toInt().coerceAtLeast(100)
              val h = (page.height * scale).toInt().coerceAtLeast(100)
              val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
              bmp.eraseColor(Color.WHITE)
              page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
              list.add(bmp)
            }
          }
        }
      }
      list
    }

  suspend fun exportAnnotatedPdf(
    sourcePdf: File,
    outputPdf: File,
    pageOrder: List<Int>,
    strokes: List<PdfStrokeAnnotation>,
    texts: List<PdfTextAnnotation>,
  ): File =
    withContext(Dispatchers.IO) {
      outputPdf.parentFile?.mkdirs()
      val rendered = renderPdfPages(sourcePdf, scale = 1.5f)
      val pdf = PdfDocument()
      try {
        pageOrder.forEachIndexed { outIdx, origPageIdx ->
          val bmp = rendered.getOrNull(origPageIdx) ?: return@forEachIndexed
          val page = pdf.startPage(PdfDocument.PageInfo.Builder(bmp.width, bmp.height, outIdx + 1).create())
          val canvas = page.canvas
          canvas.drawBitmap(bmp, 0f, 0f, null)

          for (s in strokes.filter { it.pageIndex == origPageIdx }) {
            if (s.points.size < 2) continue
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = s.colorArgb
              strokeWidth = s.strokeWidth
              style = Paint.Style.STROKE
              strokeCap = Paint.Cap.ROUND
              strokeJoin = Paint.Join.ROUND
            }
            val path = Path()
            s.points.forEachIndexed { i, (nx, ny) ->
              val px = nx * bmp.width
              val py = ny * bmp.height
              if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            canvas.drawPath(path, paint)
          }

          for (t in texts.filter { it.pageIndex == origPageIdx }) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = t.colorArgb
              textSize = 28f
              isFakeBoldText = true
            }
            canvas.drawText(t.text, t.xNorm * bmp.width, t.yNorm * bmp.height, paint)
          }
          pdf.finishPage(page)
        }
        FileOutputStream(outputPdf).use { pdf.writeTo(it) }
      } finally {
        rendered.forEach { it.recycle() }
        pdf.close()
      }
      outputPdf
    }

  // =========================================================================
  // HELPERS
  // =========================================================================

  private fun readZipEntry(file: File, entryPath: String): ByteArray? =
    runCatching {
      ZipFile(file).use { zf ->
        val entry = zf.getEntry(entryPath) ?: return null
        zf.getInputStream(entry).use { it.readBytes() }
      }
    }.getOrNull()

  private fun putZipEntry(zos: ZipOutputStream, name: String, data: ByteArray) {
    zos.putNextEntry(ZipEntry(name))
    zos.write(data)
    zos.closeEntry()
  }

  private fun parseXml(bytes: ByteArray) =
    DocumentBuilderFactory.newInstance().apply {
      isNamespaceAware = false
      runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
    }.newDocumentBuilder().parse(ByteArrayInputStream(bytes))

  private fun parseCellRef(ref: String): Pair<Int, Int>? {
    val clean = ref.trim().uppercase()
    var split = 0
    while (split < clean.length && clean[split] in 'A'..'Z') split++
    if (split == 0 || split == clean.length) return null
    val colStr = clean.substring(0, split)
    val rowNum = clean.substring(split).toIntOrNull() ?: return null
    var col = 0
    for (ch in colStr) col = col * 26 + (ch - 'A' + 1)
    return (rowNum - 1) to (col - 1)
  }

  fun colIndexToLetter(index: Int): String {
    var n = index + 1
    val sb = StringBuilder()
    while (n > 0) {
      val rem = (n - 1) % 26
      sb.append(('A'.code + rem).toChar())
      n = (n - 1) / 26
    }
    return sb.reverse().toString()
  }

  private fun formatNumber(d: Double): String =
    if (d % 1.0 == 0.0) d.toLong().toString() else String.format(java.util.Locale.US, "%.2f", d)

  private fun wrapText(text: String, paint: Paint, maxW: Float): List<String> {
    if (text.isEmpty()) return emptyList()
    val words = text.split(" ")
    val lines = mutableListOf<String>()
    var curr = StringBuilder()
    for (w in words) {
      val candidate = if (curr.isEmpty()) w else "$curr $w"
      if (paint.measureText(candidate) <= maxW) {
        curr = StringBuilder(candidate)
      } else {
        if (curr.isNotEmpty()) lines.add(curr.toString())
        curr = StringBuilder(w)
      }
    }
    if (curr.isNotEmpty()) lines.add(curr.toString())
    return lines
  }

  private fun escapeXml(s: String): String =
    s.replace("&", "&amp;")
      .replace("<", "&lt;")
      .replace(">", "&gt;")
      .replace("\"", "&quot;")
      .replace("'", "&apos;")
}
