package com.example.domain.archive

import com.example.domain.fs.ConflictAction
import com.example.domain.fs.ConflictChoice
import com.example.domain.fs.FileConflictInfo
import com.example.domain.fs.FileSourceType
import com.example.domain.fs.VirtualFileNode
import com.example.domain.fs.nextAvailableNumberedFile
import com.github.junrar.Archive as RarArchive
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionLevel
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod
import net.sf.sevenzipjbinding.ArchiveFormat as SevenZipFormat
import net.sf.sevenzipjbinding.ExtractAskMode
import net.sf.sevenzipjbinding.ExtractOperationResult
import net.sf.sevenzipjbinding.IArchiveExtractCallback
import net.sf.sevenzipjbinding.IArchiveOpenCallback
import net.sf.sevenzipjbinding.ICryptoGetTextPassword
import net.sf.sevenzipjbinding.ISequentialOutStream
import net.sf.sevenzipjbinding.PropID
import net.sf.sevenzipjbinding.SevenZip
import net.sf.sevenzipjbinding.impl.RandomAccessFileInStream
import org.apache.commons.compress.archivers.ArchiveEntry
import org.apache.commons.compress.archivers.ArchiveInputStream
import org.apache.commons.compress.archivers.ArchiveOutputStream
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZMethod
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.apache.commons.compress.compressors.gzip.GzipParameters
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream
import org.tukaani.xz.LZMA2Options
import org.tukaani.xz.XZOutputStream
import java.util.zip.Deflater

enum class ArchiveFormat(
  val extension: String,
  val displayName: String,
  val canCompress: Boolean = true,
  val supportsPassword: Boolean = false,
) {
  ZIP("zip", "ZIP", true, true),
  SEVEN_Z("7z", "7-Zip (LZMA2)", true, false),
  TAR("tar", "TAR (Uncompressed)", true, false),
  TAR_GZ("tar.gz", "TAR.GZ (Gzip)", true, false),
  TAR_BZ2("tar.bz2", "TAR.BZ2 (BZip2)", true, false),
  TAR_XZ("tar.xz", "TAR.XZ (LZMA)", true, false),
  GZ("gz", "GZIP (Single)", true, false),
  BZ2("bz2", "BZIP2 (Single)", true, false),
  XZ("xz", "XZ (Single)", true, false),
  RAR("rar", "RAR4 / RAR5 (Extract/Browse)", false, true),
  APK("apk", "APK Package", true, false),
  JAR("jar", "JAR Archive", true, false);

  companion object {
    fun detect(fileName: String): ArchiveFormat? {
      val lower = fileName.lowercase(Locale.ROOT)
      return when {
        lower.endsWith(".tar.gz") || lower.endsWith(".tgz") -> TAR_GZ
        lower.endsWith(".tar.bz2") || lower.endsWith(".tbz2") -> TAR_BZ2
        lower.endsWith(".tar.xz") || lower.endsWith(".txz") -> TAR_XZ
        lower.endsWith(".zip") -> ZIP
        lower.endsWith(".7z") -> SEVEN_Z
        lower.endsWith(".tar") -> TAR
        lower.endsWith(".gz") -> GZ
        lower.endsWith(".bz2") -> BZ2
        lower.endsWith(".xz") -> XZ
        lower.endsWith(".rar") || lower.endsWith(".cbr") || lower.endsWith(".r00") -> RAR
        lower.endsWith(".apk") || lower.endsWith(".apks") || lower.endsWith(".xapk") -> APK
        lower.endsWith(".jar") || lower.endsWith(".war") -> JAR
        else -> null
      }
    }

    val creatableFormats: List<ArchiveFormat>
      get() = listOf(ZIP, SEVEN_Z, TAR_XZ, TAR_GZ, TAR_BZ2, TAR, XZ, GZ, BZ2)
  }
}

class ArchiveEngine {

  @Volatile
  private var sevenZipInitialized: Boolean? = null

  private fun ensureSevenZipReady(): Boolean {
    sevenZipInitialized?.let { return it }
    val ok = runCatching {
      SevenZip.initSevenZipFromPlatformJAR()
      true
    }.getOrDefault(false)
    sevenZipInitialized = ok
    return ok
  }

  suspend fun listEntriesAtPath(
    archiveFile: File,
    virtualSubPath: String = "",
    password: String? = null,
  ): List<VirtualFileNode> =
    withContext(Dispatchers.IO) {
      val prefix = virtualSubPath.trim('/').let { if (it.isEmpty()) "" else "$it/" }
      val allEntries = readAllEntries(archiveFile, password)
      val foldersSeen = LinkedHashSet<String>()
      val result = mutableListOf<VirtualFileNode>()

      for (entry in allEntries) {
        val norm = entry.path.trimStart('/').replace('\\', '/')
        if (norm.isEmpty() || !norm.startsWith(prefix)) continue
        val remainder = norm.removePrefix(prefix).trimEnd('/')
        if (remainder.isEmpty()) continue

        val slashIdx = remainder.indexOf('/')
        if (slashIdx >= 0) {
          val dirName = remainder.substring(0, slashIdx)
          if (foldersSeen.add(dirName)) {
            val fullEntryPath = "$prefix$dirName"
            result.add(
              VirtualFileNode(
                name = dirName,
                path = buildArchiveUri(archiveFile.absolutePath, fullEntryPath),
                isDirectory = true,
                size = 0L,
                lastModified = entry.lastModified,
                sourceType = FileSourceType.ARCHIVE,
                archivePath = archiveFile.absolutePath,
                entryPathInArchive = fullEntryPath,
              )
            )
          }
        } else if (entry.isDirectory) {
          if (foldersSeen.add(remainder)) {
            val fullEntryPath = "$prefix$remainder"
            result.add(
              VirtualFileNode(
                name = remainder,
                path = buildArchiveUri(archiveFile.absolutePath, fullEntryPath),
                isDirectory = true,
                size = 0L,
                lastModified = entry.lastModified,
                sourceType = FileSourceType.ARCHIVE,
                archivePath = archiveFile.absolutePath,
                entryPathInArchive = fullEntryPath,
              )
            )
          }
        } else {
          result.add(
            VirtualFileNode(
              name = remainder,
              path = buildArchiveUri(archiveFile.absolutePath, norm),
              isDirectory = false,
              size = entry.size,
              lastModified = entry.lastModified,
              sourceType = FileSourceType.ARCHIVE,
              archivePath = archiveFile.absolutePath,
              entryPathInArchive = norm,
            )
          )
        }
      }

      result.sortedWith(compareBy<VirtualFileNode> { !it.isDirectory }.thenBy { it.name.lowercase() })
    }

  private data class RawArchiveEntry(
    val path: String,
    val isDirectory: Boolean,
    val size: Long,
    val lastModified: Long,
  )

  private fun readAllEntries(archiveFile: File, password: String?): List<RawArchiveEntry> {
    val format = ArchiveFormat.detect(archiveFile.name) ?: ArchiveFormat.ZIP
    val list = mutableListOf<RawArchiveEntry>()
    when (format) {
      ArchiveFormat.ZIP,
      ArchiveFormat.APK,
      ArchiveFormat.JAR -> {
        val zf = ZipFile(archiveFile)
        if (!password.isNullOrEmpty() && zf.isEncrypted) {
          zf.setPassword(password.toCharArray())
        }
        for (fh in zf.fileHeaders) {
          list.add(
            RawArchiveEntry(
              path = fh.fileName,
              isDirectory = fh.isDirectory,
              size = fh.uncompressedSize,
              lastModified = fh.lastModifiedTimeEpoch,
            )
          )
        }
      }

      ArchiveFormat.SEVEN_Z -> {
        openSevenZFile(archiveFile).use { sz ->
          var entry: SevenZArchiveEntry? = sz.nextEntry
          while (entry != null) {
            list.add(
              RawArchiveEntry(
                path = entry.name,
                isDirectory = entry.isDirectory,
                size = entry.size,
                lastModified =
                  if (entry.hasLastModifiedDate) entry.lastModifiedDate.time else 0L,
              )
            )
            entry = sz.nextEntry
          }
        }
      }

      ArchiveFormat.RAR -> {
        val sevenZipEntries = tryReadRarWithSevenZip(archiveFile, password)
        if (sevenZipEntries != null) {
          list.addAll(sevenZipEntries)
        } else {
          RarArchive(archiveFile).use { rar ->
            for (fh in rar.fileHeaders) {
              list.add(
                RawArchiveEntry(
                  path = fh.fileName.replace('\\', '/'),
                  isDirectory = fh.isDirectory,
                  size = fh.fullUnpackSize,
                  lastModified = fh.mTime?.time ?: 0L,
                )
              )
            }
          }
        }
      }

      ArchiveFormat.TAR,
      ArchiveFormat.TAR_GZ,
      ArchiveFormat.TAR_BZ2,
      ArchiveFormat.TAR_XZ -> {
        openTarStream(archiveFile, format).use { tis ->
          var entry: ArchiveEntry? = tis.nextEntry
          while (entry != null) {
            list.add(
              RawArchiveEntry(
                path = entry.name,
                isDirectory = entry.isDirectory,
                size = entry.size,
                lastModified = entry.lastModifiedDate?.time ?: 0L,
              )
            )
            entry = tis.nextEntry
          }
        }
      }

      ArchiveFormat.GZ,
      ArchiveFormat.BZ2,
      ArchiveFormat.XZ -> {
        val innerName = archiveFile.name.substringBeforeLast('.', "extracted_file")
        list.add(
          RawArchiveEntry(
            path = innerName,
            isDirectory = false,
            size = archiveFile.length(),
            lastModified = archiveFile.lastModified(),
          )
        )
      }
    }
    return list
  }

  suspend fun extractEntryBytes(
    archiveFile: File,
    entryPath: String,
    password: String? = null,
  ): ByteArray =
    withContext(Dispatchers.IO) {
      val normalized = entryPath.trimStart('/').replace('\\', '/')
      val format = ArchiveFormat.detect(archiveFile.name) ?: ArchiveFormat.ZIP
      when (format) {
        ArchiveFormat.ZIP,
        ArchiveFormat.APK,
        ArchiveFormat.JAR -> {
          val zf = ZipFile(archiveFile)
          if (!password.isNullOrEmpty() && zf.isEncrypted) {
            zf.setPassword(password.toCharArray())
          }
          val fh = zf.getFileHeader(normalized) ?: zf.getFileHeader("$normalized/")
          if (fh != null) {
            zf.getInputStream(fh).use { it.readBytes() }
          } else {
            ByteArray(0)
          }
        }

        ArchiveFormat.SEVEN_Z -> {
          openSevenZFile(archiveFile).use { sz ->
            var entry = sz.nextEntry
            while (entry != null) {
              if (entry.name.trimStart('/') == normalized) {
                val out = ByteArray(entry.size.toInt().coerceAtLeast(0))
                var off = 0
                while (off < out.size) {
                  val read = sz.read(out, off, out.size - off)
                  if (read <= 0) break
                  off += read
                }
                return@withContext out
              }
              entry = sz.nextEntry
            }
          }
          ByteArray(0)
        }

        ArchiveFormat.RAR -> {
          val sevenZipBytes = tryExtractRarEntryWithSevenZip(archiveFile, normalized, password)
          if (sevenZipBytes != null) {
            return@withContext sevenZipBytes
          }
          RarArchive(archiveFile).use { rar ->
            val fh =
              rar.fileHeaders.find {
                it.fileName.replace('\\', '/').trimStart('/') == normalized
              }
            if (fh != null) {
              val baos = ByteArrayOutputStream()
              rar.extractFile(fh, baos)
              return@withContext baos.toByteArray()
            }
          }
          ByteArray(0)
        }

        ArchiveFormat.TAR,
        ArchiveFormat.TAR_GZ,
        ArchiveFormat.TAR_BZ2,
        ArchiveFormat.TAR_XZ -> {
          openTarStream(archiveFile, format).use { tis ->
            var entry = tis.nextEntry
            while (entry != null) {
              if (entry.name.trimStart('/') == normalized) {
                return@withContext tis.readBytes()
              }
              entry = tis.nextEntry
            }
          }
          ByteArray(0)
        }

        ArchiveFormat.GZ -> GzipCompressorInputStream(BufferedInputStream(FileInputStream(archiveFile))).use { it.readBytes() }
        ArchiveFormat.BZ2 -> BZip2CompressorInputStream(BufferedInputStream(FileInputStream(archiveFile))).use { it.readBytes() }
        ArchiveFormat.XZ -> XZCompressorInputStream(BufferedInputStream(FileInputStream(archiveFile))).use { it.readBytes() }
      }
    }

  suspend fun extractArchive(
    archiveFile: File,
    destDir: File,
    password: String? = null,
    onProgress: (Int) -> Unit = {},
    onConflict: (suspend (FileConflictInfo) -> ConflictChoice)? = null,
  ): Int =
    withContext(Dispatchers.IO) {
      destDir.mkdirs()
      val format = ArchiveFormat.detect(archiveFile.name) ?: ArchiveFormat.ZIP
      var count = 0
      var cachedAction: ConflictAction? = null
      onProgress(5)

      suspend fun pickOutputTarget(
        candidate: File,
        sourceSize: Long,
        sourceModified: Long,
        remainingItems: Int = 0,
      ): File? {
        if (!candidate.exists() || onConflict == null) return candidate
        val action = cachedAction ?: run {
          val info =
            FileConflictInfo(
              fileName = candidate.name,
              destPath = candidate.absolutePath,
              sourceSize = sourceSize,
              existingSize = if (candidate.isFile) candidate.length() else 0L,
              sourceModified = sourceModified,
              existingModified = candidate.lastModified(),
              remainingItems = remainingItems.coerceAtLeast(0),
            )
          val choice = onConflict.invoke(info)
          if (choice.applyToAll) cachedAction = choice.action
          choice.action
        }
        return when (action) {
          ConflictAction.REPLACE -> candidate
          ConflictAction.KEEP_BOTH -> nextAvailableNumberedFile(candidate)
          ConflictAction.SKIP -> null
        }
      }

      when (format) {
        ArchiveFormat.ZIP,
        ArchiveFormat.APK,
        ArchiveFormat.JAR -> {
          val zf = ZipFile(archiveFile)
          if (!password.isNullOrEmpty() && zf.isEncrypted) {
            zf.setPassword(password.toCharArray())
          }
          val headers = zf.fileHeaders
          val total = headers.size.coerceAtLeast(1)
          for ((idx, fh) in headers.withIndex()) {
            val outFile = safeResolve(destDir, fh.fileName)
            if (fh.isDirectory) {
              outFile.mkdirs()
            } else {
              val resolved =
                pickOutputTarget(
                  outFile,
                  fh.uncompressedSize,
                  fh.lastModifiedTimeEpoch,
                  remainingItems = (headers.size - idx - 1).coerceAtLeast(0),
                )
              if (resolved != null) {
                resolved.parentFile?.mkdirs()
                zf.getInputStream(fh).use { inp ->
                  FileOutputStream(resolved).use { out -> inp.copyTo(out) }
                }
                count++
              }
            }
            onProgress(((idx + 1) * 100) / total)
          }
        }

        ArchiveFormat.SEVEN_Z -> {
          openSevenZFile(archiveFile).use { sz ->
            val buf = ByteArray(16384)
            var entry = sz.nextEntry
            while (entry != null) {
              val outFile = safeResolve(destDir, entry.name)
              if (entry.isDirectory) {
                outFile.mkdirs()
              } else {
                val mTime = if (entry.hasLastModifiedDate) entry.lastModifiedDate.time else 0L
                val resolved = pickOutputTarget(outFile, entry.size, mTime)
                if (resolved != null) {
                  resolved.parentFile?.mkdirs()
                  FileOutputStream(resolved).use { fos ->
                    while (true) {
                      val r = sz.read(buf)
                      if (r <= 0) break
                      fos.write(buf, 0, r)
                    }
                  }
                  count++
                }
              }
              entry = sz.nextEntry
            }
          }
          onProgress(100)
        }

        ArchiveFormat.RAR -> {
          val rarHandledCount =
            tryExtractRarWithSevenZip(
              archiveFile = archiveFile,
              destDir = destDir,
              password = password,
              onProgress = onProgress,
              pickOutputTarget = { candidate, size, mTime, rem -> pickOutputTarget(candidate, size, mTime, rem) },
            )
          if (rarHandledCount != null) {
            count = rarHandledCount
          } else {
            RarArchive(archiveFile).use { rar ->
              val headers = rar.fileHeaders
              val total = headers.size.coerceAtLeast(1)
              for ((idx, fh) in headers.withIndex()) {
                val cleanName = fh.fileName.replace('\\', '/')
                val outFile = safeResolve(destDir, cleanName)
                if (fh.isDirectory) {
                  outFile.mkdirs()
                } else {
                  val resolved =
                    pickOutputTarget(
                      outFile,
                      fh.fullUnpackSize,
                      fh.mTime?.time ?: 0L,
                      remainingItems = (headers.size - idx - 1).coerceAtLeast(0),
                    )
                  if (resolved != null) {
                    resolved.parentFile?.mkdirs()
                    FileOutputStream(resolved).use { fos -> rar.extractFile(fh, fos) }
                    count++
                  }
                }
                onProgress(((idx + 1) * 100) / total)
              }
            }
          }
        }

        ArchiveFormat.TAR,
        ArchiveFormat.TAR_GZ,
        ArchiveFormat.TAR_BZ2,
        ArchiveFormat.TAR_XZ -> {
          openTarStream(archiveFile, format).use { tis ->
            var entry = tis.nextEntry
            while (entry != null) {
              val outFile = safeResolve(destDir, entry.name)
              if (entry.isDirectory) {
                outFile.mkdirs()
              } else {
                val resolved = pickOutputTarget(outFile, entry.size, entry.lastModifiedDate?.time ?: 0L)
                if (resolved != null) {
                  resolved.parentFile?.mkdirs()
                  FileOutputStream(resolved).use { fos -> tis.copyTo(fos) }
                  count++
                }
              }
              entry = tis.nextEntry
            }
          }
          onProgress(100)
        }

        ArchiveFormat.GZ,
        ArchiveFormat.BZ2,
        ArchiveFormat.XZ -> {
          val outName = archiveFile.name.substringBeforeLast('.', "extracted")
          val outFile = safeResolve(destDir, outName)
          val resolved = pickOutputTarget(outFile, archiveFile.length(), archiveFile.lastModified())
          if (resolved != null) {
            resolved.parentFile?.mkdirs()
            val stream: InputStream =
              when (format) {
                ArchiveFormat.GZ -> GzipCompressorInputStream(BufferedInputStream(FileInputStream(archiveFile)))
                ArchiveFormat.BZ2 -> BZip2CompressorInputStream(BufferedInputStream(FileInputStream(archiveFile)))
                else -> XZCompressorInputStream(BufferedInputStream(FileInputStream(archiveFile)))
              }
            stream.use { inp -> FileOutputStream(resolved).use { out -> inp.copyTo(out) } }
            count = 1
          }
          onProgress(100)
        }
      }
      count
    }

  private fun createOpenCallback(password: String?): IArchiveOpenCallback {
    return object : IArchiveOpenCallback, ICryptoGetTextPassword {
      override fun setTotal(files: Long?, bytes: Long?) {}
      override fun setCompleted(files: Long?, bytes: Long?) {}
      override fun cryptoGetTextPassword(): String = password.orEmpty()
    }
  }

  private fun tryReadRarWithSevenZip(archiveFile: File, password: String?): List<RawArchiveEntry>? {
    if (!ensureSevenZipReady()) return null
    return runCatching {
      val result = mutableListOf<RawArchiveEntry>()
      RandomAccessFile(archiveFile, "r").use { raf ->
        SevenZip.openInArchive(null, RandomAccessFileInStream(raf), createOpenCallback(password)).use { inArchive ->
          for (i in 0 until inArchive.numberOfItems) {
            val path = (inArchive.getProperty(i, PropID.PATH) as? String)?.replace('\\', '/').orEmpty()
            if (path.isBlank()) continue
            val isDir = (inArchive.getProperty(i, PropID.IS_FOLDER) as? Boolean) ?: false
            val size = (inArchive.getProperty(i, PropID.SIZE) as? Number)?.toLong() ?: 0L
            val mTime = (inArchive.getProperty(i, PropID.LAST_MODIFICATION_TIME) as? Date)?.time ?: 0L
            result.add(RawArchiveEntry(path = path, isDirectory = isDir, size = size, lastModified = mTime))
          }
        }
      }
      result
    }.getOrNull()
  }

  private fun tryExtractRarEntryWithSevenZip(
    archiveFile: File,
    normalizedEntryPath: String,
    password: String?,
  ): ByteArray? {
    if (!ensureSevenZipReady()) return null
    return runCatching {
      RandomAccessFile(archiveFile, "r").use { raf ->
        SevenZip.openInArchive(null, RandomAccessFileInStream(raf), createOpenCallback(password)).use { inArchive ->
          var targetIdx = -1
          for (i in 0 until inArchive.numberOfItems) {
            val path = (inArchive.getProperty(i, PropID.PATH) as? String)
              ?.replace('\\', '/')
              ?.trimStart('/')
              .orEmpty()
            if (path == normalizedEntryPath) {
              targetIdx = i
              break
            }
          }
          if (targetIdx < 0) return@use ByteArray(0)
          val baos = ByteArrayOutputStream()
          var opResult: ExtractOperationResult? = null
          val cb =
            object : IArchiveExtractCallback, ICryptoGetTextPassword {
              override fun getStream(index: Int, extractAskMode: ExtractAskMode): ISequentialOutStream? {
                if (extractAskMode != ExtractAskMode.EXTRACT || index != targetIdx) return null
                return ISequentialOutStream { data ->
                  baos.write(data)
                  data.size
                }
              }
              override fun prepareOperation(extractAskMode: ExtractAskMode) {}
              override fun setOperationResult(extractOperationResult: ExtractOperationResult) {
                opResult = extractOperationResult
              }
              override fun setTotal(total: Long) {}
              override fun setCompleted(complete: Long) {}
              override fun cryptoGetTextPassword(): String = password.orEmpty()
            }
          inArchive.extract(intArrayOf(targetIdx), false, cb)
          if (opResult == ExtractOperationResult.WRONG_PASSWORD) {
            throw SecurityException("Wrong password for RAR archive")
          }
          baos.toByteArray()
        }
      }
    }.getOrNull()
  }

  private suspend fun tryExtractRarWithSevenZip(
    archiveFile: File,
    destDir: File,
    password: String?,
    onProgress: (Int) -> Unit,
    pickOutputTarget: suspend (File, Long, Long, Int) -> File?,
  ): Int? {
    if (!ensureSevenZipReady()) return null
    val resolvedTargets = HashMap<Int, File>()
    val indicesToExtract = mutableListOf<Int>()
    val opened = runCatching {
      RandomAccessFile(archiveFile, "r").use { raf ->
        SevenZip.openInArchive(null, RandomAccessFileInStream(raf), createOpenCallback(password)).use { inArchive ->
          val total = inArchive.numberOfItems
          for (i in 0 until total) {
            val rawPath = (inArchive.getProperty(i, PropID.PATH) as? String)?.replace('\\', '/') ?: continue
            if (rawPath.isBlank()) continue
            val isDir = (inArchive.getProperty(i, PropID.IS_FOLDER) as? Boolean) ?: false
            val candidate = safeResolve(destDir, rawPath)
            if (isDir) {
              candidate.mkdirs()
            } else {
              val size = (inArchive.getProperty(i, PropID.SIZE) as? Number)?.toLong() ?: 0L
              val mTime = (inArchive.getProperty(i, PropID.LAST_MODIFICATION_TIME) as? Date)?.time ?: 0L
              val target = pickOutputTarget(candidate, size, mTime, (total - i - 1).coerceAtLeast(0))
              if (target != null) {
                resolvedTargets[i] = target
                indicesToExtract.add(i)
              }
            }
          }
          if (indicesToExtract.isEmpty()) {
            onProgress(100)
            return@use 0
          }
          val totalToExtract = indicesToExtract.size.coerceAtLeast(1)
          var extracted = 0
          var opFailure: ExtractOperationResult? = null
          var currentFos: FileOutputStream? = null
          val cb =
            object : IArchiveExtractCallback, ICryptoGetTextPassword {
              override fun getStream(index: Int, extractAskMode: ExtractAskMode): ISequentialOutStream? {
                runCatching { currentFos?.close() }
                currentFos = null
                if (extractAskMode != ExtractAskMode.EXTRACT) return null
                val targetFile = resolvedTargets[index] ?: return null
                targetFile.parentFile?.mkdirs()
                val fos = FileOutputStream(targetFile)
                currentFos = fos
                return ISequentialOutStream { data ->
                  fos.write(data)
                  data.size
                }
              }
              override fun prepareOperation(extractAskMode: ExtractAskMode) {}
              override fun setOperationResult(extractOperationResult: ExtractOperationResult) {
                runCatching { currentFos?.flush(); currentFos?.close() }
                currentFos = null
                if (extractOperationResult == ExtractOperationResult.OK) {
                  extracted++
                  onProgress((extracted * 100) / totalToExtract)
                } else {
                  opFailure = extractOperationResult
                }
              }
              override fun setTotal(total: Long) {}
              override fun setCompleted(complete: Long) {}
              override fun cryptoGetTextPassword(): String = password.orEmpty()
            }
          inArchive.extract(indicesToExtract.toIntArray(), false, cb)
          runCatching { currentFos?.close() }
          if (opFailure == ExtractOperationResult.WRONG_PASSWORD) {
            throw SecurityException("Wrong password for RAR archive")
          }
          extracted
        }
      }
    }
    return opened.getOrNull()
  }

  suspend fun createArchive(
    sources: List<File>,
    outputFile: File,
    format: ArchiveFormat,
    level: Int,
    password: String? = null,
    onProgress: (Int) -> Unit = {},
  ): File =
    withContext(Dispatchers.IO) {
      val clampedLevel = level.coerceIn(0, 9)
      outputFile.parentFile?.mkdirs()
      if (outputFile.exists()) outputFile.delete()
      onProgress(5)

      val flatFiles = collectAllFiles(sources)
      val totalFiles = flatFiles.size.coerceAtLeast(1)

      when (format) {
        ArchiveFormat.ZIP,
        ArchiveFormat.APK,
        ArchiveFormat.JAR -> {
          val zf = ZipFile(outputFile)
          val hasPwd = !password.isNullOrEmpty() && format == ArchiveFormat.ZIP
          if (hasPwd) zf.setPassword(password.orEmpty().toCharArray())

          val params =
            ZipParameters().apply {
              compressionMethod =
                if (clampedLevel == 0) CompressionMethod.STORE else CompressionMethod.DEFLATE
              compressionLevel = mapZip4jLevel(clampedLevel)
              if (hasPwd) {
                isEncryptFiles = true
                encryptionMethod = EncryptionMethod.AES
                aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256
              }
            }

          for ((idx, item) in flatFiles.withIndex()) {
            val itemParams = ZipParameters(params).apply { fileNameInZip = item.relativePath }
            if (item.file.isDirectory) {
              zf.addFolder(item.file, itemParams)
            } else {
              zf.addFile(item.file, itemParams)
            }
            onProgress(((idx + 1) * 100) / totalFiles)
          }
        }

        ArchiveFormat.SEVEN_Z -> {
          SevenZOutputFile(outputFile).use { szOut ->
            val method =
              when {
                clampedLevel == 0 -> SevenZMethod.COPY
                clampedLevel <= 3 -> SevenZMethod.DEFLATE
                else -> SevenZMethod.LZMA2
              }
            szOut.setContentCompression(method)
            val buf = ByteArray(16384)
            for ((idx, item) in flatFiles.withIndex()) {
              val entry = szOut.createArchiveEntry(item.file, item.relativePath)
              putSevenZEntry(szOut, entry)
              if (!item.file.isDirectory) {
                FileInputStream(item.file).use { fis ->
                  while (true) {
                    val r = fis.read(buf)
                    if (r <= 0) break
                    szOut.write(buf, 0, r)
                  }
                }
              }
              szOut.closeArchiveEntry()
              onProgress(((idx + 1) * 100) / totalFiles)
            }
            szOut.finish()
          }
        }

        ArchiveFormat.TAR,
        ArchiveFormat.TAR_GZ,
        ArchiveFormat.TAR_BZ2,
        ArchiveFormat.TAR_XZ -> {
          val baseStream = BufferedOutputStream(FileOutputStream(outputFile))
          val wrappedStream: OutputStream =
            when (format) {
              ArchiveFormat.TAR -> baseStream
              ArchiveFormat.TAR_GZ -> {
                val gzParams =
                  GzipParameters().apply {
                    compressionLevel = clampedLevel.coerceIn(Deflater.NO_COMPRESSION, Deflater.BEST_COMPRESSION)
                  }
                GzipCompressorOutputStream(baseStream, gzParams)
              }
              ArchiveFormat.TAR_BZ2 -> BZip2CompressorOutputStream(baseStream, clampedLevel.coerceIn(1, 9))
              ArchiveFormat.TAR_XZ -> XZOutputStream(baseStream, LZMA2Options(clampedLevel))
            }
          TarArchiveOutputStream(wrappedStream).apply {
            setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
            setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX)
          }.use { tos ->
            @Suppress("UNCHECKED_CAST")
            val aos = tos as ArchiveOutputStream<ArchiveEntry>
            for ((idx, item) in flatFiles.withIndex()) {
              val entry = TarArchiveEntry(item.file, item.relativePath)
              aos.putArchiveEntry(entry)
              if (!item.file.isDirectory) {
                FileInputStream(item.file).use { it.copyTo(tos) }
              }
              tos.closeArchiveEntry()
              onProgress(((idx + 1) * 100) / totalFiles)
            }
            tos.finish()
          }
        }

        ArchiveFormat.GZ,
        ArchiveFormat.BZ2,
        ArchiveFormat.XZ -> {
          val singleFile =
            sources.firstOrNull { it.isFile }
              ?: flatFiles.firstOrNull { it.file.isFile }?.file
              ?: throw IllegalArgumentException("Single-stream format requires at least one file")
          val baseStream = BufferedOutputStream(FileOutputStream(outputFile))
          val compStream: OutputStream =
            when (format) {
              ArchiveFormat.GZ -> {
                val gzParams = GzipParameters().apply { compressionLevel = clampedLevel }
                GzipCompressorOutputStream(baseStream, gzParams)
              }
              ArchiveFormat.BZ2 -> BZip2CompressorOutputStream(baseStream, clampedLevel.coerceIn(1, 9))
              else -> XZOutputStream(baseStream, LZMA2Options(clampedLevel))
            }
          compStream.use { out -> FileInputStream(singleFile).use { it.copyTo(out) } }
          onProgress(100)
        }

        ArchiveFormat.RAR -> throw UnsupportedOperationException("RAR creation is proprietary; use ZIP, 7Z, or TAR.XZ")
      }
      outputFile
    }

  suspend fun replaceEntryInZip(zipFile: File, entryPath: String, newBytes: ByteArray): Boolean =
    withContext(Dispatchers.IO) {
      val cleanEntry = entryPath.trimStart('/')
      val zf = ZipFile(zipFile)
      val temp = File.createTempFile("vortex_entry_", ".bin")
      try {
        temp.writeBytes(newBytes)
        val params =
          ZipParameters().apply {
            fileNameInZip = cleanEntry
            compressionMethod = CompressionMethod.DEFLATE
            compressionLevel = CompressionLevel.NORMAL
          }
        zf.addFile(temp, params)
        true
      } finally {
        temp.delete()
      }
    }

  private fun openTarStream(file: File, format: ArchiveFormat): ArchiveInputStream<*> {
    val bis = BufferedInputStream(FileInputStream(file))
    val inner: InputStream =
      when (format) {
        ArchiveFormat.TAR_GZ -> GzipCompressorInputStream(bis)
        ArchiveFormat.TAR_BZ2 -> BZip2CompressorInputStream(bis)
        ArchiveFormat.TAR_XZ -> XZCompressorInputStream(bis)
        else -> bis
      }
    return TarArchiveInputStream(inner)
  }

  @Suppress("DEPRECATION")
  private fun openSevenZFile(file: File): SevenZFile =
    try {
      SevenZFile.Builder().setFile(file).get()
    } catch (_: NoSuchMethodError) {
      SevenZFile(file)
    }

  private fun putSevenZEntry(szOut: SevenZOutputFile, entry: SevenZArchiveEntry) {
    try {
      szOut.putArchiveEntry(entry)
    } catch (_: NoSuchMethodError) {
      val method = szOut.javaClass.getMethod("putArchiveEntry", ArchiveEntry::class.java)
      method.invoke(szOut, entry)
    }
  }

  private fun mapZip4jLevel(level: Int): CompressionLevel =
    when {
      level <= 0 -> CompressionLevel.NO_COMPRESSION
      level <= 2 -> CompressionLevel.FASTEST
      level <= 4 -> CompressionLevel.FAST
      level <= 6 -> CompressionLevel.NORMAL
      level <= 8 -> CompressionLevel.MAXIMUM
      else -> CompressionLevel.ULTRA
    }

  private data class RelativeFileItem(val file: File, val relativePath: String)

  private fun collectAllFiles(sources: List<File>): List<RelativeFileItem> {
    val result = mutableListOf<RelativeFileItem>()
    for (src in sources) {
      if (!src.exists()) continue
      if (src.isFile) {
        result.add(RelativeFileItem(src, src.name))
      } else {
        val baseParent = src.parentFile
        src.walkTopDown().forEach { f ->
          val rel =
            if (baseParent != null) f.relativeTo(baseParent).path.replace('\\', '/')
            else f.name
          if (f.isFile || (f.isDirectory && f.listFiles().isNullOrEmpty())) {
            result.add(RelativeFileItem(f, if (f.isDirectory) "$rel/" else rel))
          }
        }
      }
    }
    return result
  }

  private fun safeResolve(destDir: File, entryName: String): File {
    val outFile = File(destDir, entryName)
    val destCanonical = destDir.canonicalPath
    val outCanonical = outFile.canonicalPath
    if (!outCanonical.startsWith(destCanonical + File.separator) && outCanonical != destCanonical) {
      throw SecurityException("Zip Slip blocked: $entryName")
    }
    return outFile
  }

  companion object {
    const val ARCHIVE_URI_PREFIX = "archive://"

    fun buildArchiveUri(archivePath: String, entryPath: String): String {
      val cleanEntry = entryPath.trim('/')
      return if (cleanEntry.isEmpty()) "$ARCHIVE_URI_PREFIX$archivePath!"
      else "$ARCHIVE_URI_PREFIX$archivePath!/$cleanEntry"
    }

    fun parseArchiveUri(uri: String): Pair<String, String>? {
      if (!uri.startsWith(ARCHIVE_URI_PREFIX)) return null
      val body = uri.removePrefix(ARCHIVE_URI_PREFIX)
      val idx = body.indexOf("!/")
      return if (idx >= 0) {
        body.substring(0, idx) to body.substring(idx + 2)
      } else {
        body.trimEnd('!') to ""
      }
    }
  }
}
