package com.example.domain.apk

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import com.example.domain.archive.ArchiveEngine
import com.example.domain.fs.VirtualFileNode
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import net.lingala.zip4j.ZipFile

data class ApkPermissionInfo(
  val fullName: String,
  val shortName: String,
  val isDangerous: Boolean,
  val categoryLabel: String,
)

data class ApkInspectionReport(
  val fileName: String,
  val filePath: String,
  val fileSize: Long,
  val appName: String,
  val packageName: String,
  val versionName: String,
  val versionCode: Long,
  val minSdk: Int,
  val targetSdk: Int,
  val iconDrawable: Drawable?,
  val permissions: List<String>,
  val permissionDetails: List<ApkPermissionInfo>,
  val activities: List<String>,
  val services: List<String>,
  val receivers: List<String>,
  val providers: List<String>,
  val signingDigestSha256: String,
  val decodedManifestXml: String,
  val manifestSizeBytes: Int,
  val isManifestBinaryAxml: Boolean,
  val dexFiles: List<String>,
  val dexClasses: List<String>,
  val nativeLibs: List<String>,
  val entryCount: Int,
)

class ApkInspectorEngine(
  private val context: Context,
  private val archiveEngine: ArchiveEngine,
) {

  suspend fun resolveInspectableApkFile(rawPath: String, cacheDir: File): File =
    withContext(Dispatchers.IO) {
      val archivePair = ArchiveEngine.parseArchiveUri(rawPath)
      if (archivePair != null) {
        val (outerArchivePath, entryPath) = archivePair
        val outerFile = File(outerArchivePath)
        val outApk = File(cacheDir, "inspect_${outerFile.nameWithoutExtension}_${File(entryPath).name}")
        val bytes = archiveEngine.extractEntryBytes(outerFile, entryPath)
        outApk.writeBytes(bytes)
        return@withContext outApk
      }

      if (rawPath.startsWith("content://")) {
        val uri = Uri.parse(rawPath)
        val outApk = File(cacheDir, "inspect_uri_${System.currentTimeMillis()}.apk")
        context.contentResolver.openInputStream(uri)?.use { input ->
          FileOutputStream(outApk).use { output -> input.copyTo(output) }
        }
        return@withContext outApk
      }

      val localFile = File(rawPath)
      val ext = localFile.extension.lowercase(Locale.ROOT)
      if (ext in setOf("apks", "xapk", "apkm") && localFile.exists()) {
        // Check if container wraps base.apk or inner .apk files
        val zf = runCatching { ZipFile(localFile) }.getOrNull()
        val innerApkHeader =
          zf?.fileHeaders?.firstOrNull { it.fileName.endsWith("base.apk", ignoreCase = true) }
            ?: zf?.fileHeaders?.firstOrNull { it.fileName.endsWith(".apk", ignoreCase = true) }
        if (innerApkHeader != null) {
          val outApk = File(cacheDir, "inspect_bundle_${localFile.nameWithoutExtension}.apk")
          val bytes = archiveEngine.extractEntryBytes(localFile, innerApkHeader.fileName)
          if (bytes.isNotEmpty()) {
            outApk.writeBytes(bytes)
            return@withContext outApk
          }
        }
      }
      localFile
    }

  suspend fun inspectApk(apkFile: File): ApkInspectionReport =
    withContext(Dispatchers.IO) {
      if (!apkFile.exists() || !apkFile.isFile) {
        throw IllegalArgumentException("APK file does not exist: ${apkFile.absolutePath}")
      }

      val pm = context.packageManager
      val flags =
        PackageManager.GET_PERMISSIONS or
          PackageManager.GET_ACTIVITIES or
          PackageManager.GET_SERVICES or
          PackageManager.GET_RECEIVERS or
          PackageManager.GET_PROVIDERS or
          @Suppress("DEPRECATION")
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_SIGNING_CERTIFICATES
          } else {
            PackageManager.GET_SIGNATURES
          }

      val pkgInfo: PackageInfo? = runCatching { pm.getPackageArchiveInfo(apkFile.absolutePath, flags) }.getOrNull()
      pkgInfo?.applicationInfo?.let { appInfo ->
        appInfo.sourceDir = apkFile.absolutePath
        appInfo.publicSourceDir = apkFile.absolutePath
      }

      val zf = ZipFile(apkFile)
      val headers = zf.fileHeaders
      val dexFiles = headers.map { it.fileName }.filter { it.endsWith(".dex") }.sorted()
      val nativeLibs =
        headers
          .map { it.fileName }
          .filter { it.startsWith("lib/") && it.endsWith(".so") }
          .sorted()

      val manifestBytes =
        runCatching { archiveEngine.extractEntryBytes(apkFile, "AndroidManifest.xml") }
          .getOrDefault(ByteArray(0))
      val isBinaryAxml =
        manifestBytes.size >= 4 &&
          !manifestBytes.take(32).toByteArray().toString(Charsets.UTF_8).trimStart().startsWith("<")

      val decodedXml =
        if (manifestBytes.isNotEmpty()) {
          runCatching { BinaryAxmlDecoder.decode(manifestBytes) }
            .getOrElse { "// Failed to decode AXML: ${it.message}" }
        } else {
          "// AndroidManifest.xml not found (possibly split APKS/XAPK container)"
        }

      // Parse decoded manifest as resilient fallback (for unsigned/custom APKs or Robolectric)
      val xmlFallback = ManifestXmlFallbackParser.parse(decodedXml)

      val rawPmLabel = runCatching { pkgInfo?.applicationInfo?.loadLabel(pm)?.toString() }.getOrNull()
      val appLabel =
        rawPmLabel?.takeIf { it.isNotBlank() && it != pkgInfo?.packageName }
          ?: xmlFallback.appLabel?.takeIf { it.isNotBlank() && !it.startsWith("@0x") }
          ?: rawPmLabel
          ?: apkFile.nameWithoutExtension

      val icon = runCatching { pkgInfo?.applicationInfo?.loadIcon(pm) }.getOrNull()

      val packageName =
        pkgInfo?.packageName?.takeIf { it.isNotBlank() }
          ?: xmlFallback.packageName?.takeIf { it.isNotBlank() }
          ?: "Unknown"

      val versionName =
        pkgInfo?.versionName?.takeIf { it.isNotBlank() }
          ?: xmlFallback.versionName?.takeIf { it.isNotBlank() }
          ?: "?"

      val pmVersionCode =
        if (pkgInfo == null) 0L
        else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pkgInfo.longVersionCode
        else @Suppress("DEPRECATION") pkgInfo.versionCode.toLong()
      val versionCode = if (pmVersionCode > 0L) pmVersionCode else xmlFallback.versionCode

      val pmMinSdk =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
          pkgInfo?.applicationInfo?.minSdkVersion ?: 0
        } else {
          0
        }
      val minSdk = if (pmMinSdk > 0) pmMinSdk else xmlFallback.minSdk
      val targetSdk = (pkgInfo?.applicationInfo?.targetSdkVersion ?: 0).let { if (it > 0) it else xmlFallback.targetSdk }

      val perms =
        (pkgInfo?.requestedPermissions?.toList().orEmpty() + xmlFallback.permissions)
          .filter { it.isNotBlank() }
          .distinct()
      val permDetails = perms.map { classifyPermission(it) }

      val activities =
        (pkgInfo?.activities?.map { it.name }.orEmpty() + xmlFallback.activities)
          .filter { it.isNotBlank() }
          .distinct()
      val services =
        (pkgInfo?.services?.map { it.name }.orEmpty() + xmlFallback.services)
          .filter { it.isNotBlank() }
          .distinct()
      val receivers =
        (pkgInfo?.receivers?.map { it.name }.orEmpty() + xmlFallback.receivers)
          .filter { it.isNotBlank() }
          .distinct()
      val providers =
        (pkgInfo?.providers?.map { it.name }.orEmpty() + xmlFallback.providers)
          .filter { it.isNotBlank() }
          .distinct()

      val sigSha256 = extractSigningSha256(pkgInfo)

      val firstDexName = dexFiles.firstOrNull()
      val dexClasses =
        if (firstDexName != null) {
          val dexBytes =
            runCatching { archiveEngine.extractEntryBytes(apkFile, firstDexName) }
              .getOrDefault(ByteArray(0))
          if (dexBytes.isNotEmpty()) runCatching { DexClassParser.parseClasses(dexBytes) }.getOrDefault(emptyList())
          else emptyList()
        } else {
          emptyList()
        }

      ApkInspectionReport(
        fileName = apkFile.name,
        filePath = apkFile.absolutePath,
        fileSize = apkFile.length(),
        appName = appLabel,
        packageName = packageName,
        versionName = versionName,
        versionCode = versionCode,
        minSdk = minSdk,
        targetSdk = targetSdk,
        iconDrawable = icon,
        permissions = perms,
        permissionDetails = permDetails,
        activities = activities,
        services = services,
        receivers = receivers,
        providers = providers,
        signingDigestSha256 = sigSha256,
        decodedManifestXml = decodedXml,
        manifestSizeBytes = manifestBytes.size,
        isManifestBinaryAxml = isBinaryAxml,
        dexFiles = dexFiles,
        dexClasses = dexClasses,
        nativeLibs = nativeLibs,
        entryCount = headers.size,
      )
    }

  suspend fun extractManifestToFile(decodedManifestXml: String, outputFile: File): File =
    withContext(Dispatchers.IO) {
      outputFile.parentFile?.mkdirs()
      outputFile.writeText(decodedManifestXml, Charsets.UTF_8)
      outputFile
    }

  suspend fun unpackApkToDirectory(apkFile: File, destDir: File): Int =
    withContext(Dispatchers.IO) {
      archiveEngine.extractArchive(apkFile, destDir)
    }

  suspend fun listInternalFiles(apkFile: File, subPath: String = ""): List<VirtualFileNode> =
    archiveEngine.listEntriesAtPath(apkFile, subPath)

  private fun extractSigningSha256(pkgInfo: PackageInfo?): String {
    if (pkgInfo == null) return "Unsigned / V2-V3 Only"
    val sigBytes: ByteArray? =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        pkgInfo.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
      } else {
        @Suppress("DEPRECATION")
        pkgInfo.signatures?.firstOrNull()?.toByteArray()
      }
    if (sigBytes == null) return "Unavailable (V2/V3 or Unsigned)"
    val digest = MessageDigest.getInstance("SHA-256").digest(sigBytes)
    return digest.joinToString(":") { "%02X".format(it) }
  }

  private fun classifyPermission(fullName: String): ApkPermissionInfo {
    val shortName = fullName.substringAfterLast('.')
    val dangerousKeywords =
      setOf(
        "CAMERA",
        "RECORD_AUDIO",
        "ACCESS_FINE_LOCATION",
        "ACCESS_COARSE_LOCATION",
        "ACCESS_BACKGROUND_LOCATION",
        "READ_CONTACTS",
        "WRITE_CONTACTS",
        "GET_ACCOUNTS",
        "READ_CALENDAR",
        "WRITE_CALENDAR",
        "READ_PHONE_STATE",
        "CALL_PHONE",
        "READ_CALL_LOG",
        "WRITE_CALL_LOG",
        "READ_SMS",
        "SEND_SMS",
        "RECEIVE_SMS",
        "READ_EXTERNAL_STORAGE",
        "WRITE_EXTERNAL_STORAGE",
        "MANAGE_EXTERNAL_STORAGE",
        "READ_MEDIA_IMAGES",
        "READ_MEDIA_VIDEO",
        "READ_MEDIA_AUDIO",
        "BODY_SENSORS",
        "ACTIVITY_RECOGNITION",
        "BLUETOOTH_CONNECT",
        "BLUETOOTH_SCAN",
        "REQUEST_INSTALL_PACKAGES",
        "SYSTEM_ALERT_WINDOW",
        "WRITE_SETTINGS",
        "POST_NOTIFICATIONS",
        "NEARBY_WIFI_DEVICES",
      )
    val isDangerous = shortName in dangerousKeywords
    val category =
      when {
        "LOCATION" in shortName -> "Location"
        "CAMERA" in shortName -> "Camera"
        "AUDIO" in shortName || "RECORD" in shortName -> "Microphone"
        "STORAGE" in shortName || "MEDIA" in shortName -> "Storage & Media"
        "CONTACTS" in shortName || "ACCOUNTS" in shortName -> "Contacts"
        "SMS" in shortName || "PHONE" in shortName || "CALL" in shortName -> "Phone & SMS"
        "BLUETOOTH" in shortName || "WIFI" in shortName || "INTERNET" in shortName || "NETWORK" in shortName -> "Network"
        "INSTALL" in shortName || "SYSTEM" in shortName || "OVERLAY" in shortName -> "System"
        else -> if (isDangerous) "Runtime" else "Standard"
      }
    return ApkPermissionInfo(
      fullName = fullName,
      shortName = shortName,
      isDangerous = isDangerous,
      categoryLabel = category,
    )
  }
}

internal data class ManifestFallbackMeta(
  val packageName: String? = null,
  val versionName: String? = null,
  val versionCode: Long = 0L,
  val minSdk: Int = 0,
  val targetSdk: Int = 0,
  val appLabel: String? = null,
  val permissions: List<String> = emptyList(),
  val activities: List<String> = emptyList(),
  val services: List<String> = emptyList(),
  val receivers: List<String> = emptyList(),
  val providers: List<String> = emptyList(),
)

internal object ManifestXmlFallbackParser {

  private val tagRegex = Regex("""<([a-zA-Z0-9_:-]+)\b([^>]*)/?>""", setOf(RegexOption.DOT_MATCHES_ALL))
  private val attrRegex = Regex("""([a-zA-Z0-9_:-]+)\s*=\s*"([^"]*)"""")

  fun parse(xml: String): ManifestFallbackMeta {
    if (xml.isBlank() || xml.trimStart().startsWith("//")) return ManifestFallbackMeta()
    var pkg: String? = null
    var vName: String? = null
    var vCode = 0L
    var minSdk = 0
    var targetSdk = 0
    var appLabel: String? = null
    val perms = LinkedHashSet<String>()
    val activities = LinkedHashSet<String>()
    val services = LinkedHashSet<String>()
    val receivers = LinkedHashSet<String>()
    val providers = LinkedHashSet<String>()

    for (match in tagRegex.findAll(xml)) {
      val tag = match.groupValues[1].substringAfterLast(':')
      val attrBlock = match.groupValues[2]
      val attrs = HashMap<String, String>()
      for (am in attrRegex.findAll(attrBlock)) {
        val rawKey = am.groupValues[1]
        val shortKey = rawKey.substringAfterLast(':')
        attrs[shortKey] = am.groupValues[2]
      }

      when (tag) {
        "manifest" -> {
          pkg = attrs["package"] ?: pkg
          vName = attrs["versionName"] ?: vName
          vCode = parseIntOrHex(attrs["versionCode"])?.toLong() ?: vCode
        }
        "uses-sdk" -> {
          minSdk = parseIntOrHex(attrs["minSdkVersion"]) ?: minSdk
          targetSdk = parseIntOrHex(attrs["targetSdkVersion"]) ?: targetSdk
        }
        "application" -> {
          appLabel = attrs["label"] ?: appLabel
        }
        "uses-permission", "uses-permission-sdk-23" -> {
          attrs["name"]?.takeIf { it.isNotBlank() }?.let { perms.add(it) }
        }
        "activity", "activity-alias" -> {
          attrs["name"]?.takeIf { it.isNotBlank() }?.let { activities.add(it) }
        }
        "service" -> {
          attrs["name"]?.takeIf { it.isNotBlank() }?.let { services.add(it) }
        }
        "receiver" -> {
          attrs["name"]?.takeIf { it.isNotBlank() }?.let { receivers.add(it) }
        }
        "provider" -> {
          attrs["name"]?.takeIf { it.isNotBlank() }?.let { providers.add(it) }
        }
      }
    }

    return ManifestFallbackMeta(
      packageName = pkg,
      versionName = vName,
      versionCode = vCode,
      minSdk = minSdk,
      targetSdk = targetSdk,
      appLabel = appLabel,
      permissions = perms.toList(),
      activities = activities.toList(),
      services = services.toList(),
      receivers = receivers.toList(),
      providers = providers.toList(),
    )
  }

  private fun parseIntOrHex(raw: String?): Int? {
    if (raw.isNullOrBlank()) return null
    val clean = raw.trim()
    return if (clean.startsWith("0x", ignoreCase = true)) {
      clean.substring(2).toLongOrNull(16)?.toInt()
    } else {
      clean.toIntOrNull()
    }
  }
}

object BinaryAxmlDecoder {
  private const val CHUNK_AXML_FILE = 0x00080003
  private const val CHUNK_STRING_POOL = 0x001C0001
  private const val CHUNK_RESOURCE_IDS = 0x00080180
  private const val CHUNK_START_NAMESPACE = 0x00100100
  private const val CHUNK_END_NAMESPACE = 0x00100101
  private const val CHUNK_START_TAG = 0x00100102
  private const val CHUNK_END_TAG = 0x00100103
  private const val CHUNK_TEXT = 0x00100104

  fun decode(bytes: ByteArray): String {
    val textStart = bytes.take(64).toByteArray().toString(Charsets.UTF_8).trimStart()
    if (textStart.startsWith("<?xml") || textStart.startsWith("<manifest")) {
      return bytes.toString(Charsets.UTF_8)
    }

    val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
    if (buf.remaining() < 8) return "// Invalid AXML"
    val fileChunkType = buf.getInt()
    if (fileChunkType != CHUNK_AXML_FILE && (fileChunkType and 0xFFFF) != 0x0003) {
      return "// Not binary AXML (magic=0x${fileChunkType.toUInt().toString(16)})"
    }
    buf.getInt() // total file size

    var strings: List<String> = emptyList()
    val nsPrefixMap = LinkedHashMap<String, String>()
    val pendingNsDecls = mutableListOf<Pair<String, String>>()
    val xml = StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")
    var indent = 0

    while (buf.remaining() >= 8) {
      val chunkStart = buf.position()
      val chunkType = buf.getInt()
      val chunkSize = buf.getInt()
      if (chunkSize < 8 || chunkStart + chunkSize > buf.limit()) break

      when (chunkType) {
        CHUNK_STRING_POOL -> {
          strings = parseStringPool(buf, chunkStart)
        }
        CHUNK_RESOURCE_IDS -> {
          // Skip resource ID table
        }
        CHUNK_START_NAMESPACE -> {
          buf.getInt() // lineNumber
          buf.getInt() // comment
          val prefixIdx = buf.getInt()
          val uriIdx = buf.getInt()
          val prefix = strings.getOrNull(prefixIdx) ?: "ns"
          val uri = strings.getOrNull(uriIdx) ?: ""
          if (uri.isNotEmpty()) {
            nsPrefixMap[uri] = prefix
            pendingNsDecls.add(prefix to uri)
          }
        }
        CHUNK_END_NAMESPACE -> {
          // Consume
        }
        CHUNK_START_TAG -> {
          buf.getInt() // lineNumber
          buf.getInt() // comment
          val nsIdx = buf.getInt()
          val nameIdx = buf.getInt()
          buf.getShort() // attrStart
          buf.getShort() // attrSize
          val attrCount = buf.getShort().toInt() and 0xFFFF
          buf.getShort() // idIndex
          buf.getShort() // classIndex
          buf.getShort() // styleIndex

          val tagName = strings.getOrNull(nameIdx) ?: "tag"
          val tagNs = if (nsIdx >= 0) nsPrefixMap[strings.getOrNull(nsIdx)] else null
          val fullTag = if (tagNs != null) "$tagNs:$tagName" else tagName

          xml.append("  ".repeat(indent)).append("<").append(fullTag)
          if (pendingNsDecls.isNotEmpty()) {
            for ((p, u) in pendingNsDecls) {
              xml.append(" xmlns:$p=\"${escapeXmlAttr(u)}\"")
            }
            pendingNsDecls.clear()
          }

          for (i in 0 until attrCount) {
            if (buf.remaining() < 20) break
            val attrNsIdx = buf.getInt()
            val attrNameIdx = buf.getInt()
            val attrValStrIdx = buf.getInt()
            val attrType = (buf.getInt() ushr 24) and 0xFF
            val attrData = buf.getInt()

            val attrName = strings.getOrNull(attrNameIdx) ?: "attr_$i"
            val attrNs = if (attrNsIdx >= 0) nsPrefixMap[strings.getOrNull(attrNsIdx)] else null
            val attrKey = if (attrNs != null) "$attrNs:$attrName" else attrName
            val attrValue = escapeXmlAttr(formatAttributeValue(attrType, attrData, attrValStrIdx, strings))
            xml.append("\n").append("  ".repeat(indent + 1)).append("$attrKey=\"$attrValue\"")
          }
          xml.append(">\n")
          indent++
        }
        CHUNK_END_TAG -> {
          buf.getInt() // lineNumber
          buf.getInt() // comment
          val nsIdx = buf.getInt()
          val nameIdx = buf.getInt()
          indent = (indent - 1).coerceAtLeast(0)
          val tagName = strings.getOrNull(nameIdx) ?: "tag"
          val tagNs = if (nsIdx >= 0) nsPrefixMap[strings.getOrNull(nsIdx)] else null
          val fullTag = if (tagNs != null) "$tagNs:$tagName" else tagName
          xml.append("  ".repeat(indent)).append("</").append(fullTag).append(">\n")
        }
        CHUNK_TEXT -> {
          buf.getInt() // lineNumber
          buf.getInt() // comment
          val textIdx = buf.getInt()
          val t = strings.getOrNull(textIdx)
          if (!t.isNullOrBlank()) {
            xml.append("  ".repeat(indent)).append(t.trim()).append("\n")
          }
        }
      }
      buf.position(chunkStart + chunkSize)
    }
    return xml.toString()
  }

  private fun parseStringPool(buf: ByteBuffer, chunkStart: Int): List<String> {
    val stringCount = buf.getInt()
    val styleCount = buf.getInt()
    val flags = buf.getInt()
    val stringsOffset = buf.getInt()
    buf.getInt() // stylesOffset
    val isUtf8 = (flags and (1 shl 8)) != 0

    val offsets = IntArray(stringCount) { buf.getInt() }
    repeat(styleCount) { buf.getInt() }

    val poolBase = chunkStart + stringsOffset
    val result = ArrayList<String>(stringCount)
    for (off in offsets) {
      val pos = poolBase + off
      if (pos < 0 || pos >= buf.limit()) {
        result.add("")
        continue
      }
      buf.position(pos)
      if (isUtf8) {
        readUtf8Len(buf) // char len
        val byteLen = readUtf8Len(buf)
        val safeLen = byteLen.coerceAtMost(buf.remaining())
        val arr = ByteArray(safeLen)
        buf.get(arr)
        result.add(String(arr, Charsets.UTF_8))
      } else {
        var charLen = buf.getShort().toInt() and 0xFFFF
        if ((charLen and 0x8000) != 0) {
          charLen = ((charLen and 0x7FFF) shl 16) or (buf.getShort().toInt() and 0xFFFF)
        }
        val safeBytes = (charLen * 2).coerceAtMost(buf.remaining())
        val arr = ByteArray(safeBytes)
        buf.get(arr)
        result.add(String(arr, Charsets.UTF_16LE))
      }
    }
    return result
  }

  private fun readUtf8Len(buf: ByteBuffer): Int {
    val first = buf.get().toInt() and 0xFF
    return if ((first and 0x80) != 0) {
      val second = buf.get().toInt() and 0xFF
      ((first and 0x7F) shl 8) or second
    } else {
      first
    }
  }

  private fun escapeXmlAttr(value: String): String {
    return value
      .replace("&", "&amp;")
      .replace("\"", "&quot;")
      .replace("<", "&lt;")
  }

  private fun formatAttributeValue(
    type: Int,
    data: Int,
    strIdx: Int,
    strings: List<String>,
  ): String {
    return when (type) {
      0x03 -> strings.getOrNull(strIdx) ?: strings.getOrNull(data) ?: ""
      0x01 -> "@0x${data.toUInt().toString(16)}"
      0x02 -> "?0x${data.toUInt().toString(16)}"
      0x12 -> if (data != 0) "true" else "false"
      0x10 -> data.toString()
      0x11 -> "0x${data.toUInt().toString(16)}"
      0x04 -> java.lang.Float.intBitsToFloat(data).toString()
      0x05 -> "${complexToFloat(data)}${DIMEN_UNITS.getOrElse(data and 0xF) { "px" }}"
      0x06 -> "${complexToFloat(data) * 100f}%"
      in 0x1C..0x1F -> "#${data.toUInt().toString(16).padStart(8, '0').uppercase(Locale.US)}"
      else -> strings.getOrNull(strIdx) ?: "0x${data.toUInt().toString(16)}"
    }
  }

  private val DIMEN_UNITS = listOf("px", "dip", "sp", "pt", "in", "mm")

  private fun complexToFloat(complex: Int): Float {
    val radix = (complex shr 4) and 0x3
    val mantissa = (complex and 0xFFFFFF00.toInt()).toFloat()
    val shift = floatArrayOf(1f, 1f / 128f, 1f / 32768f, 1f / 8388608f)
    return mantissa * shift.getOrElse(radix) { 1f }
  }
}

object DexClassParser {
  fun parseClasses(bytes: ByteArray, limit: Int = 600): List<String> {
    if (bytes.size < 112) return emptyList()
    val magic = String(bytes, 0, 4, Charsets.US_ASCII)
    if (magic != "dex\n") return emptyList()

    val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
    val stringIdsSize = buf.getInt(56)
    val stringIdsOff = buf.getInt(60)
    val typeIdsSize = buf.getInt(64)
    val typeIdsOff = buf.getInt(68)
    val classDefsSize = buf.getInt(96)
    val classDefsOff = buf.getInt(100)

    fun readStringAt(idx: Int): String {
      if (idx < 0 || idx >= stringIdsSize) return ""
      val strDataOff = buf.getInt(stringIdsOff + idx * 4)
      if (strDataOff <= 0 || strDataOff >= bytes.size) return ""
      var p = strDataOff
      while (p < bytes.size && (bytes[p].toInt() and 0x80) != 0) p++
      p++
      val start = p
      while (p < bytes.size && bytes[p] != 0.toByte()) p++
      return String(bytes, start, (p - start).coerceAtLeast(0), Charsets.UTF_8)
    }

    val classes = ArrayList<String>(minOf(classDefsSize, limit))
    val count = minOf(classDefsSize, limit)
    for (i in 0 until count) {
      val defOff = classDefsOff + i * 32
      if (defOff + 4 > bytes.size) break
      val typeIdx = buf.getInt(defOff)
      if (typeIdx in 0 until typeIdsSize) {
        val descStrIdx = buf.getInt(typeIdsOff + typeIdx * 4)
        val desc = readStringAt(descStrIdx)
        val clean =
          if (desc.startsWith("L") && desc.endsWith(";")) {
            desc.substring(1, desc.length - 1).replace('/', '.')
          } else {
            desc
          }
        if (clean.isNotBlank()) classes.add(clean)
      }
    }
    return classes
  }
}
