package com.example.domain.editor

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.theme.VortexExtraColors

enum class CodeLanguage(val label: String, val extensions: Set<String>) {
  KOTLIN("Kotlin", setOf("kt", "kts")),
  JAVA("Java", setOf("java")),
  XML("XML", setOf("xml", "html", "htm", "svg")),
  JSON("JSON", setOf("json")),
  PYTHON("Python", setOf("py")),
  SHELL("Shell", setOf("sh", "bash", "rc", "conf")),
  SMALI("Smali", setOf("smali")),
  SQL("SQL", setOf("sql")),
  JAVASCRIPT("JS / TS", setOf("js", "ts", "css")),
  PLAIN("Text", setOf("txt", "log", "md", "yaml", "yml", "properties", "csv", "ini"));

  companion object {
    fun detect(fileName: String): CodeLanguage {
      val ext = fileName.substringAfterLast('.', "").lowercase()
      return entries.find { ext in it.extensions } ?: PLAIN
    }
  }
}

object SyntaxHighlighter {
  private val kotlinJavaKeywords =
    setOf(
      "package", "import", "class", "interface", "object", "enum", "data", "sealed", "fun", "val",
      "var", "if", "else", "when", "for", "while", "return", "throw", "try", "catch", "finally",
      "public", "private", "protected", "internal", "override", "open", "abstract", "suspend",
      "true", "false", "null", "void", "static", "final", "new", "extends", "implements", "this",
      "super", "in", "is", "as", "by", "companion", "init",
    )

  private val pythonKeywords =
    setOf(
      "def", "class", "import", "from", "as", "if", "elif", "else", "for", "while", "return",
      "yield", "try", "except", "finally", "with", "pass", "break", "continue", "True", "False",
      "None", "and", "or", "not", "in", "is", "lambda", "async", "await",
    )

  private val sqlKeywords =
    setOf(
      "SELECT", "FROM", "WHERE", "INSERT", "INTO", "VALUES", "UPDATE", "SET", "DELETE", "CREATE",
      "TABLE", "DROP", "ALTER", "JOIN", "INNER", "LEFT", "ON", "GROUP", "BY", "ORDER", "LIMIT",
      "AND", "OR", "NOT", "NULL", "PRIMARY", "KEY", "AUTOINCREMENT",
    )

  private val smaliKeywords =
    setOf(
      ".class", ".super", ".source", ".field", ".method", ".end", ".locals", ".registers", ".param",
      "invoke-virtual", "invoke-direct", "invoke-static", "invoke-interface", "return-void",
      "return-object", "const-string", "const/4", "const/16", "iget-object", "iput-object",
    )

  private val tokenRegex =
    Regex(
      """(//[^\n]*|#[^\n]*|/\*[\s\S]*?\*/|<!--[\s\S]*?-->|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|</?[A-Za-z0-9_.:-]+|/?>|\b\d+(?:\.\d+)?\b|@[A-Za-z0-9_]+|\.[a-z-]+|\b[A-Za-z_][A-Za-z0-9_-]*\b)"""
    )

  fun highlight(
    code: String,
    language: CodeLanguage,
    colors: VortexExtraColors,
  ): AnnotatedString {
    if (code.length > 150_000 || language == CodeLanguage.PLAIN) {
      return AnnotatedString(code)
    }
    return buildAnnotatedString {
      append(code)
      for (match in tokenRegex.findAll(code)) {
        val token = match.value
        val start = match.range.first
        val end = match.range.last + 1
        val style: SpanStyle? =
          when {
            token.startsWith("//") ||
              token.startsWith("/*") ||
              token.startsWith("<!--") ||
              (token.startsWith("#") && language in setOf(CodeLanguage.PYTHON, CodeLanguage.SHELL, CodeLanguage.SMALI)) ->
              SpanStyle(color = colors.syntaxComment)

            token.startsWith("\"") || token.startsWith("'") ->
              SpanStyle(color = colors.syntaxString)

            token.startsWith("<") || token == "/>" ->
              SpanStyle(color = colors.syntaxTag, fontWeight = FontWeight.SemiBold)

            token.startsWith("@") ->
              SpanStyle(color = colors.syntaxType)

            token[0].isDigit() ->
              SpanStyle(color = colors.syntaxNumber)

            language == CodeLanguage.KOTLIN || language == CodeLanguage.JAVA || language == CodeLanguage.JAVASCRIPT ->
              when {
                token in kotlinJavaKeywords -> SpanStyle(color = colors.syntaxKeyword, fontWeight = FontWeight.SemiBold)
                token[0].isUpperCase() -> SpanStyle(color = colors.syntaxType)
                else -> null
              }

            language == CodeLanguage.PYTHON ->
              if (token in pythonKeywords) SpanStyle(color = colors.syntaxKeyword, fontWeight = FontWeight.SemiBold) else null

            language == CodeLanguage.SQL ->
              if (token.uppercase() in sqlKeywords) SpanStyle(color = colors.syntaxKeyword, fontWeight = FontWeight.SemiBold) else null

            language == CodeLanguage.SMALI ->
              if (token in smaliKeywords) SpanStyle(color = colors.syntaxKeyword, fontWeight = FontWeight.SemiBold) else null

            language == CodeLanguage.JSON ->
              when (token) {
                "true", "false", "null" -> SpanStyle(color = colors.syntaxKeyword)
                else -> null
              }

            else -> null
          }
        if (style != null) {
          addStyle(style, start, end)
        }
      }
    }
  }
}
