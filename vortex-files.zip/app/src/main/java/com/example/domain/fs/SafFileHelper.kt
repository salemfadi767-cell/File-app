package com.example.domain.fs

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import java.io.InputStream
import java.io.OutputStream

class SafFileHelper(private val context: Context) {

  fun takePersistablePermission(uri: Uri) {
    val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
    try {
      context.contentResolver.takePersistableUriPermission(uri, flags)
    } catch (_: Throwable) {}
  }

  fun getPersistedTreeUris(): List<Uri> =
    context.contentResolver.persistedUriPermissions.map { it.uri }

  fun androidDataInitialUri(): Uri =
    DocumentsContract.buildDocumentUri(
      "com.android.externalstorage.documents",
      "primary:Android/data",
    )

  fun listChildren(treeUri: Uri): List<VirtualFileNode> {
    val doc = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
    return doc.listFiles().map { child ->
      VirtualFileNode(
        name = child.name ?: "unknown",
        path = child.uri.toString(),
        isDirectory = child.isDirectory,
        size = if (child.isDirectory) 0L else child.length(),
        lastModified = child.lastModified(),
        permissions = if (child.canWrite()) "drwxrwx---" else "dr-xr-x---",
        sourceType = FileSourceType.SAF,
        safUriString = child.uri.toString(),
      )
    }
  }

  fun listDocumentUri(docUri: Uri): List<VirtualFileNode> {
    val doc = DocumentFile.fromTreeUri(context, docUri)
      ?: DocumentFile.fromSingleUri(context, docUri)
      ?: return emptyList()
    return doc.listFiles().map { child ->
      VirtualFileNode(
        name = child.name ?: "unknown",
        path = child.uri.toString(),
        isDirectory = child.isDirectory,
        size = if (child.isDirectory) 0L else child.length(),
        lastModified = child.lastModified(),
        permissions = if (child.canWrite()) "-rw-rw----" else "-r--r-----",
        sourceType = FileSourceType.SAF,
        safUriString = child.uri.toString(),
      )
    }
  }

  fun openInputStream(uri: Uri): InputStream? = context.contentResolver.openInputStream(uri)

  fun openOutputStream(uri: Uri): OutputStream? = context.contentResolver.openOutputStream(uri)
}
