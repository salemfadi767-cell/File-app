package com.example.domain.media

import java.io.File
import java.util.Locale

data class EpisodeSignature(
  val normalizedTitle: String,
  val titleTokens: Set<String>,
  val season: Int?,
  val episode: Int?,
)

object SubtitleAutoMatcher {

  private val subtitleExts = setOf("srt", "vtt", "ass", "ssa")
  private val lyricsExts = setOf("lrc", "txt")

  private val seasonEpisodeRegex =
    Regex("""(?:^|[^a-z0-9])s(\d{1,2})[._\-\s]*e(\d{1,3})(?:[^a-z0-9]|$)""", RegexOption.IGNORE_CASE)
  private val crossEpisodeRegex =
    Regex("""(?:^|[^a-z0-9])(\d{1,2})x(\d{1,3})(?:[^a-z0-9]|$)""", RegexOption.IGNORE_CASE)
  private val labeledEpisodeRegex =
    Regex("""(?:^|[^a-z\u0600-\u06FF])(?:ep|episode|e|الحلقة|حلقة)[._\-\s:]*(\d{1,3})(?!\d)""", RegexOption.IGNORE_CASE)
  private val trailingEpisodeRegex =
    Regex("""(?:[-_\[\(\s.])(\d{1,3})(?:[\]\)\s._-]|$)""")

  private val noiseTagsRegex =
    Regex(
      """\b(2160p|1080p|720p|480p|360p|4k|8k|hdr|dv|x264|x265|h264|h265|hevc|av1|bluray|bdrip|brrip|webrip|web-dl|webdl|hdtv|aac|ac3|dts|mp4|mkv|avi|ar|en|ara|eng|sub|subs|subtitle|subtitles|translated)\b""",
      RegexOption.IGNORE_CASE,
    )

  fun extractEpisodeSignature(fileName: String): EpisodeSignature {
    val stem = fileName.substringBeforeLast('.')
    var season: Int? = null
    var episode: Int? = null
    var stripped = stem

    val m1 = seasonEpisodeRegex.find(stem)
    val m2 = crossEpisodeRegex.find(stem)
    val m3 = labeledEpisodeRegex.find(stem)

    when {
      m1 != null -> {
        season = m1.groupValues[1].toIntOrNull()
        episode = m1.groupValues[2].toIntOrNull()
        stripped = stem.removeRange(m1.range)
      }
      m2 != null -> {
        season = m2.groupValues[1].toIntOrNull()
        episode = m2.groupValues[2].toIntOrNull()
        stripped = stem.removeRange(m2.range)
      }
      m3 != null -> {
        episode = m3.groupValues[1].toIntOrNull()
        stripped = stem.removeRange(m3.range)
      }
      else -> {
        val m4 = trailingEpisodeRegex.findAll(stem).lastOrNull()
        val candidateNum = m4?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (m4 != null && candidateNum != null && candidateNum in 1..999 && candidateNum !in listOf(360, 480, 720, 1080, 2160)) {
          episode = candidateNum
          stripped = stem.removeRange(m4.range)
        }
      }
    }

    val normalized =
      noiseTagsRegex
        .replace(stripped.replace(Regex("[._\\-\\[\\]()]"), " "), " ")
        .replace(Regex("\\s{2,}"), " ")
        .trim()
        .lowercase(Locale.ROOT)

    val tokens =
      normalized
        .split(' ')
        .map { it.trim() }
        .filter { it.length >= 2 }
        .toSet()

    return EpisodeSignature(
      normalizedTitle = normalized,
      titleTokens = tokens,
      season = season,
      episode = episode,
    )
  }

  fun findBestLocalSubtitle(videoPath: String, dedicatedFolderPath: String): File? {
    val videoFile = File(videoPath)
    val videoStem = videoFile.nameWithoutExtension
    val searchDirs =
      buildList {
        videoFile.parentFile?.let { add(it) }
        if (dedicatedFolderPath.isNotBlank()) {
          val ded = File(dedicatedFolderPath)
          if (ded.exists() && ded.isDirectory && ded.absolutePath != videoFile.parentFile?.absolutePath) {
            add(ded)
          }
        }
      }

    // 1. Exact stem match across video parent and dedicated subtitles folder
    for (dir in searchDirs) {
      for (ext in subtitleExts) {
        val exact = File(dir, "$videoStem.$ext")
        if (exact.exists() && exact.isFile && exact.canRead()) return exact
      }
    }

    // 2. Prefix stem match (e.g. Movie.ar.srt / Movie.en.srt)
    for (dir in searchDirs) {
      val files = dir.listFiles()?.filter { it.isFile && it.extension.lowercase(Locale.ROOT) in subtitleExts }.orEmpty()
      val prefixHit =
        files.firstOrNull { sub ->
          sub.nameWithoutExtension.equals(videoStem, ignoreCase = true) ||
            sub.nameWithoutExtension.startsWith("$videoStem.", ignoreCase = true) ||
            sub.nameWithoutExtension.startsWith("${videoStem}_", ignoreCase = true)
        }
      if (prefixHit != null) return prefixHit
    }

    // 3. Episode / Series fuzzy match across video parent and dedicated folder (max depth 2)
    val videoSig = extractEpisodeSignature(videoFile.name)
    var bestFile: File? = null
    var bestScore = 0

    for (dir in searchDirs) {
      val candidates =
        dir
          .walkTopDown()
          .maxDepth(2)
          .filter { it.isFile && it.extension.lowercase(Locale.ROOT) in subtitleExts && it.canRead() }
          .toList()

      for (sub in candidates) {
        val subSig = extractEpisodeSignature(sub.name)
        var score = 0

        if (videoSig.episode != null && subSig.episode != null) {
          if (videoSig.episode != subSig.episode) continue
          if (videoSig.season != null && subSig.season != null && videoSig.season != subSig.season) continue
          score += 50
          if (videoSig.season != null && videoSig.season == subSig.season) score += 20
        } else if (videoSig.episode != null || subSig.episode != null) {
          // One has episode number, the other does not -> skip unless full title matches strongly
          continue
        }

        val overlap = videoSig.titleTokens.intersect(subSig.titleTokens).size
        if (videoSig.titleTokens.isNotEmpty() && subSig.titleTokens.isNotEmpty()) {
          if (overlap == 0) continue
          score += overlap * 15
        } else if (videoSig.normalizedTitle.isNotBlank() && videoSig.normalizedTitle == subSig.normalizedTitle) {
          score += 40
        } else {
          continue
        }

        if (score > bestScore) {
          bestScore = score
          bestFile = sub
        }
      }
    }

    return bestFile
  }

  fun findBestLocalLyrics(audioPath: String, dedicatedFolderPath: String): File? {
    val audioFile = File(audioPath)
    val stem = audioFile.nameWithoutExtension
    val searchDirs =
      buildList {
        audioFile.parentFile?.let { add(it) }
        if (dedicatedFolderPath.isNotBlank()) {
          val ded = File(dedicatedFolderPath)
          if (ded.exists() && ded.isDirectory && ded.absolutePath != audioFile.parentFile?.absolutePath) {
            add(ded)
          }
        }
      }

    for (dir in searchDirs) {
      for (ext in lyricsExts) {
        val exact = File(dir, "$stem.$ext")
        if (exact.exists() && exact.isFile && exact.canRead()) return exact
      }
    }
    return null
  }

  fun resolveTargetStorageDir(dedicatedFolderPath: String, fallbackDir: File): File {
    if (dedicatedFolderPath.isNotBlank()) {
      val f = File(dedicatedFolderPath)
      if (f.exists() || f.mkdirs()) return f
    }
    return fallbackDir.apply { mkdirs() }
  }
}
