package com.example.domain.fs

import java.util.Locale

enum class FileSourceType {
  LOCAL,
  SHIZUKU,
  ROOT,
  SAF,
  ARCHIVE,
  CLOUD,
}

enum class FileCategory {
  FOLDER,
  ARCHIVE,
  APK,
  CODE,
  IMAGE,
  VIDEO,
  AUDIO,
  PDF,
  DATABASE,
  BINARY,
  DOCUMENT,
  WORD,
  EXCEL,
  POWERPOINT,
  TORRENT,
  VAULT,
}

data class VirtualFileNode(
  val name: String,
  val path: String,
  val isDirectory: Boolean,
  val size: Long,
  val lastModified: Long,
  val permissions: String = if (isDirectory) "drwxr-xr-x" else "-rw-r--r--",
  val isHidden: Boolean = name.startsWith("."),
  val sourceType: FileSourceType = FileSourceType.LOCAL,
  val safUriString: String? = null,
  val archivePath: String? = null,
  val entryPathInArchive: String? = null,
) {
  val extension: String
    get() = if (isDirectory) "" else name.substringAfterLast('.', "").lowercase(Locale.ROOT)

  val category: FileCategory
    get() {
      if (isDirectory) return FileCategory.FOLDER
      val lower = name.lowercase(Locale.ROOT)
      return when {
        extension == "vlock" -> FileCategory.VAULT
        extension == "torrent" -> FileCategory.TORRENT
        extension in setOf("apk", "apks", "xapk", "apkm", "aab") -> FileCategory.APK
        extension in setOf("zip", "7z", "rar", "tar", "gz", "tgz", "bz2", "tbz2", "xz", "txz", "jar", "war", "zst") ||
          lower.endsWith(".tar.gz") ||
          lower.endsWith(".tar.bz2") ||
          lower.endsWith(".tar.xz") -> FileCategory.ARCHIVE
        extension in setOf("png", "jpg", "jpeg", "webp", "bmp", "gif", "heic", "svg") -> FileCategory.IMAGE
        extension in setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "flv", "ts") -> FileCategory.VIDEO
        extension in setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus") -> FileCategory.AUDIO
        extension == "pdf" -> FileCategory.PDF
        extension in setOf("doc", "docx", "rtf", "odt") -> FileCategory.WORD
        extension in setOf("xls", "xlsx", "ods") -> FileCategory.EXCEL
        extension in setOf("ppt", "pptx", "odp") -> FileCategory.POWERPOINT
        extension in setOf("db", "sqlite", "sqlite3") -> FileCategory.DATABASE
        extension in setOf(
          "kt", "kts", "java", "xml", "json", "html", "htm", "css", "js", "ts", "py", "sh", "bash",
          "smali", "sql", "md", "yaml", "yml", "toml", "properties", "gradle", "c", "cpp", "h",
          "rs", "go", "txt", "log", "csv", "ini", "conf", "rc",
        ) -> FileCategory.CODE
        else -> FileCategory.BINARY
      }
    }

  val isArchiveLike: Boolean
    get() = category == FileCategory.ARCHIVE || category == FileCategory.APK

  val isOfficeDocument: Boolean
    get() =
      category == FileCategory.WORD ||
        category == FileCategory.EXCEL ||
        category == FileCategory.POWERPOINT ||
        category == FileCategory.DOCUMENT
}

fun formatFileSize(bytes: Long): String {
  if (bytes < 0L) return "0 B"
  if (bytes < 1024L) return "$bytes B"
  val units = arrayOf("KB", "MB", "GB", "TB")
  var value = bytes.toDouble()
  var idx = -1
  while (value >= 1024.0 && idx < units.lastIndex) {
    value /= 1024.0
    idx++
  }
  return String.format(Locale.US, if (value >= 100) "%.0f %s" else "%.1f %s", value, units[idx])
}

fun mimeTypeFromExtension(ext: String): String =
  when (ext.lowercase(Locale.ROOT)) {
    "png" -> "image/png"
    "jpg", "jpeg" -> "image/jpeg"
    "webp" -> "image/webp"
    "gif" -> "image/gif"
    "bmp" -> "image/bmp"
    "mp4" -> "video/mp4"
    "mkv" -> "video/x-matroska"
    "webm" -> "video/webm"
    "mp3" -> "audio/mpeg"
    "m4a", "aac" -> "audio/mp4"
    "wav" -> "audio/wav"
    "flac" -> "audio/flac"
    "ogg", "opus" -> "audio/ogg"
    "pdf" -> "application/pdf"
    "doc" -> "application/msword"
    "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    "xls" -> "application/vnd.ms-excel"
    "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    "ppt" -> "application/vnd.ms-powerpoint"
    "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    "apk", "apks", "xapk", "apkm" -> "application/vnd.android.package-archive"
    "torrent" -> "application/x-bittorrent"
    "zip" -> "application/zip"
    "7z" -> "application/x-7z-compressed"
    "rar" -> "application/vnd.rar"
    "json" -> "application/json"
    "xml" -> "text/xml"
    "html", "htm" -> "text/html"
    "txt", "kt", "java", "py", "sh", "md", "csv", "smali", "log" -> "text/plain"
    else -> "application/octet-stream"
  }
