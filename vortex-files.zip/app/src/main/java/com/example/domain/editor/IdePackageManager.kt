package com.example.domain.editor

import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.json.JSONObject

enum class PackageEcosystem(val id: String, val label: String, val commandHint: String) {
  PIP("pip", "Python (pip / PyPI)", "pip install"),
  NPM("npm", "JavaScript (npm)", "npm install"),
  MAVEN("maven", "Java / Kotlin (Maven)", "implementation"),
  CARGO("cargo", "Rust (Cargo)", "cargo add"),
}

data class InstalledIdePackage(
  val name: String,
  val version: String,
  val ecosystem: PackageEcosystem,
  val installDir: String,
  val filesCount: Int,
  val summary: String,
)

class IdePackageManager {
  private val client =
    OkHttpClient.Builder()
      .connectTimeout(15, TimeUnit.SECONDS)
      .readTimeout(45, TimeUnit.SECONDS)
      .followRedirects(true)
      .build()

  fun libsRootForWorkspace(workspaceDir: File): File =
    File(workspaceDir, ".vortex_libs").apply { mkdirs() }

  fun listInstalledPackages(workspaceDir: File): List<InstalledIdePackage> {
    val root = File(workspaceDir, ".vortex_libs")
    if (!root.exists()) return emptyList()
    val result = mutableListOf<InstalledIdePackage>()
    for (eco in PackageEcosystem.entries) {
      val ecoDir = File(root, eco.id)
      if (!ecoDir.exists()) continue
      ecoDir.listFiles()?.filter { it.isDirectory }?.forEach { pkgDir ->
        val metaFile = File(pkgDir, ".vortex_pkg.json")
        val meta = runCatching { JSONObject(metaFile.readText()) }.getOrNull()
        val filesCount = pkgDir.walkTopDown().count { it.isFile && it.name != ".vortex_pkg.json" }
        result.add(
          InstalledIdePackage(
            name = meta?.optString("name", pkgDir.name) ?: pkgDir.name,
            version = meta?.optString("version", "latest") ?: "latest",
            ecosystem = eco,
            installDir = pkgDir.absolutePath,
            filesCount = filesCount,
            summary = meta?.optString("summary", "") ?: "",
          )
        )
      }
    }
    return result.sortedBy { it.name.lowercase() }
  }

  fun uninstallPackage(workspaceDir: File, ecosystem: PackageEcosystem, packageName: String): Boolean {
    val safeName = sanitizePkgName(packageName)
    val dir = File(File(libsRootForWorkspace(workspaceDir), ecosystem.id), safeName)
    return if (dir.exists()) dir.deleteRecursively() else false
  }

  suspend fun installPackage(
    workspaceDir: File,
    ecosystem: PackageEcosystem,
    rawSpec: String,
  ): Result<InstalledIdePackage> =
    withContext(Dispatchers.IO) {
      runCatching {
        val cleanedSpec =
          rawSpec
            .trim()
            .removePrefix("pip install ")
            .removePrefix("pip3 install ")
            .removePrefix("npm install ")
            .removePrefix("npm i ")
            .removePrefix("cargo add ")
            .trim()
        require(cleanedSpec.isNotBlank()) { "Package name is empty" }
        val pkgName = cleanedSpec.substringBefore("==").substringBefore("@").trim()

        when (ecosystem) {
          PackageEcosystem.PIP -> installPipPackage(workspaceDir, pkgName, cleanedSpec.substringAfter("==", ""))
          PackageEcosystem.NPM -> installNpmPackage(workspaceDir, pkgName)
          PackageEcosystem.MAVEN -> installMavenPackage(workspaceDir, pkgName)
          PackageEcosystem.CARGO -> installCargoPackage(workspaceDir, pkgName)
        }
      }
    }

  private fun installPipPackage(workspaceDir: File, pkgName: String, requestedVer: String): InstalledIdePackage {
    val encoded = URLEncoder.encode(pkgName, "UTF-8")
    val url =
      if (requestedVer.isNotBlank()) "https://pypi.org/pypi/$encoded/${URLEncoder.encode(requestedVer, "UTF-8")}/json"
      else "https://pypi.org/pypi/$encoded/json"
    val bodyStr = fetchText(url)
    val root = JSONObject(bodyStr)
    val info = root.getJSONObject("info")
    val version = info.optString("version", "0.0.0")
    val summary = info.optString("summary", "")
    val urlsArr = root.optJSONArray("urls")
    var chosenUrl = ""
    var isWheel = false
    if (urlsArr != null) {
      for (i in 0 until urlsArr.length()) {
        val item = urlsArr.getJSONObject(i)
        val pt = item.optString("packagetype", "")
        val fn = item.optString("filename", "")
        if (pt == "bdist_wheel" && fn.contains("py3-none-any", true)) {
          chosenUrl = item.optString("url", "")
          isWheel = true
          break
        }
      }
      if (chosenUrl.isBlank()) {
        for (i in 0 until urlsArr.length()) {
          val item = urlsArr.getJSONObject(i)
          val pt = item.optString("packagetype", "")
          if (pt == "sdist" || pt == "bdist_wheel") {
            chosenUrl = item.optString("url", "")
            isWheel = pt == "bdist_wheel"
            if (chosenUrl.isNotBlank()) break
          }
        }
      }
    }

    val targetDir = File(File(libsRootForWorkspace(workspaceDir), "pip"), sanitizePkgName(pkgName)).apply {
      deleteRecursively()
      mkdirs()
    }

    if (chosenUrl.isNotBlank()) {
      val tmpArc = File(targetDir, if (isWheel) "pkg.whl" else "pkg.tar.gz")
      downloadBinary(chosenUrl, tmpArc)
      if (isWheel) {
        extractZip(tmpArc, targetDir)
      } else if (chosenUrl.endsWith(".tar.gz", true) || chosenUrl.endsWith(".tgz", true)) {
        extractTarGz(tmpArc, targetDir)
      }
      tmpArc.delete()
    }

    return writePkgMeta(targetDir, pkgName, version, PackageEcosystem.PIP, summary)
  }

  private fun installNpmPackage(workspaceDir: File, pkgName: String): InstalledIdePackage {
    val encoded = URLEncoder.encode(pkgName, "UTF-8")
    val root = JSONObject(fetchText("https://registry.npmjs.org/$encoded/latest"))
    val version = root.optString("version", "1.0.0")
    val summary = root.optString("description", "")
    val tarballUrl = root.optJSONObject("dist")?.optString("tarball", "").orEmpty()
    val targetDir = File(File(libsRootForWorkspace(workspaceDir), "npm"), sanitizePkgName(pkgName)).apply {
      deleteRecursively()
      mkdirs()
    }
    if (tarballUrl.isNotBlank()) {
      val tgz = File(targetDir, "pkg.tgz")
      downloadBinary(tarballUrl, tgz)
      extractTarGz(tgz, targetDir)
      tgz.delete()
    }
    return writePkgMeta(targetDir, pkgName, version, PackageEcosystem.NPM, summary)
  }

  private fun installMavenPackage(workspaceDir: File, coord: String): InstalledIdePackage {
    val q = URLEncoder.encode(coord, "UTF-8")
    val root = JSONObject(fetchText("https://search.maven.org/solrsearch/select?q=$q&rows=1&wt=json"))
    val doc = root.getJSONObject("response").getJSONArray("docs").optJSONObject(0)
      ?: throw IllegalStateException("Maven artifact not found for $coord")
    val g = doc.optString("g", "")
    val a = doc.optString("a", coord)
    val v = doc.optString("latestVersion", "1.0.0")
    val targetDir = File(File(libsRootForWorkspace(workspaceDir), "maven"), sanitizePkgName("$g-$a")).apply {
      deleteRecursively()
      mkdirs()
    }
    val jarUrl = "https://repo1.maven.org/maven2/${g.replace('.', '/')}/$a/$v/$a-$v.jar"
    runCatching { downloadBinary(jarUrl, File(targetDir, "$a-$v.jar")) }
    return writePkgMeta(targetDir, "$g:$a", v, PackageEcosystem.MAVEN, "Maven Central artifact")
  }

  private fun installCargoPackage(workspaceDir: File, pkgName: String): InstalledIdePackage {
    val encoded = URLEncoder.encode(pkgName, "UTF-8")
    val root = JSONObject(fetchText("https://crates.io/api/v1/crates/$encoded"))
    val crate = root.getJSONObject("crate")
    val version = crate.optString("newest_version", "0.1.0")
    val summary = crate.optString("description", "")
    val dlUrl = "https://crates.io/api/v1/crates/$encoded/$version/download"
    val targetDir = File(File(libsRootForWorkspace(workspaceDir), "cargo"), sanitizePkgName(pkgName)).apply {
      deleteRecursively()
      mkdirs()
    }
    val tgz = File(targetDir, "crate.tar.gz")
    downloadBinary(dlUrl, tgz)
    extractTarGz(tgz, targetDir)
    tgz.delete()
    return writePkgMeta(targetDir, pkgName, version, PackageEcosystem.CARGO, summary)
  }

  private fun writePkgMeta(
    dir: File,
    name: String,
    version: String,
    eco: PackageEcosystem,
    summary: String,
  ): InstalledIdePackage {
    val count = dir.walkTopDown().count { it.isFile && it.name != ".vortex_pkg.json" }
    val obj = JSONObject().apply {
      put("name", name)
      put("version", version)
      put("ecosystem", eco.id)
      put("summary", summary)
      put("installedAt", System.currentTimeMillis())
    }
    File(dir, ".vortex_pkg.json").writeText(obj.toString(2))
    return InstalledIdePackage(name, version, eco, dir.absolutePath, count, summary)
  }

  private fun fetchText(url: String): String {
    val req = Request.Builder().url(url).header("User-Agent", "VortexFiles-IDE/1.0").build()
    client.newCall(req).execute().use { resp ->
      if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code} from $url")
      return resp.body?.string().orEmpty()
    }
  }

  private fun downloadBinary(url: String, outFile: File) {
    val req = Request.Builder().url(url).header("User-Agent", "VortexFiles-IDE/1.0").build()
    client.newCall(req).execute().use { resp ->
      if (!resp.isSuccessful) throw IllegalStateException("Download failed HTTP ${resp.code}")
      resp.body?.byteStream()?.use { inp ->
        FileOutputStream(outFile).use { out -> inp.copyTo(out) }
      }
    }
  }

  private fun extractZip(zipFile: File, destDir: File) {
    ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
      var entry = zis.nextEntry
      while (entry != null) {
        val out = safeTarget(destDir, entry.name)
        if (entry.isDirectory) out.mkdirs()
        else {
          out.parentFile?.mkdirs()
          FileOutputStream(out).use { fos -> zis.copyTo(fos) }
        }
        entry = zis.nextEntry
      }
    }
  }

  private fun extractTarGz(tgzFile: File, destDir: File) {
    TarArchiveInputStream(GZIPInputStream(BufferedInputStream(FileInputStream(tgzFile)))).use { tis ->
      var entry = tis.nextEntry
      while (entry != null) {
        val out = safeTarget(destDir, entry.name)
        if (entry.isDirectory) out.mkdirs()
        else {
          out.parentFile?.mkdirs()
          FileOutputStream(out).use { fos -> tis.copyTo(fos) }
        }
        entry = tis.nextEntry
      }
    }
  }

  private fun safeTarget(destDir: File, rel: String): File {
    val clean = rel.replace('\\', '/').trimStart('/')
    val candidate = File(destDir, clean)
    val baseCanon = destDir.canonicalPath
    val targetCanon = candidate.canonicalPath
    return if (targetCanon.startsWith(baseCanon)) candidate else File(destDir, File(clean).name)
  }

  private fun sanitizePkgName(name: String): String =
    name.replace(Regex("[^a-zA-Z0-9._-]"), "_").ifBlank { "pkg" }
}
