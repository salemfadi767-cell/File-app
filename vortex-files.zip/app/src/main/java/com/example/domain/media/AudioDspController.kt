package com.example.domain.media

import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import java.util.UUID
import kotlin.math.roundToInt

data class EqBandUi(
  val index: Int,
  val centerFreqHz: Int,
  val minLevelMb: Int,
  val maxLevelMb: Int,
  val currentLevelMb: Int,
)

enum class EqPreset(val label: String, val gainsMb: List<Int>) {
  NORMAL("Normal", listOf(0, 0, 0, 0, 0)),
  BASS_HEAVY("Bass Heavy", listOf(650, 420, 0, 150, 320)),
  VOCAL("Vocal / Lyrics", listOf(-200, 180, 550, 480, 160)),
  POP("Pop", listOf(-100, 260, 480, 220, -80)),
  ROCK("Rock", listOf(480, 260, -150, 320, 520)),
  ELECTRONIC("Club / EDM", listOf(600, 450, 80, 340, 540)),
  STUDIO_HALL("Studio Hall", listOf(220, 100, 180, 360, 420)),
  NIGHT_BOOST("Night Clear", listOf(300, 200, 450, 380, 100)),
}

enum class ReverbPresetMode(val label: String, val androidPreset: Short) {
  NONE("Studio Dry", PresetReverb.PRESET_NONE),
  SMALL_ROOM("Room", PresetReverb.PRESET_SMALLROOM),
  MEDIUM_HALL("Concert Hall", PresetReverb.PRESET_MEDIUMHALL),
  PLATE("Plate", PresetReverb.PRESET_PLATE),
  LARGE_HALL("Arena", PresetReverb.PRESET_LARGEHALL),
}

class AudioDspController {

  private var attachedSessionId: Int = -1
  private var loudnessEnhancer: LoudnessEnhancer? = null
  private var equalizer: Equalizer? = null
  private var bassBoost: BassBoost? = null
  private var presetReverb: PresetReverb? = null

  private var pendingGainMb: Int = 0
  private var pendingBassStrength: Int = 0
  private var pendingReverbMode: ReverbPresetMode = ReverbPresetMode.NONE
  private var pendingBands: MutableList<Int> = mutableListOf(0, 0, 0, 0, 0)

  private var loudnessUnsupported = false
  private var bassBoostUnsupported = false
  private var reverbUnsupported = isEmulatorAudioHal()
  private var equalizerUnsupported = false

  private fun isEmulatorAudioHal(): Boolean {
    val hw = android.os.Build.HARDWARE.lowercase()
    val fp = android.os.Build.FINGERPRINT.lowercase()
    return hw.contains("ranchu") ||
      hw.contains("goldfish") ||
      fp.contains("generic") ||
      fp.contains("emulator")
  }

  private fun querySupportedEffectUuids(): Set<UUID> =
    runCatching {
      AudioEffect.queryEffects()?.mapNotNull { it.type }?.toSet().orEmpty()
    }.getOrDefault(emptySet())

  fun attachToSession(sessionId: Int): List<EqBandUi> {
    if (sessionId <= 0 || sessionId == attachedSessionId) return currentBandsUi()
    release()
    attachedSessionId = sessionId

    val availableTypes = querySupportedEffectUuids()
    fun supports(uuid: UUID): Boolean = availableTypes.isNotEmpty() && uuid in availableTypes

    if (pendingGainMb > 0 && !loudnessUnsupported && supports(AudioEffect.EFFECT_TYPE_LOUDNESS_ENHANCER)) {
      ensureLoudnessEnhancer(sessionId)
    }
    if (pendingBassStrength > 0 && !bassBoostUnsupported && supports(AudioEffect.EFFECT_TYPE_BASS_BOOST)) {
      ensureBassBoost(sessionId)
    }
    if (pendingReverbMode != ReverbPresetMode.NONE && !reverbUnsupported && supports(AudioEffect.EFFECT_TYPE_PRESET_REVERB)) {
      ensurePresetReverb(sessionId)
    }
    if (!equalizerUnsupported && supports(AudioEffect.EFFECT_TYPE_EQUALIZER)) {
      ensureEqualizer(sessionId)
    }

    return currentBandsUi()
  }

  private fun ensureLoudnessEnhancer(sessionId: Int): LoudnessEnhancer? {
    if (loudnessEnhancer != null) return loudnessEnhancer
    if (sessionId <= 0 || loudnessUnsupported) return null
    val supported = querySupportedEffectUuids()
    if (supported.isNotEmpty() && AudioEffect.EFFECT_TYPE_LOUDNESS_ENHANCER !in supported) {
      loudnessUnsupported = true
      return null
    }
    return runCatching {
      LoudnessEnhancer(sessionId).apply {
        setTargetGain(pendingGainMb)
        enabled = pendingGainMb > 0
      }
    }.onFailure {
      loudnessUnsupported = true
    }.getOrNull().also { loudnessEnhancer = it }
  }

  private fun ensureBassBoost(sessionId: Int): BassBoost? {
    if (bassBoost != null) return bassBoost
    if (sessionId <= 0 || bassBoostUnsupported) return null
    val supported = querySupportedEffectUuids()
    if (supported.isNotEmpty() && AudioEffect.EFFECT_TYPE_BASS_BOOST !in supported) {
      bassBoostUnsupported = true
      return null
    }
    return runCatching {
      BassBoost(0, sessionId).apply {
        if (strengthSupported) setStrength(pendingBassStrength.toShort())
        enabled = pendingBassStrength > 0
      }
    }.onFailure {
      bassBoostUnsupported = true
    }.getOrNull().also { bassBoost = it }
  }

  private fun ensurePresetReverb(sessionId: Int): PresetReverb? {
    if (presetReverb != null) return presetReverb
    if (sessionId <= 0 || reverbUnsupported) return null
    val supported = querySupportedEffectUuids()
    if (supported.isNotEmpty() && AudioEffect.EFFECT_TYPE_PRESET_REVERB !in supported) {
      reverbUnsupported = true
      return null
    }
    return runCatching {
      PresetReverb(0, sessionId).apply {
        preset = pendingReverbMode.androidPreset
        enabled = pendingReverbMode != ReverbPresetMode.NONE
      }
    }.onFailure {
      reverbUnsupported = true
    }.getOrNull().also { presetReverb = it }
  }

  private fun ensureEqualizer(sessionId: Int): Equalizer? {
    if (equalizer != null) return equalizer
    if (sessionId <= 0 || equalizerUnsupported) return null
    val supported = querySupportedEffectUuids()
    if (supported.isNotEmpty() && AudioEffect.EFFECT_TYPE_EQUALIZER !in supported) {
      equalizerUnsupported = true
      return null
    }
    return runCatching {
      Equalizer(0, sessionId).apply {
        enabled = true
        val count = numberOfBands.toInt().coerceAtMost(5)
        val min = bandLevelRange[0].toInt()
        val max = bandLevelRange[1].toInt()
        for (i in 0 until count) {
          val lvl = pendingBands.getOrElse(i) { 0 }.coerceIn(min, max)
          setBandLevel(i.toShort(), lvl.toShort())
        }
      }
    }.onFailure {
      equalizerUnsupported = true
    }.getOrNull().also { equalizer = it }
  }

  fun setLoudnessGainMb(gainMb: Int) {
    pendingGainMb = gainMb.coerceIn(0, 2000)
    runCatching {
      val fx = if (pendingGainMb > 0) ensureLoudnessEnhancer(attachedSessionId) else loudnessEnhancer
      fx?.apply {
        setTargetGain(pendingGainMb)
        enabled = pendingGainMb > 0
      }
    }
  }

  fun setBassBoostStrength(strength: Int) {
    pendingBassStrength = strength.coerceIn(0, 1000)
    runCatching {
      val fx = if (pendingBassStrength > 0) ensureBassBoost(attachedSessionId) else bassBoost
      fx?.apply {
        if (strengthSupported) setStrength(pendingBassStrength.toShort())
        enabled = pendingBassStrength > 0
      }
    }
  }

  fun setReverbMode(mode: ReverbPresetMode) {
    pendingReverbMode = mode
    runCatching {
      val fx = if (mode != ReverbPresetMode.NONE) ensurePresetReverb(attachedSessionId) else presetReverb
      fx?.apply {
        preset = mode.androidPreset
        enabled = mode != ReverbPresetMode.NONE
      }
    }
  }

  fun getReverbMode(): ReverbPresetMode = pendingReverbMode

  fun setBandLevel(bandIndex: Int, levelMb: Int): List<EqBandUi> {
    if (bandIndex in pendingBands.indices) {
      pendingBands[bandIndex] = levelMb
    }
    runCatching {
      equalizer?.let { eq ->
        val min = eq.bandLevelRange[0].toInt()
        val max = eq.bandLevelRange[1].toInt()
        eq.setBandLevel(bandIndex.toShort(), levelMb.coerceIn(min, max).toShort())
      }
    }
    return currentBandsUi()
  }

  fun applyPreset(preset: EqPreset): List<EqBandUi> {
    preset.gainsMb.forEachIndexed { idx, gain ->
      if (idx < pendingBands.size) pendingBands[idx] = gain
      runCatching {
        equalizer?.let { eq ->
          if (idx < eq.numberOfBands.toInt()) {
            val min = eq.bandLevelRange[0].toInt()
            val max = eq.bandLevelRange[1].toInt()
            eq.setBandLevel(idx.toShort(), gain.coerceIn(min, max).toShort())
          }
        }
      }
    }
    return currentBandsUi()
  }

  fun currentBandsUi(): List<EqBandUi> {
    val eq = equalizer
    if (eq != null) {
      val list = runCatching {
        val count = eq.numberOfBands.toInt().coerceAtMost(5)
        val min = eq.bandLevelRange[0].toInt()
        val max = eq.bandLevelRange[1].toInt()
        (0 until count).map { i ->
          EqBandUi(
            index = i,
            centerFreqHz = (eq.getCenterFreq(i.toShort()) / 1000.0).roundToInt(),
            minLevelMb = min,
            maxLevelMb = max,
            currentLevelMb = eq.getBandLevel(i.toShort()).toInt(),
          )
        }
      }.getOrNull()
      if (list != null) return list
    }

    val defaultFreqs = listOf(60, 230, 910, 3600, 14000)
    return defaultFreqs.mapIndexed { idx, hz ->
      EqBandUi(
        index = idx,
        centerFreqHz = hz,
        minLevelMb = -1500,
        maxLevelMb = 1500,
        currentLevelMb = pendingBands.getOrElse(idx) { 0 },
      )
    }
  }

  fun current10BandUi(): List<EqBandUi> {
    val five = currentBandsUi()
    val freqs10 = listOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    return freqs10.mapIndexed { i, hz ->
      val mapped = five.getOrNull((i / 2).coerceIn(0, five.lastIndex.coerceAtLeast(0)))
      EqBandUi(
        index = i,
        centerFreqHz = hz,
        minLevelMb = mapped?.minLevelMb ?: -1500,
        maxLevelMb = mapped?.maxLevelMb ?: 1500,
        currentLevelMb = mapped?.currentLevelMb ?: 0,
      )
    }
  }

  fun set10BandLevel(band10Index: Int, levelMb: Int): List<EqBandUi> {
    val target5 = (band10Index / 2).coerceIn(0, 4)
    return setBandLevel(target5, levelMb)
  }

  fun release() {
    runCatching { loudnessEnhancer?.release() }
    runCatching { equalizer?.release() }
    runCatching { bassBoost?.release() }
    runCatching { presetReverb?.release() }
    loudnessEnhancer = null
    equalizer = null
    bassBoost = null
    presetReverb = null
    attachedSessionId = -1
  }
}
