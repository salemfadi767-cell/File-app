package com.example.domain.media

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.MainActivity
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CastBackgroundState(
  val isRunning: Boolean = false,
  val isPlaying: Boolean = false,
  val title: String = "",
  val subtitleName: String = "",
  val targetDeviceName: String = "",
  val mediaPath: String = "",
)

class MediaCastService : Service() {

  companion object {
    const val CHANNEL_ID = "vortex_tv_cast_channel"
    const val NOTIFICATION_ID = 7401
    const val ACTION_START = "com.example.CAST_START"
    const val ACTION_TOGGLE = "com.example.CAST_TOGGLE"
    const val ACTION_STOP = "com.example.CAST_STOP"
    const val EXTRA_MEDIA_PATH = "media_path"
    const val EXTRA_SUBTITLE_PATH = "subtitle_path"
    const val EXTRA_TITLE = "title"
    const val EXTRA_DEVICE_NAME = "device_name"
    const val EXTRA_POSITION_MS = "position_ms"

    private val _state = MutableStateFlow(CastBackgroundState())
    val state: StateFlow<CastBackgroundState> = _state.asStateFlow()

    @Volatile
    var sharedBackgroundPlayer: ExoPlayer? = null
      private set

    fun startBackgroundCast(
      context: Context,
      mediaPath: String,
      subtitlePath: String?,
      title: String,
      deviceName: String,
      positionMs: Long = 0L,
    ) {
      val intent = Intent(context, MediaCastService::class.java).apply {
        action = ACTION_START
        putExtra(EXTRA_MEDIA_PATH, mediaPath)
        putExtra(EXTRA_SUBTITLE_PATH, subtitlePath.orEmpty())
        putExtra(EXTRA_TITLE, title)
        putExtra(EXTRA_DEVICE_NAME, deviceName)
        putExtra(EXTRA_POSITION_MS, positionMs)
      }
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
      } else {
        context.startService(intent)
      }
    }

    fun stopBackgroundCast(context: Context) {
      val intent = Intent(context, MediaCastService::class.java).apply { action = ACTION_STOP }
      runCatching { context.startService(intent) }
    }
  }

  private var localPlayer: ExoPlayer? = null

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    ensureChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_STOP -> {
        releasePlayer()
        _state.value = CastBackgroundState()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        return START_NOT_STICKY
      }
      ACTION_TOGGLE -> {
        val p = localPlayer
        if (p != null) {
          if (p.isPlaying) p.pause() else p.play()
          _state.value = _state.value.copy(isPlaying = p.isPlaying)
          postForegroundNotification()
        }
      }
      ACTION_START -> {
        val mediaPath = intent.getStringExtra(EXTRA_MEDIA_PATH).orEmpty()
        val subPath = intent.getStringExtra(EXTRA_SUBTITLE_PATH).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Vortex Cast" }
        val deviceName = intent.getStringExtra(EXTRA_DEVICE_NAME).orEmpty().ifBlank { "TV / Background" }
        val posMs = intent.getLongExtra(EXTRA_POSITION_MS, 0L)

        startOrUpdatePlayer(mediaPath, subPath, posMs)
        _state.value = CastBackgroundState(
          isRunning = true,
          isPlaying = true,
          title = title,
          subtitleName = if (subPath.isNotBlank()) File(subPath).name else "",
          targetDeviceName = deviceName,
          mediaPath = mediaPath,
        )
        postForegroundNotification()
      }
    }
    return START_STICKY
  }

  private fun startOrUpdatePlayer(mediaPath: String, subPath: String, posMs: Long) {
    val player = localPlayer ?: ExoPlayer.Builder(this).build().also { p ->
      localPlayer = p
      sharedBackgroundPlayer = p
      p.addListener(object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
          _state.value = _state.value.copy(isPlaying = isPlaying)
          postForegroundNotification()
        }
      })
    }
    if (mediaPath.isNotBlank()) {
      val uri = if (mediaPath.startsWith("http", true)) Uri.parse(mediaPath) else Uri.fromFile(File(mediaPath))
      val itemBuilder = MediaItem.Builder().setUri(uri)
      if (subPath.isNotBlank() && File(subPath).exists()) {
        val subUri = Uri.fromFile(File(subPath))
        val mime = if (subPath.endsWith(".vtt", true)) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP
        itemBuilder.setSubtitleConfigurations(
          listOf(
            MediaItem.SubtitleConfiguration.Builder(subUri)
              .setMimeType(mime)
              .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
              .build()
          )
        )
      }
      player.setMediaItem(itemBuilder.build())
      player.prepare()
      if (posMs > 0L) player.seekTo(posMs)
      player.playWhenReady = true
    }
  }

  private fun postForegroundNotification() {
    val notification = buildNotification()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }
  }

  private fun buildNotification(): Notification {
    val st = _state.value
    val openIntent = PendingIntent.getActivity(
      this,
      0,
      Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )
    val toggleIntent = PendingIntent.getService(
      this,
      1,
      Intent(this, MediaCastService::class.java).setAction(ACTION_TOGGLE),
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )
    val stopIntent = PendingIntent.getService(
      this,
      2,
      Intent(this, MediaCastService::class.java).setAction(ACTION_STOP),
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )
    val subLine = if (st.subtitleName.isNotBlank()) " • Sub: ${st.subtitleName}" else ""
    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(android.R.drawable.ic_media_play)
      .setContentTitle("${st.targetDeviceName}: ${st.title}")
      .setContentText((if (st.isPlaying) "Casting in background" else "Paused") + subLine)
      .setContentIntent(openIntent)
      .setOngoing(st.isPlaying)
      .addAction(
        if (st.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
        if (st.isPlaying) "Pause" else "Resume",
        toggleIntent,
      )
      .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopIntent)
      .build()
  }

  private fun ensureChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
        mgr.createNotificationChannel(
          NotificationChannel(
            CHANNEL_ID,
            "Vortex TV & Background Cast",
            NotificationManager.IMPORTANCE_LOW,
          )
        )
      }
    }
  }

  private fun releasePlayer() {
    runCatching { localPlayer?.release() }
    localPlayer = null
    sharedBackgroundPlayer = null
  }

  override fun onDestroy() {
    releasePlayer()
    _state.value = CastBackgroundState()
    super.onDestroy()
  }
}
