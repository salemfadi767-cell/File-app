package com.example.domain.media

import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import com.example.domain.fs.FileSourceType
import com.example.domain.fs.VirtualFileNode
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class DiscoveredMediaKind {
  PHOTOS,
  VIDEOS,
  AUDIO,
}

data class MediaBucketSummary(
  val bucketName: String,
  val folderPath: String,
  val items: List<VirtualFileNode>,
)

object MediaLibraryScanner {

  private val photoExts = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "avif")
  private val videoExts = setOf("mp4", "mkv", "webm", "mov", "avi", "m4v", "3gp", "ts")
  private val audioExts = setOf("mp3", "m4a", "flac", "wav", "ogg", "opus", "aac")

  suspend fun discoverMediaBuckets(
    context: Context,
    kind: DiscoveredMediaKind,
  ): List<MediaBucketSummary> =
    withContext(Dispatchers.IO) {
      val byFolder = LinkedHashMap<String, MutableList<VirtualFileNode>>()
      val seenPaths = HashSet<String>()

      // 1. Query Android MediaStore for indexed media
      val contentUri =
        when (kind) {
          DiscoveredMediaKind.PHOTOS -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
          DiscoveredMediaKind.VIDEOS -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
          DiscoveredMediaKind.AUDIO -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

      val projection =
        arrayOf(
          MediaStore.MediaColumns.DATA,
          MediaStore.MediaColumns.DISPLAY_NAME,
          MediaStore.MediaColumns.SIZE,
          MediaStore.MediaColumns.DATE_MODIFIED,
        )

      runCatching {
        context.contentResolver.query(
          contentUri,
          projection,
          null,
          null,
          "${MediaStore.MediaColumns.DATE_MODIFIED} DESC",
        )?.use { cursor ->
          val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
          val nameCol = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
          val sizeCol = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE)
          val modCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)
          var count = 0
          while (cursor.moveToNext() && count < 600) {
            val path = if (dataCol >= 0) cursor.getString(dataCol).orEmpty() else ""
            if (path.isBlank() || !seenPaths.add(path)) continue
            val f = File(path)
            if (!f.exists() || !f.canRead()) continue
            val name = if (nameCol >= 0) cursor.getString(nameCol) ?: f.name else f.name
            val size = if (sizeCol >= 0) cursor.getLong(sizeCol) else f.length()
            val modMs = if (modCol >= 0) cursor.getLong(modCol) * 1000L else f.lastModified()
            val folder = f.parentFile?.absolutePath ?: "/"
            byFolder.getOrPut(folder) { mutableListOf() }.add(
              VirtualFileNode(
                name = name,
                path = path,
                isDirectory = false,
                size = size,
                lastModified = modMs,
                sourceType = FileSourceType.LOCAL,
              )
            )
            count++
          }
        }
      }

      // 2. Direct folder walk across common directories + app downloads
      val exts =
        when (kind) {
          DiscoveredMediaKind.PHOTOS -> photoExts
          DiscoveredMediaKind.VIDEOS -> videoExts
          DiscoveredMediaKind.AUDIO -> audioExts
        }
      val dirsToScan =
        listOfNotNull(
          Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
          Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
          Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
          Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
          Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
          File(context.filesDir, "VortexDownloads"),
          File(context.filesDir, "vortex_workspace"),
        ).distinctBy { it.absolutePath }

      for (root in dirsToScan) {
        if (!root.exists() || !root.canRead()) continue
        runCatching {
          root.walkTopDown().maxDepth(3).filter { it.isFile && it.canRead() }.forEach { f ->
            if (f.extension.lowercase() in exts && seenPaths.add(f.absolutePath)) {
              val folder = f.parentFile?.absolutePath ?: root.absolutePath
              byFolder.getOrPut(folder) { mutableListOf() }.add(
                VirtualFileNode(
                  name = f.name,
                  path = f.absolutePath,
                  isDirectory = false,
                  size = f.length(),
                  lastModified = f.lastModified(),
                  sourceType = FileSourceType.LOCAL,
                )
              )
            }
          }
        }
      }

      byFolder.entries
        .map { (folderPath, list) ->
          MediaBucketSummary(
            bucketName = File(folderPath).name.ifBlank { folderPath },
            folderPath = folderPath,
            items = list.sortedByDescending { it.lastModified },
          )
        }
        .sortedByDescending { it.items.size }
    }
}
