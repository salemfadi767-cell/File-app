package com.example.domain.fs

import java.io.File
import java.util.Locale
import net.lingala.zip4j.ZipFile

data class MagicDetectionResult(
  val detectedFormatName: String,
  val suggestedExtension: String,
  val mimeType: String,
  val category: FileCategory,
  val confidencePercent: Int,
  val matchesCurrentExtension: Boolean,
  val headerHexPreview: String,
  val compatibleReaderIds: List<String>, // "image", "video", "audio", "pdf", "word", "excel", "pptx", "apk", "archive", "db", "text", "hex"
)

object MagicBytesDetector {

  fun inspectFile(file: File): MagicDetectionResult {
    if (!file.exists() || !file.isFile || !file.canRead()) {
      return unknownResult(file, ByteArray(0))
    }
    val buf = ByteArray(1024)
    val read =
      runCatching {
        file.inputStream().use { inp -> inp.read(buf) }.coerceAtLeast(0)
      }.getOrDefault(0)
    val slice = buf.copyOf(read)
    val base = inspectBytes(slice, file.extension.lowercase(Locale.ROOT))

    // Refine ZIP-based containers (APK, AAB, DOCX, XLSX, PPTX) by inspecting actual entries
    if (base.suggestedExtension == "zip") {
      val refined = refineZipContainer(file)
      if (refined != null) {
        val currentExt = file.extension.lowercase(Locale.ROOT)
        return refined.copy(
          matchesCurrentExtension = currentExt == refined.suggestedExtension,
          headerHexPreview = base.headerHexPreview,
        )
      }
    }
    return base
  }

  fun inspectBytes(bytes: ByteArray, currentExt: String = ""): MagicDetectionResult {
    val hexPreview = bytes.take(12).joinToString(" ") { "%02X".format(it) }
    val cur = currentExt.lowercase(Locale.ROOT)

    fun build(
      name: String,
      ext: String,
      mime: String,
      cat: FileCategory,
      conf: Int,
      readers: List<String>,
      aliasExts: Set<String> = emptySet(),
    ): MagicDetectionResult =
      MagicDetectionResult(
        detectedFormatName = name,
        suggestedExtension = ext,
        mimeType = mime,
        category = cat,
        confidencePercent = conf,
        matchesCurrentExtension = cur == ext || cur in aliasExts,
        headerHexPreview = hexPreview,
        compatibleReaderIds = (readers + listOf("hex")).distinct(),
      )

    if (bytes.size >= 6 && String(bytes, 0, 6, Charsets.US_ASCII) == "VLOCK1") {
      return build("Vortex Encrypted Vault", "vlock", "application/octet-stream", FileCategory.VAULT, 100, listOf("vault"))
    }
    if (bytes.size >= 8 &&
      bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() &&
      bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte()
    ) {
      return build("PNG Image", "png", "image/png", FileCategory.IMAGE, 99, listOf("image"))
    }
    if (bytes.size >= 3 &&
      bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte()
    ) {
      return build("JPEG Image", "jpg", "image/jpeg", FileCategory.IMAGE, 99, listOf("image"), setOf("jpeg"))
    }
    if (bytes.size >= 6 &&
      (String(bytes, 0, 6, Charsets.US_ASCII) == "GIF87a" ||
        String(bytes, 0, 6, Charsets.US_ASCII) == "GIF89a")
    ) {
      return build("GIF Animated Image", "gif", "image/gif", FileCategory.IMAGE, 99, listOf("image"))
    }
    if (bytes.size >= 12 &&
      String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF"
    ) {
      val fourCc = String(bytes, 8, 4, Charsets.US_ASCII)
      when (fourCc) {
        "WEBP" -> return build("WebP Image", "webp", "image/webp", FileCategory.IMAGE, 99, listOf("image"))
        "WAVE" -> return build("WAV Audio", "wav", "audio/wav", FileCategory.AUDIO, 99, listOf("audio"))
        "AVI " -> return build("AVI Video", "avi", "video/x-msvideo", FileCategory.VIDEO, 98, listOf("video"))
      }
    }
    if (bytes.size >= 2 && bytes[0] == 0x42.toByte() && bytes[1] == 0x4D.toByte()) {
      return build("BMP Bitmap Image", "bmp", "image/bmp", FileCategory.IMAGE, 92, listOf("image"))
    }
    if (bytes.size >= 5 && String(bytes, 0, 5, Charsets.US_ASCII) == "%PDF-") {
      return build("PDF Document", "pdf", "application/pdf", FileCategory.PDF, 99, listOf("pdf"))
    }
    if (bytes.size >= 16 && String(bytes, 0, 15, Charsets.US_ASCII) == "SQLite format 3") {
      return build("SQLite 3 Database", "sqlite", "application/x-sqlite3", FileCategory.DATABASE, 100, listOf("db"), setOf("db", "sqlite3"))
    }
    if (bytes.size >= 4 && String(bytes, 0, 4, Charsets.US_ASCII) == "fLaC") {
      return build("FLAC Lossless Audio", "flac", "audio/flac", FileCategory.AUDIO, 99, listOf("audio"))
    }
    if (bytes.size >= 4 && String(bytes, 0, 4, Charsets.US_ASCII) == "OggS") {
      return build("Ogg / Opus Audio", "ogg", "audio/ogg", FileCategory.AUDIO, 97, listOf("audio"), setOf("opus"))
    }
    if (bytes.size >= 3 &&
      (String(bytes, 0, 3, Charsets.US_ASCII) == "ID3" ||
        (bytes[0] == 0xFF.toByte() && (bytes[1].toInt() and 0xE0) == 0xE0))
    ) {
      return build("MP3 MPEG Audio", "mp3", "audio/mpeg", FileCategory.AUDIO, 95, listOf("audio"))
    }
    if (bytes.size >= 12 && String(bytes, 4, 4, Charsets.US_ASCII) == "ftyp") {
      val brand = String(bytes, 8, 4, Charsets.US_ASCII)
      return if (brand.startsWith("M4A")) {
        build("M4A / AAC Audio", "m4a", "audio/mp4", FileCategory.AUDIO, 97, listOf("audio"))
      } else {
        build("MP4 / QuickTime Video", "mp4", "video/mp4", FileCategory.VIDEO, 96, listOf("video", "audio"), setOf("mov", "m4v", "3gp"))
      }
    }
    if (bytes.size >= 4 &&
      bytes[0] == 0x1A.toByte() && bytes[1] == 0x45.toByte() &&
      bytes[2] == 0xDF.toByte() && bytes[3] == 0xA3.toByte()
    ) {
      return build("Matroska / WebM Video", "mkv", "video/x-matroska", FileCategory.VIDEO, 96, listOf("video"), setOf("webm"))
    }
    if (bytes.size >= 6 &&
      bytes[0] == 0x37.toByte() && bytes[1] == 0x7A.toByte() &&
      bytes[2] == 0xBC.toByte() && bytes[3] == 0xAF.toByte() &&
      bytes[4] == 0x27.toByte() && bytes[5] == 0x1C.toByte()
    ) {
      return build("7-Zip Archive", "7z", "application/x-7z-compressed", FileCategory.ARCHIVE, 99, listOf("archive"))
    }
    if (bytes.size >= 6 && String(bytes, 0, 4, Charsets.US_ASCII) == "Rar!") {
      return build("RAR Archive", "rar", "application/vnd.rar", FileCategory.ARCHIVE, 99, listOf("archive"))
    }
    if (bytes.size >= 4 &&
      bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte() &&
      bytes[2] == 0x03.toByte() && bytes[3] == 0x04.toByte()
    ) {
      return build("ZIP / OOXML / APK Container", "zip", "application/zip", FileCategory.ARCHIVE, 94, listOf("archive", "apk", "word", "excel", "pptx"), setOf("apk", "apks", "xapk", "apkm", "aab", "docx", "xlsx", "pptx", "jar"))
    }
    if (bytes.size >= 4 &&
      bytes[0] == 0x7F.toByte() && bytes[1] == 'E'.code.toByte() &&
      bytes[2] == 'L'.code.toByte() && bytes[3] == 'F'.code.toByte()
    ) {
      return build("ELF Native Binary (.so)", "so", "application/octet-stream", FileCategory.BINARY, 99, listOf("hex"))
    }
    if (bytes.size >= 4 && String(bytes, 0, 4, Charsets.US_ASCII) == "dex\n") {
      return build("Android Dalvik DEX", "dex", "application/octet-stream", FileCategory.BINARY, 99, listOf("hex", "apk"))
    }
    if (bytes.size >= 11 && String(bytes, 0, 11, Charsets.US_ASCII).startsWith("d8:announce")) {
      return build("BitTorrent Metadata", "torrent", "application/x-bittorrent", FileCategory.TORRENT, 98, listOf("torrent", "text"))
    }

    // Heuristic text / code check
    val textCheckLen = minOf(bytes.size, 256)
    if (textCheckLen > 0) {
      val nonPrintable =
        (0 until textCheckLen).count { idx ->
          val b = bytes[idx].toInt() and 0xFF
          b < 9 || (b in 14..31 && b != 27)
        }
      if (nonPrintable == 0) {
        val sample = String(bytes, 0, textCheckLen, Charsets.UTF_8).trimStart()
        return when {
          sample.startsWith("{") || sample.startsWith("[") ->
            build("JSON Data", "json", "application/json", FileCategory.CODE, 84, listOf("text"))
          sample.startsWith("<!DOCTYPE html", true) || sample.startsWith("<html", true) ->
            build("HTML Document", "html", "text/html", FileCategory.CODE, 88, listOf("text"))
          sample.startsWith("<?xml") || sample.startsWith("<svg") ->
            build("XML / SVG Markup", "xml", "text/xml", FileCategory.CODE, 85, listOf("text"))
          else ->
            build("UTF-8 Text / Source Code", "txt", "text/plain", FileCategory.CODE, 78, listOf("text"), setOf("kt", "py", "js", "java", "md", "csv", "log", "sh", "sql"))
        }
      }
    }

    return MagicDetectionResult(
      detectedFormatName = "Binary / Unknown",
      suggestedExtension = cur.ifBlank { "bin" },
      mimeType = "application/octet-stream",
      category = FileCategory.BINARY,
      confidencePercent = 40,
      matchesCurrentExtension = true,
      headerHexPreview = hexPreview,
      compatibleReaderIds = listOf("hex", "text"),
    )
  }

  private fun refineZipContainer(file: File): MagicDetectionResult? {
    val names =
      runCatching {
        ZipFile(file).fileHeaders.map { it.fileName.lowercase(Locale.ROOT) }.toSet()
      }.getOrNull() ?: return null

    return when {
      "androidmanifest.xml" in names ->
        MagicDetectionResult(
          detectedFormatName = "Android APK Package",
          suggestedExtension = "apk",
          mimeType = "application/vnd.android.package-archive",
          category = FileCategory.APK,
          confidencePercent = 99,
          matchesCurrentExtension = false,
          headerHexPreview = "",
          compatibleReaderIds = listOf("apk", "archive", "hex"),
        )
      names.any { it.endsWith(".apk") } ->
        MagicDetectionResult(
          detectedFormatName = "Android Split APK Bundle (APKS/XAPK)",
          suggestedExtension = "apks",
          mimeType = "application/vnd.android.package-archive",
          category = FileCategory.APK,
          confidencePercent = 97,
          matchesCurrentExtension = false,
          headerHexPreview = "",
          compatibleReaderIds = listOf("apk", "archive", "hex"),
        )
      "word/document.xml" in names ->
        MagicDetectionResult(
          detectedFormatName = "Microsoft Word (.docx)",
          suggestedExtension = "docx",
          mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
          category = FileCategory.WORD,
          confidencePercent = 99,
          matchesCurrentExtension = false,
          headerHexPreview = "",
          compatibleReaderIds = listOf("word", "archive", "hex"),
        )
      "xl/workbook.xml" in names ->
        MagicDetectionResult(
          detectedFormatName = "Microsoft Excel (.xlsx)",
          suggestedExtension = "xlsx",
          mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          category = FileCategory.EXCEL,
          confidencePercent = 99,
          matchesCurrentExtension = false,
          headerHexPreview = "",
          compatibleReaderIds = listOf("excel", "archive", "hex"),
        )
      "ppt/presentation.xml" in names ->
        MagicDetectionResult(
          detectedFormatName = "Microsoft PowerPoint (.pptx)",
          suggestedExtension = "pptx",
          mimeType = "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          category = FileCategory.POWERPOINT,
          confidencePercent = 99,
          matchesCurrentExtension = false,
          headerHexPreview = "",
          compatibleReaderIds = listOf("pptx", "archive", "hex"),
        )
      else -> null
    }
  }

  private fun unknownResult(file: File, bytes: ByteArray) =
    MagicDetectionResult(
      detectedFormatName = "Unreadable / Empty",
      suggestedExtension = file.extension,
      mimeType = "application/octet-stream",
      category = FileCategory.BINARY,
      confidencePercent = 0,
      matchesCurrentExtension = true,
      headerHexPreview = bytes.joinToString(" ") { "%02X".format(it) },
      compatibleReaderIds = listOf("hex"),
    )
}
