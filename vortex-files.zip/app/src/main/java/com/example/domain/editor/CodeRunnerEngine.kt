package com.example.domain.editor

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.os.Handler
import android.os.Looper
import android.webkit.ConsoleMessage
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.shizuku.RootShellManager
import com.example.shizuku.ShizukuManager
import com.example.shizuku.ShizukuStatus
import java.io.File
import java.io.StringReader
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.coroutines.resume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xml.sax.InputSource

data class CodeRunResult(
  val success: Boolean,
  val stdout: String,
  val stderr: String = "",
  val durationMs: Long = 0L,
  val isHtmlPreviewAvailable: Boolean = false,
  val htmlPreviewContent: String? = null,
)

class CodeRunnerEngine(
  private val context: Context,
  private val shizukuManager: ShizukuManager,
  private val rootShellManager: RootShellManager,
) {

  suspend fun runCode(
    filePath: String,
    code: String,
    language: CodeLanguage,
    useRoot: Boolean = false,
    argsInput: String = "",
  ): CodeRunResult {
    val start = System.currentTimeMillis()
    return try {
      val result =
        when (language) {
          CodeLanguage.SHELL -> runShell(code, filePath, useRoot)
          CodeLanguage.SQL -> runSql(code, filePath)
          CodeLanguage.JAVASCRIPT -> runJavaScriptInWebView(code, filePath)
          CodeLanguage.XML -> runXmlOrHtml(code, filePath)
          CodeLanguage.JSON -> validateJson(code)
          CodeLanguage.PYTHON -> runPython(code, filePath, argsInput)
          CodeLanguage.KOTLIN,
          CodeLanguage.JAVA -> runJvmScriptSubset(code, language)
          CodeLanguage.SMALI -> analyzeSmali(code)
          CodeLanguage.PLAIN -> runPlainOrYaml(code, filePath)
        }
      result.copy(durationMs = System.currentTimeMillis() - start)
    } catch (t: Throwable) {
      CodeRunResult(
        success = false,
        stdout = "",
        stderr = t.message ?: t.javaClass.simpleName,
        durationMs = System.currentTimeMillis() - start,
      )
    }
  }

  private suspend fun runShell(code: String, filePath: String, useRoot: Boolean): CodeRunResult =
    withContext(Dispatchers.IO) {
      val trimmed = code.trim()
      if (trimmed.isEmpty()) {
        return@withContext CodeRunResult(true, "(empty script)", "")
      }
      if (useRoot) {
        val r = rootShellManager.execRoot(trimmed)
        return@withContext CodeRunResult(r.success, if (r.success) r.output else "", if (r.success) "" else r.output)
      }
      if (shizukuManager.status.value == ShizukuStatus.CONNECTED) {
        val out = runCatching { shizukuManager.getService()?.execShell(trimmed) }.getOrNull()
        if (out != null) {
          return@withContext CodeRunResult(true, out, "")
        }
      }
      val workDir = File(filePath).parentFile?.takeIf { it.exists() && it.canRead() } ?: context.filesDir
      val proc =
        ProcessBuilder("sh", "-c", trimmed)
          .directory(workDir)
          .redirectErrorStream(false)
          .start()
      val stdout = proc.inputStream.bufferedReader().readText()
      val stderr = proc.errorStream.bufferedReader().readText()
      val exit = proc.waitFor()
      CodeRunResult(exit == 0, stdout.ifBlank { if (exit == 0) "(exit 0)" else "" }, stderr)
    }

  private suspend fun runSql(code: String, filePath: String): CodeRunResult =
    withContext(Dispatchers.IO) {
      val siblingDb =
        File(filePath).parentFile?.listFiles()?.firstOrNull {
          it.isFile && it.extension.lowercase() in setOf("db", "sqlite", "sqlite3")
        }
      val db =
        if (siblingDb != null && siblingDb.canRead()) {
          SQLiteDatabase.openDatabase(siblingDb.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
        } else {
          SQLiteDatabase.create(null)
        }

      db.use { database ->
        val statements = splitSqlStatements(code)
        val out = StringBuilder()
        if (siblingDb != null) {
          out.appendLine("-- Connected DB: ${siblingDb.name}")
        } else {
          out.appendLine("-- Connected DB: In-Memory SQLite")
        }
        var executed = 0
        for (stmt in statements) {
          val s = stmt.trim()
          if (s.isEmpty()) continue
          executed++
          val upper = s.uppercase()
          if (upper.startsWith("SELECT") || upper.startsWith("PRAGMA") || upper.startsWith("WITH") || upper.startsWith("EXPLAIN")) {
            database.rawQuery(s, null).use { cursor ->
              val cols = cursor.columnNames
              out.appendLine(cols.joinToString(" | "))
              out.appendLine("-".repeat((cols.joinToString(" | ").length).coerceIn(10, 72)))
              var rowCount = 0
              while (cursor.moveToNext() && rowCount < 200) {
                val vals = (0 until cursor.columnCount).map { i -> cursor.getString(i) ?: "NULL" }
                out.appendLine(vals.joinToString(" | "))
                rowCount++
              }
              out.appendLine("($rowCount row(s))")
              out.appendLine()
            }
          } else {
            database.execSQL(s)
            out.appendLine("OK: ${s.take(64)}${if (s.length > 64) "..." else ""}")
          }
        }
        if (executed == 0) out.appendLine("(No SQL statements executed)")
        CodeRunResult(true, out.toString().trimEnd())
      }
    }

  private fun splitSqlStatements(sql: String): List<String> {
    val result = mutableListOf<String>()
    val current = StringBuilder()
    var inSingle = false
    var inDouble = false
    var i = 0
    while (i < sql.length) {
      val c = sql[i]
      if (c == '-' && i + 1 < sql.length && sql[i + 1] == '-' && !inSingle && !inDouble) {
        while (i < sql.length && sql[i] != '\n') i++
        continue
      }
      if (c == '\'' && !inDouble) inSingle = !inSingle
      else if (c == '"' && !inSingle) inDouble = !inDouble
      if (c == ';' && !inSingle && !inDouble) {
        result.add(current.toString())
        current.clear()
      } else {
        current.append(c)
      }
      i++
    }
    if (current.isNotBlank()) result.add(current.toString())
    return result
  }

  private suspend fun runJavaScriptInWebView(code: String, filePath: String): CodeRunResult {
    val ext = filePath.substringAfterLast('.', "").lowercase()
    if (ext == "css") {
      val html =
        """
        <html><head><style>$code</style></head>
        <body><h1>Vortex CSS Preview</h1><p class="card">Live stylesheet preview active.</p><button>Action</button></body></html>
        """.trimIndent()
      return CodeRunResult(
        success = true,
        stdout = "CSS parsed (${code.lines().size} lines). Live preview ready.",
        isHtmlPreviewAvailable = true,
        htmlPreviewContent = html,
      )
    }

    return withContext(Dispatchers.Main) {
      suspendCancellableCoroutine { cont ->
        val logs = StringBuilder()
        val errors = StringBuilder()
        val webView = WebView(context)
        webView.setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
          webView.settings.safeBrowsingEnabled = false
        }

        webView.webChromeClient =
          object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
              val msg = consoleMessage.message()
              if (consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                errors.appendLine("[Error L${consoleMessage.lineNumber()}] $msg")
              } else {
                logs.appendLine(msg)
              }
              return true
            }
          }

        webView.webViewClient =
          object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
              val escaped = JSONObject.quote(code)
              val wrapper =
                """
                (function() {
                  try {
                    const __res = eval($escaped);
                    return __res === undefined ? "" : String(__res);
                  } catch (e) {
                    console.error(e && e.stack ? e.stack : String(e));
                    return "__ERR__:" + e;
                  }
                })();
                """.trimIndent()
              webView.evaluateJavascript(wrapper) { rawResult ->
                Handler(Looper.getMainLooper()).postDelayed({
                  val cleaned =
                    rawResult
                      ?.removePrefix("\"")
                      ?.removeSuffix("\"")
                      ?.replace("\\n", "\n")
                      ?.replace("\\\"", "\"")
                      .orEmpty()
                  if (cleaned.startsWith("__ERR__:")) {
                    errors.appendLine(cleaned.removePrefix("__ERR__:"))
                  } else if (cleaned.isNotBlank() && cleaned != "null") {
                    logs.appendLine("=> $cleaned")
                  }
                  val hasErr = errors.isNotBlank()
                  runCatching { webView.destroy() }
                  if (cont.isActive) {
                    cont.resume(
                      CodeRunResult(
                        success = !hasErr,
                        stdout = logs.toString().trim().ifEmpty { if (!hasErr) "(Executed cleanly, no output)" else "" },
                        stderr = errors.toString().trim(),
                      )
                    )
                  }
                }, 120)
              }
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
              Handler(Looper.getMainLooper()).post { runCatching { view?.destroy() } }
              if (cont.isActive) {
                cont.resume(CodeRunResult(success = false, stdout = "", stderr = "JS WebView renderer terminated"))
              }
              return true
            }
          }

        webView.loadDataWithBaseURL(null, "<!DOCTYPE html><html><body></body></html>", "text/html", "utf-8", null)
        cont.invokeOnCancellation { Handler(Looper.getMainLooper()).post { runCatching { webView.destroy() } } }
      }
    }
  }

  private suspend fun runXmlOrHtml(code: String, filePath: String): CodeRunResult =
    withContext(Dispatchers.IO) {
      val ext = filePath.substringAfterLast('.', "").lowercase()
      if (ext in setOf("html", "htm", "svg")) {
        val wrapped =
          if (ext == "svg" && !code.contains("<html", ignoreCase = true)) {
            "<html><body style='margin:0;display:flex;justify-content:center;align-items:center;background:#111;'>$code</body></html>"
          } else {
            code
          }
        return@withContext CodeRunResult(
          success = true,
          stdout = "HTML/SVG ready (${code.length} chars). Tap Live Preview to render.",
          isHtmlPreviewAvailable = true,
          htmlPreviewContent = wrapped,
        )
      }
      val factory = DocumentBuilderFactory.newInstance()
      val builder = factory.newDocumentBuilder()
      val doc = builder.parse(InputSource(StringReader(code)))
      val root = doc.documentElement
      CodeRunResult(
        success = true,
        stdout = "Valid XML • Root: <${root.tagName}> • Children: ${root.childNodes.length}",
      )
    }

  private fun validateJson(code: String): CodeRunResult {
    val trimmed = code.trim()
    return when {
      trimmed.startsWith("{") -> {
        val obj = JSONObject(trimmed)
        val keys = obj.keys().asSequence().toList()
        CodeRunResult(true, "Valid JSON Object • ${keys.size} top-level key(s): ${keys.take(12).joinToString()}")
      }
      trimmed.startsWith("[") -> {
        val arr = JSONArray(trimmed)
        CodeRunResult(true, "Valid JSON Array • ${arr.length()} item(s)")
      }
      else -> CodeRunResult(false, "", "JSON must start with '{' or '['")
    }
  }

  private suspend fun runPython(code: String, filePath: String, argsInput: String): CodeRunResult =
    withContext(Dispatchers.IO) {
      // Try native python3 binary if present (e.g. Termux/chroot/custom PATH)
      val pyPaths = listOf("python3", "/data/data/com.termux/files/usr/bin/python3", "/system/bin/python3")
      val availableBin =
        pyPaths.firstOrNull { bin ->
          runCatching {
            val p = ProcessBuilder(bin, "--version").start()
            p.waitFor() == 0
          }.getOrDefault(false)
        }
      val projectDir = File(filePath).parentFile
      val pipLibsDir = projectDir?.let { File(it, ".vortex_libs/pip") }?.takeIf { it.exists() }
      if (availableBin != null) {
        val tmp = File(context.cacheDir, "vortex_run.py").apply { writeText(code) }
        val cmd = mutableListOf(availableBin, tmp.absolutePath)
        if (argsInput.isNotBlank()) cmd.addAll(argsInput.split(" "))
        val pb = ProcessBuilder(cmd).redirectErrorStream(false)
        if (pipLibsDir != null) {
          val oldPyPath = pb.environment()["PYTHONPATH"].orEmpty()
          pb.environment()["PYTHONPATH"] =
            if (oldPyPath.isBlank()) pipLibsDir.absolutePath else "${pipLibsDir.absolutePath}:$oldPyPath"
        }
        val proc = pb.start()
        val out = proc.inputStream.bufferedReader().readText()
        val err = proc.errorStream.bufferedReader().readText()
        val exit = proc.waitFor()
        tmp.delete()
        return@withContext CodeRunResult(exit == 0, out, err)
      }

      // Built-in deterministic Python subset evaluator (variables, arithmetic, range loops, print)
      val out = StringBuilder()
      val env = mutableMapOf<String, String>()
      val lines = code.lines()
      var idx = 0
      while (idx < lines.size) {
        val raw = lines[idx]
        val line = raw.trim()
        if (line.isEmpty() || line.startsWith("#")) {
          idx++
          continue
        }
        val printMatch = Regex("""^print\((.*)\)$""").find(line)
        if (printMatch != null) {
          out.appendLine(evalSimpleExpr(printMatch.groupValues[1], env))
          idx++
          continue
        }
        val assignMatch = Regex("""^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)$""").find(line)
        if (assignMatch != null && !line.startsWith("if ") && !line.startsWith("for ")) {
          env[assignMatch.groupValues[1]] = evalSimpleExpr(assignMatch.groupValues[2], env)
          idx++
          continue
        }
        val forRange = Regex("""^for\s+([A-Za-z_]\w*)\s+in\s+range\((\d+)(?:,\s*(\d+))?\):$""").find(line)
        if (forRange != null) {
          val varName = forRange.groupValues[1]
          val a = forRange.groupValues[2].toInt()
          val b = forRange.groupValues[3].toIntOrNull()
          val startR = if (b == null) 0 else a
          val endR = b ?: a
          val bodyIndent = lines.getOrNull(idx + 1)?.takeWhile { it == ' ' || it == '\t' }?.length ?: 0
          val bodyLines = mutableListOf<String>()
          var j = idx + 1
          while (j < lines.size && (lines[j].isBlank() || lines[j].takeWhile { it == ' ' || it == '\t' }.length >= bodyIndent.coerceAtLeast(1))) {
            if (lines[j].isNotBlank()) bodyLines.add(lines[j].trim())
            j++
          }
          for (v in startR until endR.coerceAtMost(startR + 500)) {
            env[varName] = v.toString()
            for (bl in bodyLines) {
              val pm = Regex("""^print\((.*)\)$""").find(bl)
              if (pm != null) out.appendLine(evalSimpleExpr(pm.groupValues[1], env))
            }
          }
          idx = j
          continue
        }
        idx++
      }
      val info =
        if (out.isEmpty()) "[Vortex Python Runner] No print() output produced (native python3 binary not installed on device)."
        else out.toString().trimEnd()
      CodeRunResult(true, info)
    }

  private fun runJvmScriptSubset(code: String, language: CodeLanguage): CodeRunResult {
    val out = StringBuilder()
    val env = mutableMapOf<String, String>()
    for (raw in code.lines()) {
      val line = raw.trim().removeSuffix(";")
      if (line.isEmpty() || line.startsWith("//") || line.startsWith("package ") || line.startsWith("import ")) continue
      val decl = Regex("""^(?:val|var|int|long|double|String|let|const)\s+([A-Za-z_]\w*)(?:\s*:\s*\w+)?\s*=\s*(.+)$""").find(line)
      if (decl != null) {
        env[decl.groupValues[1]] = evalSimpleExpr(decl.groupValues[2], env)
        continue
      }
      val ktPrint = Regex("""^(?:println|print)\((.*)\)$""").find(line)
      if (ktPrint != null) {
        val evaluated = evalSimpleExpr(ktPrint.groupValues[1], env)
        if (line.startsWith("println")) out.appendLine(evaluated) else out.append(evaluated)
        continue
      }
      val javaPrint = Regex("""^System\.out\.println\((.*)\)$""").find(line)
      if (javaPrint != null) {
        out.appendLine(evalSimpleExpr(javaPrint.groupValues[1], env))
      }
    }
    val summary = IdeAssistant.extractSymbols(code, language)
    if (out.isEmpty()) {
      out.appendLine("[Vortex ${language.label} Runner]")
      out.appendLine("Parsed ${summary.size} symbol(s), ${code.lines().size} line(s).")
      summary.take(10).forEach { out.appendLine("• L${it.lineNumber}: ${it.kind} ${it.name}") }
    }
    return CodeRunResult(true, out.toString().trimEnd())
  }

  private fun analyzeSmali(code: String): CodeRunResult {
    val symbols = IdeAssistant.extractSymbols(code, CodeLanguage.SMALI)
    val methods = symbols.count { it.kind == "method" }
    val fields = symbols.count { it.kind == "field" }
    return CodeRunResult(
      success = true,
      stdout = "Smali Static Inspection:\n• Methods: $methods\n• Fields: $fields\n• Lines: ${code.lines().size}",
    )
  }

  private fun runPlainOrYaml(code: String, filePath: String): CodeRunResult {
    val ext = filePath.substringAfterLast('.', "").lowercase()
    return if (ext == "md") {
      val html =
        "<html><body style='font-family:sans-serif;padding:16px;background:#12161f;color:#e5e7eb;'>" +
          code.lines().joinToString("<br/>") { line ->
            when {
              line.startsWith("### ") -> "<h3>${line.drop(4)}</h3>"
              line.startsWith("## ") -> "<h2>${line.drop(3)}</h2>"
              line.startsWith("# ") -> "<h1>${line.drop(2)}</h1>"
              line.startsWith("- ") -> "• ${line.drop(2)}"
              else -> line
            }
          } + "</body></html>"
      CodeRunResult(true, "Markdown preview ready (${code.lines().size} lines).", isHtmlPreviewAvailable = true, htmlPreviewContent = html)
    } else {
      CodeRunResult(true, "Document checked: ${code.lines().size} line(s), ${code.length} char(s).")
    }
  }

  private fun evalSimpleExpr(expr: String, env: Map<String, String>): String {
    val t = expr.trim()
    if ((t.startsWith("\"") && t.endsWith("\"")) || (t.startsWith("'") && t.endsWith("'"))) {
      var str = t.substring(1, t.length - 1)
      for ((k, v) in env) {
        str = str.replace("$$k", v).replace("\${$k}", v)
      }
      return str
    }
    if (t in env) return env[t].orEmpty()
    // Basic + concatenation or arithmetic
    if ("+" in t && !t.contains("\"")) {
      val parts = t.split("+").map { it.trim() }
      val nums = parts.mapNotNull { (env[it] ?: it).toDoubleOrNull() }
      if (nums.size == parts.size) {
        val sum = nums.sum()
        return if (sum % 1.0 == 0.0) sum.toLong().toString() else sum.toString()
      }
    }
    if ("*" in t) {
      val parts = t.split("*").map { it.trim() }
      val nums = parts.mapNotNull { (env[it] ?: it).toDoubleOrNull() }
      if (nums.size == parts.size && nums.isNotEmpty()) {
        val prod = nums.reduce { acc, d -> acc * d }
        return if (prod % 1.0 == 0.0) prod.toLong().toString() else prod.toString()
      }
    }
    if ("-" in t && !t.startsWith("-")) {
      val parts = t.split("-").map { it.trim() }
      val nums = parts.mapNotNull { (env[it] ?: it).toDoubleOrNull() }
      if (nums.size == 2) {
        val diff = nums[0] - nums[1]
        return if (diff % 1.0 == 0.0) diff.toLong().toString() else diff.toString()
      }
    }
    return t.split("+").joinToString("") { part ->
      val p = part.trim()
      when {
        (p.startsWith("\"") && p.endsWith("\"")) || (p.startsWith("'") && p.endsWith("'")) ->
          p.substring(1, p.length - 1)
        p in env -> env[p].orEmpty()
        else -> p
      }
    }
  }
}
