package com.example.domain.archive

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class CompressionMode {
  LOSSLESS,
  LOSSY,
}

enum class ImageOutputFormat(val ext: String, val label: String, val supportsLossless: Boolean) {
  PNG("png", "PNG (Lossless)", true),
  WEBP_LOSSLESS("webp", "WebP (Lossless)", true),
  WEBP_LOSSY("webp", "WebP (Lossy)", false),
  JPEG("jpg", "JPEG (Lossy)", false),
  BMP("bmp", "BMP (Uncompressed)", true),
}

data class MediaCompressionSummary(
  val outputFiles: List<File>,
  val originalTotalBytes: Long,
  val outputTotalBytes: Long,
  val isLossless: Boolean,
) {
  val savedPercent: Int
    get() =
      if (originalTotalBytes <= 0L) 0
      else (((originalTotalBytes - outputTotalBytes) * 100L) / originalTotalBytes).toInt()
}

class MediaCompressionEngine {

  fun estimateCompressedSize(
    originalBytes: Long,
    mode: CompressionMode,
    quality: Int,
    scalePercent: Int,
  ): Long {
    if (originalBytes <= 0L) return 0L
    val scaleFactor = (scalePercent.coerceIn(10, 100) / 100.0).let { it * it }
    return if (mode == CompressionMode.LOSSLESS) {
      (originalBytes * 0.78 * scaleFactor).toLong().coerceAtLeast(1024L)
    } else {
      val qFactor = (quality.coerceIn(10, 95) / 100.0) * 0.52 + 0.06
      (originalBytes * qFactor * scaleFactor).toLong().coerceAtLeast(512L)
    }
  }

  suspend fun compressImages(
    inputFiles: List<File>,
    outputDir: File,
    mode: CompressionMode,
    quality: Int,
    scalePercent: Int,
    targetFormat: ImageOutputFormat? = null,
    onProgress: (Int) -> Unit = {},
  ): MediaCompressionSummary =
    withContext(Dispatchers.IO) {
      outputDir.mkdirs()
      val outFiles = mutableListOf<File>()
      var origTotal = 0L
      var outTotal = 0L
      val total = inputFiles.size.coerceAtLeast(1)

      val resolvedFormat =
        targetFormat
          ?: if (mode == CompressionMode.LOSSLESS) ImageOutputFormat.WEBP_LOSSLESS
          else ImageOutputFormat.JPEG

      for ((idx, src) in inputFiles.withIndex()) {
        if (!src.exists() || !src.isFile) continue
        origTotal += src.length()

        val decoded = BitmapFactory.decodeFile(src.absolutePath) ?: continue
        val scaled =
          if (scalePercent < 100) {
            val w = (decoded.width * scalePercent / 100).coerceAtLeast(1)
            val h = (decoded.height * scalePercent / 100).coerceAtLeast(1)
            Bitmap.createScaledBitmap(decoded, w, h, true).also {
              if (it !== decoded) decoded.recycle()
            }
          } else {
            decoded
          }

        val suffix = if (mode == CompressionMode.LOSSLESS) "_lossless" else "_q$quality"
        val outFile = uniqueOutputFile(outputDir, "${src.nameWithoutExtension}$suffix.${resolvedFormat.ext}")

        when (resolvedFormat) {
          ImageOutputFormat.PNG -> {
            FileOutputStream(outFile).use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
          }
          ImageOutputFormat.JPEG -> {
            FileOutputStream(outFile).use {
              scaled.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(10, 100), it)
            }
          }
          ImageOutputFormat.WEBP_LOSSLESS -> {
            val fmt =
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Bitmap.CompressFormat.WEBP_LOSSLESS
              else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
            FileOutputStream(outFile).use { scaled.compress(fmt, 100, it) }
          }
          ImageOutputFormat.WEBP_LOSSY -> {
            val fmt =
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Bitmap.CompressFormat.WEBP_LOSSY
              else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
            FileOutputStream(outFile).use {
              scaled.compress(fmt, quality.coerceIn(10, 100), it)
            }
          }
          ImageOutputFormat.BMP -> {
            writeBmp(scaled, outFile)
          }
        }
        scaled.recycle()
        outTotal += outFile.length()
        outFiles.add(outFile)
        onProgress(((idx + 1) * 100) / total)
      }

      MediaCompressionSummary(
        outputFiles = outFiles,
        originalTotalBytes = origTotal,
        outputTotalBytes = outTotal,
        isLossless = mode == CompressionMode.LOSSLESS,
      )
    }

  private fun uniqueOutputFile(dir: File, name: String): File {
    var candidate = File(dir, name)
    if (!candidate.exists()) return candidate
    val base = name.substringBeforeLast('.')
    val ext = name.substringAfterLast('.', "")
    var n = 1
    while (candidate.exists()) {
      candidate = File(dir, "${base}_$n.$ext")
      n++
    }
    return candidate
  }

  private fun writeBmp(bitmap: Bitmap, outFile: File) {
    val w = bitmap.width
    val h = bitmap.height
    val pixels = IntArray(w * h)
    bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
    val rowSize = (w * 3 + 3) and 3.inv()
    val imgSize = rowSize * h
    val fileSize = 54 + imgSize

    FileOutputStream(outFile).use { fos ->
      val header = ByteArray(54)
      header[0] = 'B'.code.toByte()
      header[1] = 'M'.code.toByte()
      putIntLE(header, 2, fileSize)
      putIntLE(header, 10, 54)
      putIntLE(header, 14, 40)
      putIntLE(header, 18, w)
      putIntLE(header, 22, h)
      header[26] = 1
      header[28] = 24
      putIntLE(header, 34, imgSize)
      fos.write(header)

      val rowBuf = ByteArray(rowSize)
      for (y in h - 1 downTo 0) {
        rowBuf.fill(0)
        val rowOffset = y * w
        for (x in 0 until w) {
          val px = pixels[rowOffset + x]
          val i = x * 3
          rowBuf[i] = (px and 0xFF).toByte()
          rowBuf[i + 1] = ((px shr 8) and 0xFF).toByte()
          rowBuf[i + 2] = ((px shr 16) and 0xFF).toByte()
        }
        fos.write(rowBuf)
      }
    }
  }

  private fun putIntLE(buf: ByteArray, offset: Int, value: Int) {
    buf[offset] = (value and 0xFF).toByte()
    buf[offset + 1] = ((value ushr 8) and 0xFF).toByte()
    buf[offset + 2] = ((value ushr 16) and 0xFF).toByte()
    buf[offset + 3] = ((value ushr 24) and 0xFF).toByte()
  }
}
