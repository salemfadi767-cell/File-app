package com.example.domain.download

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import com.example.data.db.DownloadDao
import com.example.data.db.DownloadTaskEntity
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

sealed interface BencodeValue {
  data class BInt(val value: Long) : BencodeValue
  data class BBytes(val bytes: ByteArray) : BencodeValue {
    val asUtf8: String get() = bytes.toString(Charsets.UTF_8)
  }
  data class BList(val items: List<BencodeValue>) : BencodeValue
  data class BDict(val entries: LinkedHashMap<String, BencodeValue>, val rawBytes: ByteArray? = null) : BencodeValue
}

object BencodeCodec {
  fun decode(data: ByteArray): BencodeValue {
    val cursor = intArrayOf(0)
    return parseNext(data, cursor)
  }

  private fun parseNext(data: ByteArray, cursor: IntArray): BencodeValue {
    if (cursor[0] >= data.size) throw IllegalArgumentException("Unexpected end of bencode stream")
    return when (val ch = data[cursor[0]].toInt().toChar()) {
      'i' -> {
        cursor[0]++
        val end = indexOf(data, 'e'.code.toByte(), cursor[0])
        if (end < 0) throw IllegalArgumentException("Unterminated bencode int")
        val num = data.copyOfRange(cursor[0], end).toString(Charsets.US_ASCII).toLong()
        cursor[0] = end + 1
        BencodeValue.BInt(num)
      }
      'l' -> {
        cursor[0]++
        val list = mutableListOf<BencodeValue>()
        while (cursor[0] < data.size && data[cursor[0]].toInt().toChar() != 'e') {
          list.add(parseNext(data, cursor))
        }
        if (cursor[0] >= data.size) throw IllegalArgumentException("Unterminated bencode list")
        cursor[0]++
        BencodeValue.BList(list)
      }
      'd' -> {
        val start = cursor[0]
        cursor[0]++
        val map = LinkedHashMap<String, BencodeValue>()
        while (cursor[0] < data.size && data[cursor[0]].toInt().toChar() != 'e') {
          val key = parseNext(data, cursor) as? BencodeValue.BBytes
            ?: throw IllegalArgumentException("Dict key must be bytes")
          val valNode = parseNext(data, cursor)
          map[key.asUtf8] = valNode
        }
        if (cursor[0] >= data.size) throw IllegalArgumentException("Unterminated bencode dict")
        cursor[0]++
        BencodeValue.BDict(map, data.copyOfRange(start, cursor[0]))
      }
      in '0'..'9' -> {
        val colon = indexOf(data, ':'.code.toByte(), cursor[0])
        if (colon < 0) throw IllegalArgumentException("Invalid bencode string length")
        val len = data.copyOfRange(cursor[0], colon).toString(Charsets.US_ASCII).toInt()
        val start = colon + 1
        if (start + len > data.size) throw IllegalArgumentException("Bencode string out of bounds")
        val bytes = data.copyOfRange(start, start + len)
        cursor[0] = start + len
        BencodeValue.BBytes(bytes)
      }
      else -> throw IllegalArgumentException("Unexpected bencode token: $ch")
    }
  }

  private fun indexOf(data: ByteArray, target: Byte, from: Int): Int {
    for (i in from until data.size) if (data[i] == target) return i
    return -1
  }
}

data class TorrentMetadata(
  val name: String,
  val infoHashHex: String,
  val totalBytes: Long,
  val pieceLength: Long,
  val trackers: List<String>,
  val webSeeds: List<String>,
  val files: List<Pair<String, Long>>,
)

data class MagnetInfo(
  val infoHash: String,
  val displayName: String,
  val trackers: List<String>,
  val webSeeds: List<String>,
)

data class ExtractedMediaStream(
  val title: String,
  val url: String,
  val qualityLabel: String,
  val mimeType: String,
  val isHls: Boolean = false,
  val isDash: Boolean = false,
  val isDrmProtected: Boolean = false,
  val contentLength: Long = -1L,
  val hasVideo: Boolean = true,
  val hasAudio: Boolean = true,
  val pairedAudioUrl: String? = null,
  val cookieHeader: String? = null,
  val refererHeader: String? = null,
  val userAgentHeader: String? = null,
  val engineUsed: String = "Direct",
)

data class MediaResolveResult(
  val pageTitle: String,
  val streams: List<ExtractedMediaStream>,
  val drmRejectedCount: Int = 0,
  val note: String? = null,
  val engineSummary: String? = null,
)

class UniversalDownloadEngine(
  private val downloadDao: DownloadDao,
  private val autoWebSniffer: AutoWebStreamSniffer? = null,
) {
  companion object {
    private const val BROWSER_UA =
      "Mozilla/5.0 (Linux; Android 15; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    private const val YT_CONSENT_COOKIE = "SOCS=CAESHAgBEhJnd3NfMjAyMzA4MTAtMF9SQzIaAmVuIAEaBgiA_LyaBg"
    private const val MUX_SEPARATOR = "||VORTEX_AUDIO||"

    fun extractYouTubeVideoId(url: String): String? {
      val trimmed = url.trim()
      val patterns = listOf(
        Regex("""(?:youtube\.com|youtube-nocookie\.com)/(?:watch\?(?:.*&)?v=|shorts/|live/|embed/|v/)([A-Za-z0-9_-]{11})"""),
        Regex("""youtu\.be/([A-Za-z0-9_-]{11})"""),
      )
      for (rx in patterns) {
        val m = rx.find(trimmed)
        if (m != null) return m.groupValues[1]
      }
      return null
    }

    fun isTikTokUrl(url: String): Boolean {
      val lower = url.lowercase()
      return lower.contains("tiktok.com/") || lower.contains("vm.tiktok.com/") || lower.contains("vt.tiktok.com/")
    }

    fun isTwitterOrXUrl(url: String): Boolean {
      val lower = url.lowercase()
      return lower.contains("x.com/") || lower.contains("twitter.com/") || lower.contains("t.co/")
    }

    fun isInstagramUrl(url: String): Boolean {
      val lower = url.lowercase()
      return lower.contains("instagram.com/") || lower.contains("instagr.am/")
    }

    fun isFacebookUrl(url: String): Boolean {
      val lower = url.lowercase()
      return lower.contains("facebook.com/") || lower.contains("fb.watch/") || lower.contains("fb.com/")
    }

    fun isDirectPlayableMediaUrl(url: String): Boolean {
      val lower = url.trim().lowercase()
      val pathNoQuery = lower.substringBefore('?').substringBefore('#')
      if (lower.contains("googlevideo.com/videoplayback") ||
        lower.contains("/videoplayback?") ||
        lower.contains("mime=video") ||
        lower.contains("mime=audio")
      ) {
        return true
      }
      val directExts = setOf(
        "mp4", "mkv", "webm", "mov", "m4v", "3gp", "ts",
        "mp3", "m4a", "flac", "aac", "ogg", "opus", "wav",
        "m3u8", "mpd",
      )
      val ext = pathNoQuery.substringAfterLast('.', "")
      return ext in directExts
    }
  }

  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private val activeJobs = ConcurrentHashMap<Long, Job>()
  private val streamHeadersCache = ConcurrentHashMap<String, Triple<String?, String?, String?>>()
  private val streamOriginPageCache = ConcurrentHashMap<String, String>()
  private val cipherOpsCache = ConcurrentHashMap<String, List<Pair<String, Int>>>()

  private val client =
    OkHttpClient.Builder()
      .connectTimeout(25, TimeUnit.SECONDS)
      .readTimeout(60, TimeUnit.SECONDS)
      .followRedirects(true)
      .followSslRedirects(true)
      .build()

  private val probeClient =
    client.newBuilder()
      .connectTimeout(6, TimeUnit.SECONDS)
      .readTimeout(10, TimeUnit.SECONDS)
      .build()

  val allDownloads: Flow<List<DownloadTaskEntity>> = downloadDao.observeAll()

  fun parseMagnetUri(uri: String): MagnetInfo? {
    if (!uri.startsWith("magnet:?", ignoreCase = true)) return null
    val query = uri.substringAfter("?")
    val params = query.split("&").mapNotNull { part ->
      val idx = part.indexOf('=')
      if (idx <= 0) null
      else {
        val k = URLDecoder.decode(part.substring(0, idx), "UTF-8")
        val v = URLDecoder.decode(part.substring(idx + 1), "UTF-8")
        k to v
      }
    }
    val xt = params.firstOrNull { it.first == "xt" && it.second.startsWith("urn:btih:", true) }?.second ?: return null
    val hash = xt.substringAfter("urn:btih:", "").uppercase()
    val dn = params.firstOrNull { it.first == "dn" }?.second ?: "torrent_$hash"
    val trackers = params.filter { it.first == "tr" }.map { it.second }
    val webSeeds = params.filter { it.first == "ws" || it.first == "as" }.map { it.second }
    return MagnetInfo(hash, dn, trackers, webSeeds)
  }

  fun parseTorrentBytes(bytes: ByteArray): TorrentMetadata {
    val root = BencodeCodec.decode(bytes) as? BencodeValue.BDict
      ?: throw IllegalArgumentException("Invalid torrent file: root is not a dictionary")
    val info = root.entries["info"] as? BencodeValue.BDict
      ?: throw IllegalArgumentException("Invalid torrent file: missing info dictionary")
    val rawInfo = info.rawBytes ?: ByteArray(0)
    val infoHash = MessageDigest.getInstance("SHA-1").digest(rawInfo).joinToString("") { "%02X".format(it) }

    val name = (info.entries["name"] as? BencodeValue.BBytes)?.asUtf8 ?: "torrent_$infoHash"
    val pieceLength = (info.entries["piece length"] as? BencodeValue.BInt)?.value ?: 0L

    val filesList = mutableListOf<Pair<String, Long>>()
    val singleLen = (info.entries["length"] as? BencodeValue.BInt)?.value
    if (singleLen != null) {
      filesList.add(name to singleLen)
    } else {
      val multi = (info.entries["files"] as? BencodeValue.BList)?.items.orEmpty()
      for (entry in multi) {
        val dict = entry as? BencodeValue.BDict ?: continue
        val len = (dict.entries["length"] as? BencodeValue.BInt)?.value ?: 0L
        val pathParts = (dict.entries["path"] as? BencodeValue.BList)?.items
          ?.mapNotNull { (it as? BencodeValue.BBytes)?.asUtf8 }
          .orEmpty()
        filesList.add(pathParts.joinToString("/") to len)
      }
    }
    val totalBytes = filesList.sumOf { it.second }

    val trackers = mutableListOf<String>()
    (root.entries["announce"] as? BencodeValue.BBytes)?.asUtf8?.let { trackers.add(it) }
    (root.entries["announce-list"] as? BencodeValue.BList)?.items?.forEach { tier ->
      (tier as? BencodeValue.BList)?.items?.forEach { u ->
        (u as? BencodeValue.BBytes)?.asUtf8?.let { if (it !in trackers) trackers.add(it) }
      }
    }

    val webSeeds = mutableListOf<String>()
    when (val urlList = root.entries["url-list"]) {
      is BencodeValue.BBytes -> webSeeds.add(urlList.asUtf8)
      is BencodeValue.BList -> urlList.items.forEach {
        (it as? BencodeValue.BBytes)?.asUtf8?.let { u -> webSeeds.add(u) }
      }
      else -> {}
    }

    return TorrentMetadata(
      name = name,
      infoHashHex = infoHash,
      totalBytes = totalBytes,
      pieceLength = pieceLength,
      trackers = trackers,
      webSeeds = webSeeds,
      files = filesList,
    )
  }

  suspend fun resolveMediaLinks(inputUrl: String, companionServerUrl: String = ""): MediaResolveResult =
    withContext(Dispatchers.IO) {
      val trimmed = inputUrl.trim()
      val lower = trimmed.lowercase()

      // Direct manifest URLs
      if (lower.substringBefore('?').endsWith(".m3u8")) {
        return@withContext MediaResolveResult(
          pageTitle = guessNameFromUrl(trimmed, "stream.mp4"),
          streams = listOf(ExtractedMediaStream("HLS Stream", trimmed, "HLS Playlist (.m3u8)", "application/x-mpegURL", isHls = true, engineUsed = "Direct HLS")),
          engineSummary = "Direct HLS",
        )
      }
      if (lower.substringBefore('?').endsWith(".mpd")) {
        return@withContext MediaResolveResult(
          pageTitle = guessNameFromUrl(trimmed, "stream.mp4"),
          streams = listOf(ExtractedMediaStream("DASH Stream", trimmed, "DASH Manifest (.mpd)", "application/dash+xml", isDash = true, engineUsed = "Direct DASH")),
          engineSummary = "Direct DASH",
        )
      }

      // 1. Optional FastAPI 4-Tier Companion Server FIRST when configured (yt-dlp -> gallery-dl -> streamlink -> Playwright)
      val companionBase = companionServerUrl.trim().trimEnd('/')
      if (companionBase.startsWith("http", ignoreCase = true)) {
        val compRes = resolveViaCompanion(companionBase, trimmed)
        if (compRes != null && (compRes.streams.isNotEmpty() || compRes.drmRejectedCount > 0)) {
          cacheHeaders(compRes.streams, trimmed)
          return@withContext compRes
        }
      }

      // 2. YouTube Multi-Client + Piped/Invidious Strategy
      val ytId = extractYouTubeVideoId(trimmed)
      if (ytId != null) {
        val ytRes = resolveYouTubeSmart(ytId, trimmed)
        cacheHeaders(ytRes.streams, trimmed)
        if (ytRes.streams.isNotEmpty() || ytRes.drmRejectedCount > 0) {
          return@withContext ytRes.copy(engineSummary = ytRes.streams.firstOrNull()?.engineUsed ?: "YouTube Multi-Client")
        }
      }

      // 3. TikTok Multi-Source Resolver
      if (isTikTokUrl(trimmed)) {
        val ttRes = resolveTikTokSmart(trimmed)
        if (ttRes.streams.isNotEmpty()) {
          cacheHeaders(ttRes.streams, trimmed)
          return@withContext ttRes.copy(engineSummary = ttRes.streams.firstOrNull()?.engineUsed ?: "TikTok API")
        }
      }

      // 4. X / Twitter Resolver
      if (isTwitterOrXUrl(trimmed)) {
        val xRes = resolveTwitterSmart(trimmed)
        if (xRes.streams.isNotEmpty()) {
          cacheHeaders(xRes.streams, trimmed)
          return@withContext xRes.copy(engineSummary = "X/Twitter API")
        }
      }

      // 5. Instagram Reels / Posts Resolver
      if (isInstagramUrl(trimmed)) {
        val igRes = resolveInstagramSmart(trimmed)
        if (igRes.streams.isNotEmpty()) {
          cacheHeaders(igRes.streams, trimmed)
          return@withContext igRes.copy(engineSummary = "Instagram Extractor")
        }
      }

      // 6. Facebook Watch / Video Resolver
      if (isFacebookUrl(trimmed)) {
        val fbRes = resolveFacebookSmart(trimmed)
        if (fbRes.streams.isNotEmpty()) {
          cacheHeaders(fbRes.streams, trimmed)
          return@withContext fbRes.copy(engineSummary = "Facebook Extractor")
        }
      }

      val req =
        Request.Builder()
          .url(trimmed)
          .header("User-Agent", BROWSER_UA)
          .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
          .header("Accept-Language", "en-US,en;q=0.9,ar;q=0.8")
          .build()

      var httpTitle = guessNameFromUrl(trimmed, "video")
      val found = mutableListOf<ExtractedMediaStream>()
      var httpFailNote: String? = null

      runCatching {
        client.newCall(req).execute().use { resp ->
          val contentType = resp.header("Content-Type").orEmpty().lowercase()
          val contentLen = resp.header("Content-Length")?.toLongOrNull() ?: -1L
          if (!resp.isSuccessful) {
            httpFailNote = "HTTP ${resp.code}: ${resp.message}"
            return@use
          }

          // Direct non-HTML binary/media response
          if (!contentType.contains("text/html") && !contentType.contains("application/xhtml")) {
            val mime = contentType.substringBefore(';').ifBlank { "application/octet-stream" }
            val isHls = mime.contains("mpegurl", true)
            val isDash = mime.contains("dash+xml", true)
            return@withContext MediaResolveResult(
              pageTitle = guessNameFromUrl(trimmed, "download.bin"),
              streams = listOf(
                ExtractedMediaStream(
                  title = guessNameFromUrl(trimmed, "Direct File"),
                  url = resp.request.url.toString(),
                  qualityLabel = if (isHls) "HLS Stream" else if (isDash) "DASH Stream" else mime,
                  mimeType = mime,
                  isHls = isHls,
                  isDash = isDash,
                  contentLength = contentLen,
                  engineUsed = "Direct HTTP",
                )
              ),
              engineSummary = "Direct HTTP",
            )
          }

          val html = resp.body?.string().orEmpty()
          httpTitle = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
            .find(html)?.groupValues?.getOrNull(1)
            ?.replace(Regex("<[^>]+>"), "")
            ?.replace(Regex("\\s+"), " ")
            ?.trim()
            ?.ifBlank { null }
            ?: httpTitle

          found.addAll(extractHtmlMediaStreams(html, resp.request.url.toString(), httpTitle))

          // 1-hop embedded iframe inspection when main page hosts player inside an iframe
          if (found.isEmpty()) {
            val iframeRegex = Regex("""<iframe[^>]+src=["'](https?://[^"']+)["']""", RegexOption.IGNORE_CASE)
            val iframes = iframeRegex.findAll(html).map { it.groupValues[1] }.take(2).toList()
            for (frameUrl in iframes) {
              val frameYtId = extractYouTubeVideoId(frameUrl)
              if (frameYtId != null) {
                val ytRes = resolveYouTubeSmart(frameYtId, frameUrl)
                if (ytRes.streams.isNotEmpty()) {
                  cacheHeaders(ytRes.streams, trimmed)
                  return@withContext ytRes.copy(engineSummary = "Embedded YouTube")
                }
              }
              runCatching {
                val fReq = Request.Builder()
                  .url(frameUrl)
                  .header("User-Agent", BROWSER_UA)
                  .header("Referer", resp.request.url.toString())
                  .build()
                client.newCall(fReq).execute().use { fResp ->
                  if (fResp.isSuccessful) {
                    val fHtml = fResp.body?.string().orEmpty()
                    found.addAll(extractHtmlMediaStreams(fHtml, frameUrl, httpTitle))
                  }
                }
              }
            }
          }
        }
      }.onFailure { err ->
        httpFailNote = err.localizedMessage
      }

      // Auto headless/offscreen WebView stream capture fallback for JS-rendered sites
      if (found.isEmpty() && autoWebSniffer != null) {
        val (sniffTitle, sniffed) = runCatching { autoWebSniffer.sniffPageStreams(trimmed) }.getOrDefault(httpTitle to emptyList())
        if (sniffed.isNotEmpty()) {
          if (sniffTitle.isNotBlank() && sniffTitle != "Web Video") httpTitle = sniffTitle
          found.addAll(sniffed.map { it.copy(engineUsed = "Headless WebView Sniffer") })
        }
      }

      val deduped = found.distinctBy { it.url }
      cacheHeaders(deduped, trimmed)
      MediaResolveResult(
        pageTitle = httpTitle,
        streams = deduped,
        engineSummary = deduped.firstOrNull()?.engineUsed,
        note =
          if (deduped.isEmpty()) {
            httpFailNote ?: "No static video URL exposed; try Smart Browser Sniffer or Built-in Web Player."
          } else null,
      )
    }

  private fun cacheHeaders(streams: List<ExtractedMediaStream>, originPage: String? = null) {
    streams.forEach { s ->
      if (!s.cookieHeader.isNullOrBlank() || !s.refererHeader.isNullOrBlank() || !s.userAgentHeader.isNullOrBlank()) {
        streamHeadersCache[s.url] = Triple(s.cookieHeader, s.refererHeader, s.userAgentHeader)
      }
      if (!originPage.isNullOrBlank()) {
        streamOriginPageCache[s.url] = originPage
      }
    }
  }

  fun getHeadersForUrl(url: String, stream: ExtractedMediaStream? = null): Map<String, String> {
    val map = LinkedHashMap<String, String>()
    val cached = streamHeadersCache[url]
    val cookie = stream?.cookieHeader?.takeIf { it.isNotBlank() } ?: cached?.first?.takeIf { it.isNotBlank() }
    val referer = stream?.refererHeader?.takeIf { it.isNotBlank() } ?: cached?.second?.takeIf { it.isNotBlank() }
    val ua = stream?.userAgentHeader?.takeIf { it.isNotBlank() } ?: cached?.third?.takeIf { it.isNotBlank() }
    map["User-Agent"] = ua ?: BROWSER_UA
    if (!cookie.isNullOrBlank()) map["Cookie"] = cookie
    if (!referer.isNullOrBlank()) map["Referer"] = referer
    val isMobileAppClient = url.contains("c=IOS", true) || url.contains("c=ANDROID", true)
    if (url.contains("googlevideo.com", ignoreCase = true) && !isMobileAppClient) {
      map.putIfAbsent("Referer", "https://www.youtube.com/")
      map["Origin"] = "https://www.youtube.com"
    }
    return map
  }

  private fun resolveViaCompanion(baseUrl: String, targetUrl: String): MediaResolveResult? =
    runCatching {
      val payload = JSONObject().put("url", targetUrl).toString()
      val req = Request.Builder()
        .url("$baseUrl/api/resolve")
        .post(payload.toRequestBody("application/json".toMediaType()))
        .build()
      client.newCall(req).execute().use { resp ->
        if (!resp.isSuccessful) return@runCatching null
        val json = JSONObject(resp.body?.string().orEmpty())
        val drm = json.optBoolean("drm_detected", false)
        val title = json.optString("title").ifBlank { "Companion Media" }
        val engine = json.optString("engine").ifBlank { "FastAPI 4-Tier" }
        val arr = json.optJSONArray("streams") ?: JSONArray()
        val streams = mutableListOf<ExtractedMediaStream>()
        for (i in 0 until arr.length()) {
          val s = arr.optJSONObject(i) ?: continue
          val u = s.optString("url")
          if (!u.startsWith("http")) continue
          val hdrs = s.optJSONObject("headers")
          streams.add(
            ExtractedMediaStream(
              title = title,
              url = u,
              qualityLabel = s.optString("quality", "Stream"),
              mimeType = s.optString("mime", "video/mp4"),
              isHls = s.optBoolean("is_hls", false),
              isDash = s.optBoolean("is_dash", false),
              contentLength = s.optLong("size", -1L),
              hasVideo = s.optBoolean("has_video", true),
              hasAudio = s.optBoolean("has_audio", true),
              cookieHeader = hdrs?.optString("Cookie")?.takeIf { it.isNotBlank() },
              refererHeader = hdrs?.optString("Referer")?.takeIf { it.isNotBlank() },
              userAgentHeader = hdrs?.optString("User-Agent")?.takeIf { it.isNotBlank() },
              engineUsed = s.optString("engine").ifBlank { engine },
            )
          )
        }
        MediaResolveResult(
          pageTitle = title,
          streams = streams,
          drmRejectedCount = if (drm) 1 else 0,
          engineSummary = engine,
          note = json.optString("error").takeIf { it.isNotBlank() },
        )
      }
    }.getOrNull()

  private fun resolveTwitterSmart(originalUrl: String): MediaResolveResult {
    var title = "X Video"
    val streams = mutableListOf<ExtractedMediaStream>()
    val seen = hashSetOf<String>()
    val statusId = Regex("""status/(\d+)""").find(originalUrl)?.groupValues?.getOrNull(1)
    val endpoints = buildList {
      if (statusId != null) {
        add("https://api.fxtwitter.com/status/$statusId")
        add("https://api.vxtwitter.com/Twitter/status/$statusId")
        add("https://cdn.syndication.twimg.com/tweet-result?id=$statusId&token=0")
      }
    }
    for (ep in endpoints) {
      runCatching {
        val req = Request.Builder().url(ep).header("User-Agent", BROWSER_UA).build()
        client.newCall(req).execute().use { resp ->
          if (!resp.isSuccessful) return@use
          val body = resp.body?.string().orEmpty()
          val json = runCatching { JSONObject(body) }.getOrNull()
          val tweetText = json?.optJSONObject("tweet")?.optString("text")
            ?: json?.optString("text")
          if (!tweetText.isNullOrBlank()) title = tweetText.take(64).replace('\n', ' ')
          val extracted = extractHtmlMediaStreams(body, originalUrl, title)
          extracted.forEach { s ->
            if (seen.add(s.url)) streams.add(s.copy(engineUsed = "X/Twitter API", refererHeader = "https://x.com/"))
          }
        }
      }
      if (streams.isNotEmpty()) break
    }
    return MediaResolveResult(pageTitle = title, streams = streams)
  }

  private fun resolveInstagramSmart(originalUrl: String): MediaResolveResult {
    var title = "Instagram Video"
    val streams = mutableListOf<ExtractedMediaStream>()
    val seen = hashSetOf<String>()
    val cleanBase = originalUrl.substringBefore('?').trimEnd('/')
    val candidates = listOf("$cleanBase/embed/captioned/", "$cleanBase/?__a=1&__d=dis", originalUrl)
    for (u in candidates) {
      runCatching {
        val req = Request.Builder()
          .url(u)
          .header("User-Agent", BROWSER_UA)
          .header("Accept-Language", "en-US,en;q=0.9")
          .build()
        client.newCall(req).execute().use { resp ->
          if (!resp.isSuccessful) return@use
          val body = resp.body?.string().orEmpty()
          val cookie = resp.headers("Set-Cookie").joinToString("; ") { it.substringBefore(';') }.ifBlank { null }
          Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
            .find(body)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() && !it.contains("Instagram") }
            ?.let { title = it }
          extractHtmlMediaStreams(body, originalUrl, title).forEach { s ->
            if (seen.add(s.url)) {
              streams.add(s.copy(cookieHeader = cookie, refererHeader = "https://www.instagram.com/", engineUsed = "Instagram Embed"))
            }
          }
        }
      }
      if (streams.isNotEmpty()) break
    }
    return MediaResolveResult(pageTitle = title, streams = streams)
  }

  private fun resolveFacebookSmart(originalUrl: String): MediaResolveResult {
    var title = "Facebook Video"
    val streams = mutableListOf<ExtractedMediaStream>()
    val seen = hashSetOf<String>()
    val mobileUrl = originalUrl.replace("://www.facebook.com", "://m.facebook.com")
    for (u in listOf(mobileUrl, originalUrl).distinct()) {
      runCatching {
        val req = Request.Builder()
          .url(u)
          .header("User-Agent", BROWSER_UA)
          .header("Accept", "text/html,application/xhtml+xml")
          .build()
        client.newCall(req).execute().use { resp ->
          if (!resp.isSuccessful) return@use
          val html = resp.body?.string().orEmpty()
          Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
            .find(html)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }?.let { title = it }
          val normalized = html.replace("\\u0026", "&").replace("\\/", "/").replace("&amp;", "&")
          listOf("hd_src_no_ratelimit", "hd_src", "sd_src_no_ratelimit", "sd_src", "browser_native_hd_url", "browser_native_sd_url").forEach { key ->
            val rx = Regex(""""$key"\s*:\s*"(https?://[^"]+)"""")
            rx.findAll(normalized).forEach { m ->
              val vUrl = m.groupValues[1]
              if (seen.add(vUrl)) {
                val isHd = key.contains("hd", true)
                streams.add(
                  ExtractedMediaStream(
                    title = title,
                    url = vUrl,
                    qualityLabel = if (isHd) "Facebook HD MP4" else "Facebook SD MP4",
                    mimeType = "video/mp4",
                    refererHeader = "https://www.facebook.com/",
                    engineUsed = "Facebook Extractor",
                  )
                )
              }
            }
          }
          extractHtmlMediaStreams(normalized, originalUrl, title).forEach { s ->
            if (seen.add(s.url)) streams.add(s.copy(engineUsed = "Facebook Extractor"))
          }
        }
      }
      if (streams.isNotEmpty()) break
    }
    return MediaResolveResult(pageTitle = title, streams = streams)
  }

  private fun extractHtmlMediaStreams(html: String, baseUrl: String, pageTitle: String): List<ExtractedMediaStream> {
    val normalized = html
      .replace("\\u0026", "&")
      .replace("\\u002F", "/")
      .replace("\\/", "/")
      .replace("&amp;", "&")
    val found = mutableListOf<ExtractedMediaStream>()
    val seenUrls = hashSetOf<String>()

    val patterns = listOf(
      Regex("""https?://[^\s"'<>\\]+?\.(mp4|webm|mkv|mov|m4v|mp3|m4a|flac|ogg|aac|m3u8|mpd)(\?[^\s"'<>\\]*)?""", RegexOption.IGNORE_CASE),
      Regex("""<meta[^>]+(?:property|name)=["'](?:og:video(?::url|:secure_url)?|twitter:player:stream)["'][^>]+content=["']([^"']+)["']""", RegexOption.IGNORE_CASE),
      Regex("""<(?:video|source)[^>]+src=["']([^"']+)["']""", RegexOption.IGNORE_CASE),
      Regex(""""(?:contentUrl|hlsUrl|dashUrl|video_url|playbackUrl|playback_url|playable_url|playable_url_quality_hd|playAddr|downloadAddr|mp4Url|file)"\s*:\s*"(https?://[^"]+)"""", RegexOption.IGNORE_CASE),
    )

    for (regex in patterns) {
      for (match in regex.findAll(normalized)) {
        val raw = match.groupValues.getOrNull(1)?.takeIf { it.startsWith("http", true) || it.startsWith("/") } ?: match.value
        val resolved = resolveRelativeUrl(baseUrl, raw)
        if (!resolved.startsWith("http", true)) continue
        val lower = resolved.lowercase()
        if (lower.endsWith(".jpg") || lower.endsWith(".png") || lower.endsWith(".webp") || lower.endsWith(".js") || lower.endsWith(".css")) continue
        if (seenUrls.add(resolved)) {
          val isHls = lower.contains(".m3u8")
          val isDash = lower.contains(".mpd")
          val ext = lower.substringBefore('?').substringAfterLast('.', "mp4").uppercase()
          val mime = when {
            isHls -> "application/x-mpegURL"
            isDash -> "application/dash+xml"
            ext in setOf("MP3", "M4A", "AAC", "FLAC", "OGG") -> "audio/mp4"
            ext == "WEBM" -> "video/webm"
            else -> "video/mp4"
          }
          found.add(
            ExtractedMediaStream(
              title = pageTitle,
              url = resolved,
              qualityLabel = if (isHls) "HLS Stream" else if (isDash) "DASH Stream" else "$ext Video",
              mimeType = mime,
              isHls = isHls,
              isDash = isDash,
              hasVideo = !mime.startsWith("audio/"),
              hasAudio = true,
              refererHeader = baseUrl,
            )
          )
        }
      }
    }
    return found
  }

  private fun resolveTikTokSmart(originalUrl: String): MediaResolveResult {
    var title = "TikTok Video"
    val streams = mutableListOf<ExtractedMediaStream>()
    val seen = hashSetOf<String>()

    // 1. Direct HTML rehydration JSON inspection
    runCatching {
      val req =
        Request.Builder()
          .url(originalUrl)
          .header("User-Agent", BROWSER_UA)
          .header("Accept-Language", "en-US,en;q=0.9,ar;q=0.8")
          .build()
      client.newCall(req).execute().use { resp ->
        if (resp.isSuccessful) {
          val cookie = resp.headers("Set-Cookie").joinToString("; ") { it.substringBefore(';') }.ifBlank { null }
          val html = resp.body?.string().orEmpty()
          Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
            .find(html)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }?.let { title = it }
          val extracted = extractHtmlMediaStreams(html, resp.request.url.toString(), title)
          extracted.forEach { s ->
            if (seen.add(s.url)) streams.add(s.copy(cookieHeader = cookie, refererHeader = "https://www.tiktok.com/"))
          }
        }
      }
    }

    // 2. Public non-DRM JSON fallback API when direct HTML hides video streams
    if (streams.isEmpty()) {
      runCatching {
        val enc = java.net.URLEncoder.encode(originalUrl, "UTF-8")
        val req =
          Request.Builder()
            .url("https://www.tikwm.com/api/?url=$enc&hd=1")
            .header("User-Agent", BROWSER_UA)
            .build()
        client.newCall(req).execute().use { resp ->
          if (resp.isSuccessful) {
            val root = runCatching { JSONObject(resp.body?.string().orEmpty()) }.getOrNull() ?: return@use
            val data = root.optJSONObject("data") ?: return@use
            data.optString("title").takeIf { it.isNotBlank() }?.let { title = it }
            val candidates = listOf(
              data.optString("hdplay") to "TikTok HD (No Watermark)",
              data.optString("play") to "TikTok Standard MP4",
              data.optString("wmplay") to "TikTok MP4 (Watermarked)",
              data.optString("music") to "TikTok Audio (MP3)",
            )
            for ((u, label) in candidates) {
              if (u.startsWith("http", true) && seen.add(u)) {
                val isAudio = label.contains("Audio", true)
                streams.add(
                  ExtractedMediaStream(
                    title = title,
                    url = u,
                    qualityLabel = label,
                    mimeType = if (isAudio) "audio/mpeg" else "video/mp4",
                    hasVideo = !isAudio,
                    hasAudio = true,
                    refererHeader = "https://www.tikwm.com/",
                  )
                )
              }
            }
          }
        }
      }
    }

    return MediaResolveResult(pageTitle = title, streams = streams)
  }

  private data class YtSessionMeta(
    val visitorData: String = "",
    val apiKey: String = "",
    val sts: Int = 20100,
    val playerJsUrl: String = "",
    val titleHint: String = "",
  )

  private data class YtClientSpec(
    val name: String,
    val clientId: String,
    val version: String,
    val clientJson: String,
    val userAgent: String,
  )

  private fun effectiveYouTubeCookie(): String {
    val webCookie = runCatching {
      android.webkit.CookieManager.getInstance().getCookie("https://www.youtube.com")
    }.getOrNull()?.trim().orEmpty()
    return when {
      webCookie.isBlank() -> YT_CONSENT_COOKIE
      webCookie.contains("SOCS=") -> webCookie
      else -> "$webCookie; $YT_CONSENT_COOKIE"
    }
  }

  private fun fetchYouTubeSessionMeta(videoId: String): YtSessionMeta {
    var visitorData = ""
    var apiKey = ""
    var sts = 20100
    var playerJsUrl = ""
    var titleHint = ""
    val ytCookie = effectiveYouTubeCookie()

    runCatching {
      val req = Request.Builder()
        .url("https://www.youtube.com/embed/$videoId")
        .header("User-Agent", BROWSER_UA)
        .header("Cookie", ytCookie)
        .header("Accept-Language", "en-US,en;q=0.9")
        .build()
      probeClient.newCall(req).execute().use { resp ->
        if (!resp.isSuccessful) return@use
        val html = resp.body?.string().orEmpty()
        Regex(""""VISITOR_DATA"\s*:\s*"([^"]+)"""").find(html)?.groupValues?.getOrNull(1)?.let { visitorData = it }
        Regex(""""INNERTUBE_API_KEY"\s*:\s*"([^"]+)"""").find(html)?.groupValues?.getOrNull(1)?.let { apiKey = it }
        Regex(""""STS"\s*:\s*(\d+)""").find(html)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { sts = it }
        Regex(""""PLAYER_JS_URL"\s*:\s*"([^"]+)"""").find(html)?.groupValues?.getOrNull(1)?.let { pUrl ->
          playerJsUrl = if (pUrl.startsWith("http")) pUrl else "https://www.youtube.com$pUrl"
        }
        Regex(""""title"\s*:\s*"([^"]+)"""").find(html)?.groupValues?.getOrNull(1)?.takeIf {
          it.isNotBlank() && !it.equals("YouTube", true)
        }?.let { titleHint = it.replace("\\u0026", "&") }
      }
    }

    if (visitorData.isBlank()) {
      runCatching {
        val swReq = Request.Builder()
          .url("https://www.youtube.com/sw.js_data")
          .header("User-Agent", BROWSER_UA)
          .header("Cookie", ytCookie)
          .build()
        probeClient.newCall(swReq).execute().use { resp ->
          val body = resp.body?.string().orEmpty().removePrefix(")]}'")
          Regex(""""(Cg[A-Za-z0-9_%-]{16,})"""").find(body)?.groupValues?.getOrNull(1)?.let { visitorData = it }
        }
      }
    }

    if (titleHint.isBlank()) {
      runCatching {
        val oeReq = Request.Builder()
          .url("https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$videoId&format=json")
          .header("User-Agent", BROWSER_UA)
          .build()
        probeClient.newCall(oeReq).execute().use { resp ->
          if (resp.isSuccessful) {
            val obj = JSONObject(resp.body?.string().orEmpty())
            obj.optString("title").takeIf { it.isNotBlank() }?.let { titleHint = it }
          }
        }
      }
    }

    return YtSessionMeta(visitorData, apiKey, sts, playerJsUrl, titleHint)
  }

  internal fun parseSignatureCipherOps(js: String): List<Pair<String, Int>> {
    if (js.isBlank()) return emptyList()
    val sigFnMatch =
      Regex("""=function\(([a-zA-Z0-9_$]+)\)\{\1=\1\.split\(["']{2}\);(.*?)return \1\.join\(["']{2}\)""", RegexOption.DOT_MATCHES_ALL)
        .find(js) ?: return emptyList()
    val argName = sigFnMatch.groupValues[1]
    val body = sigFnMatch.groupValues[2]

    val helperNameMatch = Regex("""([a-zA-Z0-9_$]+)\.[a-zA-Z0-9_$]+\(${Regex.escape(argName)}""").find(body)
      ?: return emptyList()
    val helperName = helperNameMatch.groupValues[1]
    val helperDefMatch = Regex("""var ${Regex.escape(helperName)}=\{(.*?)\};""", RegexOption.DOT_MATCHES_ALL)
      .find(js) ?: return emptyList()
    val helperDef = helperDefMatch.groupValues[1]

    val methodKinds = mutableMapOf<String, String>()
    Regex("""([a-zA-Z0-9_$]+):function\([^)]*\)\{([^}]*)\}""").findAll(helperDef).forEach { m ->
      val mName = m.groupValues[1]
      val mBody = m.groupValues[2]
      when {
        mBody.contains("reverse()") -> methodKinds[mName] = "reverse"
        mBody.contains("splice(") -> methodKinds[mName] = "splice"
        mBody.contains("length]") -> methodKinds[mName] = "swap"
      }
    }

    val parsedOps = mutableListOf<Pair<String, Int>>()
    Regex("""${Regex.escape(helperName)}\.([a-zA-Z0-9_$]+)\(${Regex.escape(argName)}(?:,(\d+))?\)""")
      .findAll(body)
      .forEach { call ->
        val kind = methodKinds[call.groupValues[1]] ?: return@forEach
        val num = call.groupValues[2].toIntOrNull() ?: 0
        parsedOps.add(kind to num)
      }
    return parsedOps
  }

  internal fun applySignatureCipherOps(sVal: String, ops: List<Pair<String, Int>>): String {
    val chars = sVal.toCharArray().toMutableList()
    for ((op, arg) in ops) {
      when (op) {
        "reverse" -> chars.reverse()
        "splice" -> {
          val n = arg.coerceIn(0, chars.size)
          repeat(n) { if (chars.isNotEmpty()) chars.removeAt(0) }
        }
        "swap" -> if (chars.isNotEmpty()) {
          val idx = arg % chars.size
          val tmp = chars[0]
          chars[0] = chars[idx]
          chars[idx] = tmp
        }
      }
    }
    return chars.joinToString("")
  }

  private fun loadPlayerCipherOps(playerJsUrl: String): List<Pair<String, Int>> {
    if (playerJsUrl.isBlank()) return emptyList()
    cipherOpsCache[playerJsUrl]?.let { return it }

    val ops = runCatching {
      val req = Request.Builder().url(playerJsUrl).header("User-Agent", BROWSER_UA).build()
      val js = client.newCall(req).execute().use { if (it.isSuccessful) it.body?.string().orEmpty() else "" }
      parseSignatureCipherOps(js)
    }.getOrDefault(emptyList())

    if (ops.isNotEmpty()) cipherOpsCache[playerJsUrl] = ops
    return ops
  }

  private fun decipherYouTubeSignature(cipherParam: String, playerJsUrl: String): String? {
    val parts = mutableMapOf<String, String>()
    cipherParam.split("&").forEach { kv ->
      val idx = kv.indexOf('=')
      if (idx > 0) {
        val k = URLDecoder.decode(kv.substring(0, idx), "UTF-8")
        val v = URLDecoder.decode(kv.substring(idx + 1), "UTF-8")
        parts[k] = v
      }
    }
    val rawUrl = parts["url"]?.takeIf { it.startsWith("http") } ?: return null
    val sVal = parts["s"] ?: return rawUrl
    val spKey = parts["sp"].orEmpty().ifBlank { "signature" }

    val ops = loadPlayerCipherOps(playerJsUrl)
    if (ops.isEmpty()) return null

    val deciphered = java.net.URLEncoder.encode(applySignatureCipherOps(sVal, ops), "UTF-8")
    val sep = if (rawUrl.contains('?')) "&" else "?"
    return "$rawUrl$sep$spKey=$deciphered"
  }

  private suspend fun resolveYouTubeSmart(videoId: String, originalUrl: String): MediaResolveResult {
    val session = fetchYouTubeSessionMeta(videoId)
    var bestTitle = session.titleHint.ifBlank { "YouTube Video" }
    val allStreams = mutableListOf<ExtractedMediaStream>()
    var totalDrmRejected = 0
    val seenUrls = hashSetOf<String>()

    val vField = if (session.visitorData.isNotBlank()) ""","visitorData":"${session.visitorData}"""" else ""
    val keyParam = if (session.apiKey.isNotBlank()) "&key=${session.apiKey}" else ""

    // 1. Public InnerTube player JSON across non-DRM VR / Embedded / iOS / Android clients
    // ANDROID_VR is prioritized first because it yields direct MP4/adaptive streams without PO-token 403.
    val clientSpecs = listOf(
      YtClientSpec(
        name = "ANDROID_VR",
        clientId = "28",
        version = "1.60.19",
        clientJson = """{"clientName":"ANDROID_VR","clientVersion":"1.60.19","deviceMake":"Oculus","deviceModel":"Quest 3","androidSdkVersion":32,"osName":"Android","osVersion":"12L","hl":"en","gl":"US"$vField}""",
        userAgent = "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
      ),
      YtClientSpec(
        name = "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
        clientId = "85",
        version = "2.0",
        clientJson = """{"clientName":"TVHTML5_SIMPLY_EMBEDDED_PLAYER","clientVersion":"2.0","hl":"en","gl":"US"$vField}""",
        userAgent = BROWSER_UA,
      ),
      YtClientSpec(
        name = "WEB_EMBEDDED_PLAYER",
        clientId = "56",
        version = "1.20250312.01.00",
        clientJson = """{"clientName":"WEB_EMBEDDED_PLAYER","clientVersion":"1.20250312.01.00","hl":"en","gl":"US"$vField}""",
        userAgent = BROWSER_UA,
      ),
      YtClientSpec(
        name = "IOS",
        clientId = "5",
        version = "20.10.4",
        clientJson = """{"clientName":"IOS","clientVersion":"20.10.4","deviceMake":"Apple","deviceModel":"iPhone16,2","osName":"iPhone","osVersion":"18.3.1.22D72","hl":"en","gl":"US"$vField}""",
        userAgent = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_1 like Mac OS X;)",
      ),
      YtClientSpec(
        name = "ANDROID",
        clientId = "3",
        version = "20.10.38",
        clientJson = """{"clientName":"ANDROID","clientVersion":"20.10.38","androidSdkVersion":35,"hl":"en","gl":"US"$vField}""",
        userAgent = "com.google.android.youtube/20.10.38 (Linux; U; Android 15) gzip",
      ),
    )

    val ytCookie = effectiveYouTubeCookie()
    var workingClients = 0
    for (spec in clientSpecs) {
      val thirdParty = if (spec.name.contains("EMBEDDED")) {
        ""","thirdParty":{"embedUrl":"https://www.youtube.com/"}"""
      } else {
        ""
      }
      val isMobileAppSpec = spec.name == "IOS" || spec.name.startsWith("ANDROID")
      val playbackCtx = """"playbackContext":{"contentPlaybackContext":{"signatureTimestamp":${session.sts},"html5Preference":"HTML5_PREF_WANTS"}}"""
      val payload = """{"context":{"client":${spec.clientJson}$thirdParty},$playbackCtx,"videoId":"$videoId","contentCheckOk":true,"racyCheckOk":true}"""
      val reqBuilder = Request.Builder()
        .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false$keyParam")
        .header("Content-Type", "application/json")
        .header("User-Agent", spec.userAgent)
        .header("X-YouTube-Client-Name", spec.clientId)
        .header("X-YouTube-Client-Version", spec.version)
        .header("Cookie", ytCookie)
      if (session.visitorData.isNotBlank()) {
        reqBuilder.header("X-Goog-Visitor-Id", session.visitorData)
      }
      if (!isMobileAppSpec) {
        reqBuilder.header("Origin", "https://www.youtube.com")
      }
      val req = reqBuilder.post(payload.toRequestBody("application/json".toMediaType())).build()

      runCatching {
        probeClient.newCall(req).execute().use { resp ->
          if (resp.isSuccessful) {
            val jsonText = resp.body?.string().orEmpty()
            val root = runCatching { JSONObject(jsonText) }.getOrNull() ?: return@use
            val parsed = parseYouTubePlayerJson(root, bestTitle, session.playerJsUrl, spec.userAgent, spec.name)
            if (parsed.pageTitle != "YouTube Video" && parsed.pageTitle.isNotBlank()) {
              bestTitle = parsed.pageTitle
            }
            totalDrmRejected += parsed.drmRejectedCount
            var added = 0
            parsed.streams.forEach { s ->
              if (seenUrls.add(s.url)) {
                allStreams.add(s)
                added++
              }
            }
            if (added > 0) workingClients++
          }
        }
      }
      val hasProgressiveMp4 = allStreams.any { it.hasVideo && it.hasAudio && !it.isHls }
      if (hasProgressiveMp4 && workingClients >= 2) {
        break
      }
    }

    // 2. HTML Watch Page Consent-Cookie Fallback (with signatureCipher deciphering via base.js)
    if (allStreams.isEmpty()) {
      runCatching {
        val watchReq = Request.Builder()
          .url("https://www.youtube.com/watch?v=$videoId&has_verified=1")
          .header("User-Agent", BROWSER_UA)
          .header("Cookie", ytCookie)
          .header("Accept-Language", "en-US,en;q=0.9")
          .build()
        probeClient.newCall(watchReq).execute().use { resp ->
          if (resp.isSuccessful) {
            val html = resp.body?.string().orEmpty()
            val htmlPlayerUrl = Regex("""["']jsUrl["']\s*:\s*["']([^"']+)["']""")
              .find(html)?.groupValues?.getOrNull(1)?.let { u ->
                if (u.startsWith("http")) u else "https://www.youtube.com$u"
              } ?: session.playerJsUrl
            val htmlRes = extractYouTubePlayerFormats(html, bestTitle, htmlPlayerUrl)
            if (htmlRes.pageTitle.isNotBlank()) bestTitle = htmlRes.pageTitle
            totalDrmRejected += htmlRes.drmRejectedCount
            htmlRes.streams.forEach { s -> if (seenUrls.add(s.url)) allStreams.add(s) }
          }
        }
      }
    }

    // 3. Piped JSON Mirror Fallback FIRST (skip LBRY/odycdn 401 entries; api.piped.private.coffee is prioritized)
    if (allStreams.isEmpty()) {
      val pipedEndpoints = listOf(
        "https://api.piped.private.coffee/streams/$videoId",
        "https://pipedapi.ducks.party/streams/$videoId",
        "https://pipedapi.kavin.rocks/streams/$videoId",
        "https://pipedapi.adminforge.de/streams/$videoId",
      )
      for (ep in pipedEndpoints) {
        runCatching {
          val req = Request.Builder().url(ep).header("User-Agent", BROWSER_UA).build()
          probeClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@use
            val obj = runCatching { JSONObject(resp.body?.string().orEmpty()) }.getOrNull() ?: return@use
            obj.optString("title").takeIf { it.isNotBlank() }?.let { bestTitle = it }
            obj.optString("hls").takeIf { it.startsWith("http") && !it.contains("odycdn.com", true) }?.let { hls ->
              if (seenUrls.add(hls)) {
                allStreams.add(ExtractedMediaStream(bestTitle, hls, "HLS Adaptive Stream", "application/x-mpegURL", isHls = true, engineUsed = "Piped HLS"))
              }
            }
            fun collectPiped(arr: JSONArray?, isAudioOnly: Boolean) {
              if (arr == null) return
              for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val u = item.optString("url")
                val q = item.optString("quality").ifBlank { if (isAudioOnly) "Audio" else "Video" }
                if (!u.startsWith("http")) continue
                // Skip LBRY/Odysee proxy links from Piped because player.odycdn.com returns HTTP 401 Unauthorized
                if (q.contains("LBRY", ignoreCase = true) || u.contains("odycdn.com", ignoreCase = true)) continue
                if (!seenUrls.add(u)) continue
                val videoOnly = item.optBoolean("videoOnly", false)
                val mime = item.optString("mimeType", if (isAudioOnly) "audio/mp4" else "video/mp4").substringBefore(';')
                val isHls = mime.contains("mpegurl", true) || u.contains(".m3u8", true)
                allStreams.add(
                  ExtractedMediaStream(
                    title = bestTitle,
                    url = u,
                    qualityLabel = if (isHls) "$q (HLS)" else if (!videoOnly && !isAudioOnly) "$q (Direct MP4)" else q,
                    mimeType = mime,
                    isHls = isHls,
                    contentLength = item.optLong("contentLength", -1L),
                    hasVideo = !isAudioOnly,
                    hasAudio = isAudioOnly || !videoOnly,
                    engineUsed = "Piped API",
                  )
                )
              }
            }
            collectPiped(obj.optJSONArray("videoStreams"), isAudioOnly = false)
            collectPiped(obj.optJSONArray("audioStreams"), isAudioOnly = true)
          }
        }
        if (allStreams.isNotEmpty()) break
      }
    }

    // 4. Invidious (?local=true avoids IP-locked 403) Fallback
    if (allStreams.isEmpty()) {
      val invidiousBases = listOf(
        "https://inv.nadeko.net",
        "https://yewtu.be",
        "https://invidious.nerdvpn.de",
      )
      for (base in invidiousBases) {
        runCatching {
          val req = Request.Builder().url("$base/api/v1/videos/$videoId?local=true").header("User-Agent", BROWSER_UA).build()
          probeClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@use
            val obj = runCatching { JSONObject(resp.body?.string().orEmpty()) }.getOrNull() ?: return@use
            obj.optString("title").takeIf { it.isNotBlank() }?.let { bestTitle = it }
            fun collectInv(arr: JSONArray?, isProgressive: Boolean) {
              if (arr == null) return
              for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                var u = item.optString("url")
                if (u.startsWith("/")) u = "$base$u"
                if (!u.startsWith("http") || !seenUrls.add(u)) continue
                val mime = item.optString("type", "video/mp4").substringBefore(';')
                val isAudioOnly = mime.startsWith("audio/")
                val q = item.optString("qualityLabel").ifBlank { item.optString("quality", "Stream") }
                allStreams.add(
                  ExtractedMediaStream(
                    title = bestTitle,
                    url = u,
                    qualityLabel = if (isProgressive) "$q (Direct MP4)" else q,
                    mimeType = mime,
                    hasVideo = !isAudioOnly,
                    hasAudio = isProgressive || isAudioOnly,
                    engineUsed = "YouTube Mirror",
                  )
                )
              }
            }
            collectInv(obj.optJSONArray("formatStreams"), isProgressive = true)
            collectInv(obj.optJSONArray("adaptiveFormats"), isProgressive = false)
          }
        }
        if (allStreams.isNotEmpty()) break
      }
    }

    // 5. Pair adaptive MP4 video-only tracks with best M4A audio so HD downloads mux cleanly with Android MediaMuxer
    val bestAudioM4a = allStreams.firstOrNull { !it.hasVideo && it.hasAudio && it.mimeType.contains("mp4", true) }

    val enriched = allStreams.map { stream ->
      if (stream.hasVideo && !stream.hasAudio && !stream.isHls && stream.mimeType.contains("mp4", true) && bestAudioM4a != null) {
        stream.copy(
          qualityLabel = "${stream.qualityLabel} (HD + Audio Mux)",
          pairedAudioUrl = bestAudioM4a.url,
        )
      } else {
        stream
      }
    }.sortedWith(
      compareByDescending<ExtractedMediaStream> { it.hasVideo && it.hasAudio && !it.isHls }
        .thenByDescending { it.hasVideo && it.hasAudio }
        .thenByDescending { it.pairedAudioUrl != null }
        .thenByDescending { it.contentLength }
    )

    val note = when {
      enriched.isEmpty() && totalDrmRejected > 0 ->
        "Protected streams skipped ($totalDrmRejected DRM/encrypted); connect FastAPI Server in Settings or use Built-in Web Player."
      totalDrmRejected > 0 && enriched.isNotEmpty() ->
        "$totalDrmRejected protected formats skipped; ${enriched.size} non-DRM streams ready."
      enriched.isEmpty() ->
        "YouTube blocked direct extraction from this IP; connect FastAPI Server in Settings or tap Built-in Web Player."
      else -> null
    }
    return MediaResolveResult(pageTitle = bestTitle, streams = enriched, drmRejectedCount = totalDrmRejected, note = note)
  }

  private fun extractYouTubePlayerFormats(
    html: String,
    fallbackTitle: String,
    playerJsUrl: String = "",
  ): MediaResolveResult {
    val jsonStr = extractBalancedJsonObject(html, "ytInitialPlayerResponse = ")
      ?: extractBalancedJsonObject(html, "\"streamingData\":", wrapKey = "streamingData")
      ?: return MediaResolveResult(fallbackTitle, emptyList(), note = "No player metadata in HTML")
    val root = runCatching { JSONObject(jsonStr) }.getOrNull()
      ?: return MediaResolveResult(fallbackTitle, emptyList(), note = "Malformed YouTube player JSON")
    return parseYouTubePlayerJson(root, fallbackTitle, playerJsUrl, BROWSER_UA, "YouTube Watch")
  }

  private fun parseYouTubePlayerJson(
    root: JSONObject,
    fallbackTitle: String,
    playerJsUrl: String = "",
    clientUa: String = BROWSER_UA,
    engineLabel: String = "YouTube",
  ): MediaResolveResult {
    val videoDetails = root.optJSONObject("videoDetails")
    val title = videoDetails?.optString("title")?.takeIf { it.isNotBlank() } ?: fallbackTitle
    val streamingData = root.optJSONObject("streamingData")
      ?: return MediaResolveResult(title, emptyList())

    val streams = mutableListOf<ExtractedMediaStream>()
    var drmRejected = 0

    val hlsUrl = streamingData.optString("hlsManifestUrl")
    if (hlsUrl.startsWith("http")) {
      streams.add(
        ExtractedMediaStream(
          title = title,
          url = hlsUrl,
          qualityLabel = "HLS Adaptive Stream",
          mimeType = "application/x-mpegURL",
          isHls = true,
          hasVideo = true,
          hasAudio = true,
          userAgentHeader = clientUa,
          engineUsed = "$engineLabel HLS",
        )
      )
    }

    fun inspectArray(arr: JSONArray?, isProgressive: Boolean) {
      if (arr == null) return
      for (i in 0 until arr.length()) {
        val obj = arr.optJSONObject(i) ?: continue
        val isHardwareDrm = obj.optString("drmFamilies").isNotBlank()
        if (isHardwareDrm) {
          drmRejected++
          continue
        }
        var directUrl = obj.optString("url")
        if (directUrl.isBlank()) {
          val cipher = obj.optString("signatureCipher").ifBlank { obj.optString("cipher") }
          if (cipher.isNotBlank() && playerJsUrl.isNotBlank()) {
            directUrl = decipherYouTubeSignature(cipher, playerJsUrl).orEmpty()
          }
        }
        if (directUrl.isBlank()) continue

        val mimeRaw = obj.optString("mimeType", "video/mp4")
        val mime = mimeRaw.substringBefore(';')
        val isAudioOnly = mime.startsWith("audio/")
        val quality = obj.optString("qualityLabel").ifBlank {
          val bitrate = obj.optInt("bitrate", 0) / 1000
          if (isAudioOnly) "Audio ${bitrate}kbps" else "${bitrate}kbps"
        }
        val label = if (isProgressive) "$quality (Direct MP4)" else quality
        streams.add(
          ExtractedMediaStream(
            title = title,
            url = directUrl,
            qualityLabel = label,
            mimeType = mime,
            contentLength = obj.optString("contentLength").toLongOrNull() ?: -1L,
            hasVideo = !isAudioOnly,
            hasAudio = isProgressive || isAudioOnly,
            userAgentHeader = clientUa,
            engineUsed = engineLabel,
          )
        )
      }
    }

    inspectArray(streamingData.optJSONArray("formats"), isProgressive = true)
    inspectArray(streamingData.optJSONArray("adaptiveFormats"), isProgressive = false)
    return MediaResolveResult(pageTitle = title, streams = streams, drmRejectedCount = drmRejected)
  }

  private fun extractBalancedJsonObject(source: String, marker: String, wrapKey: String? = null): String? {
    val idx = source.indexOf(marker)
    if (idx < 0) return null
    val braceStart = source.indexOf('{', idx + marker.length)
    if (braceStart < 0) return null
    var depth = 0
    var inStr = false
    var escaped = false
    for (i in braceStart until source.length) {
      val c = source[i]
      if (inStr) {
        if (escaped) escaped = false
        else if (c == '\\') escaped = true
        else if (c == '"') inStr = false
      } else {
        when (c) {
          '"' -> inStr = true
          '{' -> depth++
          '}' -> {
            depth--
            if (depth == 0) {
              val body = source.substring(braceStart, i + 1)
              return if (wrapKey != null) "{\"$wrapKey\":$body}" else body
            }
          }
        }
      }
    }
    return null
  }

  private suspend fun updateProgress(
    taskId: Long,
    status: String,
    downloaded: Long,
    total: Long,
    speed: Long,
    noteOrError: String? = null,
    peersInfo: String? = null,
  ) {
    val cur = downloadDao.getById(taskId) ?: return
    downloadDao.update(
      cur.copy(
        status = status,
        bytesDownloaded = downloaded,
        totalBytes = total.coerceAtLeast(0L),
        speedBytesPerSec = speed,
        errorMessage = if (status == "FAILED") noteOrError else null,
        peersInfo = peersInfo ?: cur.peersInfo,
      )
    )
  }

  suspend fun enqueueDirectDownload(
    url: String,
    destDir: File,
    fileNameOverride: String? = null,
    downloadType: String = if (url.contains(".m3u8", true)) "HLS" else "HTTP",
  ): Long =
    withContext(Dispatchers.IO) {
      destDir.mkdirs()
      val cleanName = sanitizeFileName(fileNameOverride ?: guessNameFromUrl(url, "download_${System.currentTimeMillis()}.mp4"))
      val target = uniqueFile(destDir, cleanName)
      val id = downloadDao.insert(
        DownloadTaskEntity(
          sourceUrl = url,
          fileName = target.name,
          destinationPath = target.absolutePath,
          downloadType = downloadType,
          status = "QUEUED",
        )
      )
      startJob(id)
      id
    }

  suspend fun enqueueMuxedDownload(
    videoUrl: String,
    audioUrl: String,
    destDir: File,
    fileNameOverride: String? = null,
  ): Long =
    withContext(Dispatchers.IO) {
      destDir.mkdirs()
      val baseName = sanitizeFileName(fileNameOverride ?: "video_hd_${System.currentTimeMillis()}.mp4")
        .substringBeforeLast('.') + ".mp4"
      val target = uniqueFile(destDir, baseName)
      val id = downloadDao.insert(
        DownloadTaskEntity(
          sourceUrl = "$videoUrl$MUX_SEPARATOR$audioUrl",
          fileName = target.name,
          destinationPath = target.absolutePath,
          downloadType = "MUXED_AV",
          status = "QUEUED",
          peersInfo = "HD Video + Audio Mux",
        )
      )
      startJob(id)
      id
    }

  suspend fun enqueueTorrentOrMagnet(
    torrentOrMagnet: String,
    destDir: File,
  ): Long =
    withContext(Dispatchers.IO) {
      destDir.mkdirs()
      val isMagnet = torrentOrMagnet.startsWith("magnet:?", ignoreCase = true)
      val title: String
      val totalBytes: Long
      val peersSummary: String
      if (isMagnet) {
        val m = parseMagnetUri(torrentOrMagnet)
        title = sanitizeFileName(m?.displayName ?: "magnet_download")
        totalBytes = 0L
        peersSummary = "${m?.trackers?.size ?: 0} trackers • ${m?.webSeeds?.size ?: 0} webseeds"
      } else {
        val f = File(torrentOrMagnet)
        val meta = if (f.exists()) parseTorrentBytes(f.readBytes()) else null
        title = sanitizeFileName(meta?.name ?: f.nameWithoutExtension)
        totalBytes = meta?.totalBytes ?: 0L
        peersSummary = "${meta?.trackers?.size ?: 0} trackers • ${meta?.webSeeds?.size ?: 0} webseeds"
      }
      val outTarget = File(destDir, title)
      val id = downloadDao.insert(
        DownloadTaskEntity(
          sourceUrl = torrentOrMagnet,
          fileName = title,
          destinationPath = outTarget.absolutePath,
          totalBytes = totalBytes,
          downloadType = if (isMagnet) "MAGNET" else "TORRENT",
          status = "QUEUED",
          peersInfo = peersSummary,
        )
      )
      startJob(id)
      id
    }

  fun startJob(taskId: Long) {
    activeJobs[taskId]?.cancel()
    activeJobs[taskId] = scope.launch {
      val task = downloadDao.getById(taskId) ?: return@launch
      try {
        updateProgress(taskId, "DOWNLOADING", task.bytesDownloaded, task.totalBytes, 0L)
        when (task.downloadType) {
          "HLS" -> downloadHlsPlaylist(task)
          "MUXED_AV" -> downloadAndMuxVideoAudio(task)
          "TORRENT", "MAGNET" -> downloadTorrentTask(task)
          else -> downloadHttpFile(task)
        }
      } catch (_: CancellationException) {
        val current = downloadDao.getById(taskId)
        if (current != null && current.status != "PAUSED" && current.status != "CANCELLED") {
          updateProgress(taskId, "PAUSED", current.bytesDownloaded, current.totalBytes, 0L)
        }
      } catch (t: Throwable) {
        val current = downloadDao.getById(taskId)
        updateProgress(
          taskId,
          "FAILED",
          current?.bytesDownloaded ?: 0L,
          current?.totalBytes ?: 0L,
          0L,
          t.localizedMessage ?: "Download failed",
        )
      } finally {
        activeJobs.remove(taskId)
      }
    }
  }

  suspend fun pauseTask(taskId: Long) {
    activeJobs[taskId]?.cancel()
    val current = downloadDao.getById(taskId) ?: return
    updateProgress(taskId, "PAUSED", current.bytesDownloaded, current.totalBytes, 0L)
  }

  suspend fun cancelTask(taskId: Long, removeFile: Boolean = false) {
    activeJobs[taskId]?.cancel()
    val current = downloadDao.getById(taskId)
    if (current != null) {
      updateProgress(taskId, "CANCELLED", current.bytesDownloaded, current.totalBytes, 0L)
      if (removeFile) File(current.destinationPath).delete()
    }
  }

  suspend fun deleteTaskRecord(taskId: Long) {
    activeJobs[taskId]?.cancel()
    downloadDao.deleteById(taskId)
  }

  suspend fun clearFinished() {
    downloadDao.clearFinished()
  }

  private suspend fun downloadHttpFile(task: DownloadTaskEntity) {
    val target = File(task.destinationPath)
    streamUrlToFile(task.id, task.sourceUrl, target, allowResume = true, peersLabel = null)
    val finalLen = target.length()
    updateProgress(task.id, "COMPLETED", finalLen, finalLen, 0L)
  }

  private suspend fun downloadAndMuxVideoAudio(task: DownloadTaskEntity) {
    val parts = task.sourceUrl.split(MUX_SEPARATOR)
    if (parts.size != 2) throw IllegalArgumentException("Invalid muxed stream specification")
    val videoUrl = parts[0]
    val audioUrl = parts[1]
    val outFile = File(task.destinationPath)
    outFile.parentFile?.mkdirs()
    val tmpVideo = File(outFile.parentFile, ".tmp_v_${task.id}.mp4")
    val tmpAudio = File(outFile.parentFile, ".tmp_a_${task.id}.m4a")
    try {
      streamUrlToFile(task.id, videoUrl, tmpVideo, allowResume = false, peersLabel = "Downloading HD Video...")
      streamUrlToFile(task.id, audioUrl, tmpAudio, allowResume = false, peersLabel = "Downloading Audio Track...")
      updateProgress(task.id, "DOWNLOADING", tmpVideo.length() + tmpAudio.length(), tmpVideo.length() + tmpAudio.length(), 0L, peersInfo = "Muxing Video + Audio...")
      muxVideoAndAudio(tmpVideo, tmpAudio, outFile)
      val outLen = outFile.length()
      updateProgress(task.id, "COMPLETED", outLen, outLen, 0L, peersInfo = "Muxed MP4 Ready")
    } finally {
      tmpVideo.delete()
      tmpAudio.delete()
    }
  }

  suspend fun triggerCompanionDownload(
    companionBaseUrl: String,
    mediaUrl: String,
    quality: String = "best",
    audioOnly: Boolean = false,
  ): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val base = companionBaseUrl.trim().trimEnd('/')
        val body = JSONObject()
          .put("url", mediaUrl)
          .put("quality", quality)
          .put("audio_only", audioOnly)
          .toString()
        val req = Request.Builder()
          .url("$base/api/download")
          .post(body.toRequestBody("application/json".toMediaType()))
          .build()
        client.newCall(req).execute().use { resp ->
          if (!resp.isSuccessful) error("Companion HTTP ${resp.code}")
          JSONObject(resp.body?.string().orEmpty()).optString("task_id", "queued")
        }
      }
    }

  private suspend fun streamUrlToFile(
    taskId: Long,
    url: String,
    target: File,
    allowResume: Boolean,
    peersLabel: String?,
    retryOnAuthExpiry: Boolean = true,
  ) {
    target.parentFile?.mkdirs()
    val existing = if (allowResume && target.exists()) target.length() else 0L
    val cachedHdr = streamHeadersCache[url]
    val reqBuilder = Request.Builder()
      .url(url)
      .header("User-Agent", cachedHdr?.third?.takeIf { it.isNotBlank() } ?: BROWSER_UA)
      .header("Accept", "*/*")
    cachedHdr?.first?.takeIf { it.isNotBlank() }?.let { reqBuilder.header("Cookie", it) }
    cachedHdr?.second?.takeIf { it.isNotBlank() }?.let { reqBuilder.header("Referer", it) }
    val isMobileAppClient = url.contains("c=IOS", true) || url.contains("c=ANDROID", true)
    if (url.contains("googlevideo.com", true) && !isMobileAppClient) {
      if (cachedHdr?.second.isNullOrBlank()) reqBuilder.header("Referer", "https://www.youtube.com/")
      reqBuilder.header("Origin", "https://www.youtube.com")
    }
    if (existing > 0L) reqBuilder.header("Range", "bytes=$existing-")

    client.newCall(reqBuilder.build()).execute().use { resp ->
      if ((resp.code == 401 || resp.code == 403) && retryOnAuthExpiry) {
        val originPage = streamOriginPageCache[url]
        val ytId = originPage?.let { extractYouTubeVideoId(it) }
        if (ytId != null && originPage != null) {
          val refreshed = runCatching { resolveYouTubeSmart(ytId, originPage).streams }.getOrDefault(emptyList())
          val isAudioReq = url.contains("mime=audio", true)
          val fresh =
            refreshed.firstOrNull { !it.isDrmProtected && it.url != url && if (isAudioReq) (!it.hasVideo && it.hasAudio) else it.hasVideo }
              ?: refreshed.firstOrNull { !it.isDrmProtected && it.url != url }
          if (fresh != null) {
            cacheHeaders(listOf(fresh), originPage)
            streamUrlToFile(taskId, fresh.url, target, allowResume = false, peersLabel = "Refreshed YouTube stream", retryOnAuthExpiry = false)
            return
          }
        } else {
          val sniffer = autoWebSniffer
          if (!originPage.isNullOrBlank() && sniffer != null) {
            val refreshed = runCatching { sniffer.sniffPageStreams(originPage).second }.getOrDefault(emptyList())
            val fresh = refreshed.firstOrNull { !it.isDrmProtected && it.hasVideo } ?: refreshed.firstOrNull()
            if (fresh != null) {
              cacheHeaders(listOf(fresh), originPage)
              streamUrlToFile(taskId, fresh.url, target, allowResume = false, peersLabel = "Refreshed expired link", retryOnAuthExpiry = false)
              return
            }
          }
        }
      }
      if (!resp.isSuccessful && resp.code != 206) {
        throw IllegalStateException("HTTP ${resp.code}: ${resp.message}")
      }
      val append = allowResume && resp.code == 206 && existing > 0L
      val body = resp.body ?: throw IllegalStateException("Empty response body")
      val contentLen = body.contentLength()
      val total = if (contentLen > 0) (if (append) existing + contentLen else contentLen) else 0L
      var downloaded = if (append) existing else 0L

      body.byteStream().use { input ->
        FileOutputStream(target, append).use { output ->
          val buf = ByteArray(32 * 1024)
          var lastTick = System.currentTimeMillis()
          var bytesSinceTick = 0L
          while (true) {
            val read = input.read(buf)
            if (read <= 0) break
            output.write(buf, 0, read)
            downloaded += read
            bytesSinceTick += read
            val now = System.currentTimeMillis()
            if (now - lastTick >= 400L) {
              val speed = (bytesSinceTick * 1000L) / (now - lastTick).coerceAtLeast(1L)
              updateProgress(taskId, "DOWNLOADING", downloaded, total, speed, peersInfo = peersLabel)
              lastTick = now
              bytesSinceTick = 0L
            }
          }
          output.flush()
        }
      }
    }
  }

  private fun muxVideoAndAudio(videoFile: File, audioFile: File, outFile: File) {
    val vExt = MediaExtractor()
    val aExt = MediaExtractor()
    var muxer: MediaMuxer? = null
    try {
      vExt.setDataSource(videoFile.absolutePath)
      aExt.setDataSource(audioFile.absolutePath)

      muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
      var vTrackOut = -1
      var vTrackIn = -1
      for (i in 0 until vExt.trackCount) {
        val fmt = vExt.getTrackFormat(i)
        if (fmt.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) {
          vTrackIn = i
          vExt.selectTrack(i)
          vTrackOut = muxer.addTrack(fmt)
          break
        }
      }

      var aTrackOut = -1
      var aTrackIn = -1
      for (i in 0 until aExt.trackCount) {
        val fmt = aExt.getTrackFormat(i)
        if (fmt.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
          aTrackIn = i
          aExt.selectTrack(i)
          aTrackOut = muxer.addTrack(fmt)
          break
        }
      }

      if (vTrackIn < 0) throw IllegalStateException("No video track found to mux")
      muxer.start()

      val buffer = ByteBuffer.allocate(1024 * 1024)
      val info = MediaCodec.BufferInfo()

      while (true) {
        buffer.clear()
        val size = vExt.readSampleData(buffer, 0)
        if (size < 0) break
        info.offset = 0
        info.size = size
        info.presentationTimeUs = vExt.sampleTime
        info.flags = vExt.sampleFlags
        muxer.writeSampleData(vTrackOut, buffer, info)
        vExt.advance()
      }

      if (aTrackIn >= 0 && aTrackOut >= 0) {
        while (true) {
          buffer.clear()
          val size = aExt.readSampleData(buffer, 0)
          if (size < 0) break
          info.offset = 0
          info.size = size
          info.presentationTimeUs = aExt.sampleTime
          info.flags = aExt.sampleFlags
          muxer.writeSampleData(aTrackOut, buffer, info)
          aExt.advance()
        }
      }
    } finally {
      runCatching { muxer?.stop() }
      runCatching { muxer?.release() }
      runCatching { vExt.release() }
      runCatching { aExt.release() }
    }
  }

  private fun buildRequestWithHeaders(targetUrl: String, inheritedHeaders: Map<String, String>): Request {
    val merged = LinkedHashMap<String, String>(inheritedHeaders)
    merged.putAll(getHeadersForUrl(targetUrl))
    val b = Request.Builder().url(targetUrl)
    merged.forEach { (k, v) -> b.header(k, v) }
    return b.build()
  }

  private suspend fun downloadHlsPlaylist(task: DownloadTaskEntity) {
    val rootHeaders = getHeadersForUrl(task.sourceUrl)
    val playlistReq = buildRequestWithHeaders(task.sourceUrl, rootHeaders)
    val playlistText = client.newCall(playlistReq).execute().use { resp ->
      if (!resp.isSuccessful) throw IllegalStateException("HLS HTTP ${resp.code}")
      resp.body?.string().orEmpty()
    }
    if (playlistText.contains("#EXT-X-KEY", ignoreCase = true) && !playlistText.contains("METHOD=NONE", true)) {
      throw IllegalStateException("Encrypted/DRM HLS streams are not supported.")
    }

    var baseUrl = task.sourceUrl
    val rawLines = playlistText.lines().map { it.trim() }.filter { it.isNotEmpty() }
    val segmentUrls = mutableListOf<String>()

    var activeMediaText = playlistText
    val hasVariants = rawLines.any { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }
    if (hasVariants) {
      var bestBandwidth = -1L
      var bestVariantUrl: String? = null
      for (i in rawLines.indices) {
        val line = rawLines[i]
        if (line.startsWith("#EXT-X-STREAM-INF", ignoreCase = true)) {
          val bw = Regex("""BANDWIDTH=(\d+)""", RegexOption.IGNORE_CASE).find(line)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
          val nextUri = rawLines.drop(i + 1).firstOrNull { !it.startsWith("#") }
          if (nextUri != null && bw >= bestBandwidth) {
            bestBandwidth = bw
            bestVariantUrl = nextUri
          }
        }
      }
      val chosen = bestVariantUrl ?: rawLines.firstOrNull { !it.startsWith("#") && it.contains(".m3u8", true) }
      if (chosen != null) {
        val resolvedVariant = resolveRelativeUrl(baseUrl, chosen)
        val subText = client.newCall(buildRequestWithHeaders(resolvedVariant, rootHeaders)).execute().use {
          if (!it.isSuccessful) throw IllegalStateException("HLS Variant HTTP ${it.code}")
          it.body?.string().orEmpty()
        }
        baseUrl = resolvedVariant
        activeMediaText = subText
      }
    }

    val mediaLines = activeMediaText.lines().map { it.trim() }.filter { it.isNotEmpty() }
    if (mediaLines.any { it.contains("#EXT-X-KEY", true) && !it.contains("METHOD=NONE", true) }) {
      throw IllegalStateException("Encrypted/DRM HLS streams are not supported.")
    }
    val mapLine = mediaLines.firstOrNull { it.startsWith("#EXT-X-MAP:", ignoreCase = true) }
    if (mapLine != null) {
      val mapUri = Regex("""URI=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(mapLine)?.groupValues?.getOrNull(1)
      if (!mapUri.isNullOrBlank()) {
        segmentUrls.add(resolveRelativeUrl(baseUrl, mapUri))
      }
    }
    mediaLines.filter { !it.startsWith("#") }.forEach { segmentUrls.add(resolveRelativeUrl(baseUrl, it)) }

    if (segmentUrls.isEmpty()) throw IllegalStateException("No segments found in HLS playlist")

    val outFile = File(task.destinationPath)
    outFile.parentFile?.mkdirs()
    var written = 0L
    FileOutputStream(outFile, false).use { fos ->
      segmentUrls.forEachIndexed { idx, segUrl ->
        val segBytes = client.newCall(buildRequestWithHeaders(segUrl, rootHeaders)).execute().use { r ->
          if (!r.isSuccessful) throw IllegalStateException("Segment ${idx + 1} failed (${r.code})")
          r.body?.bytes() ?: ByteArray(0)
        }
        fos.write(segBytes)
        written += segBytes.size
        updateProgress(
          taskId = task.id,
          status = "DOWNLOADING",
          downloaded = written,
          total = (written * segmentUrls.size) / (idx + 1),
          speed = segBytes.size.toLong(),
          peersInfo = "Segment ${idx + 1}/${segmentUrls.size}",
        )
      }
      fos.flush()
    }
    updateProgress(task.id, "COMPLETED", written, written, 0L)
  }

  private suspend fun downloadTorrentTask(task: DownloadTaskEntity) {
    val webSeeds: List<String>
    val expectedFiles: List<Pair<String, Long>>
    if (task.downloadType == "MAGNET") {
      val magnet = parseMagnetUri(task.sourceUrl)
        ?: throw IllegalArgumentException("Invalid magnet URI")
      webSeeds = magnet.webSeeds
      expectedFiles = listOf(magnet.displayName to 0L)
    } else {
      val torrentFile = File(task.sourceUrl)
      val meta = parseTorrentBytes(torrentFile.readBytes())
      webSeeds = meta.webSeeds
      expectedFiles = meta.files
    }

    if (webSeeds.isNotEmpty()) {
      val seedBase = webSeeds.first()
      val target = File(task.destinationPath)
      val destFile = if (expectedFiles.size == 1 && !target.isDirectory) target else File(target, expectedFiles.first().first).also { it.parentFile?.mkdirs() }
      val seedTask = task.copy(sourceUrl = seedBase, destinationPath = destFile.absolutePath, downloadType = "HTTP")
      downloadHttpFile(seedTask)
      return
    }

    val trackerCount = if (task.downloadType == "MAGNET") parseMagnetUri(task.sourceUrl)?.trackers?.size ?: 0
    else runCatching { parseTorrentBytes(File(task.sourceUrl).readBytes()).trackers.size }.getOrDefault(0)

    throw IllegalStateException(
      "Parsed torrent ($trackerCount trackers). Direct peer swarm download requires reachable WebSeeds (BEP-19) or inbound DHT/TCP peer port; no HTTP WebSeeds were advertised."
    )
  }

  private fun resolveRelativeUrl(base: String, ref: String): String {
    if (ref.startsWith("http://") || ref.startsWith("https://")) return ref
    return runCatching { java.net.URI(base).resolve(ref).toString() }.getOrDefault(ref)
  }

  private fun guessNameFromUrl(url: String, fallback: String): String {
    val clean = url.substringBefore('?').substringAfterLast('/')
    return if (clean.contains('.') && clean.length in 3..80) clean else fallback
  }

  private fun sanitizeFileName(raw: String): String =
    raw.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "download.bin" }

  private fun uniqueFile(dir: File, name: String): File {
    var candidate = File(dir, name)
    if (!candidate.exists()) return candidate
    val base = name.substringBeforeLast('.', name)
    val ext = name.substringAfterLast('.', "")
    var i = 1
    while (candidate.exists()) {
      val next = if (ext.isNotEmpty() && base != name) "${base}_$i.$ext" else "${name}_$i"
      candidate = File(dir, next)
      i++
    }
    return candidate
  }
}
