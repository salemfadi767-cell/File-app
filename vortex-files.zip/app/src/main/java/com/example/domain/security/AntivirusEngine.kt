package com.example.domain.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.zip.ZipFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class ThreatSeverity {
  CLEAN,
  LOW_RISK,
  SUSPICIOUS,
  MALICIOUS,
}

data class ThreatFinding(
  val filePath: String,
  val fileName: String,
  val severity: ThreatSeverity,
  val riskScore: Int,
  val sha256: String,
  val reasons: List<String>,
  val scannedBytes: Long,
)

data class AntivirusScanReport(
  val targetPath: String,
  val totalFilesScanned: Int,
  val threatsFound: Int,
  val highestSeverity: ThreatSeverity,
  val findings: List<ThreatFinding>,
  val durationMs: Long,
)

class AntivirusEngine(private val context: Context) {

  private val knownThreatHashes: Map<String, String> = mapOf(
    // Standard EICAR anti-malware test file SHA-256
    "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f" to "EICAR-Standard-Test-Signature",
    // EICAR without trailing newline variant
    "131f95c51cc819465fa1797f6ccacf9d494aaaff46fa3eac73ae63ffbdfd8267" to "EICAR-Test-Signature-NoLF",
  )

  private val eicarAsciiSignature = "X5O!P%@AP[4\\PZX54(P^)7CC)7}\$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!\$H+H*"

  private val dangerousScriptPatterns: List<Pair<Regex, String>> = listOf(
    Regex("""rm\s+-rf\s+/(?:\*|\s|$)""") to "Destructive root filesystem wipe command",
    Regex("""(?:curl|wget)\s+[^\n]+\|\s*(?:sh|bash)""", RegexOption.IGNORE_CASE) to "Remote pipe-to-shell dropper pattern",
    Regex("""base64\s+-d[^\n]*\|\s*(?:sh|bash|python)""", RegexOption.IGNORE_CASE) to "Base64 obfuscated payload execution",
    Regex("""eval\s*\(\s*(?:atob|base64_decode|compile)\s*\(""", RegexOption.IGNORE_CASE) to "Obfuscated dynamic eval payload",
    Regex("""/system/bin/su\b|su\s+-c\s+""") to "Root privilege escalation attempt",
    Regex("""Runtime\.getRuntime\(\)\.exec\(""") to "Direct native process execution call",
    Regex("""DexClassLoader|InMemoryDexClassLoader""") to "Dynamic DEX code loading indicator",
  )

  private val highRiskPermissions = setOf(
    "android.permission.BIND_ACCESSIBILITY_SERVICE",
    "android.permission.BIND_DEVICE_ADMIN",
    "android.permission.READ_SMS",
    "android.permission.RECEIVE_SMS",
    "android.permission.SEND_SMS",
    "android.permission.SYSTEM_ALERT_WINDOW",
    "android.permission.REQUEST_INSTALL_PACKAGES",
    "android.permission.RECORD_AUDIO",
    "android.permission.READ_CONTACTS",
    "android.permission.ACCESS_BACKGROUND_LOCATION",
  )

  suspend fun scanTarget(
    targetPath: String,
    onProgress: (scanned: Int, total: Int) -> Unit = { _, _ -> },
  ): AntivirusScanReport =
    withContext(Dispatchers.IO) {
      val started = System.currentTimeMillis()
      val root = File(targetPath)
      val filesToScan: List<File> =
        if (!root.exists()) {
          emptyList()
        } else if (root.isFile) {
          listOf(root)
        } else {
          root.walkTopDown().maxDepth(4).filter { it.isFile && it.canRead() }.take(300).toList()
        }

      val total = filesToScan.size.coerceAtLeast(1)
      val findings = mutableListOf<ThreatFinding>()

      filesToScan.forEachIndexed { idx, file ->
        findings.add(scanSingleFile(file))
        onProgress(idx + 1, total)
      }

      val threats = findings.count { it.severity == ThreatSeverity.SUSPICIOUS || it.severity == ThreatSeverity.MALICIOUS }
      val maxSev = findings.maxByOrNull { it.severity.ordinal }?.severity ?: ThreatSeverity.CLEAN
      val sortedFindings = findings.sortedByDescending { it.riskScore }

      AntivirusScanReport(
        targetPath = targetPath,
        totalFilesScanned = filesToScan.size,
        threatsFound = threats,
        highestSeverity = maxSev,
        findings = sortedFindings,
        durationMs = (System.currentTimeMillis() - started).coerceAtLeast(1L),
      )
    }

  suspend fun scanSingleFile(file: File): ThreatFinding =
    withContext(Dispatchers.IO) {
      if (!file.exists() || !file.isFile || !file.canRead()) {
        return@withContext ThreatFinding(
          filePath = file.absolutePath,
          fileName = file.name,
          severity = ThreatSeverity.CLEAN,
          riskScore = 0,
          sha256 = "",
          reasons = listOf("File unreadable or missing"),
          scannedBytes = 0L,
        )
      }

      val reasons = mutableListOf<String>()
      var score = 0
      val sha256 = computeSha256Limited(file, maxBytes = 24 * 1024 * 1024)

      knownThreatHashes[sha256]?.let { sigName ->
        score += 100
        reasons.add("Matched known signature: $sigName")
      }

      val headSize = minOf(file.length(), 131_072L).toInt().coerceAtLeast(0)
      val headBytes = ByteArray(headSize)
      if (headSize > 0) {
        runCatching {
          FileInputStream(file).use { it.read(headBytes) }
        }
      }

      val headAscii = runCatching { headBytes.toString(Charsets.UTF_8) }.getOrDefault("")
      if (headAscii.contains(eicarAsciiSignature)) {
        score += 100
        reasons.add("EICAR antivirus signature detected in payload")
      }

      val ext = file.extension.lowercase()
      // Double extension spoofing check (e.g., invoice.pdf.exe or photo.jpg.apk)
      val lowerName = file.name.lowercase()
      if (Regex("""\.(jpg|jpeg|png|pdf|doc|docx|mp3|mp4)\.(exe|bat|cmd|vbs|ps1|apk|sh|elf|dex)$""").containsMatchIn(lowerName)) {
        score += 65
        reasons.add("Double-extension executable spoofing detected")
      }

      // Magic-byte spoofing check
      val magicType = detectExecutableMagic(headBytes)
      if (magicType != null && ext in setOf("jpg", "jpeg", "png", "gif", "webp", "mp3", "mp4", "pdf", "txt", "srt", "vtt")) {
        score += 80
        reasons.add("Disguised $magicType binary masquerading as .$ext")
      }

      // Script / Text heuristic scan
      if (ext in setOf("sh", "bash", "py", "js", "vbs", "ps1", "bat", "cmd", "txt", "html", "htm", "json", "php") || headAscii.startsWith("#!")) {
        for ((rx, msg) in dangerousScriptPatterns) {
          if (rx.containsMatchIn(headAscii)) {
            score += 35
            reasons.add(msg)
          }
        }
      }

      // APK deep security heuristics
      if (ext == "apk" || ext == "apks" || ext == "xapk") {
        val apkScore = inspectApkRisk(file, reasons)
        score += apkScore
      }

      // Archive bomb / nested executable check
      if (ext in setOf("zip", "jar") && file.length() < 15 * 1024 * 1024) {
        runCatching {
          ZipFile(file).use { zf ->
            var nestedExe = 0
            val entries = zf.entries()
            var inspected = 0
            while (entries.hasMoreElements() && inspected < 400) {
              val ze = entries.nextElement()
              inspected++
              if (ze.size > 512L * 1024 * 1024 && ze.compressedSize in 1..1024 * 1024) {
                score += 60
                reasons.add("High compression ratio anomaly (potential decompression bomb)")
                break
              }
              val nameL = ze.name.lowercase()
              if (nameL.endsWith(".exe") || nameL.endsWith(".bat") || nameL.endsWith(".dex") && ext == "zip") {
                nestedExe++
              }
            }
            if (nestedExe > 0) {
              score += 25
              reasons.add("Archive contains $nestedExe embedded executable/DEX payload(s)")
            }
          }
        }
      }

      val finalScore = score.coerceIn(0, 100)
      val severity =
        when {
          finalScore >= 70 -> ThreatSeverity.MALICIOUS
          finalScore >= 35 -> ThreatSeverity.SUSPICIOUS
          finalScore >= 15 -> ThreatSeverity.LOW_RISK
          else -> ThreatSeverity.CLEAN
        }

      ThreatFinding(
        filePath = file.absolutePath,
        fileName = file.name,
        severity = severity,
        riskScore = finalScore,
        sha256 = sha256,
        reasons = if (reasons.isEmpty()) listOf("No known signatures or heuristic threats detected") else reasons.distinct(),
        scannedBytes = file.length(),
      )
    }

  private fun inspectApkRisk(file: File, reasons: MutableList<String>): Int {
    var delta = 0
    val pm = context.packageManager
    val pkgInfo =
      runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          pm.getPackageArchiveInfo(
            file.absolutePath,
            PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()),
          )
        } else {
          @Suppress("DEPRECATION")
          pm.getPackageArchiveInfo(file.absolutePath, PackageManager.GET_PERMISSIONS)
        }
      }.getOrNull()

    val perms = pkgInfo?.requestedPermissions?.toSet().orEmpty()
    val riskyHits = perms.intersect(highRiskPermissions)
    if (riskyHits.size >= 4) {
      delta += 45
      reasons.add("APK requests ${riskyHits.size} high-risk permissions (${riskyHits.take(3).joinToString { it.substringAfterLast('.') }})")
    } else if (riskyHits.isNotEmpty()) {
      delta += 15
      reasons.add("APK requests sensitive permission(s): ${riskyHits.joinToString { it.substringAfterLast('.') }}")
    }
    if ("android.permission.RECEIVE_SMS" in perms && "android.permission.INTERNET" in perms) {
      delta += 30
      reasons.add("SMS interception + Internet exfiltration permission combination")
    }
    if ("android.permission.BIND_ACCESSIBILITY_SERVICE" in perms && "android.permission.SYSTEM_ALERT_WINDOW" in perms) {
      delta += 35
      reasons.add("Accessibility + Overlay combination (overlay/trojan behavior risk)")
    }
    return delta
  }

  private fun detectExecutableMagic(bytes: ByteArray): String? {
    if (bytes.size < 4) return null
    val b0 = bytes[0].toInt() and 0xFF
    val b1 = bytes[1].toInt() and 0xFF
    val b2 = bytes[2].toInt() and 0xFF
    val b3 = bytes[3].toInt() and 0xFF
    return when {
      b0 == 0x7F && b1 == 0x45 && b2 == 0x4C && b3 == 0x46 -> "Linux/Android ELF"
      b0 == 0x4D && b1 == 0x5A -> "Windows PE/EXE"
      b0 == 0x64 && b1 == 0x65 && b2 == 0x78 && b3 == 0x0A -> "Dalvik DEX"
      (b0 == 0xFE && b1 == 0xED && b2 == 0xFA && (b3 == 0xCE || b3 == 0xCF)) ||
        (b0 == 0xCF && b1 == 0xFA && b2 == 0xED && b3 == 0xFE) -> "macOS Mach-O"
      else -> null
    }
  }

  suspend fun quarantineFile(file: File): File? =
    withContext(Dispatchers.IO) {
      if (!file.exists() || !file.isFile) return@withContext null
      val qDir = File(context.filesDir, "vortex_quarantine").apply { mkdirs() }
      val dst = File(qDir, "${file.name}.${System.currentTimeMillis()}.quarantined")
      val moved = file.renameTo(dst)
      if (moved) dst
      else runCatching {
        file.copyTo(dst, overwrite = true)
        file.delete()
        dst
      }.getOrNull()
    }

  private fun computeSha256Limited(file: File, maxBytes: Int): String {
    val md = MessageDigest.getInstance("SHA-256")
    val buf = ByteArray(16384)
    var remaining = maxBytes
    runCatching {
      FileInputStream(file).use { fis ->
        while (remaining > 0) {
          val r = fis.read(buf, 0, minOf(buf.size, remaining))
          if (r <= 0) break
          md.update(buf, 0, r)
          remaining -= r
        }
      }
    }
    return md.digest().joinToString("") { "%02x".format(it) }
  }
}
