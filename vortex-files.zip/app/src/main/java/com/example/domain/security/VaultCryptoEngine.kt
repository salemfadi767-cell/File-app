package com.example.domain.security

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters

data class VaultLockResult(
  val lockedFile: File,
  val originalPath: String,
  val originalName: String,
  val wasDirectory: Boolean,
  val originalSizeBytes: Long,
  val recoveryKey: String,
  val recoveryKeyHash: String,
)

data class VaultUnlockResult(
  val restoredFile: File,
  val wasDirectory: Boolean,
)

/**
 * Authenticated AES-256-GCM vault container ("VLOCK1") supporting both files and directories.
 * Dual key slots allow decryption with either the user password OR the exported recovery key.
 */
object VaultCryptoEngine {
  private val MAGIC = "VLOCK1".toByteArray(Charsets.US_ASCII)
  private const val PBKDF2_ITERATIONS = 65_536
  private const val AES_KEY_BITS = 256
  private const val GCM_TAG_BITS = 128

  fun generateRecoveryKey(): String {
    val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    val rng = SecureRandom()
    val groups =
      (0 until 4).map {
        (0 until 4).map { alphabet[rng.nextInt(alphabet.length)] }.joinToString("")
      }
    return "VORTEX-${groups.joinToString("-")}"
  }

  fun sha256Hex(text: String): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(text.trim().toByteArray(Charsets.UTF_8))
    return digest.joinToString("") { "%02x".format(it) }
  }

  suspend fun lockTarget(
    target: File,
    password: String,
    deleteOriginal: Boolean = true,
  ): VaultLockResult =
    withContext(Dispatchers.IO) {
      require(target.exists()) { "Target does not exist: ${target.absolutePath}" }
      require(password.length >= 4) { "Password must be at least 4 characters" }

      val wasDir = target.isDirectory
      val originalSize =
        if (wasDir) {
          target.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        } else {
          target.length()
        }

      val payloadBytes =
        if (wasDir) {
          val tempZip = File.createTempFile("vlock_dir_", ".zip")
          try {
            tempZip.delete()
            val zf = ZipFile(tempZip)
            val children = target.listFiles()?.toList().orEmpty()
            val params = ZipParameters()
            children.forEach { child ->
              if (child.isDirectory) zf.addFolder(child, params) else zf.addFile(child, params)
            }
            if (children.isEmpty()) {
              // Preserve empty directory marker
              val marker = File.createTempFile(".vlock_empty_", ".tmp")
              zf.addFile(marker, params)
              marker.delete()
            }
            tempZip.readBytes()
          } finally {
            tempZip.delete()
          }
        } else {
          target.readBytes()
        }

      val rng = SecureRandom()
      val masterDek = ByteArray(32).also { rng.nextBytes(it) }
      val recoveryKey = generateRecoveryKey()

      val pwdSalt = ByteArray(16).also { rng.nextBytes(it) }
      val recSalt = ByteArray(16).also { rng.nextBytes(it) }
      val pwdKey = deriveKey(password, pwdSalt)
      val recKey = deriveKey(recoveryKey, recSalt)

      val pwdIv = ByteArray(12).also { rng.nextBytes(it) }
      val recIv = ByteArray(12).also { rng.nextBytes(it) }
      val payloadIv = ByteArray(12).also { rng.nextBytes(it) }

      val wrappedDekByPwd = aesGcmEncrypt(masterDek, pwdKey, pwdIv)
      val wrappedDekByRec = aesGcmEncrypt(masterDek, recKey, recIv)
      val encryptedPayload = aesGcmEncrypt(payloadBytes, SecretKeySpec(masterDek, "AES"), payloadIv)

      val lockedFile = File(target.parentFile, "${target.name}.vlock")
      val outBytes = ByteArrayOutputStream()
      DataOutputStream(outBytes).use { dos ->
        dos.write(MAGIC)
        dos.writeByte(if (wasDir) 1 else 0)
        dos.writeUTF(target.name)
        dos.write(pwdSalt)
        dos.write(pwdIv)
        dos.writeInt(wrappedDekByPwd.size)
        dos.write(wrappedDekByPwd)
        dos.write(recSalt)
        dos.write(recIv)
        dos.writeInt(wrappedDekByRec.size)
        dos.write(wrappedDekByRec)
        dos.write(payloadIv)
        dos.writeInt(encryptedPayload.size)
        dos.write(encryptedPayload)
      }
      lockedFile.writeBytes(outBytes.toByteArray())

      if (deleteOriginal) {
        if (wasDir) target.deleteRecursively() else target.delete()
      }

      VaultLockResult(
        lockedFile = lockedFile,
        originalPath = target.absolutePath,
        originalName = target.name,
        wasDirectory = wasDir,
        originalSizeBytes = originalSize,
        recoveryKey = recoveryKey,
        recoveryKeyHash = sha256Hex(recoveryKey),
      )
    }

  suspend fun unlockTarget(
    lockedFile: File,
    secretOrRecoveryKey: String,
    deleteLockedAfter: Boolean = true,
  ): VaultUnlockResult =
    withContext(Dispatchers.IO) {
      require(lockedFile.exists() && lockedFile.isFile) { "Locked file not found" }
      val raw = lockedFile.readBytes()
      DataInputStream(ByteArrayInputStream(raw)).use { dis ->
        val magic = ByteArray(MAGIC.size)
        dis.readFully(magic)
        require(magic.contentEquals(MAGIC)) { "Not a valid Vortex Vault container" }

        val wasDir = dis.readByte().toInt() == 1
        val origName = dis.readUTF()
        val pwdSalt = ByteArray(16).also { dis.readFully(it) }
        val pwdIv = ByteArray(12).also { dis.readFully(it) }
        val pwdWrapLen = dis.readInt()
        val wrappedPwd = ByteArray(pwdWrapLen).also { dis.readFully(it) }

        val recSalt = ByteArray(16).also { dis.readFully(it) }
        val recIv = ByteArray(12).also { dis.readFully(it) }
        val recWrapLen = dis.readInt()
        val wrappedRec = ByteArray(recWrapLen).also { dis.readFully(it) }

        val payloadIv = ByteArray(12).also { dis.readFully(it) }
        val payloadLen = dis.readInt()
        val encryptedPayload = ByteArray(payloadLen).also { dis.readFully(it) }

        val trimmed = secretOrRecoveryKey.trim()
        val masterDek =
          runCatching { aesGcmDecrypt(wrappedPwd, deriveKey(secretOrRecoveryKey, pwdSalt), pwdIv) }.getOrNull()
            ?: runCatching { aesGcmDecrypt(wrappedRec, deriveKey(trimmed, recSalt), recIv) }.getOrNull()
            ?: throw SecurityException("Incorrect password or recovery key")

        val plainBytes = aesGcmDecrypt(encryptedPayload, SecretKeySpec(masterDek, "AES"), payloadIv)
        val targetOut = File(lockedFile.parentFile, origName)
        if (wasDir) {
          val tempZip = File.createTempFile("vunlock_dir_", ".zip")
          try {
            tempZip.writeBytes(plainBytes)
            targetOut.mkdirs()
            ZipFile(tempZip).extractAll(targetOut.absolutePath)
            targetOut.listFiles()?.filter { it.name.startsWith(".vlock_empty_") }?.forEach { it.delete() }
          } finally {
            tempZip.delete()
          }
        } else {
          targetOut.writeBytes(plainBytes)
        }

        if (deleteLockedAfter) {
          lockedFile.delete()
        }

        VaultUnlockResult(restoredFile = targetOut, wasDirectory = wasDir)
      }
    }

  private fun deriveKey(secret: String, salt: ByteArray): SecretKeySpec {
    val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
    val spec = PBEKeySpec(secret.toCharArray(), salt, PBKDF2_ITERATIONS, AES_KEY_BITS)
    val encoded = factory.generateSecret(spec).encoded
    return SecretKeySpec(encoded, "AES")
  }

  private fun aesGcmEncrypt(plain: ByteArray, key: SecretKeySpec, iv: ByteArray): ByteArray {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
    return cipher.doFinal(plain)
  }

  private fun aesGcmDecrypt(cipherBytes: ByteArray, key: SecretKeySpec, iv: ByteArray): ByteArray {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
    return cipher.doFinal(cipherBytes)
  }
}
