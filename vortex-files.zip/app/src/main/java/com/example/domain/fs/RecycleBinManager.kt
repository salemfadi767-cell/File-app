package com.example.domain.fs

import android.content.Context
import com.example.data.db.TrashDao
import com.example.data.db.TrashEntryEntity
import java.io.File
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class RecycleBinManager(
  private val context: Context,
  private val trashDao: TrashDao,
) {
  fun trashDir(): File = File(context.filesDir, "vortex_trash").apply { mkdirs() }

  suspend fun moveToTrash(
    nodes: List<VirtualFileNode>,
    retentionDays: Int,
  ): Int =
    withContext(Dispatchers.IO) {
      if (retentionDays <= 0) return@withContext 0
      val now = System.currentTimeMillis()
      val expiresAt = now + retentionDays.toLong() * 86_400_000L
      val bin = trashDir()
      var moved = 0

      for (node in nodes) {
        val src = File(node.path)
        if (!src.exists() || !src.canRead()) continue
        val size =
          if (src.isDirectory) src.walkTopDown().filter { it.isFile }.sumOf { it.length() }
          else src.length()
        val destName = "${now}_${UUID.randomUUID().toString().take(8)}_${src.name}"
        val dest = File(bin, destName)

        val ok =
          if (src.renameTo(dest)) {
            true
          } else {
            val copied = src.copyRecursively(dest, overwrite = true)
            if (copied) src.deleteRecursively()
            copied
          }

        if (ok) {
          trashDao.insert(
            TrashEntryEntity(
              originalPath = node.path,
              originalName = node.name,
              trashPath = dest.absolutePath,
              isDirectory = node.isDirectory,
              sizeBytes = size,
              deletedAt = now,
              expiresAt = expiresAt,
            )
          )
          moved++
        }
      }
      moved
    }

  suspend fun restoreEntry(entry: TrashEntryEntity, fallbackDir: File? = null): Boolean =
    withContext(Dispatchers.IO) {
      val src = File(entry.trashPath)
      if (!src.exists()) {
        trashDao.deleteById(entry.id)
        return@withContext false
      }
      val desired = File(entry.originalPath)
      val parentDir = desired.parentFile?.takeIf { it.exists() || it.mkdirs() } ?: fallbackDir ?: context.filesDir
      var target = File(parentDir, entry.originalName)
      if (target.exists()) {
        val stem = File(entry.originalName).nameWithoutExtension
        val ext = File(entry.originalName).extension
        val ts = System.currentTimeMillis() % 10000
        target = File(parentDir, if (ext.isBlank()) "${stem}_restored_$ts" else "${stem}_restored_$ts.$ext")
      }
      val ok =
        if (src.renameTo(target)) true
        else {
          val copied = src.copyRecursively(target, overwrite = true)
          if (copied) src.deleteRecursively()
          copied
        }
      if (ok) {
        trashDao.deleteById(entry.id)
      }
      ok
    }

  suspend fun permanentlyDeleteEntry(entry: TrashEntryEntity): Boolean =
    withContext(Dispatchers.IO) {
      val f = File(entry.trashPath)
      if (f.exists()) f.deleteRecursively()
      trashDao.deleteById(entry.id)
      true
    }

  suspend fun emptyTrash(): Int =
    withContext(Dispatchers.IO) {
      val all = trashDao.getAllOnce()
      all.forEach { entry ->
        val f = File(entry.trashPath)
        if (f.exists()) f.deleteRecursively()
      }
      trashDao.clearAll()
      all.size
    }

  suspend fun purgeExpired(nowMillis: Long = System.currentTimeMillis()): Int =
    withContext(Dispatchers.IO) {
      val expired = trashDao.findExpired(nowMillis)
      expired.forEach { entry ->
        val f = File(entry.trashPath)
        if (f.exists()) f.deleteRecursively()
        trashDao.deleteById(entry.id)
      }
      expired.size
    }
}
