package com.example.domain.download

import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Self-contained generator for the standalone Python FastAPI 4-tier Universal Media Downloader
 * (yt-dlp -> gallery-dl -> streamlink -> Playwright Stealth + FFmpeg + 401/403 Recovery + DRM Guard + Dark Web UI + /api/stream proxy).
 */
object FastApiCompanionKit {

  data class ExportSummary(
    val outputDir: File,
    val filesCreated: List<String>,
  )

  suspend fun exportKitToFolder(targetRoot: File): ExportSummary =
    withContext(Dispatchers.IO) {
      val kitDir = File(targetRoot, "vortex_universal_downloader_server")
      val staticDir = File(kitDir, "static")
      val downloadsDir = File(kitDir, "downloads")
      staticDir.mkdirs()
      downloadsDir.mkdirs()

      val files = linkedMapOf(
        "requirements.txt" to REQUIREMENTS_TXT,
        "updater.py" to UPDATER_PY,
        "sniffer.py" to SNIFFER_PY,
        "engines.py" to ENGINES_PY,
        "downloader.py" to DOWNLOADER_PY,
        "main.py" to MAIN_PY,
        "static/index.html" to INDEX_HTML,
        "README_RUN.txt" to README_TXT,
      )

      val created = mutableListOf<String>()
      for ((relPath, content) in files) {
        val outFile = File(kitDir, relPath)
        outFile.parentFile?.mkdirs()
        outFile.writeText(content, Charsets.UTF_8)
        created.add(outFile.name)
      }
      ExportSummary(outputDir = kitDir, filesCreated = created)
    }

  private const val REQUIREMENTS_TXT = """fastapi>=0.115.0
uvicorn[standard]>=0.30.0
yt-dlp>=2025.1.1
gallery-dl>=1.28.0
streamlink>=7.0.0
playwright>=1.49.0
playwright-stealth>=1.0.6
aiohttp>=3.10.0
websockets>=13.0
"""

  private const val UPDATER_PY = """import asyncio
import logging
import subprocess
import sys
import time

logger = logging.getLogger("vortex.updater")
_last_emergency_update = 0.0

def upgrade_all_engines_sync() -> bool:
    \"\"\"Upgrade yt-dlp, gallery-dl, and streamlink on startup without blocking boot.\"\"\"
    packages = ["yt-dlp", "gallery-dl", "streamlink"]
    try:
        res = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet", "--upgrade", *packages],
            check=False,
            capture_output=True,
            text=True,
            timeout=180,
        )
        logger.info("Engine auto-update completed (exit=%s)", res.returncode)
        return res.returncode == 0
    except Exception as exc:
        logger.warning("Engine auto-update skipped: %s", exc)
        return False

async def emergency_update_ytdlp() -> bool:
    \"\"\"On-demand self-healing upgrade triggered when yt-dlp fails with an extractor/site error.\"\"\"
    global _last_emergency_update
    now = time.monotonic()
    if now - _last_emergency_update < 300:
        return False
    _last_emergency_update = now
    logger.info("Triggering emergency yt-dlp upgrade...")
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "pip", "install", "--quiet", "--upgrade", "--pre", "yt-dlp",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await proc.communicate()
    return proc.returncode == 0
"""

  private const val SNIFFER_PY = """import asyncio
import re
from typing import Dict, List, Any

MEDIA_EXT_RE = re.compile(r"\\.(mp4|webm|mkv|mov|m3u8|mpd|mp3|m4a|aac|opus)(\\?|$)", re.IGNORECASE)
DRM_RE = re.compile(
    r"(widevine|playready|fairplay|<ContentProtection|SAMPLE-AES|#EXT-X-KEY:(?!.*METHOD=NONE))",
    re.IGNORECASE,
)

COOKIE_BANNER_SELECTORS = [
    "button:has-text('Accept')",
    "button:has-text('Agree')",
    "button:has-text('Allow all')",
    "button:has-text('I accept')",
    "[id*='accept' i]",
    "[class*='cookie' i] button",
]

PLAY_TRIGGER_SELECTORS = [
    ".ytp-large-play-button",
    ".vjs-big-play-button",
    "button[aria-label*='Play' i]",
    "button[title*='Play' i]",
    "[class*='play' i]",
    "video",
]

async def sniff_with_playwright(url: str, timeout_sec: int = 26) -> Dict[str, Any]:
    \"\"\"Tier 4 invisible headless Chromium sniffer capturing requests, responses, cookies, Origin, and Referer.\"\"\"
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        return {"title": "Web Media", "streams": [], "drm_detected": False, "error": "Playwright not installed"}

    captured: List[Dict[str, Any]] = []
    seen = set()
    req_headers_map: Dict[str, Dict[str, str]] = {}
    drm_detected = False
    page_title = "Web Media"
    default_ua = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    )

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled", "--mute-audio"],
        )
        context = await browser.new_context(user_agent=default_ua, ignore_https_errors=True)
        page = await context.new_page()
        try:
            try:
                from playwright_stealth import stealth_async
                await stealth_async(page)
            except Exception:
                pass

            def on_request(req):
                r_url = req.url
                if MEDIA_EXT_RE.search(r_url) or req.resource_type in ("media", "xhr", "fetch"):
                    req_headers_map[r_url] = {k.lower(): v for k, v in req.headers.items()}

            async def on_response(resp):
                nonlocal drm_detected
                r_url = resp.url
                ctype = (resp.headers.get("content-type") or "").lower()
                if "mpegurl" in ctype or "dash+xml" in ctype or ".m3u8" in r_url.lower() or ".mpd" in r_url.lower():
                    try:
                        body = await resp.text()
                        if DRM_RE.search(body):
                            drm_detected = True
                            return
                    except Exception:
                        pass

                is_media = (
                    MEDIA_EXT_RE.search(r_url)
                    or ctype.startswith("video/")
                    or ctype.startswith("audio/")
                    or "mpegurl" in ctype
                    or "dash+xml" in ctype
                )
                if is_media and r_url.startswith("http") and r_url not in seen:
                    seen.add(r_url)
                    cookies = "; ".join(f"{c['name']}={c['value']}" for c in await context.cookies())
                    hdrs = req_headers_map.get(r_url) or {k.lower(): v for k, v in resp.request.headers.items()}
                    origin = hdrs.get("origin") or (f"{page.url.split('/')[0]}//{page.url.split('/')[2]}" if "//" in page.url else "")
                    captured.append({
                        "url": r_url,
                        "quality": "HLS (.m3u8)" if ".m3u8" in r_url.lower() else "DASH (.mpd)" if ".mpd" in r_url.lower() else "Sniffed Stream",
                        "mime": ctype.split(";")[0] or ("application/x-mpegURL" if ".m3u8" in r_url.lower() else "video/mp4"),
                        "is_hls": ".m3u8" in r_url.lower() or "mpegurl" in ctype,
                        "is_dash": ".mpd" in r_url.lower() or "dash+xml" in ctype,
                        "has_video": not ctype.startswith("audio/"),
                        "has_audio": True,
                        "headers": {
                            "Referer": hdrs.get("referer") or page.url or url,
                            "Origin": origin,
                            "User-Agent": hdrs.get("user-agent") or default_ua,
                            "Cookie": cookies,
                        },
                        "engine": "Playwright-Stealth",
                    })

            page.on("request", on_request)
            page.on("response", lambda r: asyncio.create_task(on_response(r)))

            await page.goto(url, wait_until="domcontentloaded", timeout=timeout_sec * 1000)
            await page.wait_for_timeout(2500)
            page_title = (await page.title()) or page_title

            for sel in COOKIE_BANNER_SELECTORS:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() > 0 and await loc.is_visible():
                        await loc.click(timeout=900)
                except Exception:
                    pass

            async def click_players_in_frame(frame):
                for sel in PLAY_TRIGGER_SELECTORS:
                    try:
                        loc = frame.locator(sel).first
                        if await loc.count() > 0:
                            await loc.click(timeout=1200)
                            await page.wait_for_timeout(1200)
                    except Exception:
                        pass

            await click_players_in_frame(page.main_frame)
            for child in page.frames:
                if child != page.main_frame:
                    await click_players_in_frame(child)

            await page.wait_for_timeout(3000)
        finally:
            await browser.close()

    return {"title": page_title, "streams": captured, "drm_detected": drm_detected}
"""

  private const val ENGINES_PY = """import asyncio
import json
from typing import Dict, Any, List
from sniffer import sniff_with_playwright
from updater import emergency_update_ytdlp

BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

async def _run_ytdlp_json(url: str, use_impersonate: bool) -> Dict[str, Any]:
    cmd = ["yt-dlp", "--dump-single-json", "--no-warnings", "--ignore-config", "--user-agent", BROWSER_UA]
    if use_impersonate:
        cmd.extend(["--impersonate", "chrome"])
    cmd.append(url)
    proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0 or not stdout:
        raise RuntimeError(stderr.decode(errors="ignore")[:320] or "yt-dlp extraction failed")
    return json.loads(stdout.decode(errors="ignore"))

async def resolve_tier1_ytdlp(url: str) -> Dict[str, Any]:
    try:
        try:
            info = await _run_ytdlp_json(url, use_impersonate=True)
        except Exception as imp_err:
            if "impersonate" in str(imp_err).lower():
                info = await _run_ytdlp_json(url, use_impersonate=False)
            else:
                raise
    except Exception as first_err:
        err_l = str(first_err).lower()
        if any(k in err_l for k in ("extractor", "http error", "unable to extract", "signature", "403")):
            if await emergency_update_ytdlp():
                info = await _run_ytdlp_json(url, use_impersonate=False)
            else:
                raise
        else:
            raise

    if info.get("_has_drm") or any(f.get("has_drm") for f in info.get("formats", [])):
        raise ValueError("DRM_PROTECTED: Hardware-encrypted stream (DRM) cannot be downloaded.")

    streams: List[Dict[str, Any]] = []
    for fmt in reversed(info.get("formats", [])):
        furl = fmt.get("url")
        if not furl or fmt.get("has_drm"):
            continue
        vcodec = fmt.get("vcodec", "none")
        acodec = fmt.get("acodec", "none")
        res = fmt.get("format_note") or (f"{fmt.get('height')}p" if fmt.get("height") else fmt.get("ext", "stream"))
        req_hdrs = fmt.get("http_headers") or {}
        streams.append({
            "url": furl,
            "quality": f"{res} ({fmt.get('ext', 'mp4')})",
            "mime": f"video/{fmt.get('ext', 'mp4')}" if vcodec != "none" else f"audio/{fmt.get('ext', 'm4a')}",
            "has_video": vcodec != "none",
            "has_audio": acodec != "none",
            "is_hls": "m3u8" in (fmt.get("protocol") or ""),
            "is_dash": "dash" in (fmt.get("protocol") or ""),
            "size": fmt.get("filesize") or fmt.get("filesize_approx") or -1,
            "headers": {
                "Referer": req_hdrs.get("Referer", ""),
                "User-Agent": req_hdrs.get("User-Agent", BROWSER_UA),
                "Cookie": req_hdrs.get("Cookie", ""),
            },
            "engine": "yt-dlp",
        })
    return {"title": info.get("title") or "Video", "streams": streams[:24], "engine": "yt-dlp"}

async def resolve_tier2_gallery_dl(url: str) -> Dict[str, Any]:
    proc = await asyncio.create_subprocess_exec(
        "gallery-dl", "--dump-json", "--range", "1-12", url,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0 or not stdout:
        raise RuntimeError(stderr.decode(errors="ignore")[:250] or "gallery-dl failed")
    streams = []
    for line in stdout.decode(errors="ignore").splitlines():
        if "\"http" in line:
            try:
                item = json.loads(line)
                media_url = item[1] if isinstance(item, list) and len(item) > 1 and isinstance(item[1], str) else None
                if media_url and media_url.startswith("http"):
                    streams.append({
                        "url": media_url,
                        "quality": "Original Media",
                        "mime": "video/mp4" if ".mp4" in media_url.lower() else "application/octet-stream",
                        "has_video": True,
                        "has_audio": True,
                        "engine": "gallery-dl",
                    })
            except Exception:
                continue
    if not streams:
        raise RuntimeError("gallery-dl returned no direct media")
    return {"title": "Gallery Media", "streams": streams, "engine": "gallery-dl"}

async def resolve_tier3_streamlink(url: str) -> Dict[str, Any]:
    proc = await asyncio.create_subprocess_exec(
        "streamlink", "--json", url,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    stdout, _ = await proc.communicate()
    if proc.returncode != 0 or not stdout:
        raise RuntimeError("streamlink failed")
    data = json.loads(stdout.decode(errors="ignore"))
    streams = []
    for name, st in (data.get("streams") or {}).items():
        if st.get("url"):
            streams.append({
                "url": st["url"],
                "quality": name,
                "mime": "application/x-mpegURL",
                "is_hls": True,
                "has_video": True,
                "has_audio": True,
                "headers": st.get("headers") or {},
                "engine": "streamlink",
            })
    if not streams:
        raise RuntimeError("streamlink found no streams")
    return {"title": data.get("metadata", {}).get("title") or "Live Stream", "streams": streams, "engine": "streamlink"}

async def resolve_universal(url: str) -> Dict[str, Any]:
    errors = []
    for label, fn in [("yt-dlp", resolve_tier1_ytdlp), ("gallery-dl", resolve_tier2_gallery_dl), ("streamlink", resolve_tier3_streamlink)]:
        try:
            res = await fn(url)
            if res.get("streams"):
                return res
        except ValueError as drm_err:
            return {"title": "Protected Content", "streams": [], "drm_detected": True, "error": str(drm_err)}
        except Exception as exc:
            errors.append(f"{label}: {exc}")

    sniff = await sniff_with_playwright(url)
    if sniff.get("drm_detected"):
        return {"title": sniff.get("title", "DRM Protected"), "streams": [], "drm_detected": True, "error": "DRM hardware encryption detected; download aborted."}
    if sniff.get("streams"):
        return {"title": sniff.get("title", "Sniffed Media"), "streams": sniff["streams"], "engine": "Playwright-Stealth"}
    return {"title": "Unresolved", "streams": [], "error": " | ".join(errors)}
"""

  private const val DOWNLOADER_PY = """import asyncio
import os
import uuid
import yt_dlp
from pathlib import Path
from typing import Dict, Any, Callable, Awaitable, List
from sniffer import sniff_with_playwright
from updater import emergency_update_ytdlp

DOWNLOAD_DIR = Path(__file__).parent / "downloads"
DOWNLOAD_DIR.mkdir(exist_ok=True)

def _format_ffmpeg_headers(headers: Dict[str, str]) -> str:
    lines: List[str] = []
    for k in ("Referer", "Origin", "User-Agent", "Cookie"):
        val = (headers.get(k) or "").strip()
        if val:
            lines.append(f"{k}: {val}")
    return "\\r\\n".join(lines) + ("\\r\\n" if lines else "")

class DownloadTaskManager:
    def __init__(self, broadcast_fn: Callable[[Dict[str, Any]], Awaitable[None]]):
        self.tasks: Dict[str, Dict[str, Any]] = {}
        self.broadcast = broadcast_fn

    async def start_download(self, url: str, quality: str = "best", audio_only: bool = False) -> str:
        task_id = uuid.uuid4().hex[:10]
        self.tasks[task_id] = {
            "id": task_id,
            "url": url,
            "status": "QUEUED",
            "percent": 0.0,
            "speed": "",
            "eta": "",
            "filename": "",
            "engine": "yt-dlp",
            "error": None,
        }
        await self.broadcast(self.tasks[task_id])
        asyncio.create_task(self._run_with_failover(task_id, url, quality, audio_only))
        return task_id

    async def _run_with_failover(self, task_id: str, url: str, quality: str, audio_only: bool):
        loop = asyncio.get_running_loop()
        task = self.tasks[task_id]
        task["status"] = "DOWNLOADING"
        await self.broadcast(task)

        def hook(d):
            if d["status"] == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate") or 1
                done = d.get("downloaded_bytes", 0)
                task["percent"] = round((done / max(total, 1)) * 100, 1)
                task["speed"] = d.get("_speed_str", "").strip()
                task["eta"] = d.get("_eta_str", "").strip()
                task["filename"] = os.path.basename(d.get("filename", ""))
                asyncio.run_coroutine_threadsafe(self.broadcast(dict(task)), loop)
            elif d["status"] == "finished":
                task["percent"] = 100.0
                task["filename"] = os.path.basename(d.get("filename", ""))

        fmt = "bestaudio/best" if audio_only else (
            f"bestvideo[height<={quality.replace('p','')}]+bestaudio/best" if quality.endswith("p") else "bestvideo+bestaudio/best"
        )
        ydl_opts = {
            "format": fmt,
            "outtmpl": str(DOWNLOAD_DIR / "%(title).120s.%(ext)s"),
            "merge_output_format": "mp4" if not audio_only else "mp3",
            "progress_hooks": [hook],
            "quiet": True,
            "noplaylist": False,
        }
        if audio_only:
            ydl_opts["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}]

        try:
            await asyncio.to_thread(lambda: yt_dlp.YoutubeDL(ydl_opts).download([url]))
            task["status"] = "COMPLETED"
            task["percent"] = 100.0
            await self.broadcast(task)
            return
        except Exception as err:
            msg = str(err)
            if "DRM" in msg.upper():
                task["status"] = "FAILED"
                task["error"] = "DRM-protected content cannot be downloaded."
                await self.broadcast(task)
                return

            if any(code in msg for code in ("403", "401", "HTTP Error")):
                await emergency_update_ytdlp()

            for attempt in range(2):
                task["engine"] = "Playwright-Stealth" if attempt == 0 else "Playwright Token Refresh"
                await self.broadcast(task)
                sniffed = await sniff_with_playwright(url)
                if sniffed.get("drm_detected"):
                    task["status"] = "FAILED"
                    task["error"] = "DRM manifest detected and aborted."
                    await self.broadcast(task)
                    return
                streams = sniffed.get("streams") or []
                if not streams:
                    break
                chosen = streams[0]
                direct = chosen["url"]
                hdr_str = _format_ffmpeg_headers(chosen.get("headers") or {})
                out_path = str(DOWNLOAD_DIR / f"sniffed_{task_id}.mp4")
                ff_cmd = ["ffmpeg", "-y"]
                if hdr_str:
                    ff_cmd.extend(["-headers", hdr_str])
                ff_cmd.extend(["-i", direct, "-c", "copy", "-movflags", "+faststart", out_path])
                proc = await asyncio.create_subprocess_exec(
                    *ff_cmd, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE
                )
                _, ferr = await proc.communicate()
                if proc.returncode == 0:
                    task["status"] = "COMPLETED"
                    task["percent"] = 100.0
                    task["filename"] = os.path.basename(out_path)
                    await self.broadcast(task)
                    return
                ferr_text = ferr.decode(errors="ignore")
                if ("401" in ferr_text or "403" in ferr_text) and attempt == 0:
                    continue
                task["error"] = ferr_text[-220:]
                break

            if not task.get("error"):
                task["error"] = msg[:240]
            task["status"] = "FAILED"
            await self.broadcast(task)
"""

  private const val MAIN_PY = """import asyncio
import aiohttp
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Request, Query
from fastapi.responses import HTMLResponse, FileResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from updater import upgrade_all_engines_sync
from engines import resolve_universal
from downloader import DownloadTaskManager, DOWNLOAD_DIR

ws_clients: List[WebSocket] = []

async def broadcast_progress(payload: dict):
    stale = []
    for ws in ws_clients:
        try:
            await ws.send_json(payload)
        except Exception:
            stale.append(ws)
    for ws in stale:
        if ws in ws_clients:
            ws_clients.remove(ws)

manager = DownloadTaskManager(broadcast_progress)

@asynccontextmanager
async def lifespan(app: FastAPI):
    asyncio.create_task(asyncio.to_thread(upgrade_all_engines_sync))
    yield

app = FastAPI(title="Vortex Universal Media Engine", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class ResolveReq(BaseModel):
    url: str

class DownloadReq(BaseModel):
    url: str
    quality: str = "best"
    audio_only: bool = False

@app.get("/", response_class=HTMLResponse)
async def home():
    return (Path(__file__).parent / "static" / "index.html").read_text(encoding="utf-8")

@app.post("/api/resolve")
async def api_resolve(req: ResolveReq):
    return await resolve_universal(req.url.strip())

@app.post("/api/download")
async def api_download(req: DownloadReq):
    tid = await manager.start_download(req.url.strip(), req.quality, req.audio_only)
    return {"task_id": tid}

@app.get("/api/tasks")
async def api_tasks():
    return list(manager.tasks.values())

@app.get("/api/stream")
async def api_stream(request: Request, url: str = Query(...), referer: str = Query(""), ua: str = Query("")):
    \"\"\"Range-aware live stream proxy forwarding captured headers so mobile/TV players never hit 403.\"\"\"
    req_headers = {}
    if "range" in request.headers:
        req_headers["Range"] = request.headers["range"]
    if referer:
        req_headers["Referer"] = referer
    req_headers["User-Agent"] = ua or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36"

    session = aiohttp.ClientSession()
    resp = await session.get(url, headers=req_headers)
    passthrough = {k: v for k, v in resp.headers.items() if k.lower() in ("content-type", "content-length", "content-range", "accept-ranges")}

    async def iter_chunks():
        try:
            async for chunk in resp.content.iter_chunked(65536):
                yield chunk
        finally:
            resp.close()
            await session.close()

    return StreamingResponse(iter_chunks(), status_code=resp.status, headers=passthrough)

@app.get("/api/files/{filename}")
async def api_file(filename: str):
    path = (DOWNLOAD_DIR / filename).resolve()
    if not path.is_file() or path.parent != DOWNLOAD_DIR.resolve():
        raise HTTPException(404, "File not found")
    return FileResponse(path, filename=path.name)

@app.websocket("/ws/progress")
async def ws_progress(websocket: WebSocket):
    await websocket.accept()
    ws_clients.append(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        if websocket in ws_clients:
            ws_clients.remove(websocket)
"""

  private const val INDEX_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Vortex Universal Media Downloader & Streamer</title>
<style>
body{margin:0;font-family:system-ui,-apple-system,sans-serif;background:#0d1117;color:#e6edf3;padding:24px}
.wrap{max-width:860px;margin:0 auto}.card{background:#161b22;border:1px solid #30363d;border-radius:14px;padding:18px;margin-bottom:16px}
input,select,button{padding:11px 14px;border-radius:10px;border:1px solid #30363d;background:#0d1117;color:#e6edf3;font-size:14px}
button{background:#238636;border:none;font-weight:600;cursor:pointer}button:hover{filter:brightness(1.1)}
.btn2{background:#1f6feb}.row{display:flex;gap:10px;flex-wrap:wrap;margin-top:10px}
.bar{height:8px;background:#30363d;border-radius:99px;overflow:hidden;margin-top:8px}.fill{height:100%;background:#58a6ff;transition:width .25s}
.badge{display:inline-block;padding:3px 9px;border-radius:99px;background:#1f6feb33;color:#58a6ff;font-size:12px}
.err{color:#f85149;background:#f8514920;padding:10px;border-radius:8px;margin-top:8px}
video{width:100%;max-height:360px;border-radius:12px;background:#000;margin-top:12px;display:none}
</style></head><body><div class="wrap">
<h2>Vortex 4-Tier Media Engine</h2>
<div class="card">
  <div class="row"><input id="url" style="flex:1" placeholder="Paste any video URL (YouTube, TikTok, IG, X, Web)...">
  <select id="q"><option value="best">Best Quality (MP4)</option><option value="1080p">1080p</option><option value="720p">720p</option><option value="audio">Audio MP3</option></select>
  <button class="btn2" onclick="resolveUrl()">Inspect &amp; Stream</button>
  <button onclick="startDownload()">Download MP4</button></div>
  <div id="status" style="margin-top:10px"></div>
  <video id="player" controls playsinline></video>
</div>
<div id="tasks"></div></div>
<script>
const tasks={};
const wsProto=location.protocol==='https:'?'wss':'ws';
const ws=new WebSocket(`${'$'}{wsProto}://${'$'}{location.host}/ws/progress`);
ws.onmessage=e=>{const t=JSON.parse(e.data);tasks[t.id]=t;render();};
async function resolveUrl(){
  const u=document.getElementById('url').value.trim();if(!u)return;
  document.getElementById('status').innerText='Running 4-tier cascade (yt-dlp -> gallery-dl -> streamlink -> Playwright Stealth)...';
  const r=await fetch('/api/resolve',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:u})});
  const d=await r.json();
  if(d.drm_detected){document.getElementById('status').innerHTML=`<div class="err">${'$'}{d.error}</div>`;return;}
  const first=(d.streams||[])[0];
  const vid=document.getElementById('player');
  if(first){
    const ref=(first.headers&&first.headers.Referer)||'';
    vid.style.display='block';
    vid.src=`/api/stream?url=${'$'}{encodeURIComponent(first.url)}&referer=${'$'}{encodeURIComponent(ref)}`;
  }
  document.getElementById('status').innerHTML=`<span class="badge">${'$'}{d.engine||'Engine'}</span> <b>${'$'}{d.title}</b> (${'$'}{(d.streams||[]).length} streams)`;
}
async function startDownload(){
  const u=document.getElementById('url').value.trim();if(!u)return;
  const q=document.getElementById('q').value;
  await fetch('/api/download',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:u,quality:q,audio_only:q==='audio'})});
}
function render(){
  document.getElementById('tasks').innerHTML=Object.values(tasks).reverse().map(t=>`<div class="card">
  <div><b>${'$'}{t.filename||t.url}</b> <span class="badge">${'$'}{t.engine}</span> <span>${'$'}{t.status} (${'$'}{t.percent}%) ${'$'}{t.speed||''}</span></div>
  <div class="bar"><div class="fill" style="width:${'$'}{t.percent}%"></div></div>
  ${'$'}{t.status==='COMPLETED'&&t.filename?`<p><a style="color:#58a6ff" href="/api/files/${'$'}{encodeURIComponent(t.filename)}">Download ${'$'}{t.filename}</a></p>`:''}
  ${'$'}{t.error?`<div class="err">${'$'}{t.error}</div>`:''}</div>`).join('');
}
</script></body></html>
"""

  private const val README_TXT = """VORTEX UNIVERSAL MEDIA DOWNLOADER (PYTHON FASTAPI BACKEND)
==========================================================

1. Create & activate Python 3.11+ virtual environment:
   python3 -m venv .venv
   source .venv/bin/activate   # On Windows: .venv\\Scripts\\activate

2. Install dependencies:
   pip install -r requirements.txt

3. Install Playwright Chromium binary (required for Tier 4 headless sniffer):
   playwright install chromium

4. Verify FFmpeg is installed:
   ffmpeg -version
   # Ubuntu/Debian: sudo apt install -y ffmpeg
   # macOS: brew install ffmpeg
   # Windows: winget install Gyan.FFmpeg

5. Launch server:
   uvicorn main:app --host 0.0.0.0 --port 8787

6. Connect Vortex Files (Android):
   - Web UI: Open http://<YOUR_LAN_IP>:8787 in any browser
   - Android App: Settings -> Companion FastAPI Server URL -> http://<YOUR_LAN_IP>:8787
"""
}
