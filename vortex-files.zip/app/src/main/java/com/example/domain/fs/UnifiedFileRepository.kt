package com.example.domain.fs

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.system.Os
import com.example.data.prefs.SortField
import com.example.domain.archive.ArchiveEngine
import com.example.domain.cloud.CloudStorageClient
import com.example.shizuku.RootShellManager
import com.example.shizuku.ShizukuManager
import com.example.shizuku.ShizukuStatus
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

data class FileHashes(val md5: String, val sha1: String, val sha256: String)

data class SearchHit(val node: VirtualFileNode, val matchedLine: String? = null)

data class DiffResult(
  val identical: Boolean,
  val summary: String,
  val onlyInLeft: List<String> = emptyList(),
  val onlyInRight: List<String> = emptyList(),
  val differentContent: List<String> = emptyList(),
)

class UnifiedFileRepository(
  private val context: Context,
  private val shizukuManager: ShizukuManager,
  private val rootShellManager: RootShellManager,
  private val safHelper: SafFileHelper,
  val archiveEngine: ArchiveEngine,
  val cloudClient: CloudStorageClient? = null,
) {
  fun hasAllFilesPermission(): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      runCatching { Environment.isExternalStorageManager() }.getOrDefault(false)
    } else {
      true
    }

  fun internalStorageRoot(): String = Environment.getExternalStorageDirectory().absolutePath

  fun appWorkspaceDir(): File = File(context.filesDir, "workspace").apply { mkdirs() }

  fun downloadsDir(): String =
    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath

  suspend fun listDirectory(
    path: String,
    showHidden: Boolean,
    sortField: SortField,
    sortAscending: Boolean,
    useRoot: Boolean,
  ): List<VirtualFileNode> =
    withContext(Dispatchers.IO) {
      val archiveParsed = ArchiveEngine.parseArchiveUri(path)
      if (archiveParsed != null) {
        val (arcPath, subPath) = archiveParsed
        val entries = archiveEngine.listEntriesAtPath(File(arcPath), subPath)
        return@withContext sortAndFilter(entries, showHidden, sortField, sortAscending)
      }

      if (path.startsWith("cloud://") && cloudClient != null) {
        val nodes = runCatching { cloudClient.listDirectoryUri(path) }.getOrDefault(emptyList())
        return@withContext sortAndFilter(nodes, showHidden, sortField, sortAscending)
      }

      if (path.startsWith("content://")) {
        val nodes = safHelper.listDocumentUri(Uri.parse(path))
        return@withContext sortAndFilter(nodes, showHidden, sortField, sortAscending)
      }

      val localDir = File(path)
      val localFiles = localDir.listFiles()
      val nodes: List<VirtualFileNode> =
        when {
          localFiles != null ->
            localFiles.map { file ->
              VirtualFileNode(
                name = file.name,
                path = file.absolutePath,
                isDirectory = file.isDirectory,
                size = if (file.isDirectory) 0L else file.length(),
                lastModified = file.lastModified(),
                permissions = readLocalPerms(file),
                sourceType = FileSourceType.LOCAL,
              )
            }

          shizukuManager.status.value == ShizukuStatus.CONNECTED &&
            shizukuManager.getService() != null -> {
            val svc = shizukuManager.getService()!!
            val json = svc.listFilesJson(path)
            parseJsonNodes(json, FileSourceType.SHIZUKU)
          }

          useRoot -> listViaRoot(path)

          else -> emptyList()
        }

      sortAndFilter(nodes, showHidden, sortField, sortAscending)
    }

  private fun parseJsonNodes(json: String, sourceType: FileSourceType): List<VirtualFileNode> {
    val array = JSONArray(json)
    val list = ArrayList<VirtualFileNode>(array.length())
    for (i in 0 until array.length()) {
      val obj = array.getJSONObject(i)
      list.add(
        VirtualFileNode(
          name = obj.getString("name"),
          path = obj.getString("path"),
          isDirectory = obj.getBoolean("isDirectory"),
          size = obj.getLong("size"),
          lastModified = obj.getLong("lastModified"),
          permissions = obj.optString("permissions", "----------"),
          isHidden = obj.optBoolean("isHidden", false),
          sourceType = sourceType,
        )
      )
    }
    return list
  }

  private suspend fun listViaRoot(path: String): List<VirtualFileNode> {
    val safePath = path.replace("\"", "\\\"")
    val res = rootShellManager.execRoot("ls -la \"$safePath\"")
    if (!res.success || res.output.isBlank()) return emptyList()
    val result = mutableListOf<VirtualFileNode>()
    for (line in res.output.lines()) {
      val trimmed = line.trim()
      if (trimmed.isEmpty() || trimmed.startsWith("total ")) continue
      val parts = trimmed.split(Regex("\\s+"), limit = 8)
      if (parts.size < 8) continue
      val perms = parts[0]
      val name = parts.last().substringBefore(" -> ")
      if (name == "." || name == "..") continue
      val isDir = perms.startsWith("d")
      val size = parts.getOrNull(4)?.toLongOrNull() ?: 0L
      val fullPath = if (path == "/") "/$name" else "${path.trimEnd('/')}/$name"
      result.add(
        VirtualFileNode(
          name = name,
          path = fullPath,
          isDirectory = isDir,
          size = if (isDir) 0L else size,
          lastModified = System.currentTimeMillis(),
          permissions = perms,
          sourceType = FileSourceType.ROOT,
        )
      )
    }
    return result
  }

  private fun readLocalPerms(file: File): String {
    return try {
      val st = Os.lstat(file.absolutePath)
      val mode = st.st_mode
      val sb = StringBuilder().append(if (file.isDirectory) 'd' else '-')
      val masks = intArrayOf(0x100, 0x080, 0x040, 0x020, 0x010, 0x008, 0x004, 0x002, 0x001)
      val chars = charArrayOf('r', 'w', 'x', 'r', 'w', 'x', 'r', 'w', 'x')
      for (i in masks.indices) sb.append(if ((mode and masks[i]) != 0) chars[i] else '-')
      sb.toString()
    } catch (_: Throwable) {
      val r = if (file.canRead()) 'r' else '-'
      val w = if (file.canWrite()) 'w' else '-'
      val x = if (file.canExecute()) 'x' else '-'
      "${if (file.isDirectory) 'd' else '-'}$r$w$x------"
    }
  }

  private fun sortAndFilter(
    items: List<VirtualFileNode>,
    showHidden: Boolean,
    sortField: SortField,
    ascending: Boolean,
  ): List<VirtualFileNode> {
    val filtered = if (showHidden) items else items.filter { !it.isHidden }
    val comparator =
      when (sortField) {
        SortField.NAME -> compareBy<VirtualFileNode> { it.name.lowercase() }
        SortField.SIZE -> compareBy<VirtualFileNode> { it.size }.thenBy { it.name.lowercase() }
        SortField.DATE -> compareBy<VirtualFileNode> { it.lastModified }.thenBy { it.name.lowercase() }
        SortField.TYPE -> compareBy<VirtualFileNode> { it.extension }.thenBy { it.name.lowercase() }
      }
    val dirs = filtered.filter { it.isDirectory }.sortedWith(if (ascending) comparator else comparator.reversed())
    val files = filtered.filter { !it.isDirectory }.sortedWith(if (ascending) comparator else comparator.reversed())
    return dirs + files
  }

  suspend fun readFileBytes(node: VirtualFileNode, maxBytes: Int = 8 * 1024 * 1024): ByteArray =
    withContext(Dispatchers.IO) {
      val arcParsed = ArchiveEngine.parseArchiveUri(node.path)
      if (arcParsed != null) {
        return@withContext archiveEngine.extractEntryBytes(File(arcParsed.first), arcParsed.second)
      }
      if (node.path.startsWith("cloud://") && cloudClient != null) {
        return@withContext runCatching { cloudClient.readFileBytes(node.path) }.getOrDefault(ByteArray(0))
      }
      if (node.path.startsWith("content://")) {
        return@withContext safHelper.openInputStream(Uri.parse(node.path))?.use { it.readBytes() }
          ?: ByteArray(0)
      }
      val file = File(node.path)
      if (file.canRead()) {
        val len = file.length().coerceAtMost(maxBytes.toLong()).toInt()
        val buf = ByteArray(len)
        FileInputStream(file).use { fis ->
          var off = 0
          while (off < len) {
            val r = fis.read(buf, off, len - off)
            if (r <= 0) break
            off += r
          }
        }
        return@withContext buf
      }
      val shizukuSvc = shizukuManager.getService()
      if (shizukuSvc != null && shizukuManager.status.value == ShizukuStatus.CONNECTED) {
        val size = shizukuSvc.getFileSize(node.path).coerceAtMost(maxBytes.toLong()).toInt()
        val out = ByteArray(size)
        var offset = 0
        val chunk = 256 * 1024
        while (offset < size) {
          val slice = shizukuSvc.readFileSlice(node.path, offset.toLong(), minOf(chunk, size - offset))
          if (slice.isEmpty()) break
          System.arraycopy(slice, 0, out, offset, slice.size)
          offset += slice.size
        }
        return@withContext out
      }
      if (rootShellManager.isRootAvailable.value) {
        val tmp = File(context.cacheDir, "root_read_${System.currentTimeMillis()}.tmp")
        rootShellManager.execRoot("cp \"${node.path}\" \"${tmp.absolutePath}\" && chmod 644 \"${tmp.absolutePath}\"")
        if (tmp.exists()) {
          val bytes = tmp.readBytes()
          tmp.delete()
          return@withContext bytes
        }
      }
      ByteArray(0)
    }

  suspend fun writeFileBytes(path: String, bytes: ByteArray, useRoot: Boolean): Boolean =
    withContext(Dispatchers.IO) {
      val arcParsed = ArchiveEngine.parseArchiveUri(path)
      if (arcParsed != null) {
        return@withContext archiveEngine.replaceEntryInZip(
          File(arcParsed.first),
          arcParsed.second,
          bytes,
        )
      }
      if (path.startsWith("cloud://") && cloudClient != null) {
        return@withContext runCatching { cloudClient.writeFileBytes(path, bytes) }.getOrDefault(false)
      }
      if (path.startsWith("content://")) {
        return@withContext safHelper.openOutputStream(Uri.parse(path))?.use {
          it.write(bytes)
          true
        } ?: false
      }
      val file = File(path)
      try {
        file.parentFile?.mkdirs()
        FileOutputStream(file).use { it.write(bytes) }
        return@withContext true
      } catch (_: Throwable) {}

      val shizukuSvc = shizukuManager.getService()
      if (shizukuSvc != null && shizukuManager.status.value == ShizukuStatus.CONNECTED) {
        val chunk = 256 * 1024
        var off = 0
        while (off < bytes.size) {
          val end = minOf(bytes.size, off + chunk)
          val ok = shizukuSvc.writeFileBytes(path, bytes.copyOfRange(off, end), off > 0)
          if (!ok) return@withContext false
          off = end
        }
        if (bytes.isEmpty()) return@withContext shizukuSvc.writeFileBytes(path, bytes, false)
        return@withContext true
      }
      if (useRoot) {
        val tmp = File(context.cacheDir, "root_write_${System.currentTimeMillis()}.tmp")
        tmp.writeBytes(bytes)
        val res = rootShellManager.execRoot("cp \"${tmp.absolutePath}\" \"$path\"")
        tmp.delete()
        return@withContext res.success
      }
      false
    }

  suspend fun createDirectory(parentPath: String, name: String, useRoot: Boolean): Boolean =
    withContext(Dispatchers.IO) {
      if (parentPath.startsWith("cloud://") && cloudClient != null) {
        return@withContext runCatching { cloudClient.createDirectory(parentPath, name) }.getOrDefault(false)
      }
      val full = "${parentPath.trimEnd('/')}/$name"
      if (File(full).mkdirs()) return@withContext true
      val svc = shizukuManager.getService()
      if (svc != null && shizukuManager.status.value == ShizukuStatus.CONNECTED) {
        if (svc.mkdirs(full)) return@withContext true
      }
      if (useRoot) return@withContext rootShellManager.execRoot("mkdir -p \"$full\"").success
      false
    }

  suspend fun createFile(parentPath: String, name: String, useRoot: Boolean): Boolean =
    writeFileBytes("${parentPath.trimEnd('/')}/$name", ByteArray(0), useRoot)

  fun targetExists(parentPath: String, name: String): Boolean {
    if (parentPath.startsWith("cloud://") || parentPath.startsWith("content://")) return false
    return File(parentPath.trimEnd('/'), name).exists()
  }

  suspend fun rename(node: VirtualFileNode, newName: String, useRoot: Boolean): Boolean =
    withContext(Dispatchers.IO) {
      if (node.path.startsWith("cloud://") && cloudClient != null) {
        return@withContext runCatching { cloudClient.renameUri(node.path, newName) }.getOrDefault(false)
      }
      val parent = File(node.path).parent ?: return@withContext false
      val newPath = "$parent/$newName"
      if (File(node.path).renameTo(File(newPath))) return@withContext true
      val svc = shizukuManager.getService()
      if (svc != null && shizukuManager.status.value == ShizukuStatus.CONNECTED) {
        if (svc.renamePath(node.path, newPath)) return@withContext true
      }
      if (useRoot) return@withContext rootShellManager.execRoot("mv \"${node.path}\" \"$newPath\"").success
      false
    }

  suspend fun deleteNodes(nodes: List<VirtualFileNode>, useRoot: Boolean): Int =
    withContext(Dispatchers.IO) {
      var deleted = 0
      for (node in nodes) {
        if (node.path.startsWith("cloud://") && cloudClient != null) {
          if (runCatching { cloudClient.deleteUri(node.path) }.getOrDefault(false)) deleted++
          continue
        }
        val f = File(node.path)
        val ok =
          if (f.exists() && f.deleteRecursively()) true
          else {
            val svc = shizukuManager.getService()
            if (svc != null && shizukuManager.status.value == ShizukuStatus.CONNECTED) {
              svc.deletePath(node.path)
            } else if (useRoot) {
              rootShellManager.execRoot("rm -rf \"${node.path}\"").success
            } else {
              false
            }
          }
        if (ok) deleted++
      }
      deleted
    }

  suspend fun copyOrMove(
    sources: List<VirtualFileNode>,
    targetDir: String,
    isMove: Boolean,
    useRoot: Boolean,
    onProgress: (Int) -> Unit = {},
    onConflict: (suspend (FileConflictInfo) -> ConflictChoice)? = null,
  ): Int =
    withContext(Dispatchers.IO) {
      var count = 0
      var cachedAction: ConflictAction? = null
      val total = sources.size.coerceAtLeast(1)

      suspend fun resolveDestinationFile(
        candidate: File,
        sourceSize: Long,
        sourceModified: Long,
        remainingItems: Int,
      ): File? {
        if (!candidate.exists() || onConflict == null) return candidate
        val action = cachedAction ?: run {
          val info =
            FileConflictInfo(
              fileName = candidate.name,
              destPath = candidate.absolutePath,
              sourceSize = sourceSize,
              existingSize = if (candidate.isFile) candidate.length() else 0L,
              sourceModified = sourceModified,
              existingModified = candidate.lastModified(),
              remainingItems = remainingItems.coerceAtLeast(0),
            )
          val choice = onConflict.invoke(info)
          if (choice.applyToAll) cachedAction = choice.action
          choice.action
        }
        return when (action) {
          ConflictAction.REPLACE -> {
            candidate.deleteRecursively()
            candidate
          }
          ConflictAction.KEEP_BOTH -> nextAvailableNumberedFile(candidate)
          ConflictAction.SKIP -> null
        }
      }

      for ((idx, srcNode) in sources.withIndex()) {
        val remaining = (sources.size - idx - 1).coerceAtLeast(0)
        if (cloudClient != null && (srcNode.path.startsWith("cloud://") || targetDir.startsWith("cloud://"))) {
          val okCloud = runCatching {
            when {
              srcNode.path.startsWith("cloud://") && !targetDir.startsWith("cloud://") -> {
                val rawDest = File(targetDir, srcNode.name)
                val dest = resolveDestinationFile(rawDest, srcNode.size, srcNode.lastModified, remaining)
                if (dest == null) {
                  false
                } else {
                  val ok = cloudClient.downloadToLocal(srcNode.path, dest)
                  if (ok && isMove) cloudClient.deleteUri(srcNode.path)
                  ok
                }
              }
              !srcNode.path.startsWith("cloud://") && targetDir.startsWith("cloud://") -> {
                val srcFile = File(srcNode.path)
                val ok = cloudClient.uploadLocalFile(srcFile, targetDir)
                if (ok && isMove) srcFile.delete()
                ok
              }
              else -> {
                val bytes = cloudClient.readFileBytes(srcNode.path)
                val parsedTarget = CloudStorageClient.parseCloudUri(targetDir)
                if (parsedTarget != null) {
                  val targetUri = CloudStorageClient.buildCloudUri(parsedTarget.first, parsedTarget.second.trimEnd('/') + "/" + srcNode.name)
                  val ok = cloudClient.writeFileBytes(targetUri, bytes)
                  if (ok && isMove) cloudClient.deleteUri(srcNode.path)
                  ok
                } else false
              }
            }
          }.getOrDefault(false)
          if (okCloud) count++
          onProgress(((idx + 1) * 100) / total)
          continue
        }

        val rawDstFile = File(targetDir.trimEnd('/'), srcNode.name)
        val srcFile = File(srcNode.path)
        val resolvedDstFile =
          if (rawDstFile.exists()) {
            resolveDestinationFile(rawDstFile, srcNode.size, srcNode.lastModified, remaining)
          } else {
            rawDstFile
          }

        if (resolvedDstFile == null) {
          onProgress(((idx + 1) * 100) / total)
          continue
        }

        // Guard against moving a file onto itself without renaming
        if (isMove && runCatching { srcFile.canonicalPath == resolvedDstFile.canonicalPath }.getOrDefault(false)) {
          onProgress(((idx + 1) * 100) / total)
          continue
        }

        val dstPath = resolvedDstFile.absolutePath
        val ok =
          try {
            if (srcFile.exists() && srcFile.canRead()) {
              if (isMove && srcFile.renameTo(resolvedDstFile)) {
                true
              } else {
                val copied = srcFile.copyRecursively(resolvedDstFile, overwrite = true)
                if (copied && isMove) srcFile.deleteRecursively()
                copied
              }
            } else {
              false
            }
          } catch (_: Throwable) {
            false
          }

        val finalOk =
          if (ok) true
          else {
            val svc = shizukuManager.getService()
            if (svc != null && shizukuManager.status.value == ShizukuStatus.CONNECTED) {
              val c = svc.copyPath(srcNode.path, dstPath)
              if (c && isMove) svc.deletePath(srcNode.path)
              c
            } else if (useRoot) {
              val cmd = if (isMove) "mv \"${srcNode.path}\" \"$dstPath\"" else "cp -r \"${srcNode.path}\" \"$dstPath\""
              rootShellManager.execRoot(cmd).success
            } else {
              false
            }
          }

        if (finalOk) count++
        onProgress(((idx + 1) * 100) / total)
      }
      count
    }

  suspend fun chmod(path: String, octalMode: String, useRoot: Boolean): Boolean =
    withContext(Dispatchers.IO) {
      try {
        Os.chmod(path, octalMode.toInt(8))
        return@withContext true
      } catch (_: Throwable) {}
      val svc = shizukuManager.getService()
      if (svc != null && shizukuManager.status.value == ShizukuStatus.CONNECTED) {
        if (svc.chmodPath(path, octalMode)) return@withContext true
      }
      if (useRoot) return@withContext rootShellManager.execRoot("chmod $octalMode \"$path\"").success
      false
    }

  suspend fun computeHashes(file: File): FileHashes =
    withContext(Dispatchers.IO) {
      val md5 = MessageDigest.getInstance("MD5")
      val sha1 = MessageDigest.getInstance("SHA-1")
      val sha256 = MessageDigest.getInstance("SHA-256")
      val buf = ByteArray(32768)
      FileInputStream(file).use { fis ->
        while (true) {
          val r = fis.read(buf)
          if (r <= 0) break
          md5.update(buf, 0, r)
          sha1.update(buf, 0, r)
          sha256.update(buf, 0, r)
        }
      }
      FileHashes(
        md5 = md5.digest().joinToString("") { "%02x".format(it) },
        sha1 = sha1.digest().joinToString("") { "%02x".format(it) },
        sha256 = sha256.digest().joinToString("") { "%02x".format(it) },
      )
    }

  suspend fun deepSearch(
    rootPath: String,
    query: String,
    searchContent: Boolean,
    useRegex: Boolean,
    maxResults: Int = 150,
  ): List<SearchHit> =
    withContext(Dispatchers.IO) {
      if (query.isBlank()) return@withContext emptyList()
      val root = File(rootPath)
      if (!root.exists() || !root.canRead()) return@withContext emptyList()
      val regex =
        if (useRegex) runCatching { Regex(query, RegexOption.IGNORE_CASE) }.getOrNull() else null
      val hits = mutableListOf<SearchHit>()

      for (file in root.walkTopDown().maxDepth(7)) {
        if (hits.size >= maxResults) break
        if (file == root) continue
        val nameMatch =
          if (regex != null) regex.containsMatchIn(file.name)
          else file.name.contains(query, ignoreCase = true)

        val node =
          VirtualFileNode(
            name = file.name,
            path = file.absolutePath,
            isDirectory = file.isDirectory,
            size = if (file.isDirectory) 0L else file.length(),
            lastModified = file.lastModified(),
          )

        if (nameMatch) {
          hits.add(SearchHit(node))
        } else if (searchContent && file.isFile && file.length() in 1..2_000_000L && node.category == FileCategory.CODE) {
          val matchedLine =
            runCatching {
              file.useLines { lines ->
                lines.firstOrNull { line ->
                  if (regex != null) regex.containsMatchIn(line)
                  else line.contains(query, ignoreCase = true)
                }
              }
            }.getOrNull()
          if (matchedLine != null) {
            hits.add(SearchHit(node, matchedLine.trim().take(120)))
          }
        }
      }
      hits
    }

  suspend fun compareNodes(left: VirtualFileNode, right: VirtualFileNode): DiffResult =
    withContext(Dispatchers.IO) {
      val f1 = File(left.path)
      val f2 = File(right.path)
      if (f1.isDirectory && f2.isDirectory) {
        val leftMap = f1.listFiles()?.associateBy { it.name } ?: emptyMap()
        val rightMap = f2.listFiles()?.associateBy { it.name } ?: emptyMap()
        val onlyLeft = leftMap.keys.filter { it !in rightMap }.sorted()
        val onlyRight = rightMap.keys.filter { it !in leftMap }.sorted()
        val diff = mutableListOf<String>()
        for (name in leftMap.keys.intersect(rightMap.keys).sorted()) {
          val a = leftMap[name]!!
          val b = rightMap[name]!!
          if (a.isFile && b.isFile && a.length() != b.length()) {
            diff.add("$name (${formatFileSize(a.length())} vs ${formatFileSize(b.length())})")
          }
        }
        val same = onlyLeft.isEmpty() && onlyRight.isEmpty() && diff.isEmpty()
        DiffResult(
          identical = same,
          summary =
            if (same) "Directories match (${leftMap.size} items)"
            else "Left only: ${onlyLeft.size}, Right only: ${onlyRight.size}, Modified: ${diff.size}",
          onlyInLeft = onlyLeft,
          onlyInRight = onlyRight,
          differentContent = diff,
        )
      } else if (f1.isFile && f2.isFile) {
        val h1 = computeHashes(f1)
        val h2 = computeHashes(f2)
        val same = h1.sha256 == h2.sha256
        DiffResult(
          identical = same,
          summary =
            if (same) "Identical SHA-256: ${h1.sha256.take(16)}..."
            else "Files differ (${formatFileSize(f1.length())} vs ${formatFileSize(f2.length())})",
          differentContent =
            if (same) emptyList()
            else listOf("SHA-256 A: ${h1.sha256}", "SHA-256 B: ${h2.sha256}"),
        )
      } else {
        DiffResult(false, "Cannot compare file with directory")
      }
    }
}
