package com.example.domain.download

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Collections
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class AutoWebStreamSniffer(private val appContext: Context) {

  @Volatile
  private var headlessRendererDisabled = false

  private val sniffJs =
    """
    (function() {
      try {
        if (!window.__vortexHooked) {
          window.__vortexHooked = true;
          var origFetch = window.fetch;
          if (origFetch) {
            window.fetch = function() {
              try {
                var u = arguments[0];
                if (typeof u === 'string' && u.indexOf('http') === 0) VortexAutoSniff.onFound(u, document.title || 'Web Video');
                else if (u && u.url) VortexAutoSniff.onFound(u.url, document.title || 'Web Video');
              } catch(e) {}
              return origFetch.apply(this, arguments);
            };
          }
          var origOpen = XMLHttpRequest.prototype.open;
          XMLHttpRequest.prototype.open = function(method, url) {
            try {
              if (typeof url === 'string' && url.indexOf('http') === 0) {
                VortexAutoSniff.onFound(url, document.title || 'Web Video');
              }
            } catch(e) {}
            return origOpen.apply(this, arguments);
          };
        }
        var found = [];
        document.querySelectorAll('video, source, audio').forEach(function(el) {
          if (el.currentSrc) found.push(el.currentSrc);
          if (el.src) found.push(el.src);
        });
        document.querySelectorAll('meta[property="og:video"], meta[property="og:video:url"], meta[property="og:video:secure_url"], meta[name="twitter:player:stream"]').forEach(function(m) {
          if (m.content) found.push(m.content);
        });
        document.querySelectorAll('iframe[src]').forEach(function(f) {
          if (f.src && f.src.indexOf('http') === 0) found.push(f.src);
        });
        if (window.performance && performance.getEntriesByType) {
          performance.getEntriesByType('resource').forEach(function(entry) {
            if (entry.name) found.push(entry.name);
          });
        }
        var title = document.title || 'Web Video';
        found.forEach(function(u) {
          if (u && u.indexOf('http') === 0 && u.indexOf('blob:') !== 0) {
            VortexAutoSniff.onFound(u, title);
          }
        });
      } catch(e) {}
    })();
    """.trimIndent()

  @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
  suspend fun sniffPageStreams(
    pageUrl: String,
    timeoutMs: Long = 8000L,
  ): Pair<String, List<ExtractedMediaStream>> {
    if (headlessRendererDisabled) {
      return "Web Video" to emptyList()
    }
    return withContext(Dispatchers.Main) {
      val collected = Collections.synchronizedList(mutableListOf<ExtractedMediaStream>())
      val seenUrls = Collections.synchronizedSet(hashSetOf<String>())
      var capturedTitle = "Web Video"
      val pageFinishedSignal = CompletableDeferred<Unit>()
      var webView: WebView? = null
      var rendererTerminated = false
      val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())

      fun recordCandidate(rawUrl: String, titleHint: String) {
        if (!looksLikeStream(rawUrl)) return
        val lower = rawUrl.lowercase()
        if (lower.endsWith(".jpg") || lower.endsWith(".png") || lower.endsWith(".webp") || lower.endsWith(".gif") || lower.endsWith(".css") || lower.endsWith(".js")) return
        if (!seenUrls.add(rawUrl)) return
        val cookieHeader = runCatching { CookieManager.getInstance().getCookie(rawUrl) }.getOrNull()
        val isHls = lower.contains(".m3u8") || lower.contains("/manifest/hls")
        val isDash = lower.contains(".mpd")
        val isAudio = lower.contains("mime=audio") || lower.substringBefore('?').endsWith(".m4a") || lower.substringBefore('?').endsWith(".mp3")
        val mime =
          when {
            isHls -> "application/x-mpegURL"
            isDash -> "application/dash+xml"
            isAudio -> "audio/mp4"
            lower.contains("webm") -> "video/webm"
            else -> "video/mp4"
          }
        val label =
          when {
            isHls -> "Auto-Captured HLS (.m3u8)"
            isDash -> "Auto-Captured DASH (.mpd)"
            isAudio -> "Auto-Captured Audio"
            lower.contains("googlevideo.com") -> "Auto-Captured Video Stream"
            else -> "Auto-Captured Video (${rawUrl.substringBefore('?').substringAfterLast('.', "MP4").uppercase()})"
          }
        collected.add(
          ExtractedMediaStream(
            title = titleHint.ifBlank { capturedTitle },
            url = rawUrl,
            qualityLabel = label,
            mimeType = mime,
            isHls = isHls,
            isDash = isDash,
            hasVideo = !isAudio,
            hasAudio = true,
            cookieHeader = cookieHeader,
            refererHeader = pageUrl,
          )
        )
      }

      runCatching {
        val wv = WebView(appContext)
        webView = wv
        wv.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        wv.settings.apply {
          javaScriptEnabled = true
          domStorageEnabled = true
          blockNetworkImage = true
          loadsImagesAutomatically = false
          mediaPlaybackRequiresUserGesture = true
          mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            safeBrowsingEnabled = false
          }
          userAgentString =
            "Mozilla/5.0 (Linux; Android 15; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        wv.addJavascriptInterface(
          object {
            @JavascriptInterface
            fun onFound(url: String, title: String) {
              if (title.isNotBlank()) capturedTitle = title
              recordCandidate(url, title)
            }
          },
          "VortexAutoSniff",
        )
        wv.webViewClient =
          object : WebViewClient() {
            override fun shouldInterceptRequest(
              view: WebView?,
              request: WebResourceRequest?,
            ): WebResourceResponse? {
              val reqUrl = request?.url?.toString().orEmpty()
              if (reqUrl.isNotBlank()) {
                recordCandidate(reqUrl, capturedTitle)
              }
              return null
            }

            override fun onPageFinished(view: WebView?, url: String?) {
              view?.title?.takeIf { it.isNotBlank() }?.let { capturedTitle = it }
              if (!rendererTerminated) {
                view?.evaluateJavascript(sniffJs, null)
              }
              if (!pageFinishedSignal.isCompleted) {
                pageFinishedSignal.complete(Unit)
              }
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
              rendererTerminated = true
              headlessRendererDisabled = true
              if (!pageFinishedSignal.isCompleted) {
                pageFinishedSignal.complete(Unit)
              }
              return true
            }
          }

        wv.loadUrl(pageUrl)
        withTimeoutOrNull(timeoutMs) {
          pageFinishedSignal.await()
          var waited = 0L
          while (waited < 3000L && !rendererTerminated) {
            delay(450L)
            waited += 450L
            runCatching {
              if (!rendererTerminated) wv.evaluateJavascript(sniffJs, null)
            }
            if (collected.any { it.hasVideo && !it.isDash } && waited >= 900L) {
              break
            }
          }
        }
      }

      val toDispose = webView
      webView = null
      if (toDispose != null) {
        mainHandler.post {
          runCatching {
            toDispose.stopLoading()
            toDispose.onPause()
            toDispose.removeJavascriptInterface("VortexAutoSniff")
            toDispose.webViewClient = WebViewClient()
            toDispose.removeAllViews()
            toDispose.destroy()
          }
        }
      }

      val finalList =
        synchronized(collected) {
          collected.sortedWith(
            compareByDescending<ExtractedMediaStream> { it.hasVideo && !it.url.contains("audio", true) }
              .thenByDescending { it.isHls }
              .thenByDescending { it.url.endsWith(".mp4", true) || it.url.contains(".mp4?", true) }
          )
        }
      capturedTitle to finalList
    }
  }

  private fun looksLikeStream(url: String): Boolean {
    val lower = url.lowercase()
    if (lower.startsWith("blob:") || lower.startsWith("data:")) return false
    val path = lower.substringBefore('?')
    return path.endsWith(".mp4") ||
      path.endsWith(".m3u8") ||
      path.endsWith(".mpd") ||
      path.endsWith(".webm") ||
      path.endsWith(".mov") ||
      path.endsWith(".m4a") ||
      path.endsWith(".mp3") ||
      lower.contains("googlevideo.com/videoplayback") ||
      lower.contains("tiktokcdn") && (lower.contains("video") || lower.contains("mime_type=video")) ||
      lower.contains("cdninstagram.com") && lower.contains(".mp4") ||
      lower.contains("fbcdn.net") && lower.contains(".mp4") ||
      lower.contains("video.twimg.com") ||
      lower.contains("mime=video") ||
      lower.contains("mime=audio") ||
      lower.contains("/manifest/hls")
  }
}
