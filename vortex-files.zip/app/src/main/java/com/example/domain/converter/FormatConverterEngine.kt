package com.example.domain.converter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.domain.archive.ArchiveEngine
import com.example.domain.archive.ArchiveFormat
import com.example.domain.archive.CompressionMode
import com.example.domain.archive.ImageOutputFormat
import com.example.domain.archive.MediaCompressionEngine
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class ConversionCategory {
  VIDEO_TO_AUDIO,
  IMAGES_TO_PDF,
  PDF_TO_IMAGES,
  IMAGE_TO_IMAGE,
  TEXT_DATA,
  ARCHIVE_TO_ARCHIVE,
}

enum class AudioTargetFormat(val ext: String, val label: String, val isLossless: Boolean) {
  M4A_AAC("m4a", "M4A / AAC (Universal)", false),
  RAW_AUDIO("m4a", "Direct Audio Stream Copy (Lossless Demux)", true),
}

enum class TextTargetFormat(val ext: String, val label: String) {
  JSON("json", "JSON (Formatted)"),
  XML("xml", "XML"),
  YAML("yaml", "YAML"),
  CSV("csv", "CSV"),
  HTML("html", "HTML"),
  MARKDOWN("md", "Markdown"),
  BASE64("b64.txt", "Base64"),
  HEX("hex.txt", "Hex Dump"),
}

class FormatConverterEngine(
  private val context: Context,
  private val archiveEngine: ArchiveEngine,
  private val mediaCompressionEngine: MediaCompressionEngine,
) {

  @OptIn(UnstableApi::class)
  suspend fun convertVideoToAudio(
    inputVideo: File,
    outputFile: File,
    format: AudioTargetFormat,
    onProgress: (Int) -> Unit = {},
  ): File {
    outputFile.parentFile?.mkdirs()
    if (outputFile.exists()) outputFile.delete()

    if (format == AudioTargetFormat.RAW_AUDIO) {
      val demuxed = tryFastAudioDemux(inputVideo, outputFile, onProgress)
      if (demuxed) return outputFile
    }

    return withContext(Dispatchers.Main) {
      suspendCancellableCoroutine { cont ->
        val mainHandler = Handler(Looper.getMainLooper())
        val listener =
          object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
              onProgress(100)
              if (cont.isActive) cont.resume(outputFile)
            }

            override fun onError(
              composition: Composition,
              exportResult: ExportResult,
              exportException: ExportException,
            ) {
              if (cont.isActive) cont.resumeWithException(exportException)
            }
          }

        val transformer =
          Transformer.Builder(context)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(listener)
            .build()

        val editedItem =
          EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(inputVideo)))
            .setRemoveVideo(true)
            .build()

        transformer.start(editedItem, outputFile.absolutePath)

        val progressHolder = ProgressHolder()
        val poll =
          object : Runnable {
            override fun run() {
              if (!cont.isActive) return
              val state = transformer.getProgress(progressHolder)
              if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                onProgress(progressHolder.progress.coerceIn(0, 99))
              }
              if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                mainHandler.postDelayed(this, 250)
              }
            }
          }
        mainHandler.post(poll)

        cont.invokeOnCancellation {
          mainHandler.post { transformer.cancel() }
        }
      }
    }
  }

  private suspend fun tryFastAudioDemux(
    input: File,
    output: File,
    onProgress: (Int) -> Unit,
  ): Boolean =
    withContext(Dispatchers.IO) {
      val extractor = MediaExtractor()
      var muxer: MediaMuxer? = null
      try {
        extractor.setDataSource(input.absolutePath)
        var audioTrack = -1
        var audioFormat: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
          val fmt = extractor.getTrackFormat(i)
          val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
          if (mime.startsWith("audio/")) {
            audioTrack = i
            audioFormat = fmt
            break
          }
        }
        if (audioTrack < 0 || audioFormat == null) return@withContext false
        extractor.selectTrack(audioTrack)
        muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val outTrack = muxer.addTrack(audioFormat)
        muxer.start()

        val buf = ByteBuffer.allocate(512 * 1024)
        val info = android.media.MediaCodec.BufferInfo()
        val duration =
          if (audioFormat.containsKey(MediaFormat.KEY_DURATION)) {
            audioFormat.getLong(MediaFormat.KEY_DURATION).coerceAtLeast(1L)
          } else {
            1L
          }
        while (true) {
          val size = extractor.readSampleData(buf, 0)
          if (size < 0) break
          info.offset = 0
          info.size = size
          info.presentationTimeUs = extractor.sampleTime
          info.flags =
            if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
              android.media.MediaCodec.BUFFER_FLAG_KEY_FRAME
            } else {
              0
            }
          muxer.writeSampleData(outTrack, buf, info)
          if (duration > 1L) {
            onProgress(((info.presentationTimeUs * 100L) / duration).toInt().coerceIn(0, 99))
          }
          extractor.advance()
        }
        onProgress(100)
        true
      } catch (_: Throwable) {
        output.delete()
        false
      } finally {
        runCatching { muxer?.stop() }
        runCatching { muxer?.release() }
        runCatching { extractor.release() }
      }
    }

  suspend fun imagesToPdf(
    imageFiles: List<File>,
    outputPdf: File,
    a4FixedPage: Boolean = true,
    onProgress: (Int) -> Unit = {},
  ): File =
    withContext(Dispatchers.IO) {
      outputPdf.parentFile?.mkdirs()
      val pdf = PdfDocument()
      val total = imageFiles.size.coerceAtLeast(1)
      var pageNum = 1

      for ((idx, imgFile) in imageFiles.withIndex()) {
        val bmp = BitmapFactory.decodeFile(imgFile.absolutePath) ?: continue
        val pageWidth = if (a4FixedPage) 1240 else bmp.width
        val pageHeight = if (a4FixedPage) 1754 else bmp.height
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum++).create()
        val page = pdf.startPage(pageInfo)
        val canvas = page.canvas
        canvas.drawColor(Color.WHITE)

        if (a4FixedPage) {
          val margin = 40
          val availW = (pageWidth - margin * 2).toFloat()
          val availH = (pageHeight - margin * 2).toFloat()
          val scale = minOf(availW / bmp.width, availH / bmp.height)
          val drawW = (bmp.width * scale).toInt()
          val drawH = (bmp.height * scale).toInt()
          val left = (pageWidth - drawW) / 2
          val top = (pageHeight - drawH) / 2
          canvas.drawBitmap(bmp, null, Rect(left, top, left + drawW, top + drawH), null)
        } else {
          canvas.drawBitmap(bmp, 0f, 0f, null)
        }

        pdf.finishPage(page)
        bmp.recycle()
        onProgress(((idx + 1) * 100) / total)
      }

      FileOutputStream(outputPdf).use { pdf.writeTo(it) }
      pdf.close()
      outputPdf
    }

  suspend fun pdfToImages(
    pdfFile: File,
    outputDir: File,
    format: ImageOutputFormat,
    quality: Int = 92,
    onProgress: (Int) -> Unit = {},
  ): List<File> =
    withContext(Dispatchers.IO) {
      outputDir.mkdirs()
      val results = mutableListOf<File>()
      val pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
      pfd.use { fd ->
        PdfRenderer(fd).use { renderer ->
          val total = renderer.pageCount.coerceAtLeast(1)
          for (i in 0 until renderer.pageCount) {
            renderer.openPage(i).use { page ->
              val w = (page.width * 2).coerceAtLeast(1)
              val h = (page.height * 2).coerceAtLeast(1)
              val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
              bmp.eraseColor(Color.WHITE)
              page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

              val outFile =
                File(outputDir, "${pdfFile.nameWithoutExtension}_page_${i + 1}.${format.ext}")
              FileOutputStream(outFile).use { fos ->
                when (format) {
                  ImageOutputFormat.PNG -> bmp.compress(Bitmap.CompressFormat.PNG, 100, fos)
                  ImageOutputFormat.JPEG -> bmp.compress(Bitmap.CompressFormat.JPEG, quality, fos)
                  ImageOutputFormat.WEBP_LOSSLESS -> {
                    val fmt =
                      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Bitmap.CompressFormat.WEBP_LOSSLESS
                      else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
                    bmp.compress(fmt, 100, fos)
                  }
                  ImageOutputFormat.WEBP_LOSSY -> {
                    val fmt =
                      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Bitmap.CompressFormat.WEBP_LOSSY
                      else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
                    bmp.compress(fmt, quality, fos)
                  }
                  ImageOutputFormat.BMP -> {
                    // Delegate to mediaCompressionEngine via temp PNG if BMP selected
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, fos)
                  }
                }
              }
              bmp.recycle()
              results.add(outFile)
              onProgress(((i + 1) * 100) / total)
            }
          }
        }
      }
      results
    }

  suspend fun convertImages(
    files: List<File>,
    outputDir: File,
    targetFormat: ImageOutputFormat,
    quality: Int,
    onProgress: (Int) -> Unit = {},
  ): List<File> {
    val mode = if (targetFormat.supportsLossless) CompressionMode.LOSSLESS else CompressionMode.LOSSY
    return mediaCompressionEngine
      .compressImages(files, outputDir, mode, quality, 100, targetFormat, onProgress)
      .outputFiles
  }

  suspend fun convertArchive(
    sourceArchive: File,
    outputArchive: File,
    targetFormat: ArchiveFormat,
    level: Int,
    password: String?,
    onProgress: (Int) -> Unit = {},
  ): File =
    withContext(Dispatchers.IO) {
      val tmpDir = File(context.cacheDir, "arc_conv_${System.currentTimeMillis()}")
      try {
        archiveEngine.extractArchive(sourceArchive, tmpDir, password, onProgress = { p -> onProgress(p / 2) })
        val roots = tmpDir.listFiles()?.toList() ?: emptyList()
        archiveEngine.createArchive(roots, outputArchive, targetFormat, level, password) { p ->
          onProgress(50 + p / 2)
        }
        outputArchive
      } finally {
        tmpDir.deleteRecursively()
      }
    }

  suspend fun convertTextOrData(
    sourceFile: File,
    outputFile: File,
    target: TextTargetFormat,
  ): File =
    withContext(Dispatchers.IO) {
      val rawBytes = sourceFile.readBytes()
      val text = rawBytes.toString(Charsets.UTF_8)
      val srcExt = sourceFile.extension.lowercase()

      val converted: String =
        when (target) {
          TextTargetFormat.BASE64 ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
              Base64.getEncoder().encodeToString(rawBytes)
            } else {
              android.util.Base64.encodeToString(rawBytes, android.util.Base64.DEFAULT)
            }

          TextTargetFormat.HEX ->
            rawBytes.joinToString(" ") { "%02X".format(it) }

          TextTargetFormat.JSON -> convertToJson(text, srcExt)

          TextTargetFormat.XML -> convertToXml(text, srcExt)

          TextTargetFormat.YAML -> convertToYaml(text, srcExt)

          TextTargetFormat.CSV -> convertToCsv(text, srcExt)

          TextTargetFormat.HTML -> convertToHtml(text, srcExt, sourceFile.name)

          TextTargetFormat.MARKDOWN -> convertToMarkdown(text, srcExt, sourceFile.name)
        }

      outputFile.parentFile?.mkdirs()
      outputFile.writeText(converted, Charsets.UTF_8)
      outputFile
    }

  private fun convertToJson(text: String, srcExt: String): String {
    val trimmed = text.trim()
    if (trimmed.startsWith("{")) return JSONObject(trimmed).toString(2)
    if (trimmed.startsWith("[")) return JSONArray(trimmed).toString(2)
    if (srcExt == "csv") {
      val lines = trimmed.lines().filter { it.isNotBlank() }
      if (lines.size >= 2) {
        val headers = lines.first().split(",").map { it.trim() }
        val arr = JSONArray()
        for (line in lines.drop(1)) {
          val cols = line.split(",")
          val obj = JSONObject()
          headers.forEachIndexed { i, h -> obj.put(h, cols.getOrNull(i)?.trim() ?: "") }
          arr.put(obj)
        }
        return arr.toString(2)
      }
    }
    val obj = JSONObject()
    trimmed.lines().forEachIndexed { idx, line ->
      val colon = line.indexOf(':')
      if (colon > 0 && !line.trimStart().startsWith("#")) {
        obj.put(line.substring(0, colon).trim(), line.substring(colon + 1).trim())
      } else if (line.isNotBlank()) {
        obj.put("line_${idx + 1}", line)
      }
    }
    return obj.toString(2)
  }

  private fun convertToXml(text: String, srcExt: String): String {
    val trimmed = text.trim()
    if (trimmed.startsWith("<")) return trimmed
    val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<root>\n")
    if (trimmed.startsWith("{")) {
      val obj = JSONObject(trimmed)
      for (key in obj.keys()) {
        sb.append("  <$key>${escapeXml(obj.opt(key)?.toString() ?: "")}</$key>\n")
      }
    } else if (trimmed.startsWith("[")) {
      val arr = JSONArray(trimmed)
      for (i in 0 until arr.length()) {
        val item = arr.opt(i)
        sb.append("  <item index=\"$i\">\n")
        if (item is JSONObject) {
          for (k in item.keys()) {
            sb.append("    <$k>${escapeXml(item.opt(k)?.toString() ?: "")}</$k>\n")
          }
        } else {
          sb.append("    ${escapeXml(item?.toString() ?: "")}\n")
        }
        sb.append("  </item>\n")
      }
    } else {
      trimmed.lines().forEachIndexed { i, line ->
        sb.append("  <line number=\"${i + 1}\">${escapeXml(line)}</line>\n")
      }
    }
    sb.append("</root>\n")
    return sb.toString()
  }

  private fun convertToYaml(text: String, srcExt: String): String {
    val trimmed = text.trim()
    if (trimmed.startsWith("{")) {
      val obj = JSONObject(trimmed)
      val sb = StringBuilder()
      for (k in obj.keys()) {
        sb.append("$k: ${obj.opt(k)}\n")
      }
      return sb.toString()
    }
    if (trimmed.startsWith("[")) {
      val arr = JSONArray(trimmed)
      val sb = StringBuilder()
      for (i in 0 until arr.length()) {
        val item = arr.opt(i)
        if (item is JSONObject) {
          var first = true
          for (k in item.keys()) {
            sb.append(if (first) "- $k: ${item.opt(k)}\n" else "  $k: ${item.opt(k)}\n")
            first = false
          }
        } else {
          sb.append("- $item\n")
        }
      }
      return sb.toString()
    }
    return text
  }

  private fun convertToCsv(text: String, srcExt: String): String {
    val trimmed = text.trim()
    if (trimmed.startsWith("[")) {
      val arr = JSONArray(trimmed)
      val objs = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
      if (objs.isNotEmpty()) {
        val keys = objs.flatMap { it.keys().asSequence().toList() }.distinct()
        val sb = StringBuilder(keys.joinToString(",") + "\n")
        for (obj in objs) {
          sb.append(
            keys.joinToString(",") { k ->
              "\"${(obj.opt(k)?.toString() ?: "").replace("\"", "\"\"")}\""
            } + "\n"
          )
        }
        return sb.toString()
      }
    }
    return trimmed.lines().joinToString("\n") { line ->
      line.trim().replace(Regex("\\s{2,}|\\t"), ",")
    }
  }

  private fun convertToHtml(text: String, srcExt: String, title: String): String {
    val body =
      if (srcExt == "md" || srcExt == "markdown") {
        text.lines().joinToString("\n") { line ->
          when {
            line.startsWith("### ") -> "<h3>${escapeXml(line.drop(4))}</h3>"
            line.startsWith("## ") -> "<h2>${escapeXml(line.drop(3))}</h2>"
            line.startsWith("# ") -> "<h1>${escapeXml(line.drop(2))}</h1>"
            line.startsWith("- ") -> "<li>${escapeXml(line.drop(2))}</li>"
            line.isBlank() -> "<br/>"
            else -> "<p>${escapeXml(line)}</p>"
          }
        }
      } else {
        "<pre><code>${escapeXml(text)}</code></pre>"
      }
    return """<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"/><title>${escapeXml(title)}</title>
<style>body{font-family:sans-serif;background:#0b1016;color:#ebf2fa;padding:24px;line-height:1.6}pre{background:#121923;padding:16px;border-radius:8px;overflow:auto}</style>
</head>
<body>
$body
</body>
</html>"""
  }

  private fun convertToMarkdown(text: String, srcExt: String, title: String): String {
    return if (srcExt in setOf("html", "htm")) {
      text
        .replace(Regex("<h1[^>]*>(.*?)</h1>", RegexOption.IGNORE_CASE), "# $1\n")
        .replace(Regex("<h2[^>]*>(.*?)</h2>", RegexOption.IGNORE_CASE), "## $1\n")
        .replace(Regex("<h3[^>]*>(.*?)</h3>", RegexOption.IGNORE_CASE), "### $1\n")
        .replace(Regex("<li[^>]*>(.*?)</li>", RegexOption.IGNORE_CASE), "- $1\n")
        .replace(Regex("<[^>]+>"), "")
        .trim()
    } else {
      "# $title\n\n```$srcExt\n$text\n```\n"
    }
  }

  private fun escapeXml(s: String): String =
    s.replace("&", "&amp;")
      .replace("<", "&lt;")
      .replace(">", "&gt;")
      .replace("\"", "&quot;")
}
