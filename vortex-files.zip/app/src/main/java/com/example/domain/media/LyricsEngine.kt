package com.example.domain.media

import java.io.File
import java.net.URLEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

data class SyncedWord(
  val text: String,
  val startMs: Long,
  val endMs: Long,
)

data class SyncedLyricLine(
  val index: Int,
  val startMs: Long,
  val endMs: Long,
  val text: String,
  val words: List<SyncedWord>,
  val isSynced: Boolean = true,
)

data class OnlineLyricsHit(
  val id: Long,
  val trackName: String,
  val artistName: String,
  val albumName: String,
  val syncedLrc: String?,
  val plainLyrics: String?,
) {
  val hasSyncedTimestamps: Boolean
    get() = !syncedLrc.isNullOrBlank()
}

object LyricsEngine {

  private val lrcLineRegex = Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?](.*)""")
  private val enhancedWordRegex = Regex("""<(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?>([^<]*)""")

  fun loadLocalSidecarLrc(audioPath: String): List<SyncedLyricLine> {
    val audioFile = File(audioPath)
    val base = audioFile.nameWithoutExtension
    val parent = audioFile.parentFile ?: return emptyList()
    val candidates =
      listOf(
        File(parent, "$base.lrc"),
        File(parent, "$base.txt"),
      )
    val hit = candidates.firstOrNull { it.exists() && it.isFile && it.canRead() } ?: return emptyList()
    return parseLyrics(hit.readText())
  }

  fun parseLyrics(rawText: String): List<SyncedLyricLine> {
    val clean = rawText.replace("\r\n", "\n").replace('\r', '\n').trim()
    if (clean.isEmpty()) return emptyList()

    val parsedTimed = mutableListOf<Pair<Long, String>>()
    for (line in clean.lines()) {
      val trimmed = line.trim()
      if (trimmed.isEmpty()) continue
      val matches = lrcLineRegex.findAll(trimmed).toList()
      if (matches.isNotEmpty()) {
        // Support multi-timestamp lines like [00:12.00][01:02.00]Chorus text
        val allTimes = Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?]""").findAll(trimmed)
        val content = trimmed.replace(Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?]"""), "").trim()
        if (content.isNotBlank()) {
          for (tm in allTimes) {
            val ms = toMillis(tm.groupValues[1], tm.groupValues[2], tm.groupValues[3])
            parsedTimed.add(ms to content)
          }
        }
      }
    }

    if (parsedTimed.isNotEmpty()) {
      val sorted = parsedTimed.sortedBy { it.first }
      return sorted.mapIndexed { idx, (startMs, rawContent) ->
        val nextStart = sorted.getOrNull(idx + 1)?.first ?: (startMs + 4500L)
        val endMs = maxOf(startMs + 800L, nextStart)
        val enhanced = enhancedWordRegex.findAll(rawContent).toList()
        val words =
          if (enhanced.isNotEmpty()) {
            enhanced.mapIndexedNotNull { wIdx, m ->
              val wText = m.groupValues[4].trim()
              if (wText.isEmpty()) null
              else {
                val wStart = toMillis(m.groupValues[1], m.groupValues[2], m.groupValues[3])
                val wEnd =
                  enhanced.getOrNull(wIdx + 1)?.let {
                    toMillis(it.groupValues[1], it.groupValues[2], it.groupValues[3])
                  } ?: endMs
                SyncedWord(wText, wStart, maxOf(wStart + 120L, wEnd))
              }
            }
          } else {
            buildInterpolatedWords(rawContent, startMs, endMs)
          }
        val displayLine = rawContent.replace(Regex("""<\d{1,2}:\d{2}(?:[.:]\d{1,3})?>"""), "").replace(Regex("\\s+"), " ").trim()
        SyncedLyricLine(idx, startMs, endMs, displayLine, words, isSynced = true)
      }
    }

    // Plain unsynced lyrics fallback
    return clean.lines()
      .map { it.trim() }
      .filter { it.isNotEmpty() }
      .mapIndexed { idx, text ->
        SyncedLyricLine(
          index = idx,
          startMs = 0L,
          endMs = 0L,
          text = text,
          words = text.split(Regex("\\s+")).map { SyncedWord(it, 0L, 0L) },
          isSynced = false,
        )
      }
  }

  fun findActiveLineIndex(lines: List<SyncedLyricLine>, positionMs: Long, syncOffsetMs: Long = 0L): Int {
    if (lines.isEmpty() || !lines.first().isSynced) return -1
    val pos = positionMs - syncOffsetMs
    var active = -1
    for (i in lines.indices) {
      if (pos >= lines[i].startMs) active = i else break
    }
    return active
  }

  fun findActiveWordIndex(line: SyncedLyricLine, positionMs: Long, syncOffsetMs: Long = 0L): Int {
    if (!line.isSynced || line.words.isEmpty()) return -1
    val pos = positionMs - syncOffsetMs
    var active = 0
    for (i in line.words.indices) {
      if (pos >= line.words[i].startMs) active = i else break
    }
    return active
  }

  private fun buildInterpolatedWords(text: String, startMs: Long, endMs: Long): List<SyncedWord> {
    val tokens = text.split(Regex("\\s+")).filter { it.isNotBlank() }
    if (tokens.isEmpty()) return emptyList()
    val totalDur = (endMs - startMs).coerceAtLeast(400L)
    val totalChars = tokens.sumOf { it.length }.coerceAtLeast(tokens.size)
    var cursor = startMs
    return tokens.mapIndexed { idx, token ->
      val weight = token.length.coerceAtLeast(1).toDouble() / totalChars.toDouble()
      val slice = (totalDur * weight).toLong().coerceAtLeast(100L)
      val wStart = cursor
      val wEnd = if (idx == tokens.lastIndex) endMs else (wStart + slice).coerceAtMost(endMs)
      cursor = wEnd
      SyncedWord(token, wStart, wEnd)
    }
  }

  private fun toMillis(minStr: String, secStr: String, msStr: String): Long {
    val m = minStr.toLongOrNull() ?: 0L
    val s = secStr.toLongOrNull() ?: 0L
    val frac =
      when (msStr.length) {
        0 -> 0L
        1 -> (msStr.toLongOrNull() ?: 0L) * 100L
        2 -> (msStr.toLongOrNull() ?: 0L) * 10L
        else -> msStr.take(3).toLongOrNull() ?: 0L
      }
    return (m * 60_000L) + (s * 1000L) + frac
  }
}

class OnlineLyricsService {
  private val client = OkHttpClient.Builder().followRedirects(true).build()

  suspend fun searchLyrics(
    trackName: String,
    artistName: String = "",
    preferredLanguages: List<String> = listOf("ar", "en"),
  ): List<OnlineLyricsHit> =
    withContext(Dispatchers.IO) {
      val cleanTrack = cleanTrackQuery(trackName)
      if (cleanTrack.isBlank()) return@withContext emptyList()
      val qTrack = URLEncoder.encode(cleanTrack, "UTF-8")
      val qArtist =
        if (artistName.isNotBlank() && !artistName.equals("Unknown Artist", ignoreCase = true)) {
          "&artist_name=${URLEncoder.encode(artistName.trim(), "UTF-8")}"
        } else {
          ""
        }

      val hits = mutableListOf<OnlineLyricsHit>()
      runCatching {
        val req =
          Request.Builder()
            .url("https://lrclib.net/api/search?track_name=$qTrack$qArtist")
            .header("User-Agent", "VortexFiles/2.0 (Android)")
            .build()
        client.newCall(req).execute().use { resp ->
          if (resp.isSuccessful) {
            val body = resp.body?.string().orEmpty()
            if (body.trimStart().startsWith("[")) {
              val arr = JSONArray(body)
              for (i in 0 until minOf(arr.length(), 15)) {
                val obj = arr.optJSONObject(i) ?: continue
                parseHit(obj)?.let { hits.add(it) }
              }
            }
          }
        }
      }

      // If strict track+artist returned nothing, broaden search with q=
      if (hits.isEmpty()) {
        runCatching {
          val qCombined = URLEncoder.encode(cleanTrack, "UTF-8")
          val req =
            Request.Builder()
              .url("https://lrclib.net/api/search?q=$qCombined")
              .header("User-Agent", "VortexFiles/2.0 (Android)")
              .build()
          client.newCall(req).execute().use { resp ->
            if (resp.isSuccessful) {
              val body = resp.body?.string().orEmpty()
              if (body.trimStart().startsWith("[")) {
                val arr = JSONArray(body)
                for (i in 0 until minOf(arr.length(), 15)) {
                  val obj = arr.optJSONObject(i) ?: continue
                  parseHit(obj)?.let { hits.add(it) }
                }
              }
            }
          }
        }
      }

      val langs = preferredLanguages.ifEmpty { listOf("ar", "en") }
      hits.sortedWith(
        compareByDescending<OnlineLyricsHit> { it.hasSyncedTimestamps }
          .thenByDescending { scoreLanguageMatch(it, langs) }
      )
    }

  private fun scoreLanguageMatch(hit: OnlineLyricsHit, langs: List<String>): Int {
    val sample = (hit.syncedLrc ?: hit.plainLyrics).orEmpty().take(400)
    if (sample.isBlank()) return 0
    val hasArabic = sample.any { it in '\u0600'..'\u06FF' }
    val hasCyrillic = sample.any { it in '\u0400'..'\u04FF' }
    val detected =
      when {
        hasArabic -> "ar"
        hasCyrillic -> "ru"
        else -> "en"
      }
    val idx = langs.indexOfFirst { it.equals(detected, ignoreCase = true) }
    return if (idx >= 0) (langs.size - idx) * 10 else 0
  }

  private fun parseHit(obj: JSONObject): OnlineLyricsHit? {
    val synced = obj.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
    val plain = obj.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
    if (synced == null && plain == null) return null
    return OnlineLyricsHit(
      id = obj.optLong("id"),
      trackName = obj.optString("trackName", "Track"),
      artistName = obj.optString("artistName", "Artist"),
      albumName = obj.optString("albumName", ""),
      syncedLrc = synced,
      plainLyrics = plain,
    )
  }

  private fun cleanTrackQuery(raw: String): String {
    return raw
      .substringBeforeLast('.')
      .replace(Regex("""\[.*?]|\(.*?\)"""), " ")
      .replace(Regex("""\b(official|audio|video|lyrics|hq|hd|320kbps|128kbps|mp3|flac|m4a)\b""", RegexOption.IGNORE_CASE), " ")
      .replace(Regex("[._-]+"), " ")
      .replace(Regex("\\s{2,}"), " ")
      .trim()
  }
}
