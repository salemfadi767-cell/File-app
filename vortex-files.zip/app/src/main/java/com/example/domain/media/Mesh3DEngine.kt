package com.example.domain.media

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class Vec3(val x: Float, val y: Float, val z: Float) {
  operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
  operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
  operator fun times(s: Float) = Vec3(x * s, y * s, z * s)
  fun dot(o: Vec3): Float = x * o.x + y * o.y + z * o.z
  fun cross(o: Vec3) = Vec3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
  fun length(): Float = sqrt(x * x + y * y + z * z)
  fun normalized(): Vec3 {
    val len = length()
    return if (len > 1e-6f) Vec3(x / len, y / len, z / len) else Vec3(0f, 1f, 0f)
  }
}

data class MeshFace(val i0: Int, val i1: Int, val i2: Int)

data class MeshObject(
  val id: String,
  val name: String,
  val vertices: List<Vec3>,
  val faces: List<MeshFace>,
  val colorArgb: Int = Color(0xFF4DD0E1).toArgb(),
  val position: Vec3 = Vec3(0f, 0f, 0f),
  val rotationDeg: Vec3 = Vec3(0f, 0f, 0f),
  val scale: Vec3 = Vec3(1f, 1f, 1f),
  val visible: Boolean = true,
)

enum class Shading3DMode {
  SOLID_LIT,
  WIREFRAME,
  NORMALS,
}

enum class Primitive3DType(val label: String) {
  CUBE("Cube"),
  SPHERE("UV Sphere"),
  CYLINDER("Cylinder"),
  CONE("Cone"),
  TORUS("Torus"),
  PLANE("Grid Plane"),
}

enum class Mesh3DFormat(val ext: String, val label: String) {
  OBJ("obj", "Wavefront OBJ"),
  STL("stl", "STL (3D Print)"),
  PLY("ply", "Stanford PLY"),
  GLB("glb", "Binary glTF (.glb)"),
  GLTF("gltf", "glTF 2.0 JSON"),
  OFF("off", "Object File Format (.off)"),
  DAE("dae", "COLLADA (.dae)"),
  THREEDS("3ds", "Autodesk 3DS");

  companion object {
    fun detect(fileName: String): Mesh3DFormat? {
      val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
      return entries.find { it.ext == ext }
    }

    fun is3DFile(fileName: String): Boolean = detect(fileName) != null
  }
}

object Mesh3DEngine {

  fun createPrimitive(
    type: Primitive3DType,
    name: String = type.label,
    colorArgb: Int = Color(0xFF4DD0E1).toArgb(),
  ): MeshObject {
    val id = "obj_${System.nanoTime()}"
    return when (type) {
      Primitive3DType.CUBE -> {
        val v = listOf(
          Vec3(-1f, -1f, -1f), Vec3(1f, -1f, -1f), Vec3(1f, 1f, -1f), Vec3(-1f, 1f, -1f),
          Vec3(-1f, -1f, 1f), Vec3(1f, -1f, 1f), Vec3(1f, 1f, 1f), Vec3(-1f, 1f, 1f),
        )
        val f = listOf(
          MeshFace(0, 2, 1), MeshFace(0, 3, 2),
          MeshFace(4, 5, 6), MeshFace(4, 6, 7),
          MeshFace(0, 1, 5), MeshFace(0, 5, 4),
          MeshFace(2, 3, 7), MeshFace(2, 7, 6),
          MeshFace(0, 4, 7), MeshFace(0, 7, 3),
          MeshFace(1, 2, 6), MeshFace(1, 6, 5),
        )
        MeshObject(id = id, name = name, vertices = v, faces = f, colorArgb = colorArgb)
      }

      Primitive3DType.SPHERE -> buildUvSphere(id, name, colorArgb, rings = 12, sectors = 18)
      Primitive3DType.CYLINDER -> buildCylinder(id, name, colorArgb, sectors = 20, topRadius = 1f)
      Primitive3DType.CONE -> buildCylinder(id, name, colorArgb, sectors = 20, topRadius = 0.001f)
      Primitive3DType.TORUS -> buildTorus(id, name, colorArgb, majorSegs = 20, minorSegs = 12)
      Primitive3DType.PLANE -> {
        val v = listOf(
          Vec3(-1.5f, 0f, -1.5f),
          Vec3(1.5f, 0f, -1.5f),
          Vec3(1.5f, 0f, 1.5f),
          Vec3(-1.5f, 0f, 1.5f),
        )
        val f = listOf(MeshFace(0, 1, 2), MeshFace(0, 2, 3))
        MeshObject(id = id, name = name, vertices = v, faces = f, colorArgb = colorArgb)
      }
    }
  }

  private fun buildUvSphere(
    id: String,
    name: String,
    colorArgb: Int,
    rings: Int,
    sectors: Int,
  ): MeshObject {
    val verts = mutableListOf<Vec3>()
    val faces = mutableListOf<MeshFace>()
    for (r in 0..rings) {
      val theta = PI * r / rings
      val sinT = sin(theta).toFloat()
      val cosT = cos(theta).toFloat()
      for (s in 0..sectors) {
        val phi = 2.0 * PI * s / sectors
        val x = (cos(phi) * sinT).toFloat()
        val y = cosT
        val z = (sin(phi) * sinT).toFloat()
        verts.add(Vec3(x, y, z))
      }
    }
    val stride = sectors + 1
    for (r in 0 until rings) {
      for (s in 0 until sectors) {
        val a = r * stride + s
        val b = a + stride
        val c = b + 1
        val d = a + 1
        if (r != 0) faces.add(MeshFace(a, b, d))
        if (r != rings - 1) faces.add(MeshFace(d, b, c))
      }
    }
    return MeshObject(id = id, name = name, vertices = verts, faces = faces, colorArgb = colorArgb)
  }

  private fun buildCylinder(
    id: String,
    name: String,
    colorArgb: Int,
    sectors: Int,
    topRadius: Float,
  ): MeshObject {
    val verts = mutableListOf<Vec3>()
    val faces = mutableListOf<MeshFace>()
    val bottomCenter = 0
    verts.add(Vec3(0f, -1f, 0f))
    val topCenter = 1
    verts.add(Vec3(0f, 1f, 0f))
    val ringStart = 2
    for (i in 0 until sectors) {
      val a = (2.0 * PI * i / sectors).toFloat()
      val cx = cos(a)
      val cz = sin(a)
      verts.add(Vec3(cx, -1f, cz))
      verts.add(Vec3(cx * topRadius, 1f, cz * topRadius))
    }
    for (i in 0 until sectors) {
      val next = (i + 1) % sectors
      val b0 = ringStart + i * 2
      val t0 = b0 + 1
      val b1 = ringStart + next * 2
      val t1 = b1 + 1
      faces.add(MeshFace(bottomCenter, b1, b0))
      faces.add(MeshFace(topCenter, t0, t1))
      faces.add(MeshFace(b0, b1, t1))
      faces.add(MeshFace(b0, t1, t0))
    }
    return MeshObject(id = id, name = name, vertices = verts, faces = faces, colorArgb = colorArgb)
  }

  private fun buildTorus(
    id: String,
    name: String,
    colorArgb: Int,
    majorSegs: Int,
    minorSegs: Int,
    majorR: Float = 1.0f,
    minorR: Float = 0.36f,
  ): MeshObject {
    val verts = mutableListOf<Vec3>()
    val faces = mutableListOf<MeshFace>()
    for (i in 0 until majorSegs) {
      val u = 2.0 * PI * i / majorSegs
      val cosU = cos(u).toFloat()
      val sinU = sin(u).toFloat()
      for (j in 0 until minorSegs) {
        val v = 2.0 * PI * j / minorSegs
        val cosV = cos(v).toFloat()
        val sinV = sin(v).toFloat()
        val x = (majorR + minorR * cosV) * cosU
        val y = minorR * sinV
        val z = (majorR + minorR * cosV) * sinU
        verts.add(Vec3(x, y, z))
      }
    }
    for (i in 0 until majorSegs) {
      val nextI = (i + 1) % majorSegs
      for (j in 0 until minorSegs) {
        val nextJ = (j + 1) % minorSegs
        val a = i * minorSegs + j
        val b = nextI * minorSegs + j
        val c = nextI * minorSegs + nextJ
        val d = i * minorSegs + nextJ
        faces.add(MeshFace(a, b, c))
        faces.add(MeshFace(a, c, d))
      }
    }
    return MeshObject(id = id, name = name, vertices = verts, faces = faces, colorArgb = colorArgb)
  }

  fun subdivideMesh(obj: MeshObject): MeshObject {
    if (obj.faces.size > 8000) return obj
    val newVerts = obj.vertices.toMutableList()
    val midCache = HashMap<Long, Int>()
    fun midpoint(a: Int, b: Int): Int {
      val minIdx = minOf(a, b).toLong()
      val maxIdx = maxOf(a, b).toLong()
      val key = (minIdx shl 32) or (maxIdx and 0xFFFFFFFFL)
      midCache[key]?.let { return it }
      val va = newVerts[a]
      val vb = newVerts[b]
      val mid = Vec3((va.x + vb.x) * 0.5f, (va.y + vb.y) * 0.5f, (va.z + vb.z) * 0.5f)
      val idx = newVerts.size
      newVerts.add(mid)
      midCache[key] = idx
      return idx
    }
    val newFaces = ArrayList<MeshFace>(obj.faces.size * 4)
    for (f in obj.faces) {
      val ab = midpoint(f.i0, f.i1)
      val bc = midpoint(f.i1, f.i2)
      val ca = midpoint(f.i2, f.i0)
      newFaces.add(MeshFace(f.i0, ab, ca))
      newFaces.add(MeshFace(f.i1, bc, ab))
      newFaces.add(MeshFace(f.i2, ca, bc))
      newFaces.add(MeshFace(ab, bc, ca))
    }
    return obj.copy(vertices = newVerts, faces = newFaces)
  }

  fun mirrorMesh(obj: MeshObject, axisX: Boolean, axisY: Boolean, axisZ: Boolean): MeshObject {
    val mirroredVerts =
      obj.vertices.map { v ->
        Vec3(
          if (axisX) -v.x else v.x,
          if (axisY) -v.y else v.y,
          if (axisZ) -v.z else v.z,
        )
      }
    val flipCount = (if (axisX) 1 else 0) + (if (axisY) 1 else 0) + (if (axisZ) 1 else 0)
    val fixedFaces = if (flipCount % 2 == 1) obj.faces.map { MeshFace(it.i0, it.i2, it.i1) } else obj.faces
    return obj.copy(vertices = mirroredVerts, faces = fixedFaces)
  }

  fun normalizeToUnitBounds(obj: MeshObject): MeshObject {
    if (obj.vertices.isEmpty()) return obj
    var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
    var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
    var minZ = Float.MAX_VALUE; var maxZ = -Float.MAX_VALUE
    for (v in obj.vertices) {
      if (v.x < minX) minX = v.x; if (v.x > maxX) maxX = v.x
      if (v.y < minY) minY = v.y; if (v.y > maxY) maxY = v.y
      if (v.z < minZ) minZ = v.z; if (v.z > maxZ) maxZ = v.z
    }
    val cx = (minX + maxX) * 0.5f
    val cy = (minY + maxY) * 0.5f
    val cz = (minZ + maxZ) * 0.5f
    val extent = max(maxX - minX, max(maxY - minY, maxZ - minZ)).coerceAtLeast(1e-4f)
    val scale = 2.2f / extent
    return obj.copy(
      vertices = obj.vertices.map { Vec3((it.x - cx) * scale, (it.y - cy) * scale, (it.z - cz) * scale) },
    )
  }

  fun bakeWorldVertices(obj: MeshObject): List<Vec3> {
    val rx = Math.toRadians(obj.rotationDeg.x.toDouble())
    val ry = Math.toRadians(obj.rotationDeg.y.toDouble())
    val rz = Math.toRadians(obj.rotationDeg.z.toDouble())
    val cx = cos(rx).toFloat(); val sx = sin(rx).toFloat()
    val cy = cos(ry).toFloat(); val sy = sin(ry).toFloat()
    val cz = cos(rz).toFloat(); val sz = sin(rz).toFloat()

    return obj.vertices.map { v ->
      val x0 = v.x * obj.scale.x
      val y0 = v.y * obj.scale.y
      val z0 = v.z * obj.scale.z
      // Rotate X
      val y1 = y0 * cx - z0 * sx
      val z1 = y0 * sx + z0 * cx
      val x1 = x0
      // Rotate Y
      val x2 = x1 * cy + z1 * sy
      val z2 = -x1 * sy + z1 * cy
      val y2 = y1
      // Rotate Z
      val x3 = x2 * cz - y2 * sz
      val y3 = x2 * sz + y2 * cz
      val z3 = z2
      Vec3(x3 + obj.position.x, y3 + obj.position.y, z3 + obj.position.z)
    }
  }

  suspend fun loadMeshFromFile(file: File): List<MeshObject> =
    withContext(Dispatchers.IO) {
      if (!file.exists() || !file.isFile) return@withContext emptyList()
      val fmt = Mesh3DFormat.detect(file.name) ?: return@withContext emptyList()
      val raw =
        when (fmt) {
          Mesh3DFormat.OBJ -> listOf(parseObj(file.readText(), file.nameWithoutExtension))
          Mesh3DFormat.STL -> listOf(parseStl(file.readBytes(), file.nameWithoutExtension))
          Mesh3DFormat.PLY -> listOf(parsePly(file.readText(), file.nameWithoutExtension))
          Mesh3DFormat.OFF -> listOf(parseOff(file.readText(), file.nameWithoutExtension))
          Mesh3DFormat.GLTF -> parseGltfJson(file.readText(), file.parentFile, file.nameWithoutExtension)
          Mesh3DFormat.GLB -> parseGlb(file.readBytes(), file.nameWithoutExtension)
          Mesh3DFormat.DAE -> parseDae(file.readText(), file.nameWithoutExtension)
          Mesh3DFormat.THREEDS -> parse3ds(file.readBytes(), file.nameWithoutExtension)
        }
      raw.filter { it.vertices.isNotEmpty() && it.faces.isNotEmpty() }.map { normalizeToUnitBounds(it) }
    }

  suspend fun exportScene(
    objects: List<MeshObject>,
    outputFile: File,
    format: Mesh3DFormat,
  ): File =
    withContext(Dispatchers.IO) {
      outputFile.parentFile?.mkdirs()
      val visible = objects.filter { it.visible && it.vertices.isNotEmpty() && it.faces.isNotEmpty() }
      val bakedAll = flattenScene(visible)
      when (format) {
        Mesh3DFormat.OBJ -> outputFile.writeText(serializeObj(visible))
        Mesh3DFormat.STL -> outputFile.writeBytes(serializeBinaryStl(bakedAll))
        Mesh3DFormat.PLY -> outputFile.writeText(serializePly(bakedAll))
        Mesh3DFormat.OFF -> outputFile.writeText(serializeOff(bakedAll))
        Mesh3DFormat.GLTF -> outputFile.writeText(serializeGltfJson(bakedAll))
        Mesh3DFormat.GLB -> outputFile.writeBytes(serializeGlb(bakedAll))
        Mesh3DFormat.DAE -> outputFile.writeText(serializeDae(bakedAll))
        Mesh3DFormat.THREEDS -> outputFile.writeBytes(serialize3ds(bakedAll))
      }
      outputFile
    }

  private fun flattenScene(objects: List<MeshObject>): MeshObject {
    val allVerts = mutableListOf<Vec3>()
    val allFaces = mutableListOf<MeshFace>()
    var baseColor = Color(0xFF4DD0E1).toArgb()
    for (obj in objects) {
      baseColor = obj.colorArgb
      val offset = allVerts.size
      allVerts.addAll(bakeWorldVertices(obj))
      for (f in obj.faces) {
        if (f.i0 in obj.vertices.indices && f.i1 in obj.vertices.indices && f.i2 in obj.vertices.indices) {
          allFaces.add(MeshFace(f.i0 + offset, f.i1 + offset, f.i2 + offset))
        }
      }
    }
    return MeshObject(id = "merged", name = "VortexScene", vertices = allVerts, faces = allFaces, colorArgb = baseColor)
  }

  private fun parseObj(text: String, name: String): MeshObject {
    val verts = mutableListOf<Vec3>()
    val faces = mutableListOf<MeshFace>()
    text.lineSequence().forEach { line ->
      val t = line.trim()
      when {
        t.startsWith("v ") -> {
          val p = t.split(Regex("\\s+"))
          if (p.size >= 4) {
            val x = p[1].toFloatOrNull() ?: 0f
            val y = p[2].toFloatOrNull() ?: 0f
            val z = p[3].toFloatOrNull() ?: 0f
            verts.add(Vec3(x, y, z))
          }
        }
        t.startsWith("f ") -> {
          val p = t.split(Regex("\\s+")).drop(1)
          val idxs = p.mapNotNull { token ->
            val rawIdx = token.substringBefore('/').toIntOrNull() ?: return@mapNotNull null
            val resolved = if (rawIdx > 0) rawIdx - 1 else verts.size + rawIdx
            resolved.takeIf { it in verts.indices }
          }
          for (i in 1 until idxs.size - 1) {
            faces.add(MeshFace(idxs[0], idxs[i], idxs[i + 1]))
          }
        }
      }
    }
    return MeshObject(id = "obj_${System.nanoTime()}", name = name, vertices = verts, faces = faces)
  }

  private fun parseStl(bytes: ByteArray, name: String): MeshObject {
    val asAscii = runCatching { bytes.take(256).toByteArray().toString(Charsets.UTF_8) }.getOrDefault("")
    if (asAscii.trimStart().startsWith("solid", ignoreCase = true) && asAscii.contains("facet", ignoreCase = true)) {
      val verts = mutableListOf<Vec3>()
      val faces = mutableListOf<MeshFace>()
      val text = bytes.toString(Charsets.UTF_8)
      val rx = Regex("""vertex\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)""")
      val matches = rx.findAll(text).toList()
      var i = 0
      while (i + 2 < matches.size) {
        val bIdx = verts.size
        for (k in 0..2) {
          val m = matches[i + k]
          verts.add(Vec3(m.groupValues[1].toFloat(), m.groupValues[2].toFloat(), m.groupValues[3].toFloat()))
        }
        faces.add(MeshFace(bIdx, bIdx + 1, bIdx + 2))
        i += 3
      }
      if (faces.isNotEmpty()) return MeshObject("obj_${System.nanoTime()}", name, verts, faces)
    }

    if (bytes.size < 84) return createPrimitive(Primitive3DType.CUBE, name)
    val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
    bb.position(80)
    val triCount = bb.int.coerceIn(0, (bytes.size - 84) / 50)
    val verts = ArrayList<Vec3>(triCount * 3)
    val faces = ArrayList<MeshFace>(triCount)
    for (t in 0 until triCount) {
      bb.float; bb.float; bb.float // normal
      val bIdx = verts.size
      for (k in 0..2) {
        verts.add(Vec3(bb.float, bb.float, bb.float))
      }
      faces.add(MeshFace(bIdx, bIdx + 1, bIdx + 2))
      bb.short // attr
    }
    return MeshObject("obj_${System.nanoTime()}", name, verts, faces)
  }

  private fun parsePly(text: String, name: String): MeshObject {
    val lines = text.lines()
    var vertexCount = 0
    var faceCount = 0
    var headerEnd = 0
    for ((idx, l) in lines.withIndex()) {
      val t = l.trim()
      if (t.startsWith("element vertex ")) vertexCount = t.removePrefix("element vertex ").trim().toIntOrNull() ?: 0
      if (t.startsWith("element face ")) faceCount = t.removePrefix("element face ").trim().toIntOrNull() ?: 0
      if (t == "end_header") {
        headerEnd = idx + 1
        break
      }
    }
    val verts = mutableListOf<Vec3>()
    val faces = mutableListOf<MeshFace>()
    for (i in 0 until vertexCount) {
      val line = lines.getOrNull(headerEnd + i)?.trim() ?: break
      val p = line.split(Regex("\\s+"))
      if (p.size >= 3) {
        verts.add(Vec3(p[0].toFloatOrNull() ?: 0f, p[1].toFloatOrNull() ?: 0f, p[2].toFloatOrNull() ?: 0f))
      }
    }
    for (i in 0 until faceCount) {
      val line = lines.getOrNull(headerEnd + vertexCount + i)?.trim() ?: break
      val p = line.split(Regex("\\s+"))
      val n = p.firstOrNull()?.toIntOrNull() ?: continue
      val idxs = p.drop(1).take(n).mapNotNull { it.toIntOrNull()?.takeIf { v -> v in verts.indices } }
      for (k in 1 until idxs.size - 1) {
        faces.add(MeshFace(idxs[0], idxs[k], idxs[k + 1]))
      }
    }
    return MeshObject("obj_${System.nanoTime()}", name, verts, faces)
  }

  private fun parseOff(text: String, name: String): MeshObject {
    val lines = text.lines().map { it.substringBefore('#').trim() }.filter { it.isNotEmpty() }
    val startIdx = if (lines.firstOrNull()?.startsWith("OFF", true) == true) 1 else 0
    val counts = lines.getOrNull(startIdx)?.split(Regex("\\s+")) ?: return createPrimitive(Primitive3DType.CUBE, name)
    val vCount = counts.getOrNull(0)?.toIntOrNull() ?: 0
    val fCount = counts.getOrNull(1)?.toIntOrNull() ?: 0
    val verts = mutableListOf<Vec3>()
    val faces = mutableListOf<MeshFace>()
    for (i in 0 until vCount) {
      val p = lines.getOrNull(startIdx + 1 + i)?.split(Regex("\\s+")) ?: break
      if (p.size >= 3) verts.add(Vec3(p[0].toFloatOrNull() ?: 0f, p[1].toFloatOrNull() ?: 0f, p[2].toFloatOrNull() ?: 0f))
    }
    for (i in 0 until fCount) {
      val p = lines.getOrNull(startIdx + 1 + vCount + i)?.split(Regex("\\s+")) ?: break
      val n = p.firstOrNull()?.toIntOrNull() ?: continue
      val idxs = p.drop(1).take(n).mapNotNull { it.toIntOrNull()?.takeIf { v -> v in verts.indices } }
      for (k in 1 until idxs.size - 1) faces.add(MeshFace(idxs[0], idxs[k], idxs[k + 1]))
    }
    return MeshObject("obj_${System.nanoTime()}", name, verts, faces)
  }

  private fun parseGltfJson(jsonText: String, baseDir: File?, fallbackName: String, binChunk: ByteArray? = null): List<MeshObject> {
    return runCatching {
      val root = JSONObject(jsonText)
      val buffers = root.optJSONArray("buffers") ?: JSONArray()
      val bufferBytesList = (0 until buffers.length()).map { i ->
        val bufObj = buffers.getJSONObject(i)
        val uri = bufObj.optString("uri", "")
        when {
          uri.isBlank() && i == 0 && binChunk != null -> binChunk
          uri.startsWith("data:") -> {
            val b64 = uri.substringAfter("base64,", "")
            android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
          }
          uri.isNotBlank() && baseDir != null -> File(baseDir, uri).takeIf { it.exists() }?.readBytes() ?: ByteArray(0)
          else -> ByteArray(0)
        }
      }
      val bufferViews = root.optJSONArray("bufferViews") ?: JSONArray()
      val accessors = root.optJSONArray("accessors") ?: JSONArray()
      val meshes = root.optJSONArray("meshes") ?: JSONArray()

      fun readFloat3Accessor(accIdx: Int): List<Vec3> {
        val acc = accessors.getJSONObject(accIdx)
        val bv = bufferViews.getJSONObject(acc.getInt("bufferView"))
        val raw = bufferBytesList[bv.optInt("buffer", 0)]
        val offset = bv.optInt("byteOffset", 0) + acc.optInt("byteOffset", 0)
        val stride = bv.optInt("byteStride", 12).coerceAtLeast(12)
        val count = acc.getInt("count")
        val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
        val out = ArrayList<Vec3>(count)
        for (k in 0 until count) {
          val pos = offset + k * stride
          if (pos + 12 <= raw.size) {
            out.add(Vec3(bb.getFloat(pos), bb.getFloat(pos + 4), bb.getFloat(pos + 8)))
          }
        }
        return out
      }

      fun readIndexAccessor(accIdx: Int, maxVert: Int): List<Int> {
        val acc = accessors.getJSONObject(accIdx)
        val bv = bufferViews.getJSONObject(acc.getInt("bufferView"))
        val raw = bufferBytesList[bv.optInt("buffer", 0)]
        val offset = bv.optInt("byteOffset", 0) + acc.optInt("byteOffset", 0)
        val compType = acc.getInt("componentType")
        val count = acc.getInt("count")
        val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
        val out = ArrayList<Int>(count)
        for (k in 0 until count) {
          val idx = when (compType) {
            5121 -> (raw.getOrElse(offset + k) { 0 }.toInt() and 0xFF)
            5123 -> if (offset + k * 2 + 2 <= raw.size) (bb.getShort(offset + k * 2).toInt() and 0xFFFF) else 0
            else -> if (offset + k * 4 + 4 <= raw.size) bb.getInt(offset + k * 4) else 0
          }
          if (idx in 0 until maxVert) out.add(idx)
        }
        return out
      }

      val result = mutableListOf<MeshObject>()
      for (m in 0 until meshes.length()) {
        val mesh = meshes.getJSONObject(m)
        val mName = mesh.optString("name", "$fallbackName #$m")
        val prims = mesh.optJSONArray("primitives") ?: continue
        val verts = mutableListOf<Vec3>()
        val faces = mutableListOf<MeshFace>()
        for (p in 0 until prims.length()) {
          val prim = prims.getJSONObject(p)
          val attrs = prim.optJSONObject("attributes") ?: continue
          if (!attrs.has("POSITION")) continue
          val posList = readFloat3Accessor(attrs.getInt("POSITION"))
          val baseOffset = verts.size
          verts.addAll(posList)
          if (prim.has("indices")) {
            val idxs = readIndexAccessor(prim.getInt("indices"), posList.size)
            var t = 0
            while (t + 2 < idxs.size) {
              faces.add(MeshFace(baseOffset + idxs[t], baseOffset + idxs[t + 1], baseOffset + idxs[t + 2]))
              t += 3
            }
          } else {
            var t = 0
            while (t + 2 < posList.size) {
              faces.add(MeshFace(baseOffset + t, baseOffset + t + 1, baseOffset + t + 2))
              t += 3
            }
          }
        }
        if (verts.isNotEmpty() && faces.isNotEmpty()) {
          result.add(MeshObject("obj_${System.nanoTime()}_$m", mName, verts, faces))
        }
      }
      result
    }.getOrDefault(emptyList())
  }

  private fun parseGlb(bytes: ByteArray, name: String): List<MeshObject> {
    if (bytes.size < 20) return emptyList()
    val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
    val magic = bb.int
    if (magic != 0x46546C67) return emptyList() // "glTF"
    bb.int // version
    bb.int // total length
    var jsonStr = ""
    var binBytes: ByteArray? = null
    while (bb.remaining() >= 8) {
      val chunkLen = bb.int
      val chunkType = bb.int
      if (chunkLen <= 0 || chunkLen > bb.remaining()) break
      val chunkData = ByteArray(chunkLen)
      bb.get(chunkData)
      when (chunkType) {
        0x4E4F534A -> jsonStr = chunkData.toString(Charsets.UTF_8)
        0x004E4942 -> binBytes = chunkData
      }
    }
    return if (jsonStr.isNotBlank()) parseGltfJson(jsonStr, null, name, binBytes) else emptyList()
  }

  private fun parseDae(xml: String, name: String): List<MeshObject> {
    val floatArrayRx = Regex("""<float_array[^>]*>([^<]+)</float_array>""")
    val pRx = Regex("""<p>([^<]+)</p>""")
    val posText = floatArrayRx.find(xml)?.groupValues?.getOrNull(1) ?: return emptyList()
    val floats = posText.trim().split(Regex("\\s+")).mapNotNull { it.toFloatOrNull() }
    val verts = mutableListOf<Vec3>()
    var i = 0
    while (i + 2 < floats.size) {
      verts.add(Vec3(floats[i], floats[i + 1], floats[i + 2]))
      i += 3
    }
    val pMatch = pRx.find(xml)?.groupValues?.getOrNull(1)
    val faces = mutableListOf<MeshFace>()
    if (pMatch != null) {
      val ints = pMatch.trim().split(Regex("\\s+")).mapNotNull { it.toIntOrNull() }
      val stride = max(1, ints.size / max(1, (verts.size)))
      val step = if (ints.size >= 9 && ints.maxOrNull()?.let { it < verts.size } == true) 1 else 3
      var k = 0
      while (k + 2 * step < ints.size) {
        val a = ints[k]
        val b = ints[k + step]
        val c = ints[k + 2 * step]
        if (a in verts.indices && b in verts.indices && c in verts.indices) {
          faces.add(MeshFace(a, b, c))
        }
        k += 3 * step
      }
      if (faces.isEmpty() && ints.size >= 3) {
        var j = 0
        while (j + 2 < ints.size) {
          val a = ints[j]; val b = ints[j + 1]; val c = ints[j + 2]
          if (a in verts.indices && b in verts.indices && c in verts.indices) faces.add(MeshFace(a, b, c))
          j += 3
        }
      }
    }
    return if (verts.isNotEmpty() && faces.isNotEmpty()) listOf(MeshObject("obj_${System.nanoTime()}", name, verts, faces)) else emptyList()
  }

  private fun parse3ds(bytes: ByteArray, name: String): List<MeshObject> {
    if (bytes.size < 16) return emptyList()
    val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
    val verts = mutableListOf<Vec3>()
    val faces = mutableListOf<MeshFace>()
    fun walk(endPos: Int) {
      while (bb.position() + 6 <= endPos) {
        val chunkId = bb.short.toInt() and 0xFFFF
        val chunkLen = bb.int
        if (chunkLen < 6 || bb.position() - 6 + chunkLen > endPos) break
        val chunkEnd = bb.position() - 6 + chunkLen
        when (chunkId) {
          0x4D4D, 0x3D3D, 0x4100 -> walk(chunkEnd)
          0x4000 -> {
            while (bb.position() < chunkEnd && bb.get().toInt() != 0) {}
            walk(chunkEnd)
          }
          0x4110 -> {
            val count = bb.short.toInt() and 0xFFFF
            for (i in 0 until count) {
              if (bb.position() + 12 > chunkEnd) break
              verts.add(Vec3(bb.float, bb.float, bb.float))
            }
          }
          0x4120 -> {
            val count = bb.short.toInt() and 0xFFFF
            for (i in 0 until count) {
              if (bb.position() + 8 > chunkEnd) break
              val a = bb.short.toInt() and 0xFFFF
              val b = bb.short.toInt() and 0xFFFF
              val c = bb.short.toInt() and 0xFFFF
              bb.short // flags
              if (a in verts.indices && b in verts.indices && c in verts.indices) {
                faces.add(MeshFace(a, b, c))
              }
            }
          }
        }
        bb.position(chunkEnd)
      }
    }
    walk(bytes.size)
    return if (verts.isNotEmpty() && faces.isNotEmpty()) listOf(MeshObject("obj_${System.nanoTime()}", name, verts, faces)) else emptyList()
  }

  private fun serializeObj(objects: List<MeshObject>): String {
    val sb = StringBuilder("# Exported by Vortex 3D Studio\n")
    var vOffset = 1
    for (obj in objects) {
      sb.appendLine("o ${obj.name.replace(' ', '_')}")
      val baked = bakeWorldVertices(obj)
      for (v in baked) {
        sb.appendLine(String.format(Locale.US, "v %.6f %.6f %.6f", v.x, v.y, v.z))
      }
      for (f in obj.faces) {
        sb.appendLine("f ${f.i0 + vOffset} ${f.i1 + vOffset} ${f.i2 + vOffset}")
      }
      vOffset += baked.size
    }
    return sb.toString()
  }

  private fun serializeBinaryStl(mesh: MeshObject): ByteArray {
    val bb = ByteBuffer.allocate(84 + mesh.faces.size * 50).order(ByteOrder.LITTLE_ENDIAN)
    val header = "Vortex 3D Studio Binary STL".toByteArray().copyOf(80)
    bb.put(header)
    bb.putInt(mesh.faces.size)
    for (f in mesh.faces) {
      val v0 = mesh.vertices[f.i0]; val v1 = mesh.vertices[f.i1]; val v2 = mesh.vertices[f.i2]
      val n = (v1 - v0).cross(v2 - v0).normalized()
      bb.putFloat(n.x); bb.putFloat(n.y); bb.putFloat(n.z)
      bb.putFloat(v0.x); bb.putFloat(v0.y); bb.putFloat(v0.z)
      bb.putFloat(v1.x); bb.putFloat(v1.y); bb.putFloat(v1.z)
      bb.putFloat(v2.x); bb.putFloat(v2.y); bb.putFloat(v2.z)
      bb.putShort(0)
    }
    return bb.array()
  }

  private fun serializePly(mesh: MeshObject): String {
    val sb = StringBuilder()
    sb.appendLine("ply")
    sb.appendLine("format ascii 1.0")
    sb.appendLine("element vertex ${mesh.vertices.size}")
    sb.appendLine("property float x")
    sb.appendLine("property float y")
    sb.appendLine("property float z")
    sb.appendLine("element face ${mesh.faces.size}")
    sb.appendLine("property list uchar int vertex_indices")
    sb.appendLine("end_header")
    mesh.vertices.forEach { sb.appendLine(String.format(Locale.US, "%.6f %.6f %.6f", it.x, it.y, it.z)) }
    mesh.faces.forEach { sb.appendLine("3 ${it.i0} ${it.i1} ${it.i2}") }
    return sb.toString()
  }

  private fun serializeOff(mesh: MeshObject): String {
    val sb = StringBuilder("OFF\n${mesh.vertices.size} ${mesh.faces.size} 0\n")
    mesh.vertices.forEach { sb.appendLine(String.format(Locale.US, "%.6f %.6f %.6f", it.x, it.y, it.z)) }
    mesh.faces.forEach { sb.appendLine("3 ${it.i0} ${it.i1} ${it.i2}") }
    return sb.toString()
  }

  private fun buildGltfBufferAndJson(mesh: MeshObject): Pair<String, ByteArray> {
    val vBytes = mesh.vertices.size * 12
    val iBytes = mesh.faces.size * 12
    val raw = ByteBuffer.allocate(vBytes + iBytes).order(ByteOrder.LITTLE_ENDIAN)
    var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var minZ = Float.MAX_VALUE
    var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE; var maxZ = -Float.MAX_VALUE
    for (v in mesh.vertices) {
      raw.putFloat(v.x); raw.putFloat(v.y); raw.putFloat(v.z)
      if (v.x < minX) minX = v.x; if (v.x > maxX) maxX = v.x
      if (v.y < minY) minY = v.y; if (v.y > maxY) maxY = v.y
      if (v.z < minZ) minZ = v.z; if (v.z > maxZ) maxZ = v.z
    }
    for (f in mesh.faces) {
      raw.putInt(f.i0); raw.putInt(f.i1); raw.putInt(f.i2)
    }
    val bin = raw.array()
    val json = JSONObject().apply {
      put("asset", JSONObject().apply { put("version", "2.0"); put("generator", "Vortex 3D Studio") })
      put("scene", 0)
      put("scenes", JSONArray().put(JSONObject().put("nodes", JSONArray().put(0))))
      put("nodes", JSONArray().put(JSONObject().put("mesh", 0).put("name", mesh.name)))
      put("meshes", JSONArray().put(JSONObject().apply {
        put("name", mesh.name)
        put("primitives", JSONArray().put(JSONObject().apply {
          put("attributes", JSONObject().put("POSITION", 0))
          put("indices", 1)
        }))
      }))
      put("bufferViews", JSONArray()
        .put(JSONObject().put("buffer", 0).put("byteOffset", 0).put("byteLength", vBytes))
        .put(JSONObject().put("buffer", 0).put("byteOffset", vBytes).put("byteLength", iBytes)))
      put("accessors", JSONArray()
        .put(JSONObject().apply {
          put("bufferView", 0); put("componentType", 5126); put("count", mesh.vertices.size); put("type", "VEC3")
          put("min", JSONArray().put(minX).put(minY).put(minZ))
          put("max", JSONArray().put(maxX).put(maxY).put(maxZ))
        })
        .put(JSONObject().apply {
          put("bufferView", 1); put("componentType", 5125); put("count", mesh.faces.size * 3); put("type", "SCALAR")
        }))
      put("buffers", JSONArray().put(JSONObject().put("byteLength", bin.size)))
    }
    return json.toString() to bin
  }

  private fun serializeGltfJson(mesh: MeshObject): String {
    val (jsonText, bin) = buildGltfBufferAndJson(mesh)
    val root = JSONObject(jsonText)
    val b64 = android.util.Base64.encodeToString(bin, android.util.Base64.NO_WRAP)
    root.getJSONArray("buffers").getJSONObject(0).put("uri", "data:application/octet-stream;base64,$b64")
    return root.toString(2)
  }

  private fun serializeGlb(mesh: MeshObject): ByteArray {
    val (jsonRaw, binRaw) = buildGltfBufferAndJson(mesh)
    val jsonBytes = jsonRaw.toByteArray(Charsets.UTF_8)
    val jsonPad = (4 - jsonBytes.size % 4) % 4
    val binPad = (4 - binRaw.size % 4) % 4
    val totalLen = 12 + 8 + jsonBytes.size + jsonPad + 8 + binRaw.size + binPad
    val bb = ByteBuffer.allocate(totalLen).order(ByteOrder.LITTLE_ENDIAN)
    bb.putInt(0x46546C67); bb.putInt(2); bb.putInt(totalLen)
    bb.putInt(jsonBytes.size + jsonPad); bb.putInt(0x4E4F534A)
    bb.put(jsonBytes); repeat(jsonPad) { bb.put(0x20.toByte()) }
    bb.putInt(binRaw.size + binPad); bb.putInt(0x004E4942)
    bb.put(binRaw); repeat(binPad) { bb.put(0) }
    return bb.array()
  }

  private fun serializeDae(mesh: MeshObject): String {
    val floats = mesh.vertices.joinToString(" ") { String.format(Locale.US, "%.5f %.5f %.5f", it.x, it.y, it.z) }
    val indices = mesh.faces.joinToString(" ") { "${it.i0} ${it.i1} ${it.i2}" }
    return """<?xml version="1.0" encoding="utf-8"?>
<COLLADA xmlns="http://www.collada.org/2005/11/COLLADASchema" version="1.4.1">
  <asset><up_axis>Y_UP</up_axis></asset>
  <library_geometries>
    <geometry id="mesh-id" name="${mesh.name}">
      <mesh>
        <source id="pos-src">
          <float_array id="pos-arr" count="${mesh.vertices.size * 3}">$floats</float_array>
          <technique_common><accessor source="#pos-arr" count="${mesh.vertices.size}" stride="3">
            <param name="X" type="float"/><param name="Y" type="float"/><param name="Z" type="float"/>
          </accessor></technique_common>
        </source>
        <vertices id="verts"><input semantic="POSITION" source="#pos-src"/></vertices>
        <triangles count="${mesh.faces.size}">
          <input semantic="VERTEX" source="#verts" offset="0"/>
          <p>$indices</p>
        </triangles>
      </mesh>
    </geometry>
  </library_geometries>
  <library_visual_scenes>
    <visual_scene id="Scene"><node id="Model"><instance_geometry url="#mesh-id"/></node></visual_scene>
  </library_visual_scenes>
  <scene><instance_visual_scene url="#Scene"/></scene>
</COLLADA>"""
  }

  private fun serialize3ds(mesh: MeshObject): ByteArray {
    val vCount = mesh.vertices.size.coerceAtMost(65535)
    val fCount = mesh.faces.size.coerceAtMost(65535)
    val vertData = ByteBuffer.allocate(2 + vCount * 12).order(ByteOrder.LITTLE_ENDIAN).apply {
      putShort(vCount.toShort())
      for (i in 0 until vCount) {
        val v = mesh.vertices[i]
        putFloat(v.x); putFloat(v.y); putFloat(v.z)
      }
    }.array()
    val faceData = ByteBuffer.allocate(2 + fCount * 8).order(ByteOrder.LITTLE_ENDIAN).apply {
      putShort(fCount.toShort())
      for (i in 0 until fCount) {
        val f = mesh.faces[i]
        putShort(f.i0.toShort()); putShort(f.i1.toShort()); putShort(f.i2.toShort()); putShort(0)
      }
    }.array()

    fun chunk(id: Int, payload: ByteArray): ByteArray {
      return ByteBuffer.allocate(6 + payload.size).order(ByteOrder.LITTLE_ENDIAN)
        .putShort(id.toShort()).putInt(6 + payload.size).put(payload).array()
    }

    val triMesh = chunk(0x4100, chunk(0x4110, vertData) + chunk(0x4120, faceData))
    val objNameBytes = (mesh.name.take(16) + "\u0000").toByteArray(Charsets.US_ASCII)
    val namedObj = chunk(0x4000, objNameBytes + triMesh)
    val editor = chunk(0x3D3D, namedObj)
    return chunk(0x4D4D, editor)
  }
}
