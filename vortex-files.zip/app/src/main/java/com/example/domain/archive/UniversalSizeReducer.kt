package com.example.domain.archive

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.example.domain.fs.FileCategory
import com.example.domain.fs.VirtualFileNode
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class VideoTargetResolution(val heightPx: Int, val bitrateBps: Int, val label: String) {
  RES_360P(360, 650_000, "360p (Ultra Small)"),
  RES_480P(480, 1_100_000, "480p (Compact)"),
  RES_720P(720, 2_200_000, "720p (Balanced)"),
}

enum class AudioTargetBitrate(val bitrateBps: Int, val label: String) {
  KBPS_48(48_000, "48 kbps (Voice/Ultra Small)"),
  KBPS_96(96_000, "96 kbps (Compact)"),
  KBPS_128(128_000, "128 kbps (Standard)"),
}

data class UniversalReductionRequest(
  val qualityPercent: Int = 70,
  val scalePercent: Int = 75,
  val videoResolution: VideoTargetResolution = VideoTargetResolution.RES_480P,
  val stripVideoAudio: Boolean = false,
  val audioBitrate: AudioTargetBitrate = AudioTargetBitrate.KBPS_96,
  val pdfQualityPercent: Int = 65,
  val pdfScalePercent: Int = 70,
)

data class UniversalReductionResult(
  val outputFiles: List<File>,
  val originalBytes: Long,
  val reducedBytes: Long,
) {
  val savedPercent: Int
    get() =
      if (originalBytes <= 0L) 0
      else (((originalBytes - reducedBytes) * 100L) / originalBytes).toInt()
}

class UniversalSizeReducer(
  private val context: Context,
  private val mediaCompressionEngine: MediaCompressionEngine,
  private val archiveEngine: ArchiveEngine,
) {

  suspend fun reduceFiles(
    nodes: List<VirtualFileNode>,
    outputDir: File,
    request: UniversalReductionRequest,
    onProgress: (Int) -> Unit = {},
  ): UniversalReductionResult {
    outputDir.mkdirs()
    val files = nodes.map { File(it.path) }.filter { it.exists() }
    val outFiles = mutableListOf<File>()
    var origTotal = 0L
    var reducedTotal = 0L
    val total = files.size.coerceAtLeast(1)

    for ((idx, file) in files.withIndex()) {
      origTotal += if (file.isDirectory) 0L else file.length()
      val node = nodes[idx]
      val baseProgress = (idx * 100) / total
      val sliceWeight = 100 / total

      val produced: File? =
        when (node.category) {
          FileCategory.IMAGE -> {
            val summary =
              mediaCompressionEngine.compressImages(
                inputFiles = listOf(file),
                outputDir = outputDir,
                mode = CompressionMode.LOSSY,
                quality = request.qualityPercent,
                scalePercent = request.scalePercent,
                targetFormat = ImageOutputFormat.JPEG,
              ) { p -> onProgress(baseProgress + (p * sliceWeight) / 100) }
            summary.outputFiles.firstOrNull()
          }

          FileCategory.VIDEO -> {
            val out = uniqueFile(outputDir, "${file.nameWithoutExtension}_reduced_${request.videoResolution.heightPx}p.mp4")
            reduceVideo(file, out, request) { p ->
              onProgress(baseProgress + (p * sliceWeight) / 100)
            }
          }

          FileCategory.AUDIO -> {
            val out = uniqueFile(outputDir, "${file.nameWithoutExtension}_${request.audioBitrate.bitrateBps / 1000}k.m4a")
            reduceAudio(file, out, request.audioBitrate) { p ->
              onProgress(baseProgress + (p * sliceWeight) / 100)
            }
          }

          FileCategory.PDF -> {
            val out = uniqueFile(outputDir, "${file.nameWithoutExtension}_compact.pdf")
            reducePdf(file, out, request.pdfQualityPercent, request.pdfScalePercent) { p ->
              onProgress(baseProgress + (p * sliceWeight) / 100)
            }
          }

          FileCategory.CODE -> {
            val out = uniqueFile(outputDir, "${file.nameWithoutExtension}.min.${file.extension}")
            minifyCodeOrText(file, out)
          }

          else -> {
            val out = uniqueFile(outputDir, "${file.nameWithoutExtension}_ultra.7z")
            archiveEngine.createArchive(listOf(file), out, ArchiveFormat.SEVEN_Z, level = 9) { p ->
              onProgress(baseProgress + (p * sliceWeight) / 100)
            }
          }
        }

      if (produced != null && produced.exists()) {
        outFiles.add(produced)
        reducedTotal += produced.length()
      }
      onProgress(((idx + 1) * 100) / total)
    }

    return UniversalReductionResult(outFiles, origTotal, reducedTotal)
  }

  @OptIn(UnstableApi::class)
  private suspend fun reduceVideo(
    input: File,
    output: File,
    request: UniversalReductionRequest,
    onProgress: (Int) -> Unit,
  ): File =
    withContext(Dispatchers.Main) {
      suspendCancellableCoroutine { cont ->
        val mainHandler = Handler(Looper.getMainLooper())
        val listener =
          object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
              onProgress(100)
              if (cont.isActive) cont.resume(output)
            }

            override fun onError(
              composition: Composition,
              exportResult: ExportResult,
              exportException: ExportException,
            ) {
              if (cont.isActive) cont.resumeWithException(exportException)
            }
          }

        val encoderFactory =
          DefaultEncoderFactory.Builder(context)
            .setRequestedVideoEncoderSettings(
              VideoEncoderSettings.Builder()
                .setBitrate(request.videoResolution.bitrateBps)
                .build()
            )
            .build()

        val transformer =
          Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(listener)
            .build()

        val effects =
          Effects(
            emptyList(),
            listOf(Presentation.createForHeight(request.videoResolution.heightPx)),
          )

        val edited =
          EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input)))
            .setRemoveAudio(request.stripVideoAudio)
            .setEffects(effects)
            .build()

        transformer.start(edited, output.absolutePath)

        val holder = ProgressHolder()
        val poll =
          object : Runnable {
            override fun run() {
              if (!cont.isActive) return
              val state = transformer.getProgress(holder)
              if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                onProgress(holder.progress.coerceIn(0, 99))
              }
              if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                mainHandler.postDelayed(this, 250)
              }
            }
          }
        mainHandler.post(poll)
        cont.invokeOnCancellation { mainHandler.post { transformer.cancel() } }
      }
    }

  @OptIn(UnstableApi::class)
  private suspend fun reduceAudio(
    input: File,
    output: File,
    bitrate: AudioTargetBitrate,
    onProgress: (Int) -> Unit,
  ): File =
    withContext(Dispatchers.Main) {
      suspendCancellableCoroutine { cont ->
        val mainHandler = Handler(Looper.getMainLooper())
        val listener =
          object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
              onProgress(100)
              if (cont.isActive) cont.resume(output)
            }

            override fun onError(
              composition: Composition,
              exportResult: ExportResult,
              exportException: ExportException,
            ) {
              if (cont.isActive) cont.resumeWithException(exportException)
            }
          }

        val transformer =
          Transformer.Builder(context)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(listener)
            .build()

        val edited =
          EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input)))
            .setRemoveVideo(true)
            .build()

        transformer.start(edited, output.absolutePath)

        val holder = ProgressHolder()
        val poll =
          object : Runnable {
            override fun run() {
              if (!cont.isActive) return
              val state = transformer.getProgress(holder)
              if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                onProgress(holder.progress.coerceIn(0, 99))
              }
              if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                mainHandler.postDelayed(this, 250)
              }
            }
          }
        mainHandler.post(poll)
        cont.invokeOnCancellation { mainHandler.post { transformer.cancel() } }
      }
    }

  private suspend fun reducePdf(
    input: File,
    output: File,
    qualityPercent: Int,
    scalePercent: Int,
    onProgress: (Int) -> Unit,
  ): File =
    withContext(Dispatchers.IO) {
      val pdf = PdfDocument()
      val scale = scalePercent.coerceIn(25, 100) / 100f
      val pfd = ParcelFileDescriptor.open(input, ParcelFileDescriptor.MODE_READ_ONLY)
      pfd.use { fd ->
        PdfRenderer(fd).use { renderer ->
          val total = renderer.pageCount.coerceAtLeast(1)
          for (i in 0 until renderer.pageCount) {
            renderer.openPage(i).use { page ->
              val w = (page.width * scale).toInt().coerceAtLeast(100)
              val h = (page.height * scale).toInt().coerceAtLeast(100)
              val rawBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
              rawBmp.eraseColor(Color.WHITE)
              page.render(rawBmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

              val jpgBytes = ByteArrayOutputStream()
              rawBmp.compress(Bitmap.CompressFormat.JPEG, qualityPercent.coerceIn(20, 95), jpgBytes)
              rawBmp.recycle()

              val compressedBmp = android.graphics.BitmapFactory.decodeByteArray(jpgBytes.toByteArray(), 0, jpgBytes.size())
              val pageInfo = PdfDocument.PageInfo.Builder(page.width, page.height, i + 1).create()
              val outPage = pdf.startPage(pageInfo)
              outPage.canvas.drawBitmap(compressedBmp, null, Rect(0, 0, page.width, page.height), null)
              pdf.finishPage(outPage)
              compressedBmp.recycle()
              onProgress(((i + 1) * 100) / total)
            }
          }
        }
      }
      FileOutputStream(output).use { pdf.writeTo(it) }
      pdf.close()
      output
    }

  private suspend fun minifyCodeOrText(input: File, output: File): File =
    withContext(Dispatchers.IO) {
      val text = input.readText()
      val minified =
        when (input.extension.lowercase()) {
          "json" -> {
            val t = text.trim()
            runCatching {
              if (t.startsWith("{")) JSONObject(t).toString()
              else if (t.startsWith("[")) JSONArray(t).toString()
              else t
            }.getOrElse { t }
          }
          "xml", "html", "htm", "svg" ->
            text.replace(Regex(">\\s+<"), "><").replace(Regex("\\s{2,}"), " ").trim()
          else ->
            text.lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
        }
      output.writeText(minified)
      output
    }

  private fun uniqueFile(dir: File, name: String): File {
    var candidate = File(dir, name)
    if (!candidate.exists()) return candidate
    val base = name.substringBeforeLast('.')
    val ext = name.substringAfterLast('.', "")
    var n = 1
    while (candidate.exists()) {
      candidate = File(dir, "${base}_$n.$ext")
      n++
    }
    return candidate
  }
}
