package com.example.domain.media

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

data class VideoEditSpec(
  val trimStartMs: Long = 0L,
  val trimEndMs: Long = 0L,     // <= 0 means full length
  val speedMultiplier: Float = 1f, // 0.5 .. 2.0
  val contrast: Float = 0f,        // -0.5 .. +0.5
  val saturation: Float = 0f,      // -100 .. +100
  val hueShift: Float = 0f,        // -180 .. +180
  val lightness: Float = 0f,       // -100 .. +100
  val muteAudio: Boolean = false,
  val audioGainMultiplier: Float = 1f, // 0.2 .. 3.0
  val simpleNoiseGate: Boolean = false,
)

class VideoEditorEngine(private val context: Context) {

  @OptIn(UnstableApi::class)
  suspend fun exportEditedVideo(
    inputVideo: File,
    outputVideo: File,
    spec: VideoEditSpec,
    onProgress: (Int) -> Unit = {},
  ): File {
    outputVideo.parentFile?.mkdirs()
    if (outputVideo.exists()) outputVideo.delete()

    return withContext(Dispatchers.Main) {
      suspendCancellableCoroutine { cont ->
        val mainHandler = Handler(Looper.getMainLooper())
        val listener = object : Transformer.Listener {
          override fun onCompleted(composition: Composition, exportResult: ExportResult) {
            onProgress(100)
            if (cont.isActive) cont.resume(outputVideo)
          }

          override fun onError(
            composition: Composition,
            exportResult: ExportResult,
            exportException: ExportException,
          ) {
            if (cont.isActive) cont.resumeWithException(exportException)
          }
        }

        val transformer = Transformer.Builder(context).addListener(listener).build()

        val mediaBuilder = MediaItem.Builder().setUri(Uri.fromFile(inputVideo))
        if (spec.trimStartMs > 0L || spec.trimEndMs > spec.trimStartMs) {
          val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(spec.trimStartMs.coerceAtLeast(0L))
          if (spec.trimEndMs > spec.trimStartMs) clip.setEndPositionMs(spec.trimEndMs)
          mediaBuilder.setClippingConfiguration(clip.build())
        }

        val videoEffects = mutableListOf<Effect>()
        if (spec.contrast != 0f) {
          videoEffects.add(Contrast(spec.contrast.coerceIn(-0.9f, 0.9f)))
        }
        if (spec.hueShift != 0f || spec.saturation != 0f || spec.lightness != 0f) {
          videoEffects.add(
            HslAdjustment.Builder()
              .adjustHue(spec.hueShift)
              .adjustSaturation(spec.saturation)
              .adjustLightness(spec.lightness)
              .build()
          )
        }
        if (spec.speedMultiplier != 1f) {
          videoEffects.add(SpeedChangeEffect(spec.speedMultiplier.coerceIn(0.25f, 4f)))
        }

        val audioProcessors = mutableListOf<AudioProcessor>()
        if (!spec.muteAudio && (spec.audioGainMultiplier != 1f || spec.simpleNoiseGate)) {
          audioProcessors.add(GainAndGateAudioProcessor(spec.audioGainMultiplier, spec.simpleNoiseGate))
        }

        val edited = EditedMediaItem.Builder(mediaBuilder.build())
          .setRemoveAudio(spec.muteAudio)
          .setEffects(Effects(audioProcessors, videoEffects))
          .build()

        transformer.start(edited, outputVideo.absolutePath)

        val progressHolder = ProgressHolder()
        val poll = object : Runnable {
          override fun run() {
            if (!cont.isActive) return
            val st = transformer.getProgress(progressHolder)
            if (st == Transformer.PROGRESS_STATE_AVAILABLE) {
              onProgress(progressHolder.progress.coerceIn(0, 99))
            }
            if (st != Transformer.PROGRESS_STATE_NOT_STARTED) {
              mainHandler.postDelayed(this, 250)
            }
          }
        }
        mainHandler.post(poll)

        cont.invokeOnCancellation { mainHandler.post { transformer.cancel() } }
      }
    }
  }
}

@OptIn(UnstableApi::class)
private class GainAndGateAudioProcessor(
  private val gain: Float,
  private val noiseGate: Boolean,
) : AudioProcessor {
  private var inputAudioFormat = AudioProcessor.AudioFormat.NOT_SET
  private var outputAudioFormat = AudioProcessor.AudioFormat.NOT_SET
  private var buffer = AudioProcessor.EMPTY_BUFFER
  private var outBuffer = AudioProcessor.EMPTY_BUFFER
  private var inputEnded = false

  override fun configure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
    this.inputAudioFormat = inputAudioFormat
    this.outputAudioFormat = inputAudioFormat
    return inputAudioFormat
  }

  override fun isActive(): Boolean = gain != 1f || noiseGate

  override fun queueInput(inputBuffer: ByteBuffer) {
    val rem = inputBuffer.remaining()
    if (rem == 0) return
    if (buffer.capacity() < rem) {
      buffer = ByteBuffer.allocateDirect(rem).order(ByteOrder.nativeOrder())
    } else {
      buffer.clear()
    }
    while (inputBuffer.remaining() >= 2) {
      var sample = inputBuffer.short.toInt()
      if (noiseGate && kotlin.math.abs(sample) < 380) sample = (sample * 0.2f).toInt()
      val scaled = (sample * gain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
      buffer.putShort(scaled.toShort())
    }
    buffer.flip()
    outBuffer = buffer
  }

  override fun queueEndOfStream() { inputEnded = true }
  override fun getOutput(): ByteBuffer {
    val out = outBuffer
    outBuffer = AudioProcessor.EMPTY_BUFFER
    return out
  }
  override fun isEnded(): Boolean = inputEnded && outBuffer === AudioProcessor.EMPTY_BUFFER
  override fun flush() { outBuffer = AudioProcessor.EMPTY_BUFFER; inputEnded = false }
  override fun reset() { flush(); buffer = AudioProcessor.EMPTY_BUFFER }
}
