package com.example.domain.media

import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.util.TypedValue
import android.view.Display
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import androidx.compose.ui.graphics.toArgb
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class VideoCastPresentation(
  outerContext: Context,
  display: Display,
  private val player: ExoPlayer,
) : Presentation(outerContext, display) {

  private lateinit var playerView: PlayerView
  private lateinit var subtitleView: TextView

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    val root =
      FrameLayout(context).apply {
        setBackgroundColor(Color.BLACK)
      }

    playerView =
      PlayerView(context).apply {
        this.player = this@VideoCastPresentation.player
        useController = false
      }

    subtitleView =
      TextView(context).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        setTypeface(typeface, Typeface.BOLD)
        setShadowLayer(4f, 1.5f, 1.5f, Color.BLACK)
        setBackgroundColor(Color.argb(150, 0, 0, 0))
        setPadding(24, 10, 24, 10)
        gravity = Gravity.CENTER
        visibility = TextView.GONE
      }

    val subParams =
      FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.WRAP_CONTENT,
        FrameLayout.LayoutParams.WRAP_CONTENT,
      ).apply {
        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        bottomMargin = 56
      }

    root.addView(
      playerView,
      FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.MATCH_PARENT,
        FrameLayout.LayoutParams.MATCH_PARENT,
      ),
    )
    root.addView(subtitleView, subParams)
    setContentView(root)
  }

  fun updateSubtitle(text: String?, style: SubtitleStyleConfig) {
    if (!::subtitleView.isInitialized) return
    if (text.isNullOrBlank()) {
      subtitleView.visibility = TextView.GONE
    } else {
      subtitleView.visibility = TextView.VISIBLE
      subtitleView.text = text
      subtitleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, (style.fontSizeSp + 4).toFloat())
      subtitleView.setTextColor(style.textColor.toArgb())
      subtitleView.setBackgroundColor(
        Color.argb((style.backgroundAlpha * 255).toInt().coerceIn(0, 255), 0, 0, 0)
      )
    }
  }

  override fun onStop() {
    if (::playerView.isInitialized) {
      playerView.player = null
    }
    super.onStop()
  }

  companion object {
    fun getPresentationDisplays(context: Context): List<Display> {
      val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
      return dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION).toList()
    }
  }
}
