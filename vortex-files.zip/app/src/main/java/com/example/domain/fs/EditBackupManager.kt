package com.example.domain.fs

import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class VortexBackupMetadata(
  val backupFilePath: String,
  val originalPath: String,
  val originalName: String,
  val originalSize: Long,
  val compressedSize: Long,
  val createdAt: Long,
  val sha256: String,
)

object EditBackupManager {
  const val BACKUP_EXTENSION = "vortexbak"
  private const val META_ENTRY = "vortex_backup_meta.json"
  private const val PAYLOAD_ENTRY = "original_payload.bin"

  fun isBackupFile(nameOrPath: String): Boolean =
    nameOrPath.lowercase().endsWith(".$BACKUP_EXTENSION")

  fun backupFileFor(originalPath: String): File {
    val src = File(originalPath)
    val parent = src.parentFile ?: File(".")
    return File(parent, "${src.name}.$BACKUP_EXTENSION")
  }

  suspend fun createSnapshotBeforeEdit(originalPath: String): File? =
    withContext(Dispatchers.IO) {
      val src = File(originalPath)
      if (!src.exists() || !src.isFile || !src.canRead()) return@withContext null
      if (isBackupFile(src.name)) return@withContext null
      val bytes = runCatching { src.readBytes() }.getOrNull() ?: return@withContext null
      val sha256 = sha256Hex(bytes)
      val outFile = backupFileFor(src.absolutePath)
      val meta =
        JSONObject().apply {
          put("originalPath", src.absolutePath)
          put("originalName", src.name)
          put("originalSize", bytes.size.toLong())
          put("createdAt", System.currentTimeMillis())
          put("sha256", sha256)
        }
      runCatching {
        outFile.parentFile?.mkdirs()
        ZipOutputStream(FileOutputStream(outFile)).use { zos ->
          zos.setLevel(Deflater.BEST_COMPRESSION)
          zos.putNextEntry(ZipEntry(META_ENTRY))
          zos.write(meta.toString(2).toByteArray(Charsets.UTF_8))
          zos.closeEntry()

          zos.putNextEntry(ZipEntry(PAYLOAD_ENTRY))
          zos.write(bytes)
          zos.closeEntry()
        }
        outFile
      }.getOrNull()
    }

  suspend fun inspectBackup(backupFile: File): VortexBackupMetadata? =
    withContext(Dispatchers.IO) {
      if (!backupFile.exists() || !backupFile.isFile) return@withContext null
      runCatching {
        ZipFile(backupFile).use { zf ->
          val metaEntry = zf.getEntry(META_ENTRY) ?: return@use null
          val metaJson = zf.getInputStream(metaEntry).bufferedReader().use { it.readText() }
          val obj = JSONObject(metaJson)
          VortexBackupMetadata(
            backupFilePath = backupFile.absolutePath,
            originalPath = obj.optString("originalPath", backupFile.absolutePath.removeSuffix(".$BACKUP_EXTENSION")),
            originalName = obj.optString("originalName", backupFile.name.removeSuffix(".$BACKUP_EXTENSION")),
            originalSize = obj.optLong("originalSize", 0L),
            compressedSize = backupFile.length(),
            createdAt = obj.optLong("createdAt", backupFile.lastModified()),
            sha256 = obj.optString("sha256", ""),
          )
        }
      }.getOrNull()
    }

  suspend fun restoreBackup(backupFile: File): Result<File> =
    withContext(Dispatchers.IO) {
      runCatching {
        val meta = inspectBackup(backupFile)
          ?: throw IllegalArgumentException("Invalid or corrupted .vortexbak archive")
        val targetFile = File(meta.originalPath).let { desired ->
          if (desired.parentFile?.exists() == true || desired.parentFile?.mkdirs() == true) {
            desired
          } else {
            File(backupFile.parentFile ?: File("."), meta.originalName)
          }
        }
        ZipFile(backupFile).use { zf ->
          val payloadEntry = zf.getEntry(PAYLOAD_ENTRY)
            ?: throw IllegalStateException("Backup payload missing")
          val payload = zf.getInputStream(payloadEntry).use { it.readBytes() }
          targetFile.parentFile?.mkdirs()
          FileOutputStream(targetFile).use { it.write(payload) }
        }
        targetFile
      }
    }

  private fun sha256Hex(bytes: ByteArray): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
    return digest.joinToString("") { "%02x".format(it) }
  }
}
