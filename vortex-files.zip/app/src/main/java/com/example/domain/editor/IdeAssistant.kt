package com.example.domain.editor

import java.io.StringReader
import javax.xml.parsers.DocumentBuilderFactory
import org.json.JSONArray
import org.json.JSONObject
import org.xml.sax.InputSource

data class CodeDiagnostic(
  val line: Int,
  val message: String,
  val isError: Boolean = true,
)

data class CodeSymbol(
  val name: String,
  val kind: String,
  val lineNumber: Int,
)

data class IdeCompletion(
  val label: String,
  val insertText: String,
  val detail: String,
)

object IdeAssistant {

  fun suggestCompletions(code: String, language: CodeLanguage): List<IdeCompletion> {
    val lastWord =
      code.takeLastWhile { it.isLetterOrDigit() || it == '_' || it == '.' || it == '<' }
        .lowercase()

    val base =
      when (language) {
        CodeLanguage.KOTLIN ->
          listOf(
            IdeCompletion("fun", "fun name() {\n  \n}", "Function"),
            IdeCompletion("println", "println(\"\")", "Print line"),
            IdeCompletion("data class", "data class Item(val id: Int)", "Data class"),
            IdeCompletion("when", "when (x) {\n  else -> Unit\n}", "Branch"),
            IdeCompletion("val", "val value = ", "Immutable"),
            IdeCompletion("forEach", "forEach { item ->\n  \n}", "Loop"),
          )
        CodeLanguage.JAVA ->
          listOf(
            IdeCompletion("System.out", "System.out.println(\"\");", "Print"),
            IdeCompletion("public class", "public class Main {\n  \n}", "Class"),
            IdeCompletion("psvm", "public static void main(String[] args) {\n  \n}", "Main method"),
            IdeCompletion("for", "for (int i = 0; i < n; i++) {\n  \n}", "For loop"),
          )
        CodeLanguage.PYTHON ->
          listOf(
            IdeCompletion("def", "def solve():\n    pass", "Function"),
            IdeCompletion("print", "print(\"\")", "Output"),
            IdeCompletion("for range", "for i in range(10):\n    print(i)", "Range loop"),
            IdeCompletion("import", "import json", "Import"),
            IdeCompletion("if main", "if __name__ == \"__main__\":\n    ", "Entry"),
          )
        CodeLanguage.JAVASCRIPT ->
          listOf(
            IdeCompletion("console.log", "console.log();", "Console log"),
            IdeCompletion("function", "function run() {\n  \n}", "Function"),
            IdeCompletion("const", "const value = ;", "Constant"),
            IdeCompletion("async", "async function fetchJson(url) {\n  const r = await fetch(url);\n  return r.json();\n}", "Async"),
            IdeCompletion("map", ".map((x) => x)", "Array map"),
          )
        CodeLanguage.SQL ->
          listOf(
            IdeCompletion("SELECT", "SELECT * FROM table_name LIMIT 50;", "Query"),
            IdeCompletion("CREATE TABLE", "CREATE TABLE items (id INTEGER PRIMARY KEY, name TEXT);", "DDL"),
            IdeCompletion("INSERT INTO", "INSERT INTO items (name) VALUES ('sample');", "Insert"),
            IdeCompletion("WHERE", "WHERE id = 1", "Filter"),
            IdeCompletion("ORDER BY", "ORDER BY id DESC", "Sort"),
          )
        CodeLanguage.SHELL ->
          listOf(
            IdeCompletion("echo", "echo \"Hello\"", "Print"),
            IdeCompletion("ls -la", "ls -la", "List files"),
            IdeCompletion("chmod", "chmod 755 ", "Permissions"),
            IdeCompletion("grep -rn", "grep -rn \"pattern\" .", "Search"),
            IdeCompletion("if [", "if [ -f \"file\" ]; then\n  \nfi", "Condition"),
          )
        CodeLanguage.XML ->
          listOf(
            IdeCompletion("div", "<div></div>", "Element"),
            IdeCompletion("html5", "<!DOCTYPE html>\n<html>\n<body>\n  <h1>Hello</h1>\n</body>\n</html>", "HTML5"),
            IdeCompletion("uses-permission", "<uses-permission android:name=\"android.permission.INTERNET\" />", "Manifest"),
          )
        CodeLanguage.JSON ->
          listOf(
            IdeCompletion("\"key\": \"\"", "\"key\": \"value\"", "String field"),
            IdeCompletion("\"items\": []", "\"items\": []", "Array field"),
          )
        CodeLanguage.SMALI ->
          listOf(
            IdeCompletion(".method", ".method public static run()V\n    .locals 1\n    return-void\n.end method", "Method"),
            IdeCompletion("const-string", "const-string v0, \"\"", "String"),
          )
        CodeLanguage.PLAIN ->
          listOf(
            IdeCompletion("# Heading", "# Title\n", "Markdown H1"),
            IdeCompletion("- Item", "- ", "List item"),
          )
      }

    return if (lastWord.isBlank()) base
    else {
      val filtered = base.filter { it.label.lowercase().contains(lastWord) }
      filtered.ifEmpty { base }
    }
  }

  fun analyzeDiagnostics(code: String, language: CodeLanguage): List<CodeDiagnostic> {
    if (code.isBlank()) return emptyList()
    val diagnostics = mutableListOf<CodeDiagnostic>()

    if (language == CodeLanguage.JSON) {
      val t = code.trim()
      runCatching {
        if (t.startsWith("{")) JSONObject(t) else JSONArray(t)
      }.onFailure { e ->
        diagnostics.add(CodeDiagnostic(1, e.message ?: "Invalid JSON syntax"))
      }
      return diagnostics
    }

    if (language == CodeLanguage.XML && code.trimStart().startsWith("<") && !code.contains("<!DOCTYPE html", ignoreCase = true)) {
      runCatching {
        val factory = DocumentBuilderFactory.newInstance()
        factory.newDocumentBuilder().parse(InputSource(StringReader(code)))
      }.onFailure { e ->
        diagnostics.add(CodeDiagnostic(1, e.message ?: "Malformed XML"))
      }
    }

    // Bracket & delimiter matching across code languages
    if (language != CodeLanguage.PLAIN) {
      val stack = ArrayDeque<Pair<Char, Int>>()
      val pairs = mapOf(')' to '(', '}' to '{', ']' to '[')
      var inSingle = false
      var inDouble = false
      var lineNum = 1
      for (i in code.indices) {
        val c = code[i]
        if (c == '\n') lineNum++
        val prev = if (i > 0) code[i - 1] else ' '
        if (c == '"' && prev != '\\' && !inSingle) inDouble = !inDouble
        else if (c == '\'' && prev != '\\' && !inDouble) inSingle = !inSingle
        if (inSingle || inDouble) continue

        if (c == '(' || c == '{' || c == '[') {
          stack.addLast(c to lineNum)
        } else if (c in pairs.keys) {
          val expected = pairs[c]
          if (stack.isEmpty()) {
            diagnostics.add(CodeDiagnostic(lineNum, "Unmatched '$c'"))
          } else {
            val (top, topLine) = stack.removeLast()
            if (top != expected) {
              diagnostics.add(CodeDiagnostic(lineNum, "Expected matching for '$top' (line $topLine) before '$c'"))
            }
          }
        }
      }
      for ((open, ln) in stack) {
        diagnostics.add(CodeDiagnostic(ln, "Unclosed '$open'"))
      }
    }
    return diagnostics.take(15)
  }

  fun extractSymbols(code: String, language: CodeLanguage): List<CodeSymbol> {
    val symbols = mutableListOf<CodeSymbol>()
    val lines = code.lines()
    lines.forEachIndexed { idx, raw ->
      val lineNo = idx + 1
      val line = raw.trim()
      when (language) {
        CodeLanguage.KOTLIN -> {
          Regex("""\b(class|interface|object|enum class|fun)\s+([A-Za-z_]\w*)""").find(line)?.let {
            symbols.add(CodeSymbol(it.groupValues[2], it.groupValues[1], lineNo))
          }
        }
        CodeLanguage.JAVA -> {
          Regex("""\b(class|interface|enum)\s+([A-Za-z_]\w*)""").find(line)?.let {
            symbols.add(CodeSymbol(it.groupValues[2], it.groupValues[1], lineNo))
          }
          Regex("""(?:public|private|protected)\s+[\w<>\[\]]+\s+([A-Za-z_]\w*)\s*\(""").find(line)?.let {
            symbols.add(CodeSymbol(it.groupValues[1], "method", lineNo))
          }
        }
        CodeLanguage.PYTHON -> {
          Regex("""^(def|class)\s+([A-Za-z_]\w*)""").find(line)?.let {
            symbols.add(CodeSymbol(it.groupValues[2], it.groupValues[1], lineNo))
          }
        }
        CodeLanguage.JAVASCRIPT -> {
          Regex("""\b(?:async\s+)?function\s+([A-Za-z_$][\w$]*)""").find(line)?.let {
            symbols.add(CodeSymbol(it.groupValues[1], "function", lineNo))
          }
          Regex("""\b(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\(""").find(line)?.let {
            symbols.add(CodeSymbol(it.groupValues[1], "fn", lineNo))
          }
        }
        CodeLanguage.SQL -> {
          Regex("""(?i)CREATE\s+(?:TABLE|VIEW|INDEX)\s+(?:IF\s+NOT\s+EXISTS\s+)?([A-Za-z_]\w*)""").find(line)?.let {
            symbols.add(CodeSymbol(it.groupValues[1], "table", lineNo))
          }
        }
        CodeLanguage.SMALI -> {
          if (line.startsWith(".method ")) {
            symbols.add(CodeSymbol(line.removePrefix(".method ").trim(), "method", lineNo))
          } else if (line.startsWith(".field ")) {
            symbols.add(CodeSymbol(line.removePrefix(".field ").trim(), "field", lineNo))
          }
        }
        CodeLanguage.SHELL -> {
          Regex("""^([A-Za-z_]\w*)\s*\(\)\s*\{""").find(line)?.let {
            symbols.add(CodeSymbol(it.groupValues[1], "func", lineNo))
          }
        }
        CodeLanguage.XML -> {
          Regex("""<([A-Za-z_][\w:.-]*)\b[^>]*android:id="@+id/([^"]+)"""").find(line)?.let {
            symbols.add(CodeSymbol("@+id/${it.groupValues[2]}", it.groupValues[1], lineNo))
          }
        }
        else -> Unit
      }
    }
    return symbols
  }

  fun formatCode(code: String, language: CodeLanguage): String {
    if (language == CodeLanguage.JSON) {
      val t = code.trim()
      return runCatching {
        when {
          t.startsWith("{") -> JSONObject(t).toString(2)
          t.startsWith("[") -> JSONArray(t).toString(2)
          else -> code
        }
      }.getOrElse { code }
    }

    // Brace-based auto-indentation for C-style / JS / Kotlin / Java / Shell
    if (language in setOf(CodeLanguage.KOTLIN, CodeLanguage.JAVA, CodeLanguage.JAVASCRIPT, CodeLanguage.SHELL)) {
      val out = StringBuilder()
      var indent = 0
      for (raw in code.lines()) {
        val trimmed = raw.trim()
        if (trimmed.startsWith("}") || trimmed.startsWith("]")) {
          indent = (indent - 1).coerceAtLeast(0)
        }
        if (trimmed.isNotEmpty()) {
          out.append("  ".repeat(indent)).append(trimmed)
        }
        out.append('\n')
        val opens = trimmed.count { it == '{' }
        val closes = trimmed.count { it == '}' }
        val delta = opens - closes
        if (trimmed.startsWith("}")) {
          indent = (indent + opens).coerceAtLeast(0)
        } else {
          indent = (indent + delta).coerceAtLeast(0)
        }
      }
      return out.toString().trimEnd('\n')
    }
    return code
  }
}
