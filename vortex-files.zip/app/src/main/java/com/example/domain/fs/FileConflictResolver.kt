package com.example.domain.fs

import java.io.File

enum class ConflictAction {
  REPLACE,
  KEEP_BOTH,
  SKIP,
}

data class ConflictChoice(
  val action: ConflictAction,
  val applyToAll: Boolean = false,
)

data class FileConflictInfo(
  val fileName: String,
  val destPath: String,
  val sourceSize: Long,
  val existingSize: Long,
  val sourceModified: Long,
  val existingModified: Long,
  val remainingItems: Int,
)

fun nextAvailableNumberedFile(target: File): File {
  if (!target.exists()) return target
  val parent = target.parentFile ?: File(".")
  val name = target.name
  val dotIdx = name.lastIndexOf('.')
  val hasExt = dotIdx in 1 until name.length && !target.isDirectory
  val stem = if (hasExt) name.substring(0, dotIdx) else name
  val ext = if (hasExt) name.substring(dotIdx) else ""
  var counter = 1
  while (counter < 10_000) {
    val candidate = File(parent, "$stem ($counter)$ext")
    if (!candidate.exists()) return candidate
    counter++
  }
  return File(parent, "${stem}_${System.currentTimeMillis()}$ext")
}
