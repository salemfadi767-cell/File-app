package com.example.domain.editor

import android.content.Context
import com.example.domain.apk.ApkSignerAndBuilder
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.ArchiveEntry
import org.apache.commons.compress.archivers.ArchiveOutputStream
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream

enum class AppTargetPlatform(
  val id: String,
  val label: String,
  val extension: String,
) {
  ANDROID_APK("android_apk", "Android (.apk)", "apk"),
  IOS_IPA("ios_ipa", "iPhone / iOS (.ipa bundle)", "ipa"),
  MACOS_APP("macos_app", "macOS (.app.zip)", "macos.zip"),
  WINDOWS_APP("windows_app", "Windows (.exe launcher zip)", "win.zip"),
  LINUX_APP("linux_app", "Linux (AppDir .tar.gz)", "linux.tar.gz"),
}

data class BuiltAppArtifact(
  val platform: AppTargetPlatform,
  val outputFile: File,
  val filesBundled: Int,
  val summary: String,
)

class MultiPlatformAppBuilder(
  private val context: Context,
  private val apkSignerAndBuilder: ApkSignerAndBuilder,
) {

  suspend fun buildAppPackage(
    projectDir: File,
    appName: String,
    packageId: String,
    platform: AppTargetPlatform,
    outputDir: File,
  ): Result<BuiltAppArtifact> =
    withContext(Dispatchers.IO) {
      runCatching {
        require(projectDir.exists() && projectDir.isDirectory) { "Project directory missing" }
        outputDir.mkdirs()
        val cleanApp = appName.trim().ifBlank { "VortexApp" }.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val cleanPkg = packageId.trim().ifBlank { "com.vortex.${cleanApp.lowercase()}" }
        val sourceFiles =
          projectDir
            .walkTopDown()
            .filter {
              it.isFile &&
                !it.name.endsWith(".apk", true) &&
                !it.name.endsWith(".ipa", true) &&
                !it.absolutePath.contains("${File.separator}build${File.separator}")
            }
            .toList()

        when (platform) {
          AppTargetPlatform.ANDROID_APK -> buildSignedAndroidApk(projectDir, sourceFiles, cleanApp, cleanPkg, outputDir)
          AppTargetPlatform.IOS_IPA -> buildIosIpaBundle(projectDir, sourceFiles, cleanApp, cleanPkg, outputDir)
          AppTargetPlatform.MACOS_APP -> buildMacOsBundle(projectDir, sourceFiles, cleanApp, cleanPkg, outputDir)
          AppTargetPlatform.WINDOWS_APP -> buildWindowsBundle(projectDir, sourceFiles, cleanApp, outputDir)
          AppTargetPlatform.LINUX_APP -> buildLinuxAppDirTarGz(projectDir, sourceFiles, cleanApp, cleanPkg, outputDir)
        }
      }
    }

  private suspend fun buildSignedAndroidApk(
    projectDir: File,
    sourceFiles: List<File>,
    appName: String,
    packageId: String,
    outputDir: File,
  ): BuiltAppArtifact {
    val staging = File(context.cacheDir, "apk_stage_${System.currentTimeMillis()}").apply { mkdirs() }
    try {
      // Check if project already contains compiled APK structure
      val hasManifest = sourceFiles.any { it.name.equals("AndroidManifest.xml", true) }
      if (!hasManifest) {
        val manifestXml =
          """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="$packageId"
    android:versionCode="1"
    android:versionName="1.0">
    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="35" />
    <uses-permission android:name="android.permission.INTERNET" />
    <application android:label="$appName" android:allowBackup="true">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
"""
        File(staging, "AndroidManifest.xml").writeText(manifestXml)
      }

      val assetsDir = File(staging, "assets/app").apply { mkdirs() }
      sourceFiles.forEach { file ->
        val rel = file.relativeTo(projectDir).invariantSeparatorsPath
        val dest =
          if (rel == "AndroidManifest.xml" || rel.startsWith("res/") || rel.endsWith(".dex", true)) {
            File(staging, rel)
          } else {
            File(assetsDir, rel)
          }
        dest.parentFile?.mkdirs()
        file.copyTo(dest, overwrite = true)
      }

      // Ensure entry metadata json for hybrid launchers
      File(staging, "assets/vortex_app_meta.json").writeText(
        """{"appName":"$appName","packageId":"$packageId","entry":"${detectEntryFile(sourceFiles)}"}"""
      )

      val outApk = File(outputDir, "${appName}_signed.apk")
      val res = apkSignerAndBuilder.convertToSignedApk(staging, outApk, signerCommonName = appName)
      return BuiltAppArtifact(
        platform = AppTargetPlatform.ANDROID_APK,
        outputFile = res.outputApk,
        filesBundled = res.entriesCount,
        summary = "Signed Android APK (V1+V2) built with ${res.entriesCount} entries",
      )
    } finally {
      staging.deleteRecursively()
    }
  }

  private fun buildIosIpaBundle(
    projectDir: File,
    sourceFiles: List<File>,
    appName: String,
    packageId: String,
    outputDir: File,
  ): BuiltAppArtifact {
    val outFile = File(outputDir, "${appName}_ios.ipa")
    val appRoot = "Payload/$appName.app"
    val infoPlist =
      """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>$appName</string>
  <key>CFBundleIdentifier</key><string>$packageId</string>
  <key>CFBundleVersion</key><string>1.0</string>
  <key>CFBundleShortVersionString</key><string>1.0</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>MinimumOSVersion</key><string>15.0</string>
</dict></plist>"""
    var count = 0
    ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile))).use { zos ->
      writeZip(zos, "$appRoot/Info.plist", infoPlist.toByteArray())
      count++
      sourceFiles.forEach { file ->
        val rel = file.relativeTo(projectDir).invariantSeparatorsPath
        writeZip(zos, "$appRoot/www/$rel", file.readBytes())
        count++
      }
    }
    return BuiltAppArtifact(
      platform = AppTargetPlatform.IOS_IPA,
      outputFile = outFile,
      filesBundled = count,
      summary = "iOS .ipa Payload bundle ready for Xcode / AltStore signing",
    )
  }

  private fun buildMacOsBundle(
    projectDir: File,
    sourceFiles: List<File>,
    appName: String,
    packageId: String,
    outputDir: File,
  ): BuiltAppArtifact {
    val outFile = File(outputDir, "${appName}_macos.zip")
    val contents = "$appName.app/Contents"
    val infoPlist =
      """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>$appName</string>
  <key>CFBundleExecutable</key><string>launch.sh</string>
  <key>CFBundleIdentifier</key><string>$packageId</string>
  <key>CFBundlePackageType</key><string>APPL</string>
</dict></plist>"""
    val entry = detectEntryFile(sourceFiles)
    val launcher =
      """#!/usr/bin/env bash
DIR="$(cd "$(dirname "${'$'}0")/../Resources/app" && pwd)"
cd "${'$'}DIR"
${buildPosixRunnerSnippet(entry)}
"""
    var count = 0
    ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile))).use { zos ->
      writeZip(zos, "$contents/Info.plist", infoPlist.toByteArray())
      writeZip(zos, "$contents/MacOS/launch.sh", launcher.toByteArray())
      count += 2
      sourceFiles.forEach { file ->
        val rel = file.relativeTo(projectDir).invariantSeparatorsPath
        writeZip(zos, "$contents/Resources/app/$rel", file.readBytes())
        count++
      }
    }
    return BuiltAppArtifact(
      platform = AppTargetPlatform.MACOS_APP,
      outputFile = outFile,
      filesBundled = count,
      summary = "macOS .app bundle packaged ($count files)",
    )
  }

  private fun buildWindowsBundle(
    projectDir: File,
    sourceFiles: List<File>,
    appName: String,
    outputDir: File,
  ): BuiltAppArtifact {
    val outFile = File(outputDir, "${appName}_windows.zip")
    val entry = detectEntryFile(sourceFiles)
    val bat =
      when {
        entry.endsWith(".py", true) -> "@echo off\r\nset PYTHONPATH=%~dp0app\\.vortex_libs\\pip\r\npython \"%~dp0app\\$entry\"\r\npause\r\n"
        entry.endsWith(".js", true) -> "@echo off\r\nnode \"%~dp0app\\$entry\"\r\npause\r\n"
        entry.endsWith(".html", true) || entry.endsWith(".htm", true) -> "@echo off\r\nstart \"\" \"%~dp0app\\$entry\"\r\n"
        else -> "@echo off\r\ncd /d \"%~dp0app\"\r\ncmd\r\n"
      }
    var count = 0
    ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile))).use { zos ->
      writeZip(zos, "run_${appName}.bat", bat.toByteArray())
      count++
      sourceFiles.forEach { file ->
        val rel = file.relativeTo(projectDir).invariantSeparatorsPath
        writeZip(zos, "app/$rel", file.readBytes())
        count++
      }
    }
    return BuiltAppArtifact(
      platform = AppTargetPlatform.WINDOWS_APP,
      outputFile = outFile,
      filesBundled = count,
      summary = "Windows portable bundle with launcher (.bat) packaged ($count files)",
    )
  }

  private fun buildLinuxAppDirTarGz(
    projectDir: File,
    sourceFiles: List<File>,
    appName: String,
    packageId: String,
    outputDir: File,
  ): BuiltAppArtifact {
    val outFile = File(outputDir, "${appName}_linux.tar.gz")
    val entry = detectEntryFile(sourceFiles)
    val appRun =
      """#!/usr/bin/env bash
HERE="$(dirname "$(readlink -f "${'$'}0")")"
cd "${'$'}HERE/usr/app"
${buildPosixRunnerSnippet(entry)}
"""
    val desktop =
      """[Desktop Entry]
Name=$appName
Exec=AppRun
Type=Application
Categories=Utility;Development;
X-AppImage-Id=$packageId
"""
    var count = 0
    GzipCompressorOutputStream(BufferedOutputStream(FileOutputStream(outFile))).use { gz ->
      TarArchiveOutputStream(gz).use { tar ->
        tar.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
        writeTarEntry(tar, "${appName}.AppDir/AppRun", appRun.toByteArray(), mode = 0b111_101_101) // 0755
        writeTarEntry(tar, "${appName}.AppDir/${appName}.desktop", desktop.toByteArray(), mode = 0b110_100_100)
        count += 2
        sourceFiles.forEach { file ->
          val rel = file.relativeTo(projectDir).invariantSeparatorsPath
          writeTarEntry(tar, "${appName}.AppDir/usr/app/$rel", file.readBytes(), mode = 0b110_100_100)
          count++
        }
      }
    }
    return BuiltAppArtifact(
      platform = AppTargetPlatform.LINUX_APP,
      outputFile = outFile,
      filesBundled = count,
      summary = "Linux AppDir (.tar.gz) packaged with executable AppRun ($count files)",
    )
  }

  private fun detectEntryFile(files: List<File>): String {
    val preferred = listOf("main.py", "app.py", "index.html", "index.js", "main.js", "main.kt", "run.sh")
    for (p in preferred) {
      files.firstOrNull { it.name.equals(p, true) }?.let { return it.name }
    }
    return files.firstOrNull()?.name ?: "index.html"
  }

  private fun buildPosixRunnerSnippet(entry: String): String =
    when {
      entry.endsWith(".py", true) -> "PYTHONPATH=\"./.vortex_libs/pip:${'$'}PYTHONPATH\" python3 \"$entry\""
      entry.endsWith(".js", true) -> "node \"$entry\""
      entry.endsWith(".html", true) || entry.endsWith(".htm", true) -> "xdg-open \"$entry\" 2>/dev/null || open \"$entry\""
      else -> "sh \"$entry\""
    }

  private fun writeZip(zos: ZipOutputStream, name: String, data: ByteArray) {
    zos.putNextEntry(ZipEntry(name))
    zos.write(data)
    zos.closeEntry()
  }

  @Suppress("UNCHECKED_CAST")
  private fun writeTarEntry(tar: TarArchiveOutputStream, name: String, data: ByteArray, mode: Int) {
    val entry = TarArchiveEntry(name)
    entry.size = data.size.toLong()
    entry.mode = mode
    val aos = tar as ArchiveOutputStream<ArchiveEntry>
    try {
      aos.putArchiveEntry(entry)
    } catch (_: NoSuchMethodError) {
      tar.javaClass.getMethod("putArchiveEntry", ArchiveEntry::class.java).invoke(tar, entry)
    }
    tar.write(data)
    tar.closeArchiveEntry()
  }
}
