package com.example.domain.media

import androidx.compose.ui.graphics.Color
import java.io.File

data class SubtitleCue(
  val index: Int,
  val startMs: Long,
  val endMs: Long,
  val text: String,
)

data class SubtitleStyleConfig(
  val fontSizeSp: Int = 18,
  val textColor: Color = Color.White,
  val backgroundAlpha: Float = 0.62f,
  val bottomOffsetDp: Int = 56,
  val syncOffsetMs: Long = 0L,
  val hasShadow: Boolean = true,
)

object SubtitleEngine {

  fun parseFile(file: File): List<SubtitleCue> {
    if (!file.exists() || !file.isFile) return emptyList()
    return parseString(file.readText())
  }

  fun parseString(raw: String): List<SubtitleCue> {
    val normalized = raw.replace("\r\n", "\n").replace('\r', '\n').trim()
    if (normalized.isEmpty()) return emptyList()

    val body =
      if (normalized.startsWith("WEBVTT", ignoreCase = true)) {
        normalized.substringAfter("\n", "")
      } else {
        normalized
      }

    val blocks = body.split(Regex("\n\\s*\n"))
    val cues = mutableListOf<SubtitleCue>()
    var autoIdx = 1

    for (block in blocks) {
      val lines = block.lines().map { it.trimEnd() }.filter { it.isNotBlank() }
      if (lines.isEmpty()) continue
      val timeLineIdx = lines.indexOfFirst { "-->" in it }
      if (timeLineIdx < 0) continue

      val timeParts = lines[timeLineIdx].split("-->")
      if (timeParts.size < 2) continue
      val startMs = parseTimestampMs(timeParts[0].trim())
      val endMs = parseTimestampMs(timeParts[1].trim().substringBefore(" "))
      if (startMs < 0L || endMs < startMs) continue

      val text =
        lines.drop(timeLineIdx + 1)
          .joinToString("\n")
          .replace(Regex("<[^>]+>"), "")
          .trim()
      if (text.isNotEmpty()) {
        cues.add(SubtitleCue(index = autoIdx++, startMs = startMs, endMs = endMs, text = text))
      }
    }
    return cues
  }

  fun findActiveCue(cues: List<SubtitleCue>, positionMs: Long, syncOffsetMs: Long = 0L): SubtitleCue? {
    if (cues.isEmpty()) return null
    val effectivePos = positionMs - syncOffsetMs
    return cues.firstOrNull { effectivePos in it.startMs..it.endMs }
  }

  private fun parseTimestampMs(ts: String): Long {
    // Supports HH:MM:SS,mmm or HH:MM:SS.mmm or MM:SS.mmm
    val clean = ts.replace(',', '.')
    val parts = clean.split(':')
    return try {
      when (parts.size) {
        3 -> {
          val h = parts[0].toLong()
          val m = parts[1].toLong()
          val secParts = parts[2].split('.')
          val s = secParts[0].toLong()
          val ms = secParts.getOrNull(1)?.padEnd(3, '0')?.take(3)?.toLong() ?: 0L
          ((h * 3600 + m * 60 + s) * 1000L) + ms
        }
        2 -> {
          val m = parts[0].toLong()
          val secParts = parts[1].split('.')
          val s = secParts[0].toLong()
          val ms = secParts.getOrNull(1)?.padEnd(3, '0')?.take(3)?.toLong() ?: 0L
          ((m * 60 + s) * 1000L) + ms
        }
        else -> -1L
      }
    } catch (_: Throwable) {
      -1L
    }
  }
}
