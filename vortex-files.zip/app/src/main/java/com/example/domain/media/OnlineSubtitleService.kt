package com.example.domain.media

import com.example.domain.archive.ArchiveEngine
import java.io.File
import java.net.URLEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

data class OnlineSubtitleHit(
  val title: String,
  val language: String,
  val downloadUrl: String,
  val sourceName: String,
)

class OnlineSubtitleService(private val archiveEngine: ArchiveEngine) {

  private val client =
    OkHttpClient.Builder()
      .followRedirects(true)
      .build()

  suspend fun searchSubtitles(query: String, languageFilter: String = "arabic"): List<OnlineSubtitleHit> =
    searchSubtitlesMultiLang(query, listOf(languageFilter))

  suspend fun searchSubtitlesMultiLang(
    query: String,
    orderedLanguages: List<String>,
  ): List<OnlineSubtitleHit> =
    withContext(Dispatchers.IO) {
      val cleaned = cleanVideoTitle(query)
      if (cleaned.isBlank()) return@withContext emptyList()
      val langs = orderedLanguages.ifEmpty { listOf("ar", "en") }
      val results = mutableListOf<OnlineSubtitleHit>()
      val seenUrls = hashSetOf<String>()

      for (langPref in langs) {
        val langCode = mapToOpenSubtitlesCode(langPref)
        runCatching {
          val enc = URLEncoder.encode(cleaned, "UTF-8")
          val req =
            Request.Builder()
              .url("https://rest.opensubtitles.org/search/query-$enc/sublanguageid-$langCode")
              .header("User-Agent", "VortexFilesPlayer v2.0")
              .build()
          client.newCall(req).execute().use { resp ->
            if (resp.isSuccessful) {
              val body = resp.body?.string().orEmpty()
              if (body.trimStart().startsWith("[")) {
                val arr = JSONArray(body)
                for (i in 0 until minOf(arr.length(), 15)) {
                  val obj = arr.optJSONObject(i) ?: continue
                  val name = obj.optString("SubFileName").ifBlank { obj.optString("MovieName") }
                  val lang = obj.optString("LanguageName", langCode)
                  val url = obj.optString("SubDownloadLink").ifBlank { obj.optString("ZipDownloadLink") }
                  if (name.isNotBlank() && url.isNotBlank() && seenUrls.add(url)) {
                    results.add(OnlineSubtitleHit(name, lang, url, "OpenSubtitles"))
                  }
                }
              }
            }
          }
        }
        if (results.isNotEmpty()) break
      }

      // 2. Fallback: YTS-Subs HTML lookup prioritized by orderedLanguages
      if (results.isEmpty()) {
        runCatching {
          val enc = URLEncoder.encode(cleaned, "UTF-8")
          val req =
            Request.Builder()
              .url("https://yts-subs.com/search/$enc")
              .header("User-Agent", "Mozilla/5.0")
              .build()
          client.newCall(req).execute().use { resp ->
            if (resp.isSuccessful) {
              val html = resp.body?.string().orEmpty()
              val movieLinks = Regex("""href="(/movie-imdb/tt\d+)"""").findAll(html).map { it.groupValues[1] }.distinct().take(3)
              val fallbackHits = mutableListOf<OnlineSubtitleHit>()
              for (moviePath in movieLinks) {
                val subReq =
                  Request.Builder()
                    .url("https://yts-subs.com$moviePath")
                    .header("User-Agent", "Mozilla/5.0")
                    .build()
                client.newCall(subReq).execute().use { subResp ->
                  if (subResp.isSuccessful) {
                    val subHtml = subResp.body?.string().orEmpty()
                    val rowRegex = Regex("""<span class="sub-lang">([^<]+)</span>.*?href="(/subtitles/[^"]+)"""", setOf(RegexOption.DOT_MATCHES_ALL))
                    for (m in rowRegex.findAll(subHtml).take(20)) {
                      val lang = m.groupValues[1].trim()
                      val path = m.groupValues[2].trim()
                      val zipUrl = "https://yts-subs.com/subtitle/${path.substringAfterLast('/')}.zip"
                      if (seenUrls.add(zipUrl)) {
                        fallbackHits.add(OnlineSubtitleHit("$cleaned ($lang)", lang, zipUrl, "YTS-Subs"))
                      }
                    }
                  }
                }
              }
              val ranked =
                fallbackHits.sortedBy { hit ->
                  val idx = langs.indexOfFirst { hit.language.contains(languageDisplayName(it), ignoreCase = true) || hit.language.startsWith(it, ignoreCase = true) }
                  if (idx >= 0) idx else 99
                }
              results.addAll(ranked)
            }
          }
        }
      }
      results
    }

  private fun mapToOpenSubtitlesCode(code: String): String =
    when (code.lowercase().take(2)) {
      "ar" -> "ara"
      "en" -> "eng"
      "fr" -> "fre"
      "es" -> "spa"
      "de" -> "ger"
      "tr" -> "tur"
      "ru" -> "rus"
      else -> "eng"
    }

  private fun languageDisplayName(code: String): String =
    when (code.lowercase().take(2)) {
      "ar" -> "Arabic"
      "en" -> "English"
      "fr" -> "French"
      "es" -> "Spanish"
      "de" -> "German"
      "tr" -> "Turkish"
      "ru" -> "Russian"
      else -> code
    }

  suspend fun downloadSubtitle(
    url: String,
    outputDir: File,
    preferredStem: String? = null,
  ): File? =
    withContext(Dispatchers.IO) {
      outputDir.mkdirs()
      val req =
        Request.Builder()
          .url(url)
          .header("User-Agent", "VortexFilesPlayer v2.0")
          .build()

      client.newCall(req).execute().use { resp ->
        if (!resp.isSuccessful) return@withContext null
        val bytes = resp.body?.bytes() ?: return@withContext null
        if (bytes.isEmpty()) return@withContext null

        val cleanName = url.substringAfterLast('/').substringBefore('?').ifBlank { "subtitle_${System.currentTimeMillis()}" }
        val extracted =
          when {
            // GZIP compressed subtitle (from OpenSubtitles .gz)
            bytes.size >= 2 && bytes[0] == 0x1F.toByte() && bytes[1] == 0x8B.toByte() -> {
              val gzFile = File(outputDir, "$cleanName.gz").apply { writeBytes(bytes) }
              val extDir = File(outputDir, "ext_${System.currentTimeMillis()}").apply { mkdirs() }
              archiveEngine.extractArchive(gzFile, extDir)
              gzFile.delete()
              extDir.walkTopDown().firstOrNull { it.isFile && it.extension.lowercase() in setOf("srt", "vtt", "ass") }
                ?: extDir.walkTopDown().firstOrNull { it.isFile }
            }
            // ZIP archive containing .srt
            bytes.size >= 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte() -> {
              val zipFile = File(outputDir, "$cleanName.zip").apply { writeBytes(bytes) }
              val extDir = File(outputDir, "ext_${System.currentTimeMillis()}").apply { mkdirs() }
              archiveEngine.extractArchive(zipFile, extDir)
              zipFile.delete()
              extDir.walkTopDown().firstOrNull { it.isFile && it.extension.lowercase() in setOf("srt", "vtt", "ass") }
            }
            else -> {
              val ext = if (cleanName.endsWith(".vtt", true)) "vtt" else "srt"
              File(outputDir, "online_${System.currentTimeMillis()}.$ext").apply { writeBytes(bytes) }
            }
          }

        if (extracted != null && !preferredStem.isNullOrBlank()) {
          val ext = extracted.extension.ifBlank { "srt" }
          val named = File(outputDir, "$preferredStem.$ext")
          if (extracted.absolutePath != named.absolutePath) {
            runCatching {
              extracted.copyTo(named, overwrite = true)
              if (extracted.parentFile?.name?.startsWith("ext_") == true) {
                extracted.parentFile?.deleteRecursively()
              } else {
                extracted.delete()
              }
              return@withContext named
            }
          }
        }
        extracted
      }
    }

  private fun cleanVideoTitle(raw: String): String {
    val base = raw.substringAfterLast('/').substringBeforeLast('.')
    return base
      .replace(Regex("[._]+"), " ")
      .replace(Regex("""\b(1080p|720p|480p|2160p|4k|x264|x265|hevc|bluray|webrip|hdtv|aac|mp4|mkv)\b""", RegexOption.IGNORE_CASE), "")
      .replace(Regex("\\s{2,}"), " ")
      .trim()
  }
}
