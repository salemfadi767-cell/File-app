package com.example.domain.apk

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Base64
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.jar.Attributes
import java.util.jar.Manifest
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ApkBuildSignResult(
  val outputApk: File,
  val entriesCount: Int,
  val v1Signed: Boolean,
  val v2Signed: Boolean,
  val sha256CertFingerprint: String,
)

data class ApkSignatureVerification(
  val hasV1JarSignature: Boolean,
  val hasV2ApkSigBlock: Boolean,
  val v2SchemeIdPresent: Boolean,
  val eocdValid: Boolean,
)

class ApkSignerAndBuilder {

  companion object {
    private const val APK_SIG_BLOCK_MAGIC_LO = 0x20676953204b5041L // "APK Sig "
    private const val APK_SIG_BLOCK_MAGIC_HI = 0x3234206b636f6c42L // "Block 42"
    private const val APK_SIG_V2_BLOCK_ID = 0x7109871a
    private const val CONTENT_DIGEST_CHUNKED_SHA256 = 0x0103
    private const val SIGNATURE_RSA_PKCS1_V15_WITH_SHA256 = 0x0104
    private const val CHUNK_SIZE = 1024 * 1024
  }

  /**
   * Merges split APK packages (.apks, .xapk, .apkm), .aab bundles (base module), .zip,
   * or raw directories into a unified .apk archive, then signs with v1 JAR + APK Signature Scheme v2.
   */
  suspend fun convertToSignedApk(
    source: File,
    outputApk: File,
    signerCommonName: String = "Vortex Files Signer",
    onProgress: (Int) -> Unit = {},
  ): ApkBuildSignResult =
    withContext(Dispatchers.IO) {
      outputApk.parentFile?.mkdirs()
      val mergedUnsigned = File(outputApk.parentFile, ".tmp_unsigned_${System.currentTimeMillis()}.apk")
      try {
        onProgress(15)
        val entryCount = mergeSourceIntoUnsignedApk(source, mergedUnsigned)
        onProgress(55)
        val signedResult = signApkV1AndV2(mergedUnsigned, outputApk, signerCommonName)
        onProgress(100)
        signedResult.copy(entriesCount = entryCount)
      } finally {
        mergedUnsigned.delete()
      }
    }

  private fun mergeSourceIntoUnsignedApk(source: File, outUnsignedApk: File): Int {
    val entriesWritten = hashSetOf<String>()
    var count = 0

    ZipOutputStream(FileOutputStream(outUnsignedApk)).use { zos ->
      if (source.isDirectory) {
        source.walkTopDown().filter { it.isFile }.forEach { f ->
          val rel = f.relativeTo(source).invariantSeparatorsPath
          if (!rel.startsWith("META-INF/")) {
            writeZipEntry(zos, rel, f.readBytes(), compress = !shouldStoreUncompressed(rel))
            entriesWritten.add(rel)
            count++
          }
        }
        return count
      }

      val ext = source.extension.lowercase()
      if (ext == "apk" || ext == "zip") {
        ZipFile(source).use { zf ->
          val e = zf.entries()
          while (e.hasMoreElements()) {
            val ze = e.nextElement()
            if (ze.isDirectory || ze.name.startsWith("META-INF/")) continue
            val bytes = zf.getInputStream(ze).use { it.readBytes() }
            if (entriesWritten.add(ze.name)) {
              writeZipEntry(zos, ze.name, bytes, compress = !shouldStoreUncompressed(ze.name))
              count++
            }
          }
        }
        return count
      }

      // Handle split bundles: .apks / .xapk / .apkm / .aab
      val tempDir = File(outUnsignedApk.parentFile, ".tmp_bundle_${System.currentTimeMillis()}")
      try {
        tempDir.mkdirs()
        val innerApks = mutableListOf<File>()
        val looseFiles = mutableListOf<Pair<String, ByteArray>>()

        ZipFile(source).use { zf ->
          val e = zf.entries()
          while (e.hasMoreElements()) {
            val ze = e.nextElement()
            if (ze.isDirectory) continue
            val name = ze.name
            val bytes = zf.getInputStream(ze).use { it.readBytes() }
            if (name.endsWith(".apk", ignoreCase = true)) {
              val tmpInner = File(tempDir, File(name).name)
              tmpInner.writeBytes(bytes)
              if (tmpInner.name.contains("base", true)) innerApks.add(0, tmpInner) else innerApks.add(tmpInner)
            } else if (ext == "aab") {
              val mapped = when {
                name.startsWith("base/manifest/") -> name.removePrefix("base/manifest/")
                name.startsWith("base/dex/") -> name.removePrefix("base/dex/")
                name.startsWith("base/root/") -> name.removePrefix("base/root/")
                name.startsWith("base/") -> name.removePrefix("base/")
                else -> name
              }
              if (!mapped.startsWith("META-INF/")) looseFiles.add(mapped to bytes)
            } else if (!name.startsWith("META-INF/") && name != "manifest.json" && name != "info.json") {
              looseFiles.add(name to bytes)
            }
          }
        }

        for (innerApk in innerApks) {
          ZipFile(innerApk).use { innerZf ->
            val ie = innerZf.entries()
            while (ie.hasMoreElements()) {
              val ize = ie.nextElement()
              if (ize.isDirectory || ize.name.startsWith("META-INF/")) continue
              if (entriesWritten.add(ize.name)) {
                val bytes = innerZf.getInputStream(ize).use { it.readBytes() }
                writeZipEntry(zos, ize.name, bytes, compress = !shouldStoreUncompressed(ize.name))
                count++
              }
            }
          }
        }

        for ((path, bytes) in looseFiles) {
          if (entriesWritten.add(path)) {
            writeZipEntry(zos, path, bytes, compress = !shouldStoreUncompressed(path))
            count++
          }
        }
      } finally {
        tempDir.deleteRecursively()
      }
    }
    return count
  }

  private fun shouldStoreUncompressed(entryName: String): Boolean =
    entryName == "resources.arsc" || entryName.endsWith(".so")

  suspend fun signApkV1AndV2(
    inputApk: File,
    outputApk: File,
    signerCommonName: String = "Vortex Files Signer",
  ): ApkBuildSignResult =
    withContext(Dispatchers.IO) {
      val keyPair = generateRsa2048KeyPair()
      val certDer = buildSelfSignedX509Cert(keyPair, signerCommonName)
      val certSha256 = MessageDigest.getInstance("SHA-256").digest(certDer)
        .joinToString(":") { "%02X".format(it) }

      val v1Temp = File(outputApk.parentFile, ".tmp_v1_${System.currentTimeMillis()}.apk")
      var entriesCount = 0
      try {
        val entriesMap = LinkedHashMap<String, ByteArray>()
        ZipFile(inputApk).use { zf ->
          val e = zf.entries()
          while (e.hasMoreElements()) {
            val ze = e.nextElement()
            if (ze.isDirectory || ze.name.startsWith("META-INF/")) continue
            entriesMap[ze.name] = zf.getInputStream(ze).use { it.readBytes() }
          }
        }
        entriesCount = entriesMap.size

        // Build v1 MANIFEST.MF
        val manifest = Manifest()
        manifest.mainAttributes[Attributes.Name.MANIFEST_VERSION] = "1.0"
        manifest.mainAttributes[Attributes.Name("Created-By")] = "Vortex Files APK Signer"
        val sha256 = MessageDigest.getInstance("SHA-256")
        val entryDigests = LinkedHashMap<String, String>()
        for ((name, bytes) in entriesMap) {
          val digestB64 = Base64.getEncoder().encodeToString(sha256.digest(bytes))
          entryDigests[name] = digestB64
          val attr = Attributes()
          attr[Attributes.Name("SHA-256-Digest")] = digestB64
          manifest.entries[name] = attr
        }
        val manifestBytes = ByteArrayOutputStream().apply { manifest.write(this) }.toByteArray()

        // Build VORTEX.SF
        val sfText = buildString {
          append("Signature-Version: 1.0\r\n")
          append("Created-By: Vortex Files APK Signer\r\n")
          append("X-Android-APK-Signed: 2\r\n")
          append("SHA-256-Digest-Manifest: ")
          append(Base64.getEncoder().encodeToString(sha256.digest(manifestBytes)))
          append("\r\n\r\n")
          for ((name, digestB64) in entryDigests) {
            append("Name: $name\r\n")
            append("SHA-256-Digest: $digestB64\r\n\r\n")
          }
        }
        val sfBytes = sfText.toByteArray(Charsets.UTF_8)
        val pkcs7RsaBytes = buildPkcs7SignedData(sfBytes, certDer, keyPair.private)

        ZipOutputStream(FileOutputStream(v1Temp)).use { zos ->
          for ((name, bytes) in entriesMap) {
            writeZipEntry(zos, name, bytes, compress = !shouldStoreUncompressed(name))
          }
          writeZipEntry(zos, "META-INF/MANIFEST.MF", manifestBytes, compress = true)
          writeZipEntry(zos, "META-INF/VORTEX.SF", sfBytes, compress = true)
          writeZipEntry(zos, "META-INF/VORTEX.RSA", pkcs7RsaBytes, compress = true)
        }

        // Apply APK Signature Scheme v2 Signing Block
        outputApk.parentFile?.mkdirs()
        insertApkSignatureSchemeV2Block(v1Temp, outputApk, keyPair, certDer)

        ApkBuildSignResult(
          outputApk = outputApk,
          entriesCount = entriesCount,
          v1Signed = true,
          v2Signed = true,
          sha256CertFingerprint = certSha256,
        )
      } finally {
        v1Temp.delete()
      }
    }

  fun verifyApkSignatureBlock(apkFile: File): ApkSignatureVerification {
    var hasManifest = false
    var hasSf = false
    var hasRsa = false
    runCatching {
      ZipFile(apkFile).use { zf ->
        hasManifest = zf.getEntry("META-INF/MANIFEST.MF") != null
        hasSf = zf.getEntry("META-INF/VORTEX.SF") != null
        hasRsa = zf.getEntry("META-INF/VORTEX.RSA") != null
      }
    }

    val raw = apkFile.readBytes()
    val eocdIdx = findEocdOffset(raw)
    if (eocdIdx < 0) return ApkSignatureVerification(hasManifest && hasSf && hasRsa, false, false, false)

    val cdOffset = ByteBuffer.wrap(raw, eocdIdx + 16, 4).order(ByteOrder.LITTLE_ENDIAN).int
    var hasMagic = false
    var hasV2Id = false
    if (cdOffset >= 32 && cdOffset <= raw.size) {
      val footerStart = cdOffset - 24
      val buf = ByteBuffer.wrap(raw, footerStart, 24).order(ByteOrder.LITTLE_ENDIAN)
      val sizeInFooter = buf.long
      val magicLo = buf.long
      val magicHi = buf.long
      if (magicLo == APK_SIG_BLOCK_MAGIC_LO && magicHi == APK_SIG_BLOCK_MAGIC_HI) {
        hasMagic = true
        val blockStart = cdOffset - 8 - sizeInFooter.toInt()
        if (blockStart >= 0) {
          var pos = blockStart + 8
          val endPairs = footerStart
          while (pos + 12 <= endPairs) {
            val pairLen = ByteBuffer.wrap(raw, pos, 8).order(ByteOrder.LITTLE_ENDIAN).long.toInt()
            val id = ByteBuffer.wrap(raw, pos + 8, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (id == APK_SIG_V2_BLOCK_ID) hasV2Id = true
            if (pairLen <= 4) break
            pos += 8 + pairLen
          }
        }
      }
    }
    return ApkSignatureVerification(
      hasV1JarSignature = hasManifest && hasSf && hasRsa,
      hasV2ApkSigBlock = hasMagic,
      v2SchemeIdPresent = hasV2Id,
      eocdValid = true,
    )
  }

  private fun insertApkSignatureSchemeV2Block(
    v1Apk: File,
    outputApk: File,
    keyPair: KeyPair,
    certDer: ByteArray,
  ) {
    val raw = v1Apk.readBytes()
    val eocdOffset = findEocdOffset(raw)
    if (eocdOffset < 0) throw IllegalStateException("EOCD not found in APK")

    val cdOffset = ByteBuffer.wrap(raw, eocdOffset + 16, 4).order(ByteOrder.LITTLE_ENDIAN).int
    val cdSize = ByteBuffer.wrap(raw, eocdOffset + 12, 4).order(ByteOrder.LITTLE_ENDIAN).int

    val beforeCd = raw.copyOfRange(0, cdOffset)
    val centralDir = raw.copyOfRange(cdOffset, cdOffset + cdSize)
    val eocd = raw.copyOfRange(eocdOffset, raw.size)

    // Compute APK Signature Scheme v2 chunked SHA-256 digest across:
    // 1) ZIP Contents before CD, 2) Central Directory, 3) EOCD (with CD offset patched cleanly;
    // note Section 3 digest uses EOCD with original CD offset per AOSP spec? Actually AOSP v2 spec
    // hashes ZIP contents, Central Directory, and EOCD BEFORE modifying EOCD? No, spec fixes EOCD offset
    // to match before insertion or hashes the final CD offset. We compute digest over sections 1, 2, 3!)
    val sectionDigests = mutableListOf<ByteArray>()
    for (section in listOf(beforeCd, centralDir, eocd)) {
      var off = 0
      while (off < section.size) {
        val len = minOf(CHUNK_SIZE, section.size - off)
        val md = MessageDigest.getInstance("SHA-256")
        md.update(0xa5.toByte())
        md.update(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(len).array())
        md.update(section, off, len)
        sectionDigests.add(md.digest())
        off += len
      }
    }
    val topDigest = MessageDigest.getInstance("SHA-256").apply {
      update(0x5a.toByte())
      update(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(sectionDigests.size).array())
      for (d in sectionDigests) update(d)
    }.digest()

    // Build signedData structure (AOSP APK Sig v2)
    val digestsBlock = lenPrefixed(
      ByteBuffer.allocate(4 + 4 + topDigest.size).order(ByteOrder.LITTLE_ENDIAN)
        .putInt(CONTENT_DIGEST_CHUNKED_SHA256)
        .putInt(topDigest.size)
        .put(topDigest)
        .array()
    )
    val certsBlock = lenPrefixed(certDer)
    val signedData = ByteArrayOutputStream().apply {
      write(lenPrefixed(digestsBlock))
      write(lenPrefixed(certsBlock))
      write(lenPrefixed(ByteArray(0))) // additional attributes
    }.toByteArray()

    // Sign signedData with RSA-SHA256
    val sigEngine = Signature.getInstance("SHA256withRSA")
    sigEngine.initSign(keyPair.private)
    sigEngine.update(signedData)
    val signatureBytes = sigEngine.sign()

    val signaturesSeq = lenPrefixed(
      ByteBuffer.allocate(4 + 4 + signatureBytes.size).order(ByteOrder.LITTLE_ENDIAN)
        .putInt(SIGNATURE_RSA_PKCS1_V15_WITH_SHA256)
        .putInt(signatureBytes.size)
        .put(signatureBytes)
        .array()
    )
    val spkiBytes = keyPair.public.encoded

    val signer = ByteArrayOutputStream().apply {
      write(lenPrefixed(signedData))
      write(lenPrefixed(signaturesSeq))
      write(lenPrefixed(spkiBytes))
    }.toByteArray()
    val v2SchemeValue = lenPrefixed(lenPrefixed(signer))

    // Construct ID-value pair + APK Signing Block (padded to 4096-byte multiple)
    val pairBytes = ByteBuffer.allocate(8 + 4 + v2SchemeValue.size).order(ByteOrder.LITTLE_ENDIAN)
      .putLong((4 + v2SchemeValue.size).toLong())
      .putInt(APK_SIG_V2_BLOCK_ID)
      .put(v2SchemeValue)
      .array()

    val rawBlockSize = 8 + pairBytes.size + 24
    val paddedBlockSize = ((rawBlockSize + 4095) / 4096) * 4096
    val paddingLen = paddedBlockSize - rawBlockSize
    val sizeOfBlockField = (paddedBlockSize - 8).toLong()

    val apkSigBlock = ByteBuffer.allocate(paddedBlockSize).order(ByteOrder.LITTLE_ENDIAN)
    apkSigBlock.putLong(sizeOfBlockField)
    apkSigBlock.put(pairBytes)
    if (paddingLen >= 12) {
      apkSigBlock.putLong((paddingLen - 8).toLong())
      apkSigBlock.putInt(0x42726577) // verity/alignment padding ID
      repeat(paddingLen - 12) { apkSigBlock.put(0) }
    } else {
      repeat(paddingLen) { apkSigBlock.put(0) }
    }
    apkSigBlock.putLong(sizeOfBlockField)
    apkSigBlock.putLong(APK_SIG_BLOCK_MAGIC_LO)
    apkSigBlock.putLong(APK_SIG_BLOCK_MAGIC_HI)
    val blockBytes = apkSigBlock.array()

    // Patch EOCD Central Directory offset
    val newCdOffset = cdOffset + blockBytes.size
    val patchedEocd = eocd.copyOf()
    ByteBuffer.wrap(patchedEocd, 16, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(newCdOffset)

    FileOutputStream(outputApk).use { fos ->
      fos.write(beforeCd)
      fos.write(blockBytes)
      fos.write(centralDir)
      fos.write(patchedEocd)
    }
  }

  private fun lenPrefixed(data: ByteArray): ByteArray =
    ByteBuffer.allocate(4 + data.size).order(ByteOrder.LITTLE_ENDIAN).putInt(data.size).put(data).array()

  private fun findEocdOffset(data: ByteArray): Int {
    val minOffset = (data.size - 65557).coerceAtLeast(0)
    for (i in (data.size - 22) downTo minOffset) {
      if (data[i] == 0x50.toByte() &&
        data[i + 1] == 0x4b.toByte() &&
        data[i + 2] == 0x05.toByte() &&
        data[i + 3] == 0x06.toByte()
      ) {
        return i
      }
    }
    return -1
  }

  private fun writeZipEntry(zos: ZipOutputStream, name: String, data: ByteArray, compress: Boolean) {
    val entry = ZipEntry(name)
    if (!compress) {
      entry.method = ZipEntry.STORED
      entry.size = data.size.toLong()
      entry.compressedSize = data.size.toLong()
      val crc = CRC32().apply { update(data) }
      entry.crc = crc.value
    } else {
      entry.method = ZipEntry.DEFLATED
    }
    zos.putNextEntry(entry)
    zos.write(data)
    zos.closeEntry()
  }

  private fun generateRsa2048KeyPair(): KeyPair {
    val kpg = KeyPairGenerator.getInstance("RSA")
    kpg.initialize(2048)
    return kpg.generateKeyPair()
  }

  // Pure-Kotlin minimal X.509 v3 DER certificate + PKCS#7 SignedData generator
  private fun buildSelfSignedX509Cert(keyPair: KeyPair, commonName: String): ByteArray {
    val serial = derInteger(BigInteger.valueOf(System.currentTimeMillis()).toByteArray())
    val sha256WithRsaOid = derSeq(derOid(1, 2, 840, 113549, 1, 1, 11) + derNull())
    val dn = derSeq(derSet(derSeq(derOid(2, 5, 4, 3) + derUtf8String(commonName))))

    val now = Date()
    val end = Date(now.time + 3650L * 24L * 3600L * 1000L)
    val validity = derSeq(derUtcTime(now) + derUtcTime(end))
    val spki = keyPair.public.encoded

    val tbsCert = derSeq(
      derTag(0xa0, derInteger(byteArrayOf(2))) + // v3
        serial +
        sha256WithRsaOid +
        dn +
        validity +
        dn +
        spki
    )
    val sig = Signature.getInstance("SHA256withRSA").apply {
      initSign(keyPair.private)
      update(tbsCert)
    }.sign()
    return derSeq(tbsCert + sha256WithRsaOid + derBitString(sig))
  }

  private fun buildPkcs7SignedData(content: ByteArray, certDer: ByteArray, privateKey: PrivateKey): ByteArray {
    val sha256AlgId = derSeq(derOid(2, 16, 840, 1, 101, 3, 4, 2, 1) + derNull())
    val rsaAlgId = derSeq(derOid(1, 2, 840, 113549, 1, 1, 1) + derNull())
    val dataOid = derOid(1, 2, 840, 113549, 1, 7, 1)
    val signedDataOid = derOid(1, 2, 840, 113549, 1, 7, 2)

    val signature = Signature.getInstance("SHA256withRSA").apply {
      initSign(privateKey)
      update(content)
    }.sign()

    // IssuerAndSerialNumber from cert (serial + issuer)
    val dnSeq = extractIssuerFromCert(certDer)
    val serial = extractSerialFromCert(certDer)
    val issuerAndSerial = derSeq(dnSeq + serial)

    val signerInfo = derSeq(
      derInteger(byteArrayOf(1)) +
        issuerAndSerial +
        sha256AlgId +
        rsaAlgId +
        derOctetString(signature)
    )
    val signedData = derSeq(
      derInteger(byteArrayOf(1)) +
        derSet(sha256AlgId) +
        derSeq(dataOid) +
        derTag(0xa0, certDer) +
        derSet(signerInfo)
    )
    return derSeq(signedDataOid + derTag(0xa0, signedData))
  }

  private fun extractSerialFromCert(certDer: ByteArray): ByteArray {
    val tbs = unwrapNextTlv(certDer, 0).second
    var pos = 0
    val first = unwrapNextTlv(tbs, pos)
    if (tbs[pos] == 0xa0.toByte()) pos = first.first
    val serialEnd = unwrapNextTlv(tbs, pos).first
    return tbs.copyOfRange(pos, serialEnd)
  }

  private fun extractIssuerFromCert(certDer: ByteArray): ByteArray {
    val tbs = unwrapNextTlv(certDer, 0).second
    var pos = 0
    if (tbs[pos] == 0xa0.toByte()) pos = unwrapNextTlv(tbs, pos).first // version
    pos = unwrapNextTlv(tbs, pos).first // serial
    pos = unwrapNextTlv(tbs, pos).first // sigAlg
    val issuerEnd = unwrapNextTlv(tbs, pos).first
    return tbs.copyOfRange(pos, issuerEnd)
  }

  private fun unwrapNextTlv(data: ByteArray, offset: Int): Pair<Int, ByteArray> {
    var pos = offset + 1
    var len = data[pos++].toInt() and 0xff
    if ((len and 0x80) != 0) {
      val numBytes = len and 0x7f
      len = 0
      repeat(numBytes) { len = (len shl 8) or (data[pos++].toInt() and 0xff) }
    }
    return (pos + len) to data.copyOfRange(pos, pos + len)
  }

  private fun derTag(tag: Int, body: ByteArray): ByteArray {
    val out = ByteArrayOutputStream()
    out.write(tag)
    val len = body.size
    when {
      len < 128 -> out.write(len)
      len < 256 -> { out.write(0x81); out.write(len) }
      else -> { out.write(0x82); out.write(len shr 8); out.write(len and 0xff) }
    }
    out.write(body)
    return out.toByteArray()
  }

  private fun derSeq(body: ByteArray) = derTag(0x30, body)
  private fun derSet(body: ByteArray) = derTag(0x31, body)
  private fun derInteger(bytes: ByteArray) = derTag(0x02, if ((bytes[0].toInt() and 0x80) != 0) byteArrayOf(0) + bytes else bytes)
  private fun derOctetString(bytes: ByteArray) = derTag(0x04, bytes)
  private fun derBitString(bytes: ByteArray) = derTag(0x03, byteArrayOf(0) + bytes)
  private fun derNull() = byteArrayOf(0x05, 0x00)
  private fun derUtf8String(s: String) = derTag(0x0c, s.toByteArray(Charsets.UTF_8))
  private fun derUtcTime(date: Date): ByteArray {
    val sdf = SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    return derTag(0x17, sdf.format(date).toByteArray(Charsets.US_ASCII))
  }

  private fun derOid(vararg arcs: Int): ByteArray {
    val out = ByteArrayOutputStream()
    out.write(arcs[0] * 40 + arcs[1])
    for (i in 2 until arcs.size) {
      var v = arcs[i]
      val stack = mutableListOf<Int>()
      stack.add(v and 0x7f)
      while ((v ushr 7) > 0) {
        v = v ushr 7
        stack.add((v and 0x7f) or 0x80)
      }
      for (j in stack.indices.reversed()) out.write(stack[j])
    }
    return derTag(0x06, out.toByteArray())
  }
}
