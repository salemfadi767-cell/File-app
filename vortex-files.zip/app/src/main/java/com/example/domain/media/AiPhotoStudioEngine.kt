package com.example.domain.media

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

enum class HslColorChannel(val label: String, val centerHueDeg: Float) {
  RED("Red", 0f),
  ORANGE("Orange", 30f),
  YELLOW("Yellow", 60f),
  GREEN("Green", 120f),
  CYAN("Cyan", 180f),
  BLUE("Blue", 240f),
  PURPLE("Purple", 275f),
  MAGENTA("Magenta", 315f),
}

data class ChannelHslAdjustment(
  val hueShift: Float = 0f,      // -45 .. +45 degrees
  val saturationShift: Float = 0f, // -1 .. +1
  val luminanceShift: Float = 0f,  // -1 .. +1
)

enum class OverlayBlendMode(val label: String, val xferMode: PorterDuff.Mode?) {
  NORMAL("Normal", null),
  MULTIPLY("Multiply", PorterDuff.Mode.MULTIPLY),
  SCREEN("Screen", PorterDuff.Mode.SCREEN),
  OVERLAY("Overlay", PorterDuff.Mode.OVERLAY),
}

data class PhotoStudioParams(
  val exposure: Float = 0f,      // -1..+1
  val contrast: Float = 1f,      // 0.5..1.8
  val saturation: Float = 1f,    // 0..2
  val warmth: Float = 0f,        // -1..+1
  val channelAdjustments: Map<HslColorChannel, ChannelHslAdjustment> = emptyMap(),
)

data class ImageOverlayLayer(
  val overlayBitmap: Bitmap,
  val opacity: Float = 0.85f,
  val scale: Float = 0.45f,
  val offsetXNorm: Float = 0.5f,
  val offsetYNorm: Float = 0.5f,
  val blendMode: OverlayBlendMode = OverlayBlendMode.NORMAL,
)

class AiPhotoStudioEngine {

  companion object {
    private const val TAG = "AiPhotoStudioEngine"
  }

  private val imageEditModel by lazy {
    val config = generationConfig {
      responseModalities = listOf(ResponseModality.IMAGE)
    }
    Firebase.ai.generativeModel(
      modelName = "gemini-nano-banana-2.1",
      generationConfig = config,
    )
  }

  suspend fun processWithHslAndOverlay(
    source: Bitmap,
    params: PhotoStudioParams,
    overlay: ImageOverlayLayer? = null,
    maxDimension: Int = 1440,
  ): Bitmap =
    withContext(Dispatchers.Default) {
      val scaled = scaleDownIfNeeded(source, maxDimension)
      val w = scaled.width
      val h = scaled.height
      val pixels = IntArray(w * h)
      scaled.getPixels(pixels, 0, w, 0, 0, w, h)

      val expMul = Math.pow(2.0, params.exposure.toDouble()).toFloat()
      val hasChannelEdits = params.channelAdjustments.values.any {
        it.hueShift != 0f || it.saturationShift != 0f || it.luminanceShift != 0f
      }
      val hsl = FloatArray(3)

      for (i in pixels.indices) {
        val c = pixels[i]
        val a = (c ushr 24) and 0xff
        var r = ((c ushr 16) and 0xff) / 255f
        var g = ((c ushr 8) and 0xff) / 255f
        var b = (c and 0xff) / 255f

        // Global Exposure + Warmth + Contrast
        r = ((r * expMul + params.warmth * 0.10f - 0.5f) * params.contrast + 0.5f).coerceIn(0f, 1f)
        g = ((g * expMul - 0.5f) * params.contrast + 0.5f).coerceIn(0f, 1f)
        b = ((b * expMul - params.warmth * 0.10f - 0.5f) * params.contrast + 0.5f).coerceIn(0f, 1f)

        // Global saturation + 8-channel selective HSL Color Mixer
        if (params.saturation != 1f || hasChannelEdits) {
          rgbToHsl(r, g, b, hsl)
          hsl[1] = (hsl[1] * params.saturation).coerceIn(0f, 1f)
          if (hasChannelEdits && hsl[1] > 0.04f) {
            for ((ch, adj) in params.channelAdjustments) {
              if (adj.hueShift == 0f && adj.saturationShift == 0f && adj.luminanceShift == 0f) continue
              val dist = hueDistanceDeg(hsl[0], ch.centerHueDeg)
              if (dist < 38f) {
                val weight = 1f - (dist / 38f)
                hsl[0] = (hsl[0] + adj.hueShift * weight + 360f) % 360f
                hsl[1] = (hsl[1] + adj.saturationShift * weight * 0.6f).coerceIn(0f, 1f)
                hsl[2] = (hsl[2] + adj.luminanceShift * weight * 0.35f).coerceIn(0f, 1f)
              }
            }
          }
          val rgbOut = hslToRgb(hsl[0], hsl[1], hsl[2])
          r = rgbOut[0]; g = rgbOut[1]; b = rgbOut[2]
        }

        pixels[i] = (a shl 24) or
          ((r * 255f).toInt().coerceIn(0, 255) shl 16) or
          ((g * 255f).toInt().coerceIn(0, 255) shl 8) or
          (b * 255f).toInt().coerceIn(0, 255)
      }

      val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
      out.setPixels(pixels, 0, w, 0, 0, w, h)
      if (scaled !== source) scaled.recycle()

      if (overlay != null) {
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
          alpha = (overlay.opacity.coerceIn(0f, 1f) * 255).toInt()
          overlay.blendMode.xferMode?.let { xfermode = PorterDuffXfermode(it) }
        }
        val targetW = w * overlay.scale.coerceIn(0.05f, 2f)
        val aspect = overlay.overlayBitmap.height.toFloat() / overlay.overlayBitmap.width.coerceAtLeast(1)
        val targetH = targetW * aspect
        val cx = overlay.offsetXNorm * w
        val cy = overlay.offsetYNorm * h
        val dest = android.graphics.RectF(cx - targetW / 2f, cy - targetH / 2f, cx + targetW / 2f, cy + targetH / 2f)
        canvas.drawBitmap(overlay.overlayBitmap, null, dest, paint)
      }
      out
    }

  /**
   * Executes generative subject separation, background replacement, or AI portrait editing
   * via Firebase AI Logic (gemini-nano-banana-2.1). Errors are propagated transparently.
   */
  suspend fun editImageWithGeminiAi(
    inputBitmap: Bitmap,
    instruction: String,
    secondaryBitmap: Bitmap? = null,
  ): Bitmap =
    withContext(Dispatchers.IO) {
      val resizedPrimary = scaleDownIfNeeded(inputBitmap, 1024)
      val resizedSecondary = secondaryBitmap?.let { scaleDownIfNeeded(it, 1024) }
      try {
        val response = withTimeout(60_000L) {
          imageEditModel.generateContent(
            content {
              image(resizedPrimary)
              if (resizedSecondary != null) {
                image(resizedSecondary)
              }
              text(instruction)
            }
          )
        }
        val imagePart = response.candidates.firstOrNull()
          ?.content?.parts?.filterIsInstance<ImagePart>()
          ?.firstOrNull()
        imagePart?.image ?: throw IllegalStateException("AI model returned no edited image.")
      } catch (e: TimeoutCancellationException) {
        Log.e(TAG, "AI studio request timed out", e)
        throw IllegalStateException("AI image edit timed out after 60 seconds. Please retry.")
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        Log.e(TAG, "Firebase AI Logic edit failed", e)
        throw e
      }
    }

  suspend fun saveBitmapToFile(bitmap: Bitmap, destFile: File): File =
    withContext(Dispatchers.IO) {
      destFile.parentFile?.mkdirs()
      val isPng = destFile.extension.equals("png", ignoreCase = true)
      FileOutputStream(destFile).use { fos ->
        bitmap.compress(
          if (isPng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG,
          95,
          fos,
        )
      }
      destFile
    }

  private fun scaleDownIfNeeded(src: Bitmap, maxDim: Int): Bitmap {
    val maxSide = max(src.width, src.height)
    if (maxSide <= maxDim) return src
    val ratio = maxDim.toFloat() / maxSide.toFloat()
    return Bitmap.createScaledBitmap(
      src,
      (src.width * ratio).toInt().coerceAtLeast(1),
      (src.height * ratio).toInt().coerceAtLeast(1),
      true,
    )
  }

  private fun hueDistanceDeg(h1: Float, h2: Float): Float {
    val d = abs(h1 - h2) % 360f
    return min(d, 360f - d)
  }

  private fun rgbToHsl(r: Float, g: Float, b: Float, out: FloatArray) {
    val maxC = max(r, max(g, b))
    val minC = min(r, min(g, b))
    val l = (maxC + minC) / 2f
    if (maxC == minC) {
      out[0] = 0f; out[1] = 0f; out[2] = l
      return
    }
    val d = maxC - minC
    val s = if (l > 0.5f) d / (2f - maxC - minC) else d / (maxC + minC)
    val h = when (maxC) {
      r -> ((g - b) / d + (if (g < b) 6f else 0f)) * 60f
      g -> ((b - r) / d + 2f) * 60f
      else -> ((r - g) / d + 4f) * 60f
    }
    out[0] = (h + 360f) % 360f
    out[1] = s.coerceIn(0f, 1f)
    out[2] = l.coerceIn(0f, 1f)
  }

  private fun hslToRgb(h: Float, s: Float, l: Float): FloatArray {
    if (s == 0f) return floatArrayOf(l, l, l)
    val q = if (l < 0.5f) l * (1f + s) else l + s - l * s
    val p = 2f * l - q
    val hk = h / 360f
    return floatArrayOf(
      hueToRgb(p, q, hk + 1f / 3f),
      hueToRgb(p, q, hk),
      hueToRgb(p, q, hk - 1f / 3f),
    )
  }

  private fun hueToRgb(p: Float, q: Float, tIn: Float): Float {
    var t = tIn
    if (t < 0f) t += 1f
    if (t > 1f) t -= 1f
    return when {
      t < 1f / 6f -> p + (q - p) * 6f * t
      t < 0.5f -> q
      t < 2f / 3f -> p + (q - p) * (2f / 3f - t) * 6f
      else -> p
    }.coerceIn(0f, 1f)
  }
}
