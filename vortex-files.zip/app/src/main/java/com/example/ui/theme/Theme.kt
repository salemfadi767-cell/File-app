package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class VortexExtraColors(
  val isDark: Boolean,
  val losslessGreen: Color,
  val lossyWarning: Color,
  val shizukuCyan: Color,
  val rootGold: Color,
  val paneActiveBorder: Color,
  val paneInactiveSurface: Color,
  val syntaxKeyword: Color,
  val syntaxString: Color,
  val syntaxNumber: Color,
  val syntaxComment: Color,
  val syntaxType: Color,
  val syntaxTag: Color,
)

val LocalVortexExtraColors =
  staticCompositionLocalOf {
    VortexExtraColors(
      isDark = true,
      losslessGreen = LosslessGreenDark,
      lossyWarning = LossyCoralDark,
      shizukuCyan = ShizukuCyanDark,
      rootGold = RootGoldDark,
      paneActiveBorder = CyberEmeraldPrimary,
      paneInactiveSurface = CyberSurface,
      syntaxKeyword = Color(0xFFC792EA),
      syntaxString = Color(0xFF00E5A3),
      syntaxNumber = Color(0xFFF5B041),
      syntaxComment = Color(0xFF637777),
      syntaxType = Color(0xFF82AAFF),
      syntaxTag = Color(0xFFFF5C77),
    )
  }

val VortexShapes =
  Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp),
  )

@Composable
fun VortexTheme(
  themePreset: ThemePreset = ThemePreset.CYBER_EMERALD,
  accentStyle: AccentStyle = AccentStyle.DEFAULT,
  content: @Composable () -> Unit,
) {
  val isDark = themePreset != ThemePreset.MATERIAL_LIGHT
  val primaryOverride =
    when (accentStyle) {
      AccentStyle.DEFAULT -> null
      else -> if (isDark) accentStyle.darkColor else accentStyle.lightColor
    }

  val colorScheme =
    when (themePreset) {
      ThemePreset.CYBER_EMERALD -> {
        val p = primaryOverride ?: CyberEmeraldPrimary
        darkColorScheme(
          primary = p,
          onPrimary = Color(0xFF042219),
          primaryContainer = p.copy(alpha = 0.16f),
          onPrimaryContainer = p,
          secondary = CyberGoldSecondary,
          onSecondary = Color(0xFF281900),
          secondaryContainer = CyberGoldSecondary.copy(alpha = 0.16f),
          onSecondaryContainer = CyberGoldSecondary,
          tertiary = CyberCyanTertiary,
          onTertiary = Color(0xFF002133),
          background = CyberBg,
          onBackground = CyberTextPrimary,
          surface = CyberSurface,
          onSurface = CyberTextPrimary,
          surfaceVariant = CyberSurfaceElevated,
          onSurfaceVariant = CyberTextMuted,
          surfaceContainerLowest = CyberBg,
          surfaceContainerLow = CyberSurface,
          surfaceContainer = CyberSurfaceElevated,
          surfaceContainerHigh = CyberSurfaceHigh,
          outline = CyberOutline,
          outlineVariant = CyberOutline.copy(alpha = 0.5f),
          error = LossyCoralDark,
          onError = Color.White,
        )
      }

      ThemePreset.MIDNIGHT_COBALT -> {
        val p = primaryOverride ?: CobaltPrimary
        darkColorScheme(
          primary = p,
          onPrimary = Color(0xFF001E2E),
          primaryContainer = p.copy(alpha = 0.18f),
          onPrimaryContainer = p,
          secondary = CobaltSecondary,
          onSecondary = Color(0xFF10133D),
          secondaryContainer = CobaltSecondary.copy(alpha = 0.18f),
          onSecondaryContainer = CobaltSecondary,
          tertiary = CobaltTertiary,
          background = CobaltBg,
          onBackground = CyberTextPrimary,
          surface = CobaltSurface,
          onSurface = CyberTextPrimary,
          surfaceVariant = CobaltSurfaceElevated,
          onSurfaceVariant = CyberTextMuted,
          surfaceContainerLowest = CobaltBg,
          surfaceContainerLow = CobaltSurface,
          surfaceContainer = CobaltSurfaceElevated,
          surfaceContainerHigh = Color(0xFF1F2F4F),
          outline = Color(0xFF2A3E61),
          error = LossyCoralDark,
          onError = Color.White,
        )
      }

      ThemePreset.AMOLED_OBSIDIAN -> {
        val p = primaryOverride ?: CyberEmeraldPrimary
        darkColorScheme(
          primary = p,
          onPrimary = Color(0xFF002218),
          primaryContainer = p.copy(alpha = 0.16f),
          onPrimaryContainer = p,
          secondary = CyberGoldSecondary,
          onSecondary = Color(0xFF261700),
          secondaryContainer = CyberGoldSecondary.copy(alpha = 0.16f),
          onSecondaryContainer = CyberGoldSecondary,
          tertiary = CyberCyanTertiary,
          background = AmoledBg,
          onBackground = Color(0xFFF3F6FA),
          surface = AmoledSurface,
          onSurface = Color(0xFFF3F6FA),
          surfaceVariant = AmoledSurfaceElevated,
          onSurfaceVariant = CyberTextMuted,
          surfaceContainerLowest = AmoledBg,
          surfaceContainerLow = AmoledSurface,
          surfaceContainer = AmoledSurfaceElevated,
          surfaceContainerHigh = Color(0xFF1A212E),
          outline = AmoledOutline,
          error = LossyCoralDark,
          onError = Color.White,
        )
      }

      ThemePreset.MATERIAL_LIGHT -> {
        val p = primaryOverride ?: LightPrimary
        lightColorScheme(
          primary = p,
          onPrimary = Color.White,
          primaryContainer = p.copy(alpha = 0.12f),
          onPrimaryContainer = p,
          secondary = LightSecondary,
          onSecondary = Color.White,
          secondaryContainer = LightSecondary.copy(alpha = 0.12f),
          onSecondaryContainer = LightSecondary,
          tertiary = LightTertiary,
          background = LightBg,
          onBackground = LightTextPrimary,
          surface = LightSurface,
          onSurface = LightTextPrimary,
          surfaceVariant = LightSurfaceElevated,
          onSurfaceVariant = LightTextMuted,
          surfaceContainerLowest = LightSurface,
          surfaceContainerLow = LightBg,
          surfaceContainer = LightSurfaceElevated,
          surfaceContainerHigh = Color(0xFFDCE5F0),
          outline = LightOutline,
          error = LossyCoralLight,
          onError = Color.White,
        )
      }
    }

  val extraColors =
    if (isDark) {
      VortexExtraColors(
        isDark = true,
        losslessGreen = LosslessGreenDark,
        lossyWarning = LossyCoralDark,
        shizukuCyan = ShizukuCyanDark,
        rootGold = RootGoldDark,
        paneActiveBorder = colorScheme.primary,
        paneInactiveSurface = colorScheme.surface,
        syntaxKeyword = Color(0xFFC792EA),
        syntaxString = Color(0xFF00E5A3),
        syntaxNumber = Color(0xFFF5B041),
        syntaxComment = Color(0xFF6B7F99),
        syntaxType = Color(0xFF60A5FA),
        syntaxTag = Color(0xFFFF6B81),
      )
    } else {
      VortexExtraColors(
        isDark = false,
        losslessGreen = LosslessGreenLight,
        lossyWarning = LossyCoralLight,
        shizukuCyan = ShizukuCyanLight,
        rootGold = RootGoldLight,
        paneActiveBorder = colorScheme.primary,
        paneInactiveSurface = colorScheme.surface,
        syntaxKeyword = Color(0xFF7C3AED),
        syntaxString = Color(0xFF047857),
        syntaxNumber = Color(0xFFB45309),
        syntaxComment = Color(0xFF64748B),
        syntaxType = Color(0xFF1D4ED8),
        syntaxTag = Color(0xFFBE123C),
      )
    }

  CompositionLocalProvider(LocalVortexExtraColors provides extraColors) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = VortexTypography,
      shapes = VortexShapes,
      content = content,
    )
  }
}
