package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.fs.formatFileSize
import com.example.i18n.LocalAppStrings
import com.example.ui.viewmodel.StorageAnalysisSummary

@Composable
fun StreamUrlDialog(
  onDismiss: () -> Unit,
  onPlayUrl: (String) -> Unit,
  onDownloadUrl: ((String) -> Unit)? = null,
) {
  val strings = LocalAppStrings.current
  var url by remember { mutableStateOf("https://") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.LiveTv, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(strings.streamUrlTitle)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(strings.streamUrlHint, style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(
          value = url,
          onValueChange = { url = it },
          label = { Text("URL / YouTube / Magnet") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("stream_url_input"),
        )
      }
    },
    confirmButton = {
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        if (onDownloadUrl != null) {
          TextButton(
            onClick = {
              if (url.isNotBlank() && url != "https://") {
                onDownloadUrl(url.trim())
                onDismiss()
              }
            },
          ) {
            Text(strings.resolveStreams)
          }
        }
        Button(
          onClick = {
            if (url.isNotBlank() && url != "https://") {
              onPlayUrl(url.trim())
              onDismiss()
            }
          },
          modifier = Modifier.testTag("stream_play_btn"),
        ) {
          Text(strings.playStream)
        }
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(strings.cancel) }
    },
  )
}

@Composable
fun BatchRenameDialog(
  selectedCount: Int,
  sampleNames: List<String> = emptyList(),
  onDismiss: () -> Unit,
  onConfirm: (prefix: String, suffix: String, find: String, replace: String, addCounter: Boolean, startNum: Int) -> Unit,
) {
  val strings = LocalAppStrings.current
  var prefix by remember { mutableStateOf("") }
  var suffix by remember { mutableStateOf("") }
  var findText by remember { mutableStateOf("") }
  var replaceText by remember { mutableStateOf("") }
  var addCounter by remember { mutableStateOf(true) }
  var startNum by remember { mutableStateOf("1") }

  val startInt = startNum.toIntOrNull() ?: 1
  val previews = remember(sampleNames, prefix, suffix, findText, replaceText, addCounter, startInt) {
    sampleNames.take(4).mapIndexed { idx, oldName ->
      val base = if (oldName.contains('.')) oldName.substringBeforeLast('.') else oldName
      val ext = if (oldName.contains('.')) ".${oldName.substringAfterLast('.')}" else ""
      var next = if (findText.isNotEmpty()) base.replace(findText, replaceText) else base
      next = "$prefix$next$suffix"
      if (addCounter) next = "${next}_${startInt + idx}"
      oldName to "$next$ext"
    }
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("${strings.batchRename} ($selectedCount)") },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(value = prefix, onValueChange = { prefix = it }, label = { Text("Prefix") }, singleLine = true)
        OutlinedTextField(value = suffix, onValueChange = { suffix = it }, label = { Text("Suffix") }, singleLine = true)
        OutlinedTextField(value = findText, onValueChange = { findText = it }, label = { Text("Find text") }, singleLine = true)
        OutlinedTextField(value = replaceText, onValueChange = { replaceText = it }, label = { Text("Replace with") }, singleLine = true)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("Auto Number (_1, _2...)", style = MaterialTheme.typography.bodySmall)
          Switch(checked = addCounter, onCheckedChange = { addCounter = it })
        }
        if (addCounter) {
          OutlinedTextField(
            value = startNum,
            onValueChange = { if (it.all { ch -> ch.isDigit() }) startNum = it },
            label = { Text("Start #") },
            singleLine = true,
          )
        }
        if (previews.isNotEmpty()) {
          Surface(
            color = MaterialTheme.colorScheme.surfaceContainer,
            shape = MaterialTheme.shapes.small,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
              Text(strings.batchPreviewTitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
              previews.forEach { (before, after) ->
                Text("$before -> $after", style = MaterialTheme.typography.labelSmall, maxLines = 1)
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onConfirm(prefix, suffix, findText, replaceText, addCounter, startInt)
          onDismiss()
        },
        modifier = Modifier.testTag("batch_rename_confirm"),
      ) {
        Text(strings.confirm)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(strings.cancel) }
    },
  )
}

@Composable
fun StorageAnalyzerDialog(
  rootPath: String,
  analyze: suspend (String) -> StorageAnalysisSummary,
  onNavigateTo: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  var summary by remember { mutableStateOf<StorageAnalysisSummary?>(null) }

  LaunchedEffect(rootPath) {
    summary = analyze(rootPath)
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.storageAnalyzerTitle) },
    text = {
      val s = summary
      if (s == null) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          CircularProgressIndicator()
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "${formatFileSize(s.totalBytes)} • ${s.folderCount} folders • ${s.fileCount} files",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
          )
          LazyColumn(
            modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            items(s.topEntries) { stat ->
              val ratio =
                if (s.totalBytes > 0L) (stat.bytes.toFloat() / s.totalBytes.toFloat()).coerceIn(0f, 1f)
                else 0f
              Surface(
                color = MaterialTheme.colorScheme.surfaceContainer,
                shape = MaterialTheme.shapes.small,
                modifier =
                  Modifier
                    .fillMaxWidth()
                    .clickable {
                      if (stat.isDirectory) {
                        onNavigateTo(stat.path)
                        onDismiss()
                      }
                    },
              ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                      Icon(
                        if (stat.isDirectory) Icons.Default.Folder else Icons.AutoMirrored.Filled.InsertDriveFile,
                        contentDescription = null,
                        tint = if (stat.isDirectory) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                      )
                      Text(stat.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                    }
                    Text(
                      formatFileSize(stat.bytes),
                      style = MaterialTheme.typography.labelMedium,
                      color = MaterialTheme.colorScheme.primary,
                    )
                  }
                  LinearProgressIndicator(progress = { ratio }, modifier = Modifier.fillMaxWidth())
                }
              }
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text(strings.close) }
    },
  )
}
