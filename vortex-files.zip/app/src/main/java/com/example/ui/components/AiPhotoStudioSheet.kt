package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.media.AiPhotoStudioEngine
import com.example.domain.media.ChannelHslAdjustment
import com.example.domain.media.HslColorChannel
import com.example.domain.media.ImageOverlayLayer
import com.example.domain.media.OverlayBlendMode
import com.example.domain.media.PhotoStudioParams
import com.example.i18n.LocalAppStrings
import java.io.File
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AiPhotoStudioSheet(
  sourceFile: File,
  sourceBitmap: Bitmap,
  engine: AiPhotoStudioEngine,
  onSavedImage: (File) -> Unit,
  onDismiss: () -> Unit,
) {
  val context = LocalContext.current
  val strings = LocalAppStrings.current
  val scope = rememberCoroutineScope()
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  var selectedTab by remember { mutableIntStateOf(0) }
  var previewBitmap by remember { mutableStateOf(sourceBitmap) }
  var baseBitmap by remember { mutableStateOf(sourceBitmap) }

  // Tab 0: Adobe HSL Color Mixer + Light
  var exposure by remember { mutableFloatStateOf(0f) }
  var contrast by remember { mutableFloatStateOf(1f) }
  var saturation by remember { mutableFloatStateOf(1f) }
  var warmth by remember { mutableFloatStateOf(0f) }
  var selectedChannel by remember { mutableStateOf(HslColorChannel.RED) }
  val channelMap = remember { mutableStateMapOf<HslColorChannel, ChannelHslAdjustment>() }

  // Tab 1: Second Image Overlay Layer
  var overlayBitmap by remember { mutableStateOf<Bitmap?>(null) }
  var overlayOpacity by remember { mutableFloatStateOf(0.85f) }
  var overlayScale by remember { mutableFloatStateOf(0.45f) }
  var overlayX by remember { mutableFloatStateOf(0.5f) }
  var overlayY by remember { mutableFloatStateOf(0.5f) }
  var blendMode by remember { mutableStateOf(OverlayBlendMode.NORMAL) }

  // Tab 2: Gemini AI Subject Separation & Editing
  var aiPrompt by remember { mutableStateOf("Separate the main subject cleanly onto a clean transparent-style studio background and enhance portrait lighting.") }
  var aiSecondaryBg by remember { mutableStateOf<Bitmap?>(null) }
  var isAiLoading by remember { mutableStateOf(false) }
  var aiError by remember { mutableStateOf<String?>(null) }
  var isSaving by remember { mutableStateOf(false) }

  val overlayPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
      if (uri != null) {
        context.contentResolver.openInputStream(uri)?.use { stream ->
          BitmapFactory.decodeStream(stream)?.let { overlayBitmap = it }
        }
      }
    }

  val aiBgPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
      if (uri != null) {
        context.contentResolver.openInputStream(uri)?.use { stream ->
          BitmapFactory.decodeStream(stream)?.let { aiSecondaryBg = it }
        }
      }
    }

  val currentChannelAdj = channelMap[selectedChannel] ?: ChannelHslAdjustment()

  LaunchedEffect(
    baseBitmap,
    exposure,
    contrast,
    saturation,
    warmth,
    channelMap.toMap(),
    overlayBitmap,
    overlayOpacity,
    overlayScale,
    overlayX,
    overlayY,
    blendMode,
  ) {
    previewBitmap =
      engine.processWithHslAndOverlay(
        source = baseBitmap,
        params = PhotoStudioParams(exposure, contrast, saturation, warmth, channelMap.toMap()),
        overlay = overlayBitmap?.let {
          ImageOverlayLayer(it, overlayOpacity, overlayScale, overlayX, overlayY, blendMode)
        },
        maxDimension = 1080,
      )
  }

  ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(strings.aiPhotoStudioTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row {
          Button(
            onClick = {
              isSaving = true
              scope.launch {
                val rendered =
                  engine.processWithHslAndOverlay(
                    source = baseBitmap,
                    params = PhotoStudioParams(exposure, contrast, saturation, warmth, channelMap.toMap()),
                    overlay = overlayBitmap?.let {
                      ImageOverlayLayer(it, overlayOpacity, overlayScale, overlayX, overlayY, blendMode)
                    },
                    maxDimension = 2048,
                  )
                val out = File(sourceFile.parentFile, "${sourceFile.nameWithoutExtension}_studio.png")
                engine.saveBitmapToFile(rendered, out)
                isSaving = false
                onSavedImage(out)
              }
            },
            enabled = !isSaving && !isAiLoading,
            modifier = Modifier.testTag("photo_studio_save_button"),
          ) {
            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(strings.saveFile)
          }
          IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = strings.close) }
        }
      }

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(220.dp)
          .background(MaterialTheme.colorScheme.surfaceContainerLowest, RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center,
      ) {
        Image(
          bitmap = previewBitmap.asImageBitmap(),
          contentDescription = strings.aiPhotoStudioTitle,
          contentScale = ContentScale.Fit,
          modifier = Modifier.fillMaxWidth().height(216.dp),
        )
        if (isAiLoading) {
          Surface(color = MaterialTheme.colorScheme.scrim.copy(alpha = 0.65f), shape = RoundedCornerShape(12.dp)) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
              CircularProgressIndicator()
              Spacer(Modifier.height(6.dp))
              Text("AI Studio processing...", color = MaterialTheme.colorScheme.onPrimary)
            }
          }
        }
      }

      PrimaryTabRow(selectedTabIndex = selectedTab) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          icon = { Icon(Icons.Default.Palette, contentDescription = null) },
          text = { Text(strings.colorMixerHsl, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          icon = { Icon(Icons.Default.Layers, contentDescription = null) },
          text = { Text(strings.addImageOverlay, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        )
        Tab(
          selected = selectedTab == 2,
          onClick = { selectedTab = 2 },
          icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null) },
          text = { Text(strings.separateSubjectAi, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        )
      }

      when (selectedTab) {
        0 -> {
          Text("Exposure: ${"%.2f".format(exposure)}", style = MaterialTheme.typography.labelMedium)
          Slider(value = exposure, onValueChange = { exposure = it }, valueRange = -1f..1f)
          Text("${strings.contrastLabel}: ${"%.2f".format(contrast)} • ${strings.saturationLabel}: ${"%.2f".format(saturation)}", style = MaterialTheme.typography.labelMedium)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Slider(value = contrast, onValueChange = { contrast = it }, valueRange = 0.5f..1.8f, modifier = Modifier.weight(1f))
            Slider(value = saturation, onValueChange = { saturation = it }, valueRange = 0f..2f, modifier = Modifier.weight(1f))
          }
          Text("8-Channel HSL Color Mixer", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HslColorChannel.entries.forEach { ch ->
              FilterChip(
                selected = selectedChannel == ch,
                onClick = { selectedChannel = ch },
                label = { Text(ch.label) },
              )
            }
          }
          Text("${selectedChannel.label} Hue (${currentChannelAdj.hueShift.toInt()}°)")
          Slider(
            value = currentChannelAdj.hueShift,
            onValueChange = { channelMap[selectedChannel] = currentChannelAdj.copy(hueShift = it) },
            valueRange = -45f..45f,
          )
          Text("${selectedChannel.label} Saturation / Luminance")
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Slider(
              value = currentChannelAdj.saturationShift,
              onValueChange = { channelMap[selectedChannel] = currentChannelAdj.copy(saturationShift = it) },
              valueRange = -1f..1f,
              modifier = Modifier.weight(1f),
            )
            Slider(
              value = currentChannelAdj.luminanceShift,
              onValueChange = { channelMap[selectedChannel] = currentChannelAdj.copy(luminanceShift = it) },
              valueRange = -1f..1f,
              modifier = Modifier.weight(1f),
            )
          }
        }

        1 -> {
          OutlinedButton(
            onClick = { overlayPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            modifier = Modifier.fillMaxWidth().testTag("pick_overlay_image_button"),
          ) {
            Text(strings.addImageOverlay)
          }
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OverlayBlendMode.entries.forEach { mode ->
              FilterChip(selected = blendMode == mode, onClick = { blendMode = mode }, label = { Text(mode.label) })
            }
          }
          Text("Opacity (${(overlayOpacity * 100).toInt()}%) & Scale (${(overlayScale * 100).toInt()}%)")
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Slider(value = overlayOpacity, onValueChange = { overlayOpacity = it }, valueRange = 0f..1f, modifier = Modifier.weight(1f))
            Slider(value = overlayScale, onValueChange = { overlayScale = it }, valueRange = 0.1f..1.5f, modifier = Modifier.weight(1f))
          }
          Text("Position X / Y")
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Slider(value = overlayX, onValueChange = { overlayX = it }, valueRange = 0f..1f, modifier = Modifier.weight(1f))
            Slider(value = overlayY, onValueChange = { overlayY = it }, valueRange = 0f..1f, modifier = Modifier.weight(1f))
          }
        }

        2 -> {
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(
              "Isolate subject on clean studio white backdrop",
              "Isolate person & replace background with neon city night",
              "Enhance portrait skin lighting & bokeh background",
              "Combine subject with the attached second background image",
            ).forEach { preset ->
              FilterChip(
                selected = aiPrompt == preset,
                onClick = { aiPrompt = preset },
                label = { Text(preset.take(28) + "…") },
              )
            }
          }
          OutlinedTextField(
            value = aiPrompt,
            onValueChange = { aiPrompt = it },
            label = { Text(strings.separateSubjectAi) },
            modifier = Modifier.fillMaxWidth().testTag("ai_photo_prompt_input"),
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
              onClick = { aiBgPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
              modifier = Modifier.weight(1f),
            ) {
              Text(if (aiSecondaryBg != null) "2nd Photo Attached" else "Attach 2nd Photo")
            }
            Button(
              onClick = {
                isAiLoading = true
                aiError = null
                scope.launch {
                  runCatching {
                    engine.editImageWithGeminiAi(baseBitmap, aiPrompt, aiSecondaryBg)
                  }.onSuccess { resultBmp ->
                    baseBitmap = resultBmp
                    previewBitmap = resultBmp
                  }.onFailure { err ->
                    aiError = err.localizedMessage ?: "AI request failed"
                  }
                  isAiLoading = false
                }
              },
              enabled = !isAiLoading && aiPrompt.isNotBlank(),
              modifier = Modifier.weight(1f).testTag("run_ai_photo_edit_button"),
            ) {
              Icon(Icons.Default.AutoAwesome, contentDescription = null)
              Spacer(Modifier.width(6.dp))
              Text("Run AI Edit")
            }
          }
          if (!aiError.isNullOrBlank()) {
            Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(10.dp)) {
              Text(
                aiError!!,
                color = MaterialTheme.colorScheme.onErrorContainer,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(10.dp),
              )
            }
          }
        }
      }
      Spacer(Modifier.height(12.dp))
    }
  }
}
