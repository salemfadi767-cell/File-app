package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.ManageSearch
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.fs.DiffResult
import com.example.domain.fs.FileCategory
import com.example.domain.fs.FileHashes
import com.example.domain.fs.MagicDetectionResult
import com.example.domain.fs.SearchHit
import com.example.domain.fs.VirtualFileNode
import com.example.domain.fs.VortexBackupMetadata
import com.example.domain.fs.formatFileSize
import com.example.domain.security.AntivirusScanReport
import com.example.domain.security.ThreatSeverity
import com.example.i18n.LocalAppStrings
import com.example.ui.theme.MonoFontFamily

@Composable
fun TextInputDialog(
  title: String,
  label: String,
  initialValue: String = "",
  onDismiss: () -> Unit,
  onConfirm: (String) -> Unit,
) {
  val strings = LocalAppStrings.current
  var value by remember { mutableStateOf(initialValue) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title) },
    text = {
      OutlinedTextField(
        value = value,
        onValueChange = { value = it },
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("dialog_text_input"),
      )
    },
    confirmButton = {
      Button(
        onClick = {
          onConfirm(value)
          onDismiss()
        },
        modifier = Modifier.testTag("dialog_confirm_btn"),
      ) {
        Text(strings.confirm)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(strings.cancel) }
    },
  )
}

@Composable
fun ChmodDialog(
  node: VirtualFileNode,
  onDismiss: () -> Unit,
  onApply: (String) -> Unit,
) {
  val strings = LocalAppStrings.current
  var octal by remember { mutableStateOf("755") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.permissionsChmod) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(node.name, style = MaterialTheme.typography.titleSmall)
        Text("Current: ${node.permissions}", style = MaterialTheme.typography.labelMedium)
        OutlinedTextField(
          value = octal,
          onValueChange = { if (it.length <= 4 && it.all { c -> c in '0'..'7' }) octal = it },
          label = { Text("Octal Mode (e.g. 755, 644, 777)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf("644", "755", "777").forEach { preset ->
            TextButton(onClick = { octal = preset }) { Text(preset) }
          }
        }
      }
    },
    confirmButton = {
      Button(onClick = {
        onApply(octal)
        onDismiss()
      }) { Text(strings.confirm) }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } },
  )
}

@Composable
fun PropertiesAndHashDialog(
  node: VirtualFileNode,
  computeHashes: suspend (VirtualFileNode) -> FileHashes?,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  var hashes by remember { mutableStateOf<FileHashes?>(null) }
  var loading by remember { mutableStateOf(!node.isDirectory) }

  LaunchedEffect(node.path) {
    if (!node.isDirectory) {
      hashes = computeHashes(node)
      loading = false
    }
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.properties) },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Text(node.name, style = MaterialTheme.typography.titleMedium)
        Text("Path: ${node.path}", style = MaterialTheme.typography.labelMedium)
        Text("Size: ${formatFileSize(node.size)} (${node.size} B)", style = MaterialTheme.typography.bodySmall)
        Text("Permissions: ${node.permissions}", style = MaterialTheme.typography.bodySmall)
        Text("Source: ${node.sourceType.name}", style = MaterialTheme.typography.bodySmall)
        if (!node.isDirectory) {
          HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
          if (loading) {
            Text("Computing MD5 / SHA-1 / SHA-256...", style = MaterialTheme.typography.bodySmall)
          } else if (hashes != null) {
            Text("MD5: ${hashes!!.md5}", style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily))
            Text("SHA-1: ${hashes!!.sha1}", style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily))
            Text("SHA-256: ${hashes!!.sha256}", style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily))
          }
        }
      }
    },
    confirmButton = { TextButton(onClick = onDismiss) { Text(strings.close) } },
  )
}

@Composable
fun CompareResultDialog(
  diff: DiffResult,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.compare) },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Text(
          diff.summary,
          style = MaterialTheme.typography.titleSmall,
          color = if (diff.identical) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
        )
        if (diff.onlyInLeft.isNotEmpty()) {
          Text("Only in Left:", style = MaterialTheme.typography.labelLarge)
          diff.onlyInLeft.take(20).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        }
        if (diff.onlyInRight.isNotEmpty()) {
          Text("Only in Right:", style = MaterialTheme.typography.labelLarge)
          diff.onlyInRight.take(20).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        }
        if (diff.differentContent.isNotEmpty()) {
          Text("Differences:", style = MaterialTheme.typography.labelLarge)
          diff.differentContent.take(20).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        }
      }
    },
    confirmButton = { TextButton(onClick = onDismiss) { Text(strings.close) } },
  )
}

enum class OpenAsMode(val routeParam: String) {
  TEXT_CODE("text"),
  HEX("hex"),
  IMAGE("image"),
  VIDEO("video"),
  AUDIO("audio"),
  PDF("pdf"),
  DATABASE("db"),
  ARCHIVE("archive"),
  APK("apk"),
  EXTERNAL("external"),
}

@Composable
fun OpenAsDialog(
  node: VirtualFileNode,
  onSelectMode: (OpenAsMode) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val options =
    listOf(
      Triple(OpenAsMode.TEXT_CODE, Icons.Default.Code, strings.readAsCode),
      Triple(OpenAsMode.HEX, Icons.Default.Code, strings.readAsHex),
      Triple(OpenAsMode.IMAGE, Icons.Default.Image, strings.readAsImage),
      Triple(OpenAsMode.VIDEO, Icons.Default.VideoFile, strings.readAsVideo),
      Triple(OpenAsMode.AUDIO, Icons.Default.AudioFile, strings.readAsAudio),
      Triple(OpenAsMode.PDF, Icons.Default.PictureAsPdf, strings.readAsPdf),
      Triple(OpenAsMode.DATABASE, Icons.Default.Storage, strings.readAsDatabase),
      Triple(OpenAsMode.ARCHIVE, Icons.Default.Archive, strings.readAsArchive),
      Triple(OpenAsMode.APK, Icons.Default.Android, strings.readAsApk),
      Triple(OpenAsMode.EXTERNAL, Icons.AutoMirrored.Filled.OpenInNew, strings.openWithExternalApp),
    )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Column {
        Text(strings.readAsTitle)
        Text(node.name, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    },
    text = {
      Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        options.forEach { (mode, icon, label) ->
          ActionSheetRow(icon, label) {
            onDismiss()
            onSelectMode(mode)
          }
        }
      }
    },
    confirmButton = { TextButton(onClick = onDismiss) { Text(strings.close) } },
  )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileContextActionSheet(
  node: VirtualFileNode,
  onDismiss: () -> Unit,
  onOpenViewer: () -> Unit,
  onOpenOffice: () -> Unit,
  onOpenAs: () -> Unit,
  onDetectFormat: () -> Unit,
  onOpenEditor: () -> Unit,
  onOpenHex: () -> Unit,
  onInspectApk: () -> Unit,
  onConvertSignApk: () -> Unit,
  onLockOrUnlockVault: () -> Unit,
  onBrowseArchive: () -> Unit,
  onExtractHere: () -> Unit,
  onExtractToOther: () -> Unit,
  onConvert: () -> Unit,
  onCompress: () -> Unit,
  onRename: () -> Unit,
  onChmod: () -> Unit,
  onProperties: () -> Unit,
  onAntivirusScan: () -> Unit = {},
  onShare: () -> Unit,
  onOpenExternal: () -> Unit,
  onDelete: () -> Unit,
) {
  val strings = LocalAppStrings.current
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
    ) {
      Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text(node.name, style = MaterialTheme.typography.titleMedium)
        Text(
          "${if (node.isDirectory) "Folder" else formatFileSize(node.size)} • ${node.permissions}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
      HorizontalDivider()

      if (node.isOfficeDocument || node.category == FileCategory.PDF) {
        ActionSheetRow(Icons.Default.Description, strings.officeSuiteTitle) { onDismiss(); onOpenOffice() }
      }
      if (node.category == FileCategory.APK) {
        ActionSheetRow(Icons.Default.Android, strings.inspectApk) { onDismiss(); onInspectApk() }
      }
      if (node.category == FileCategory.APK || node.isArchiveLike || node.isDirectory) {
        ActionSheetRow(Icons.Default.Build, strings.convertToSignedApk) { onDismiss(); onConvertSignApk() }
      }
      if (node.isArchiveLike) {
        ActionSheetRow(Icons.Default.Archive, strings.browseInsideArchive) { onDismiss(); onBrowseArchive() }
        ActionSheetRow(Icons.Default.Unarchive, strings.extractHere) { onDismiss(); onExtractHere() }
        ActionSheetRow(Icons.Default.Unarchive, strings.extractToPane) { onDismiss(); onExtractToOther() }
      }
      if (!node.isDirectory) {
        ActionSheetRow(Icons.Default.ManageSearch, strings.detectOriginalFormat) { onDismiss(); onDetectFormat() }
        ActionSheetRow(Icons.AutoMirrored.Filled.OpenInNew, strings.openWithExternalApp) { onDismiss(); onOpenExternal() }
        ActionSheetRow(Icons.Default.Transform, strings.readAsTitle) { onDismiss(); onOpenAs() }
        ActionSheetRow(Icons.AutoMirrored.Filled.OpenInNew, strings.openBuiltinViewer) { onDismiss(); onOpenViewer() }
        ActionSheetRow(Icons.Default.Code, strings.openInEditor) { onDismiss(); onOpenEditor() }
        ActionSheetRow(Icons.Default.Code, strings.openAsHex) { onDismiss(); onOpenHex() }
        ActionSheetRow(Icons.Default.Transform, strings.convertFormat) { onDismiss(); onConvert() }
      }
      ActionSheetRow(
        if (node.category == FileCategory.VAULT) Icons.Default.LockOpen else Icons.Default.EnhancedEncryption,
        if (node.category == FileCategory.VAULT) strings.unlockVault else strings.lockWithPassword,
      ) { onDismiss(); onLockOrUnlockVault() }
      ActionSheetRow(Icons.Default.Archive, strings.compress) { onDismiss(); onCompress() }
      ActionSheetRow(Icons.Default.DriveFileRenameOutline, strings.rename) { onDismiss(); onRename() }
      ActionSheetRow(Icons.Default.Lock, strings.permissionsChmod) { onDismiss(); onChmod() }
      ActionSheetRow(Icons.Default.Info, strings.properties) { onDismiss(); onProperties() }
      ActionSheetRow(Icons.Default.Security, strings.antivirusScanAction) { onDismiss(); onAntivirusScan() }
      if (!node.isDirectory) {
        ActionSheetRow(Icons.Default.Share, strings.shareFileLabel) { onDismiss(); onShare() }
      }
      ActionSheetRow(Icons.Default.Delete, strings.delete) { onDismiss(); onDelete() }
    }
  }
}

@Composable
private fun ActionSheetRow(icon: ImageVector, label: String, onClick: () -> Unit) {
  ListItem(
    headlineContent = { Text(label) },
    leadingContent = { Icon(icon, contentDescription = label, tint = MaterialTheme.colorScheme.primary) },
    modifier = Modifier.clickable(onClick = onClick),
  )
}

@Composable
fun DeepSearchDialog(
  results: List<SearchHit>?,
  isSearching: Boolean,
  onSearch: (query: String, content: Boolean, regex: Boolean) -> Unit,
  onHitClick: (SearchHit) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  var query by remember { mutableStateOf("") }
  var searchContent by remember { mutableStateOf(false) }
  var useRegex by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.deepSearch) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
          value = query,
          onValueChange = { query = it },
          label = { Text(strings.searchHint) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("deep_search_input"),
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(strings.searchContentToggle, style = MaterialTheme.typography.bodySmall)
          Switch(checked = searchContent, onCheckedChange = { searchContent = it })
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(strings.searchRegexToggle, style = MaterialTheme.typography.bodySmall)
          Switch(checked = useRegex, onCheckedChange = { useRegex = it })
        }
        Button(
          onClick = { onSearch(query, searchContent, useRegex) },
          modifier = Modifier.fillMaxWidth().testTag("deep_search_run_btn"),
        ) {
          Text(if (isSearching) "..." else strings.deepSearch)
        }
        if (results != null) {
          LazyColumn(modifier = Modifier.height(220.dp)) {
            items(results) { hit ->
              Surface(
                modifier =
                  Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
                    .clickable {
                      onHitClick(hit)
                      onDismiss()
                    },
                color = MaterialTheme.colorScheme.surfaceContainer,
                shape = MaterialTheme.shapes.small,
              ) {
                Column(modifier = Modifier.padding(8.dp)) {
                  Text(hit.node.name, style = MaterialTheme.typography.titleSmall)
                  Text(hit.node.path, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  if (hit.matchedLine != null) {
                    Text(hit.matchedLine, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                  }
                }
              }
            }
          }
        }
      }
    },
    confirmButton = { TextButton(onClick = onDismiss) { Text(strings.close) } },
  )
}

@Composable
fun DeleteConfirmDialog(
  count: Int,
  trashRetentionDays: Int,
  onDismiss: () -> Unit,
  onConfirmDelete: (permanent: Boolean) -> Unit,
) {
  val strings = LocalAppStrings.current
  var bypassTrash by remember(trashRetentionDays) { mutableStateOf(trashRetentionDays <= 0) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("${strings.delete} ($count)") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (trashRetentionDays > 0) {
          Text(
            text = "${strings.moveToRecycleBin} ($trashRetentionDays d)",
            style = MaterialTheme.typography.bodyMedium,
          )
        }
        Row(
          modifier = Modifier.fillMaxWidth().clickable { bypassTrash = !bypassTrash },
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Checkbox(checked = bypassTrash, onCheckedChange = { bypassTrash = it })
          Icon(
            Icons.Default.DeleteForever,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.error,
          )
          Text(
            strings.deletePermanentOption,
            style = MaterialTheme.typography.bodySmall,
            color = if (bypassTrash) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
          )
        }
      }
    },
    confirmButton = {
      Button(
        colors = if (bypassTrash) ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error) else ButtonDefaults.buttonColors(),
        onClick = {
          onConfirmDelete(bypassTrash)
          onDismiss()
        },
        modifier = Modifier.testTag("confirm_delete_btn"),
      ) {
        Text(if (bypassTrash) strings.deletePermanentOption else strings.moveToRecycleBin)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(strings.cancel) }
    },
  )
}

@Composable
fun MagicFormatDialog(
  node: VirtualFileNode,
  result: MagicDetectionResult,
  onOpenReader: (readerId: String) -> Unit,
  onFixExtension: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.detectOriginalFormat) },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Text(node.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
          shape = MaterialTheme.shapes.small,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(strings.detectedFormatLabel, style = MaterialTheme.typography.labelSmall)
            Text(
              "${result.detectedFormatName} (.${result.suggestedExtension}) • ${result.confidencePercent}%",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary,
            )
            Text("MIME: ${result.mimeType}", style = MaterialTheme.typography.labelSmall)
          }
        }
        if (result.headerHexPreview.isNotBlank()) {
          Text(strings.headerHexLabel, style = MaterialTheme.typography.labelSmall)
          Text(
            result.headerHexPreview,
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        if (!result.matchesCurrentExtension && result.suggestedExtension.isNotBlank()) {
          Button(
            onClick = {
              onFixExtension(result.suggestedExtension)
              onDismiss()
            },
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text("${strings.fixExtensionAction} (.${result.suggestedExtension})")
          }
        }
        HorizontalDivider()
        Text(strings.readAsTitle, style = MaterialTheme.typography.labelMedium)
        result.compatibleReaderIds.forEach { readerId ->
          val label = when (readerId) {
            "image" -> strings.readAsImage
            "video" -> strings.readAsVideo
            "audio" -> strings.readAsAudio
            "pdf" -> strings.readAsPdf
            "word" -> "Word (.docx)"
            "excel" -> "Excel (.xlsx)"
            "pptx" -> "PowerPoint (.pptx)"
            "apk" -> strings.readAsApk
            "archive" -> strings.readAsArchive
            "db" -> strings.readAsDatabase
            "hex" -> strings.readAsHex
            else -> strings.readAsCode
          }
          OutlinedButton(
            onClick = {
              onDismiss()
              onOpenReader(readerId)
            },
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(label)
          }
        }
      }
    },
    confirmButton = { TextButton(onClick = onDismiss) { Text(strings.close) } },
  )
}

@Composable
fun VaultLockDialog(
  targetName: String,
  onDismiss: () -> Unit,
  onConfirmLock: (password: String) -> Unit,
) {
  val strings = LocalAppStrings.current
  var pass by remember { mutableStateOf("") }
  var confirmPass by remember { mutableStateOf("") }
  val valid = pass.length >= 4 && pass == confirmPass

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.lockWithPassword) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(targetName, style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
          value = pass,
          onValueChange = { pass = it },
          label = { Text("Password (min 4 chars)") },
          visualTransformation = PasswordVisualTransformation(),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = confirmPass,
          onValueChange = { confirmPass = it },
          label = { Text("Confirm Password") },
          visualTransformation = PasswordVisualTransformation(),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        Text(strings.recoveryKeyNotice, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
      }
    },
    confirmButton = {
      Button(
        enabled = valid,
        onClick = {
          onConfirmLock(pass)
          onDismiss()
        },
        modifier = Modifier.testTag("vault_lock_confirm_btn"),
      ) {
        Text(strings.confirm)
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } },
  )
}

@Composable
fun VaultUnlockDialog(
  targetName: String,
  onDismiss: () -> Unit,
  onConfirmUnlock: (secretOrRecoveryKey: String) -> Unit,
) {
  val strings = LocalAppStrings.current
  var secret by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.unlockVault) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(targetName, style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
          value = secret,
          onValueChange = { secret = it },
          label = { Text(strings.enterPasswordOrKey) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(
        enabled = secret.isNotBlank(),
        onClick = {
          onConfirmUnlock(secret)
          onDismiss()
        },
        modifier = Modifier.testTag("vault_unlock_confirm_btn"),
      ) {
        Text(strings.unlockVault)
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } },
  )
}

@Composable
fun AntivirusReportDialog(
  report: AntivirusScanReport,
  onQuarantine: (String) -> Unit,
  onDelete: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val hasThreats = report.threatsFound > 0
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = if (hasThreats) Icons.Default.Warning else Icons.Default.Security,
        contentDescription = null,
        tint = if (hasThreats) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
      )
    },
    title = { Text(strings.antivirusSection) },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Surface(
          color = if (hasThreats) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
          shape = MaterialTheme.shapes.medium,
        ) {
          Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
              text = "Status: ${report.highestSeverity.name} • Threats: ${report.threatsFound}",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = if (hasThreats) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Text(
              text = "Scanned ${report.totalFilesScanned} file(s) in ${report.durationMs} ms",
              style = MaterialTheme.typography.labelSmall,
              color = if (hasThreats) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer,
            )
          }
        }

        report.findings.take(15).forEach { finding ->
          val isFlagged = finding.riskScore >= 35 || finding.severity == ThreatSeverity.MALICIOUS || finding.severity == ThreatSeverity.SUSPICIOUS
          Card(
            colors = CardDefaults.cardColors(
              containerColor =
                if (isFlagged) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f)
                else MaterialTheme.colorScheme.surfaceContainer,
            ),
          ) {
            Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  finding.fileName,
                  style = MaterialTheme.typography.labelLarge,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.weight(1f),
                )
                Text(
                  "${finding.severity.name} (${finding.riskScore})",
                  style = MaterialTheme.typography.labelSmall,
                  color = if (isFlagged) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                )
              }
              Text(
                "SHA-256: ${finding.sha256.take(24)}… • ${formatFileSize(finding.scannedBytes)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              if (finding.reasons.isNotEmpty()) {
                Text(
                  finding.reasons.joinToString("\n• ", prefix = "• "),
                  style = MaterialTheme.typography.bodySmall,
                )
              }
              if (isFlagged) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  OutlinedButton(
                    onClick = { onQuarantine(finding.filePath) },
                    modifier = Modifier.weight(1f),
                  ) {
                    Text("Quarantine", maxLines = 1, overflow = TextOverflow.Ellipsis)
                  }
                  Button(
                    onClick = { onDelete(finding.filePath) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.weight(1f),
                  ) {
                    Text(strings.delete, maxLines = 1, overflow = TextOverflow.Ellipsis)
                  }
                }
              }
            }
          }
        }
      }
    },
    confirmButton = { TextButton(onClick = onDismiss) { Text(strings.close) } },
  )
}

@Composable
fun BackupRestoreDialog(
  meta: VortexBackupMetadata,
  onRestore: () -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = { Icon(Icons.Default.Restore, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
    title = { Text(strings.restoreOriginalAction) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(meta.originalName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Text(
          "Compressed: ${formatFileSize(meta.compressedSize)} -> Original: ${formatFileSize(meta.originalSize)}",
          style = MaterialTheme.typography.bodySmall,
        )
        Text(
          "SHA-256: ${meta.sha256.take(32)}…",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
          "Target: ${meta.originalPath}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.primary,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onRestore,
        modifier = Modifier.testTag("confirm_backup_restore_btn"),
      ) {
        Text(strings.restoreOriginalAction)
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } },
  )
}
