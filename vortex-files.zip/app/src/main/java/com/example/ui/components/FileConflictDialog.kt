package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.fs.ConflictAction
import com.example.domain.fs.FileConflictInfo
import com.example.domain.fs.formatFileSize
import com.example.i18n.LocalAppStrings
import java.text.DateFormat
import java.util.Date

@Composable
fun FileConflictDialog(
  conflict: FileConflictInfo,
  onResolve: (action: ConflictAction, applyToAll: Boolean) -> Unit,
) {
  val strings = LocalAppStrings.current
  var applyToAll by remember(conflict.destPath) { mutableStateOf(false) }
  val dateFmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }

  AlertDialog(
    onDismissRequest = { onResolve(ConflictAction.SKIP, false) },
    icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
    title = {
      Text(strings.conflictTitle, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          conflict.fileName,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.SemiBold,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )

        Surface(
          color = MaterialTheme.colorScheme.surfaceContainerHigh,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(strings.sourceFileInfoLabel, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            val srcDate = if (conflict.sourceModified > 0) dateFmt.format(Date(conflict.sourceModified)) else "-"
            Text("${formatFileSize(conflict.sourceSize)} • $srcDate", style = MaterialTheme.typography.bodySmall)
          }
        }

        Surface(
          color = MaterialTheme.colorScheme.surfaceContainer,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(strings.existingFileInfoLabel, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
            val dstDate = if (conflict.existingModified > 0) dateFmt.format(Date(conflict.existingModified)) else "-"
            Text("${formatFileSize(conflict.existingSize)} • $dstDate", style = MaterialTheme.typography.bodySmall)
          }
        }

        if (conflict.remainingItems > 0) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { applyToAll = !applyToAll }
              .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Checkbox(
              checked = applyToAll,
              onCheckedChange = { applyToAll = it },
              modifier = Modifier.testTag("conflict_apply_all_checkbox"),
            )
            Spacer(Modifier.width(6.dp))
            Text(
              "${strings.conflictApplyAll} (${conflict.remainingItems})",
              style = MaterialTheme.typography.bodyMedium,
            )
          }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
          Button(
            onClick = { onResolve(ConflictAction.REPLACE, applyToAll) },
            modifier = Modifier.fillMaxWidth().testTag("conflict_replace_btn"),
          ) {
            Text(strings.conflictReplace)
          }
          FilledTonalButton(
            onClick = { onResolve(ConflictAction.KEEP_BOTH, applyToAll) },
            modifier = Modifier.fillMaxWidth().testTag("conflict_keep_both_btn"),
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text(strings.conflictKeepBoth)
          }
          OutlinedButton(
            onClick = { onResolve(ConflictAction.SKIP, applyToAll) },
            modifier = Modifier.fillMaxWidth().testTag("conflict_skip_btn"),
          ) {
            Text(strings.conflictSkip)
          }
        }
      }
    },
    confirmButton = {},
  )
}
