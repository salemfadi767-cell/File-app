package com.example.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.example.VortexAppContainer
import com.example.data.db.PlaylistEntity
import com.example.data.db.PlaylistTrackEntity
import com.example.domain.media.AudioDspController
import com.example.domain.media.EqBandUi
import com.example.domain.media.EqPreset
import com.example.domain.media.LyricsEngine
import com.example.domain.media.OnlineLyricsHit
import com.example.domain.media.ReverbPresetMode
import com.example.domain.media.SubtitleAutoMatcher
import com.example.domain.media.SyncedLyricLine
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class MusicSortMode {
  SHUFFLE,
  ALPHA_ASC,
  ALPHA_DESC,
  NUMERIC,
  DATE_NEWEST,
  SIZE_DESC,
  CUSTOM,
}

enum class MusicRepeatMode {
  OFF,
  ALL,
  ONE,
}

data class MusicTrackItem(
  val path: String,
  val fileName: String,
  val title: String,
  val artist: String,
  val album: String,
  val folderPath: String,
  val folderName: String,
  val extension: String,
  val sizeBytes: Long,
  val dateModified: Long,
  val durationMs: Long = 0L,
)

data class MusicFolderGroup(
  val folderPath: String,
  val folderName: String,
  val tracks: List<MusicTrackItem>,
)

data class MusicHubUiState(
  val isScanning: Boolean = false,
  val folders: List<MusicFolderGroup> = emptyList(),
  val selectedFolderPath: String? = null,
  val sortMode: MusicSortMode = MusicSortMode.ALPHA_ASC,
  val queue: List<MusicTrackItem> = emptyList(),
  val currentIndex: Int = -1,
  val isPlaying: Boolean = false,
  val positionMs: Long = 0L,
  val durationMs: Long = 0L,
  val shuffleEnabled: Boolean = false,
  val repeatMode: MusicRepeatMode = MusicRepeatMode.ALL,
  val currentCoverArt: Bitmap? = null,
  // Cover Visual Enhancement & Lark Vinyl Mode
  val coverBrightness: Float = 0f,
  val coverContrast: Float = 1f,
  val coverSaturation: Float = 1f,
  val coverGlowEnabled: Boolean = true,
  val vinylDiscMode: Boolean = false,
  // Audio DSP
  val loudnessGainMb: Int = 0,
  val bassStrength: Int = 0,
  val eqBands: List<EqBandUi> = emptyList(),
  val eq10Bands: List<EqBandUi> = emptyList(),
  val use10BandEq: Boolean = false,
  val activeEqPreset: EqPreset = EqPreset.NORMAL,
  val reverbMode: ReverbPresetMode = ReverbPresetMode.NONE,
  // Lyrics
  val lyrics: List<SyncedLyricLine> = emptyList(),
  val rawLrcContent: String = "",
  val activeLyricIndex: Int = -1,
  val activeWordIndex: Int = -1,
  val lyricsOffsetMs: Long = 0L,
  val isSearchingLyrics: Boolean = false,
  val onlineLyricsHits: List<OnlineLyricsHit> = emptyList(),
  // Sleep Timer
  val sleepRemainingMs: Long = 0L,
  val stopAfterCurrentTrack: Boolean = false,
  // Playlists
  val selectedPlaylistId: Long? = null,
  val selectedPlaylistTracks: List<PlaylistTrackEntity> = emptyList(),
  val statusMessage: String? = null,
) {
  val currentTrack: MusicTrackItem?
    get() = queue.getOrNull(currentIndex)
}

@OptIn(UnstableApi::class)
class MusicViewModel(
  private val appContext: Context,
  private val container: VortexAppContainer,
) : ViewModel() {

  private val _uiState = MutableStateFlow(MusicHubUiState())
  val uiState: StateFlow<MusicHubUiState> = _uiState.asStateFlow()

  val playlists: StateFlow<List<PlaylistEntity>> =
    container.database
      .playlistDao()
      .observePlaylists()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val dspController = AudioDspController()
  private val exoPlayer: ExoPlayer = ExoPlayer.Builder(appContext).build()
  private var tickerJob: Job? = null
  private var sleepJob: Job? = null
  private var playlistObserverJob: Job? = null
  private var lyricsFetchJob: Job? = null
  private var lastLoadedInitialPath: String? = null

  init {
    _uiState.update {
      it.copy(
        eqBands = dspController.currentBandsUi(),
        eq10Bands = dspController.current10BandUi(),
      )
    }
    exoPlayer.addListener(
      object : Player.Listener {
        override fun onAudioSessionIdChanged(audioSessionId: Int) {
          val bands = dspController.attachToSession(audioSessionId)
          _uiState.update {
            it.copy(
              eqBands = bands,
              eq10Bands = dspController.current10BandUi(),
            )
          }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
          _uiState.update { it.copy(isPlaying = isPlaying) }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
          if (playbackState == Player.STATE_ENDED) {
            onTrackCompleted()
          } else if (playbackState == Player.STATE_READY) {
            val dur = exoPlayer.duration.coerceAtLeast(0L)
            if (dur > 0L) _uiState.update { it.copy(durationMs = dur) }
          }
        }
      }
    )
    startPositionTicker()
    scanLibrary(null)
  }

  fun openFromFile(audioPath: String) {
    if (audioPath.isBlank() || audioPath == lastLoadedInitialPath) return
    lastLoadedInitialPath = audioPath
    val parentDir = File(audioPath).parent
    viewModelScope.launch {
      scanLibraryInternal(parentDir)
      val folders = _uiState.value.folders
      val folder = folders.firstOrNull { it.folderPath == parentDir }
      val targetList =
        folder?.tracks ?: listOf(buildTrackFromFile(File(audioPath)))
      val sorted = applySort(targetList, _uiState.value.sortMode)
      val idx = sorted.indexOfFirst { it.path == audioPath }.coerceAtLeast(0)
      _uiState.update { it.copy(selectedFolderPath = parentDir) }
      playQueueAt(sorted, idx)
    }
  }

  fun scanLibrary(extraFolder: String?) {
    viewModelScope.launch {
      scanLibraryInternal(extraFolder)
    }
  }

  private suspend fun scanLibraryInternal(extraFolder: String?) {
    _uiState.update { it.copy(isScanning = true) }
    val discovered =
      withContext(Dispatchers.IO) {
        val map = LinkedHashMap<String, MusicTrackItem>()
        val audioExts = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus")

        // 1. MediaStore Audio query
        runCatching {
          val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
          val proj =
            arrayOf(
              MediaStore.Audio.Media.DATA,
              MediaStore.Audio.Media.TITLE,
              MediaStore.Audio.Media.ARTIST,
              MediaStore.Audio.Media.ALBUM,
              MediaStore.Audio.Media.DURATION,
              MediaStore.Audio.Media.SIZE,
              MediaStore.Audio.Media.DATE_MODIFIED,
            )
          appContext.contentResolver.query(uri, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, null)?.use { c ->
            val dataCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val dateCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
            while (c.moveToNext()) {
              val path = c.getString(dataCol) ?: continue
              val file = File(path)
              if (!file.exists() || !file.isFile) continue
              val parent = file.parentFile
              map[path] =
                MusicTrackItem(
                  path = path,
                  fileName = file.name,
                  title = c.getString(titleCol)?.takeIf { it.isNotBlank() } ?: file.nameWithoutExtension,
                  artist = c.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown Artist",
                  album = c.getString(albumCol)?.takeIf { it.isNotBlank() } ?: (parent?.name ?: "Music"),
                  folderPath = parent?.absolutePath ?: "/",
                  folderName = parent?.name ?: "Music",
                  extension = file.extension.lowercase(),
                  sizeBytes = c.getLong(sizeCol).takeIf { it > 0L } ?: file.length(),
                  dateModified = c.getLong(dateCol) * 1000L,
                  durationMs = c.getLong(durCol),
                )
            }
          }
        }

        // 2. Direct directory scan for Music, Downloads, App Workspace, and extraFolder
        val dirsToScan =
          listOfNotNull(
            extraFolder?.let { File(it) },
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            container.fileRepository.appWorkspaceDir(),
          )
        for (dir in dirsToScan) {
          if (dir.exists() && dir.isDirectory && dir.canRead()) {
            dir.walkTopDown().maxDepth(4).forEach { f ->
              if (f.isFile && f.extension.lowercase() in audioExts && f.absolutePath !in map) {
                map[f.absolutePath] = buildTrackFromFile(f)
              }
            }
          }
        }

        map.values
          .groupBy { it.folderPath }
          .map { (fPath, list) ->
            MusicFolderGroup(
              folderPath = fPath,
              folderName = File(fPath).name.ifEmpty { fPath },
              tracks = list.sortedBy { it.title.lowercase() },
            )
          }
          .sortedBy { it.folderName.lowercase() }
      }

    _uiState.update { st ->
      val sel = st.selectedFolderPath ?: discovered.firstOrNull()?.folderPath
      val newQueue =
        if (st.queue.isEmpty() && discovered.isNotEmpty()) {
          applySort(discovered.first().tracks, st.sortMode)
        } else {
          st.queue
        }
      st.copy(
        isScanning = false,
        folders = discovered,
        selectedFolderPath = sel,
        queue = newQueue,
      )
    }
  }

  private fun buildTrackFromFile(file: File): MusicTrackItem {
    val parent = file.parentFile
    return MusicTrackItem(
      path = file.absolutePath,
      fileName = file.name,
      title = file.nameWithoutExtension.ifBlank { file.name },
      artist = "Unknown Artist",
      album = parent?.name ?: "Music",
      folderPath = parent?.absolutePath ?: "/",
      folderName = parent?.name ?: "Music",
      extension = file.extension.lowercase(),
      sizeBytes = file.length(),
      dateModified = file.lastModified(),
    )
  }

  fun selectFolder(folderPath: String) {
    _uiState.update { it.copy(selectedFolderPath = folderPath) }
  }

  fun playFolder(folder: MusicFolderGroup, startIndex: Int = 0) {
    val sorted = applySort(folder.tracks, _uiState.value.sortMode)
    playQueueAt(sorted, startIndex.coerceIn(0, (sorted.size - 1).coerceAtLeast(0)))
  }

  fun setSortMode(mode: MusicSortMode) {
    val current = _uiState.value.currentTrack
    val baseTracks =
      if (_uiState.value.queue.isNotEmpty()) _uiState.value.queue
      else _uiState.value.folders.firstOrNull { it.folderPath == _uiState.value.selectedFolderPath }?.tracks.orEmpty()
    val sorted = applySort(baseTracks, mode)
    val newIdx = if (current != null) sorted.indexOfFirst { it.path == current.path }.coerceAtLeast(0) else -1
    _uiState.update {
      it.copy(
        sortMode = mode,
        shuffleEnabled = mode == MusicSortMode.SHUFFLE,
        queue = sorted,
        currentIndex = newIdx,
      )
    }
  }

  fun applySort(tracks: List<MusicTrackItem>, mode: MusicSortMode): List<MusicTrackItem> {
    return when (mode) {
      MusicSortMode.SHUFFLE -> tracks.shuffled()
      MusicSortMode.ALPHA_ASC -> tracks.sortedBy { it.title.lowercase() }
      MusicSortMode.ALPHA_DESC -> tracks.sortedByDescending { it.title.lowercase() }
      MusicSortMode.NUMERIC -> tracks.sortedWith(compareBy({ extractFirstNumber(it.fileName) }, { it.fileName.lowercase() }))
      MusicSortMode.DATE_NEWEST -> tracks.sortedByDescending { it.dateModified }
      MusicSortMode.SIZE_DESC -> tracks.sortedByDescending { it.sizeBytes }
      MusicSortMode.CUSTOM -> tracks
    }
  }

  private fun extractFirstNumber(name: String): Long {
    val match = Regex("\\d+").find(name) ?: return Long.MAX_VALUE
    return match.value.toLongOrNull() ?: Long.MAX_VALUE
  }

  fun playQueueAt(queue: List<MusicTrackItem>, index: Int) {
    if (queue.isEmpty() || index !in queue.indices) return
    val track = queue[index]
    _uiState.update {
      it.copy(
        queue = queue,
        currentIndex = index,
        positionMs = 0L,
        durationMs = track.durationMs,
        lyrics = emptyList(),
        rawLrcContent = "",
        activeLyricIndex = -1,
        activeWordIndex = -1,
      )
    }
    exoPlayer.setMediaItem(MediaItem.fromUri(Uri.fromFile(File(track.path))))
    exoPlayer.prepare()
    exoPlayer.volume = 1f
    exoPlayer.playWhenReady = true

    loadArtMetadataAndLyricsForTrack(track)
  }

  private fun loadArtMetadataAndLyricsForTrack(track: MusicTrackItem) {
    lyricsFetchJob?.cancel()
    lyricsFetchJob =
      viewModelScope.launch {
        val art = container.mediaThumbnailLoader.loadAudioAlbumArt(track.path, track.dateModified, targetPx = 640)
        val meta = container.mediaThumbnailLoader.extractAudioMetadata(track.path)

        val enrichedTrack =
          track.copy(
            title = if (meta.title.isNotBlank()) meta.title else track.title,
            artist = meta.artist,
            album = meta.album,
            durationMs = if (meta.durationMs > 0L) meta.durationMs else track.durationMs,
          )
        _uiState.update { st ->
          val updatedQ = st.queue.map { if (it.path == track.path) enrichedTrack else it }
          st.copy(queue = updatedQ, currentCoverArt = art)
        }

        val prefs = container.preferencesRepo.preferences.first()
        if (!prefs.autoSubtitlesEnabled) {
          _uiState.update { it.copy(lyrics = emptyList(), isSearchingLyrics = false, onlineLyricsHits = emptyList()) }
          return@launch
        }

        // 1. Try local sidecar .lrc / .txt in track folder OR dedicated subtitles folder
        val localFile =
          withContext(Dispatchers.IO) {
            SubtitleAutoMatcher.findBestLocalLyrics(track.path, prefs.subtitlesFolderPath)
          }
        val local =
          if (localFile != null) {
            withContext(Dispatchers.IO) { runCatching { LyricsEngine.parseLyrics(localFile.readText()) }.getOrDefault(emptyList()) }
          } else {
            emptyList()
          }
        if (local.isNotEmpty()) {
          _uiState.update { it.copy(lyrics = local, isSearchingLyrics = false) }
          return@launch
        }

        // 2. Fallback: automatic online synced lyrics search prioritized by user language order
        _uiState.update { it.copy(isSearchingLyrics = true, onlineLyricsHits = emptyList()) }
        val hits =
          container.onlineLyricsService.searchLyrics(
            trackName = enrichedTrack.title,
            artistName = enrichedTrack.artist,
            preferredLanguages = prefs.subtitleLanguages,
          )
        if (_uiState.value.currentTrack?.path != track.path) return@launch

        val best = hits.firstOrNull()
        if (best != null) {
          val raw = best.syncedLrc ?: best.plainLyrics.orEmpty()
          val parsed = LyricsEngine.parseLyrics(raw)
          if (raw.isNotBlank()) {
            withContext(Dispatchers.IO) {
              runCatching {
                val trackFile = File(track.path)
                val targetDir =
                  SubtitleAutoMatcher.resolveTargetStorageDir(
                    prefs.subtitlesFolderPath,
                    trackFile.parentFile ?: File(container.fileRepository.downloadsDir(), "Subtitles"),
                  )
                File(targetDir, "${trackFile.nameWithoutExtension}.lrc").writeText(raw)
              }
            }
          }
          _uiState.update {
            it.copy(
              lyrics = parsed,
              rawLrcContent = raw,
              isSearchingLyrics = false,
              onlineLyricsHits = hits,
            )
          }
        } else {
          _uiState.update { it.copy(isSearchingLyrics = false, onlineLyricsHits = emptyList()) }
        }
      }
  }

  fun searchLyricsManually(trackQuery: String, artistQuery: String) {
    lyricsFetchJob?.cancel()
    lyricsFetchJob =
      viewModelScope.launch {
        _uiState.update { it.copy(isSearchingLyrics = true) }
        val langs = container.preferencesRepo.preferences.first().subtitleLanguages
        val hits = container.onlineLyricsService.searchLyrics(trackQuery, artistQuery, langs)
        _uiState.update { it.copy(isSearchingLyrics = false, onlineLyricsHits = hits) }
      }
  }

  fun applyOnlineLyricsHit(hit: OnlineLyricsHit) {
    val raw = hit.syncedLrc ?: hit.plainLyrics.orEmpty()
    val parsed = LyricsEngine.parseLyrics(raw)
    _uiState.update { it.copy(lyrics = parsed, rawLrcContent = raw) }
  }

  fun saveCurrentLyricsLocally() {
    val track = _uiState.value.currentTrack ?: return
    val raw = _uiState.value.rawLrcContent
    if (raw.isBlank()) return
    viewModelScope.launch(Dispatchers.IO) {
      runCatching {
        val f = File(track.path)
        val lrcFile = File(f.parentFile, "${f.nameWithoutExtension}.lrc")
        lrcFile.writeText(raw)
        _uiState.update { it.copy(statusMessage = "Saved ${lrcFile.name}") }
      }.onFailure { e ->
        _uiState.update { it.copy(statusMessage = e.message) }
      }
    }
  }

  fun setLyricsSyncOffset(offsetMs: Long) {
    _uiState.update { it.copy(lyricsOffsetMs = offsetMs) }
  }

  fun togglePlayPause() {
    if (_uiState.value.queue.isEmpty()) return
    if (_uiState.value.currentIndex < 0) {
      playQueueAt(_uiState.value.queue, 0)
      return
    }
    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
  }

  fun next() {
    val st = _uiState.value
    if (st.queue.isEmpty()) return
    val nextIdx =
      when {
        st.shuffleEnabled && st.queue.size > 1 -> (st.queue.indices - st.currentIndex).random()
        st.currentIndex + 1 < st.queue.size -> st.currentIndex + 1
        st.repeatMode == MusicRepeatMode.ALL -> 0
        else -> return
      }
    playQueueAt(st.queue, nextIdx)
  }

  fun previous() {
    val st = _uiState.value
    if (st.queue.isEmpty()) return
    if (exoPlayer.currentPosition > 3500L) {
      exoPlayer.seekTo(0L)
      return
    }
    val prevIdx = if (st.currentIndex - 1 >= 0) st.currentIndex - 1 else st.queue.lastIndex
    playQueueAt(st.queue, prevIdx)
  }

  fun seekTo(ms: Long) {
    exoPlayer.seekTo(ms.coerceAtLeast(0L))
    _uiState.update { it.copy(positionMs = ms) }
  }

  fun cycleRepeatMode() {
    _uiState.update { st ->
      val next =
        when (st.repeatMode) {
          MusicRepeatMode.ALL -> MusicRepeatMode.ONE
          MusicRepeatMode.ONE -> MusicRepeatMode.OFF
          MusicRepeatMode.OFF -> MusicRepeatMode.ALL
        }
      st.copy(repeatMode = next)
    }
  }

  fun toggleShuffle() {
    val nextShuffle = !_uiState.value.shuffleEnabled
    setSortMode(if (nextShuffle) MusicSortMode.SHUFFLE else MusicSortMode.ALPHA_ASC)
  }

  private fun onTrackCompleted() {
    val st = _uiState.value
    if (st.stopAfterCurrentTrack) {
      _uiState.update { it.copy(stopAfterCurrentTrack = false, isPlaying = false) }
      exoPlayer.pause()
      return
    }
    if (st.repeatMode == MusicRepeatMode.ONE) {
      exoPlayer.seekTo(0L)
      exoPlayer.play()
      return
    }
    if (st.currentIndex + 1 < st.queue.size || st.repeatMode == MusicRepeatMode.ALL || st.shuffleEnabled) {
      next()
    }
  }

  // Live Queue & Custom Playlist Reordering
  fun moveTrackInQueue(fromIdx: Int, toIdx: Int) {
    val st = _uiState.value
    if (fromIdx !in st.queue.indices || toIdx !in st.queue.indices || fromIdx == toIdx) return
    val currentPath = st.currentTrack?.path
    val mutable = st.queue.toMutableList()
    val item = mutable.removeAt(fromIdx)
    mutable.add(toIdx, item)
    val newCurIdx = if (currentPath != null) mutable.indexOfFirst { it.path == currentPath } else -1
    _uiState.update { it.copy(queue = mutable, currentIndex = newCurIdx, sortMode = MusicSortMode.CUSTOM) }
  }

  fun createPlaylist(name: String) {
    if (name.isBlank()) return
    viewModelScope.launch {
      val id = container.database.playlistDao().insertPlaylist(PlaylistEntity(name = name.trim()))
      selectPlaylist(id)
    }
  }

  fun createPlaylistAndAddTrack(name: String, track: MusicTrackItem) {
    if (name.isBlank()) return
    viewModelScope.launch {
      val dao = container.database.playlistDao()
      val id = dao.insertPlaylist(PlaylistEntity(name = name.trim()))
      dao.insertTrack(
        PlaylistTrackEntity(
          playlistId = id,
          trackPath = track.path,
          title = track.title,
          artist = track.artist,
          durationMs = track.durationMs,
          sortOrder = 0,
        )
      )
      selectPlaylist(id)
      _uiState.update { it.copy(statusMessage = "Added: ${track.title}") }
    }
  }

  fun saveCurrentQueueAsPlaylist(name: String) {
    val tracks = _uiState.value.queue
    if (name.isBlank() || tracks.isEmpty()) return
    viewModelScope.launch {
      val dao = container.database.playlistDao()
      val pid = dao.insertPlaylist(PlaylistEntity(name = name.trim()))
      tracks.forEachIndexed { idx, t ->
        dao.insertTrack(
          PlaylistTrackEntity(
            playlistId = pid,
            trackPath = t.path,
            title = t.title,
            artist = t.artist,
            durationMs = t.durationMs,
            sortOrder = idx,
          )
        )
      }
      selectPlaylist(pid)
      _uiState.update { it.copy(statusMessage = "Playlist saved (${tracks.size} tracks)") }
    }
  }

  fun selectPlaylist(playlistId: Long) {
    playlistObserverJob?.cancel()
    _uiState.update { it.copy(selectedPlaylistId = playlistId) }
    playlistObserverJob =
      viewModelScope.launch {
        container.database.playlistDao().observePlaylistTracks(playlistId).collect { list ->
          _uiState.update { it.copy(selectedPlaylistTracks = list) }
        }
      }
  }

  fun addTrackToPlaylist(playlistId: Long, track: MusicTrackItem) {
    viewModelScope.launch {
      val dao = container.database.playlistDao()
      val existing = dao.getPlaylistTracksOnce(playlistId)
      dao.insertTrack(
        PlaylistTrackEntity(
          playlistId = playlistId,
          trackPath = track.path,
          title = track.title,
          artist = track.artist,
          durationMs = track.durationMs,
          sortOrder = existing.size,
        )
      )
      _uiState.update { it.copy(statusMessage = "Added: ${track.title}") }
    }
  }

  fun moveTrackInPlaylist(playlistId: Long, fromIdx: Int, toIdx: Int) {
    val current = _uiState.value.selectedPlaylistTracks.toMutableList()
    if (fromIdx !in current.indices || toIdx !in current.indices || fromIdx == toIdx) return
    val moved = current.removeAt(fromIdx)
    current.add(toIdx, moved)
    val reindexed = current.mapIndexed { idx, item -> item.copy(sortOrder = idx) }
    viewModelScope.launch {
      container.database.playlistDao().updateTracks(reindexed)
    }
  }

  fun removeTrackFromPlaylist(trackId: Long) {
    viewModelScope.launch {
      container.database.playlistDao().deleteTrack(trackId)
    }
  }

  fun deletePlaylist(playlistId: Long) {
    viewModelScope.launch {
      container.database.playlistDao().deletePlaylist(playlistId)
      if (_uiState.value.selectedPlaylistId == playlistId) {
        _uiState.update { it.copy(selectedPlaylistId = null, selectedPlaylistTracks = emptyList()) }
      }
    }
  }

  fun playCustomPlaylist(startIndex: Int = 0) {
    val entities = _uiState.value.selectedPlaylistTracks
    if (entities.isEmpty()) return
    val items =
      entities.mapNotNull { ent ->
        val f = File(ent.trackPath)
        if (!f.exists()) null
        else buildTrackFromFile(f).copy(title = ent.title, artist = ent.artist, durationMs = ent.durationMs)
      }
    if (items.isNotEmpty()) {
      _uiState.update { it.copy(sortMode = MusicSortMode.CUSTOM) }
      playQueueAt(items, startIndex.coerceIn(0, items.lastIndex))
    }
  }

  // Audio DSP Controls
  fun setLoudnessGainMb(gainMb: Int) {
    dspController.setLoudnessGainMb(gainMb)
    _uiState.update { it.copy(loudnessGainMb = gainMb) }
  }

  fun setBassBoostStrength(strength: Int) {
    dspController.setBassBoostStrength(strength)
    _uiState.update { it.copy(bassStrength = strength) }
  }

  fun setEqBandLevel(bandIdx: Int, levelMb: Int) {
    val updated = dspController.setBandLevel(bandIdx, levelMb)
    _uiState.update { it.copy(eqBands = updated, eq10Bands = dspController.current10BandUi()) }
  }

  fun setEq10BandLevel(band10Idx: Int, levelMb: Int) {
    val updated5 = dspController.set10BandLevel(band10Idx, levelMb)
    _uiState.update { it.copy(eqBands = updated5, eq10Bands = dspController.current10BandUi()) }
  }

  fun toggle10BandEq(use10: Boolean) {
    _uiState.update { it.copy(use10BandEq = use10, eq10Bands = dspController.current10BandUi()) }
  }

  fun setReverbMode(mode: ReverbPresetMode) {
    dspController.setReverbMode(mode)
    _uiState.update { it.copy(reverbMode = mode) }
  }

  fun applyEqPreset(preset: EqPreset) {
    val updated = dspController.applyPreset(preset)
    _uiState.update { it.copy(eqBands = updated, eq10Bands = dspController.current10BandUi(), activeEqPreset = preset) }
  }

  fun toggleVinylDiscMode() {
    _uiState.update { it.copy(vinylDiscMode = !it.vinylDiscMode) }
  }

  // Album Cover Visual Enhancement
  fun setCoverVisuals(brightness: Float, contrast: Float, saturation: Float, glow: Boolean) {
    _uiState.update {
      it.copy(
        coverBrightness = brightness,
        coverContrast = contrast,
        coverSaturation = saturation,
        coverGlowEnabled = glow,
      )
    }
  }

  // Sleep Timer with Smooth Volume Fade-Out
  fun startSleepTimer(minutes: Int) {
    sleepJob?.cancel()
    if (minutes <= 0) {
      _uiState.update { it.copy(sleepRemainingMs = 0L) }
      exoPlayer.volume = 1f
      return
    }
    var remaining = minutes * 60_000L
    _uiState.update { it.copy(sleepRemainingMs = remaining, stopAfterCurrentTrack = false) }
    sleepJob =
      viewModelScope.launch {
        while (remaining > 0L) {
          delay(1000L)
          remaining = (remaining - 1000L).coerceAtLeast(0L)
          _uiState.update { it.copy(sleepRemainingMs = remaining) }
          if (remaining in 1L..5000L) {
            exoPlayer.volume = (remaining / 5000f).coerceIn(0.05f, 1f)
          }
        }
        exoPlayer.pause()
        exoPlayer.volume = 1f
        _uiState.update { it.copy(sleepRemainingMs = 0L, isPlaying = false, statusMessage = "Sleep timer paused playback") }
      }
  }

  fun toggleStopAfterCurrentTrack(enabled: Boolean) {
    if (enabled) cancelSleepTimer()
    _uiState.update { it.copy(stopAfterCurrentTrack = enabled) }
  }

  fun cancelSleepTimer() {
    sleepJob?.cancel()
    exoPlayer.volume = 1f
    _uiState.update { it.copy(sleepRemainingMs = 0L, stopAfterCurrentTrack = false) }
  }

  fun clearMessage() {
    _uiState.update { it.copy(statusMessage = null) }
  }

  private fun startPositionTicker() {
    tickerJob?.cancel()
    tickerJob =
      viewModelScope.launch {
        while (true) {
          if (exoPlayer.isPlaying || _uiState.value.lyrics.isNotEmpty()) {
            val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
            val dur = exoPlayer.duration.coerceAtLeast(_uiState.value.durationMs)
            val st = _uiState.value
            val activeLine = LyricsEngine.findActiveLineIndex(st.lyrics, pos, st.lyricsOffsetMs)
            val activeWord =
              if (activeLine in st.lyrics.indices) {
                LyricsEngine.findActiveWordIndex(st.lyrics[activeLine], pos, st.lyricsOffsetMs)
              } else {
                -1
              }
            _uiState.update {
              it.copy(
                positionMs = pos,
                durationMs = dur,
                activeLyricIndex = activeLine,
                activeWordIndex = activeWord,
              )
            }
          }
          delay(110L)
        }
      }
  }

  override fun onCleared() {
    tickerJob?.cancel()
    sleepJob?.cancel()
    playlistObserverJob?.cancel()
    lyricsFetchJob?.cancel()
    dspController.release()
    exoPlayer.release()
    super.onCleared()
  }
}
