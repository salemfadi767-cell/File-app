package com.example.ui.components

import android.annotation.SuppressLint
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.domain.download.ExtractedMediaStream
import com.example.domain.download.UniversalDownloadEngine
import com.example.i18n.LocalAppStrings
import kotlinx.coroutines.launch

private val SNIFF_SCAN_JS =
  """
  (function() {
    try {
      var urls = [];
      document.querySelectorAll('video, source, audio').forEach(function(el) {
        if (el.currentSrc) urls.push(el.currentSrc);
        if (el.src) urls.push(el.src);
      });
      var og = document.querySelector('meta[property="og:video"], meta[property="og:video:url"], meta[name="twitter:player:stream"]');
      if (og && og.content) urls.push(og.content);
      var title = document.title || 'Web Video';
      urls.forEach(function(u) {
        if (u && u.indexOf('http') === 0 && u.indexOf('blob:') !== 0) {
          VortexSniffer.onMediaFound(u, title);
        }
      });
    } catch(e) {}
  })();
  """.trimIndent()

private fun looksLikeSniffableMediaRequest(url: String): Boolean {
  val lower = url.lowercase()
  if (lower.startsWith("blob:") || lower.startsWith("data:")) return false
  // Skip YouTube UMP binary protobuf / partial byte-range MSE chunks that cannot play standalone
  if (lower.contains("&ump=1") || lower.contains("?ump=1")) return false
  if (lower.contains("googlevideo.com/videoplayback") && lower.contains("&range=")) return false
  val pathPart = lower.substringBefore('?')
  return pathPart.endsWith(".mp4") ||
    pathPart.endsWith(".m3u8") ||
    pathPart.endsWith(".mpd") ||
    pathPart.endsWith(".webm") ||
    pathPart.endsWith(".mov") ||
    pathPart.endsWith(".m4a") ||
    pathPart.endsWith(".mp3") ||
    lower.contains("googlevideo.com/videoplayback") ||
    lower.contains("mime=video") ||
    lower.contains("mime=audio") ||
    lower.contains("/manifest/hls")
}

private fun classifySniffedStream(url: String, pageTitle: String): ExtractedMediaStream {
  val lower = url.lowercase()
  val isHls = lower.contains(".m3u8") || lower.contains("hls")
  val isDash = lower.contains(".mpd")
  val isAudio = lower.contains("mime=audio") || lower.substringBefore('?').endsWith(".m4a") || lower.substringBefore('?').endsWith(".mp3")
  val mime = when {
    isHls -> "application/x-mpegURL"
    isDash -> "application/dash+xml"
    isAudio -> "audio/mp4"
    lower.contains("webm") -> "video/webm"
    else -> "video/mp4"
  }
  val label = when {
    isHls -> "Captured HLS (.m3u8)"
    isDash -> "Captured DASH (.mpd)"
    isAudio -> "Captured Audio"
    lower.contains("googlevideo.com") -> "Captured Stream (Media)"
    else -> "Captured Video (${url.substringBefore('?').substringAfterLast('.', "MP4").uppercase()})"
  }
  return ExtractedMediaStream(
    title = pageTitle.ifBlank { "Captured Video" },
    url = url,
    qualityLabel = label,
    mimeType = mime,
    isHls = isHls,
    isDash = isDash,
    hasVideo = !isAudio,
    hasAudio = true,
  )
}

private fun hasHardwareRenderNode(): Boolean {
  val hw = Build.HARDWARE.lowercase()
  val fp = Build.FINGERPRINT.lowercase()
  if (hw.contains("ranchu") || hw.contains("goldfish") || fp.contains("generic") || fp.contains("emulator")) {
    return false
  }
  val dri = java.io.File("/dev/dri")
  val nodes = runCatching { dri.listFiles() }.getOrNull().orEmpty()
  return nodes.any { it.name.startsWith("renderD") }
}

@SuppressLint("SetJavaScriptEnabled")
private fun configureSafeWebView(webView: WebView, useSoftwareLayer: Boolean) {
  if (useSoftwareLayer) {
    webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
  }
  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
    runCatching {
      webView.settings.safeBrowsingEnabled = false
      if (!useSoftwareLayer) {
        webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_BOUND, true)
      }
    }
  }
  webView.settings.apply {
    javaScriptEnabled = true
    domStorageEnabled = true
    mediaPlaybackRequiresUserGesture = !useSoftwareLayer
    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
    useWideViewPort = true
    loadWithOverviewMode = true
    setSupportMultipleWindows(false)
    setGeolocationEnabled(false)
    builtInZoomControls = false
    displayZoomControls = false
  }
}

private fun disposeWebViewSafely(webView: WebView?, deferDestroy: Boolean = false) {
  if (webView == null) return
  if (webView.getTag(0x564F5254) == true) return
  webView.setTag(0x564F5254, true)
  val cleanup = Runnable {
    runCatching {
      webView.clearFocus()
      webView.stopLoading()
      webView.onPause()
      webView.removeJavascriptInterface("VortexSniffer")
      webView.webChromeClient = WebChromeClient()
      webView.webViewClient = WebViewClient()
      (webView.parent as? ViewGroup)?.removeView(webView)
      webView.removeAllViews()
      webView.destroy()
    }
  }
  if (deferDestroy) {
    Handler(Looper.getMainLooper()).post(cleanup)
  } else {
    cleanup.run()
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SmartBrowserSnifferDialog(
  initialUrl: String,
  onPlayStream: (ExtractedMediaStream) -> Unit,
  onDownloadStream: (ExtractedMediaStream) -> Unit,
  onResolvePageStreams: (suspend (String) -> List<ExtractedMediaStream>)? = null,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val scope = rememberCoroutineScope()
  val mainHandler = remember { Handler(Looper.getMainLooper()) }
  val latestResolvePage by rememberUpdatedState(onResolvePageStreams)

  val startUrl =
    initialUrl.trim().takeIf { it.startsWith("http://", true) || it.startsWith("https://", true) }
      ?: "https://m.youtube.com"
  var addressInput by remember { mutableStateOf(startUrl) }
  var targetUrlToLoad by remember { mutableStateOf(startUrl) }
  var loadProgress by remember { mutableIntStateOf(0) }
  var currentPageTitle by remember { mutableStateOf("Web Browser") }
  var showCapturedDrawer by remember { mutableStateOf(false) }
  val captured = remember { mutableStateListOf<ExtractedMediaStream>() }
  var lastResolvedPageUrl by remember { mutableStateOf("") }
  var webViewRef by remember { mutableStateOf<WebView?>(null) }
  var webViewInstanceKey by remember { mutableIntStateOf(0) }
  var useSoftwareFallback by remember { mutableStateOf(!hasHardwareRenderNode()) }
  var rendererCrashedPermanently by remember { mutableStateOf(false) }
  var isDisposed by remember { mutableStateOf(false) }

  DisposableEffect(Unit) {
    onDispose {
      isDisposed = true
      focusManager.clearFocus(force = true)
      disposeWebViewSafely(webViewRef)
      webViewRef = null
    }
  }

  BackHandler {
    focusManager.clearFocus(force = true)
    keyboardController?.hide()
    if (webViewRef?.canGoBack() == true) {
      webViewRef?.goBack()
    } else {
      onDismiss()
    }
  }

  fun recordUrl(url: String, title: String) {
    if (isDisposed || !looksLikeSniffableMediaRequest(url)) return
    if (captured.none { it.url == url }) {
      captured.add(0, classifySniffedStream(url, title))
    }
  }

  fun maybeResolveSocialVideoPage(pageUrl: String) {
    val resolver = latestResolvePage ?: return
    val isSocialVideo =
      UniversalDownloadEngine.extractYouTubeVideoId(pageUrl) != null ||
        UniversalDownloadEngine.isTikTokUrl(pageUrl) ||
        UniversalDownloadEngine.isInstagramUrl(pageUrl) ||
        UniversalDownloadEngine.isTwitterOrXUrl(pageUrl) ||
        UniversalDownloadEngine.isFacebookUrl(pageUrl)
    if (!isSocialVideo || pageUrl == lastResolvedPageUrl) return
    lastResolvedPageUrl = pageUrl
    scope.launch {
      val resolved = runCatching { resolver(pageUrl) }.getOrDefault(emptyList())
      if (!isDisposed) {
        resolved.asReversed().forEach { s ->
          if (captured.none { it.url == s.url }) {
            captured.add(0, s)
          }
        }
      }
    }
  }

  // Rendered in-window (not in a separate Dialog PhoneWindow) so DecorView ActionMode never collides
  Surface(
    modifier = Modifier.fillMaxSize(),
    color = MaterialTheme.colorScheme.background,
  ) {
    Column(
      modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
    ) {
      // Browser Address Toolbar
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        IconButton(
          onClick = {
            focusManager.clearFocus(force = true)
            keyboardController?.hide()
            onDismiss()
          },
          modifier = Modifier.testTag("sniffer_close_btn"),
        ) {
          Icon(Icons.Default.Close, contentDescription = strings.close)
        }
        IconButton(
          onClick = {
            focusManager.clearFocus(force = true)
            if (webViewRef?.canGoBack() == true) webViewRef?.goBack()
          },
        ) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        OutlinedTextField(
          value = addressInput,
          onValueChange = { addressInput = it },
          singleLine = true,
          modifier = Modifier.weight(1f),
        )
        IconButton(
          onClick = {
            focusManager.clearFocus(force = true)
            keyboardController?.hide()
            val url =
              if (addressInput.startsWith("http://", true) || addressInput.startsWith("https://", true)) {
                addressInput.trim()
              } else {
                "https://${addressInput.trim()}"
              }
            addressInput = url
            targetUrlToLoad = url
            if (rendererCrashedPermanently) {
              useSoftwareFallback = false
              rendererCrashedPermanently = false
              webViewInstanceKey++
            } else {
              webViewRef?.loadUrl(url)
            }
          },
        ) {
          Icon(Icons.Default.Search, contentDescription = "Go")
        }
        IconButton(
          onClick = {
            focusManager.clearFocus(force = true)
            if (rendererCrashedPermanently) {
              useSoftwareFallback = false
              rendererCrashedPermanently = false
              webViewInstanceKey++
            } else {
              webViewRef?.evaluateJavascript(SNIFF_SCAN_JS, null)
            }
          },
        ) {
          Icon(Icons.Default.Refresh, contentDescription = "Scan page")
        }
        IconButton(
          onClick = {
            focusManager.clearFocus(force = true)
            showCapturedDrawer = !showCapturedDrawer
          },
          modifier = Modifier.testTag("sniffer_toggle_captured_btn"),
        ) {
          BadgedBox(
            badge = {
              if (captured.isNotEmpty()) {
                Badge { Text("${captured.size}") }
              }
            },
          ) {
            Icon(Icons.Default.VideoLibrary, contentDescription = strings.capturedStreamsCount(captured.size))
          }
        }
      }

      if (loadProgress in 1..99 && !rendererCrashedPermanently) {
        LinearProgressIndicator(progress = { loadProgress / 100f }, modifier = Modifier.fillMaxWidth())
      }

      // Embedded WebView with DOM + Network Request Stream Sniffing + RenderProcessGone Recovery
      Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
        if (rendererCrashedPermanently) {
          Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
              Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(36.dp))
                Text(
                  "Browser renderer restarted due to device graphics limits.",
                  style = MaterialTheme.typography.bodyMedium,
                  textAlign = TextAlign.Center,
                )
                Button(
                  onClick = {
                    useSoftwareFallback = true
                    rendererCrashedPermanently = false
                    webViewInstanceKey++
                  },
                ) {
                  Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(Modifier.width(6.dp))
                  Text("Reload")
                }
              }
            }
          }
        } else {
          key(webViewInstanceKey) {
            AndroidView(
              factory = { ctx ->
                WebView(ctx).apply {
                  layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                  )
                  configureSafeWebView(this, useSoftwareFallback)
                  addJavascriptInterface(
                    object {
                      @JavascriptInterface
                      fun onMediaFound(url: String, title: String) {
                        if (!isDisposed) {
                          mainHandler.post { recordUrl(url, title) }
                        }
                      }
                    },
                    "VortexSniffer",
                  )
                  webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                      if (!isDisposed) loadProgress = newProgress
                    }

                    override fun onReceivedTitle(view: WebView?, title: String?) {
                      if (!isDisposed && !title.isNullOrBlank()) currentPageTitle = title
                    }
                  }
                  webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                      val reqUrl = request?.url?.toString().orEmpty()
                      if (!isDisposed && looksLikeSniffableMediaRequest(reqUrl)) {
                        mainHandler.post { recordUrl(reqUrl, currentPageTitle) }
                      }
                      return super.shouldInterceptRequest(view, request)
                    }

                    override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                      super.doUpdateVisitedHistory(view, url, isReload)
                      if (!isDisposed && !url.isNullOrBlank()) {
                        addressInput = url
                        maybeResolveSocialVideoPage(url)
                      }
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                      super.onPageFinished(view, url)
                      if (!isDisposed && !url.isNullOrBlank()) {
                        addressInput = url
                        maybeResolveSocialVideoPage(url)
                      }
                      view?.evaluateJavascript(SNIFF_SCAN_JS, null)
                    }

                    override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                      disposeWebViewSafely(view, deferDestroy = true)
                      webViewRef = null
                      if (!isDisposed) {
                        mainHandler.post {
                          if (!useSoftwareFallback) {
                            useSoftwareFallback = true
                            webViewInstanceKey++
                          } else {
                            rendererCrashedPermanently = true
                          }
                        }
                      }
                      return true
                    }
                  }
                  webViewRef = this
                  loadUrl(targetUrlToLoad)
                }
              },
              onRelease = { view ->
                if (webViewRef === view) webViewRef = null
                disposeWebViewSafely(view)
              },
              modifier = Modifier.fillMaxSize(),
            )
          }
        }

        // Live Captured Count Pill
        Surface(
          onClick = {
            focusManager.clearFocus(force = true)
            showCapturedDrawer = !showCapturedDrawer
          },
          color = MaterialTheme.colorScheme.primaryContainer,
          shape = RoundedCornerShape(50),
          modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
            Text(
              strings.capturedStreamsCount(captured.size),
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.SemiBold,
            )
            Icon(
              if (showCapturedDrawer) Icons.Default.ExpandMore else Icons.Default.ExpandLess,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
          }
        }
      }

      // Expandable Captured Streams Drawer
      AnimatedVisibility(visible = showCapturedDrawer) {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
          shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
          modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp, max = 320.dp),
        ) {
          Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
            Text(
              strings.capturedStreamsCount(captured.size),
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
            )
            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
            if (captured.isEmpty()) {
              Text(
                "Play the video on the page or tap Refresh to capture direct streams.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            } else {
              LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(captured, key = { it.url }) { stream ->
                  Surface(
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    shape = RoundedCornerShape(10.dp),
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                      Column(modifier = Modifier.weight(1f)) {
                        Text(stream.qualityLabel, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                        Text(stream.url, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                      }
                      Row {
                        IconButton(
                          onClick = {
                            focusManager.clearFocus(force = true)
                            keyboardController?.hide()
                            onPlayStream(stream)
                          },
                        ) {
                          Icon(Icons.Default.PlayArrow, contentDescription = strings.playStream)
                        }
                        IconButton(
                          onClick = {
                            focusManager.clearFocus(force = true)
                            onDownloadStream(stream)
                          },
                        ) {
                          Icon(Icons.Default.Download, contentDescription = strings.downloads)
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun EmbeddedWebVideoPlayer(
  url: String,
  onStreamCaptured: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val latestOnStreamCaptured by rememberUpdatedState(onStreamCaptured)
  val mainHandler = remember { Handler(Looper.getMainLooper()) }
  val ytId = remember(url) { UniversalDownloadEngine.extractYouTubeVideoId(url) }
  val effectiveUrl = remember(url, ytId) {
    if (ytId != null) "https://www.youtube.com/embed/$ytId?playsinline=1&rel=0" else url
  }
  var loadProgress by remember(effectiveUrl) { mutableIntStateOf(0) }
  var webViewInstanceKey by remember(effectiveUrl) { mutableIntStateOf(0) }
  var useSoftwareFallback by remember(effectiveUrl) { mutableStateOf(!hasHardwareRenderNode()) }
  var rendererCrashedPermanently by remember(effectiveUrl) { mutableStateOf(false) }
  var switchedToMobileWatch by remember(effectiveUrl) { mutableStateOf(false) }
  var isDisposed by remember { mutableStateOf(false) }

  DisposableEffect(Unit) {
    onDispose { isDisposed = true }
  }

  Column(modifier = modifier.fillMaxSize()) {
    if (loadProgress in 1..99 && !rendererCrashedPermanently) {
      LinearProgressIndicator(progress = { loadProgress / 100f }, modifier = Modifier.fillMaxWidth())
    }
    if (rendererCrashedPermanently) {
      Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
          Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(36.dp))
            Text(
              "Embedded web renderer stopped; tap below to reload.",
              style = MaterialTheme.typography.bodyMedium,
              textAlign = TextAlign.Center,
            )
            Button(
              onClick = {
                useSoftwareFallback = true
                rendererCrashedPermanently = false
                webViewInstanceKey++
              },
            ) {
              Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(Modifier.width(6.dp))
              Text("Reload")
            }
          }
        }
      }
    } else {
      key(effectiveUrl, webViewInstanceKey) {
        AndroidView(
          factory = { ctx ->
            WebView(ctx).apply {
              layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
              )
              configureSafeWebView(this, useSoftwareFallback)
              addJavascriptInterface(
                object {
                  @JavascriptInterface
                  fun onMediaFound(mediaUrl: String, title: String) {
                    if (!isDisposed && looksLikeSniffableMediaRequest(mediaUrl)) {
                      mainHandler.post {
                        if (!isDisposed) latestOnStreamCaptured(mediaUrl)
                      }
                    }
                  }
                },
                "VortexSniffer",
              )
              webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                  if (!isDisposed) loadProgress = newProgress
                }
              }
              webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                  val reqUrl = request?.url?.toString().orEmpty()
                  if (!isDisposed && looksLikeSniffableMediaRequest(reqUrl)) {
                    mainHandler.post {
                      if (!isDisposed) latestOnStreamCaptured(reqUrl)
                    }
                  }
                  return super.shouldInterceptRequest(view, request)
                }

                override fun onPageFinished(view: WebView?, loadedUrl: String?) {
                  super.onPageFinished(view, loadedUrl)
                  view?.evaluateJavascript(SNIFF_SCAN_JS, null)
                  // Auto-fallback to m.youtube.com if YouTube Embed reports Error 153 or owner disabled embedding
                  if (ytId != null && !switchedToMobileWatch && loadedUrl?.contains("/embed/") == true) {
                    view?.evaluateJavascript(
                      """
                      (function(){
                        var txt = (document.body && document.body.innerText) || '';
                        var err = document.querySelector('.ytp-error');
                        return !!(err || txt.indexOf('Error 153') >= 0 || txt.indexOf('Video unavailable') >= 0 || txt.indexOf('Playback on other websites') >= 0);
                      })();
                      """.trimIndent()
                    ) { result ->
                      if (result == "true" && !isDisposed && !switchedToMobileWatch) {
                        switchedToMobileWatch = true
                        view.loadUrl("https://m.youtube.com/watch?v=$ytId")
                      }
                    }
                  }
                }

                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                  disposeWebViewSafely(view, deferDestroy = true)
                  if (!isDisposed) {
                    mainHandler.post {
                      if (!useSoftwareFallback) {
                        useSoftwareFallback = true
                        webViewInstanceKey++
                      } else {
                        rendererCrashedPermanently = true
                      }
                    }
                  }
                  return true
                }
              }
              if (ytId != null) {
                loadUrl(effectiveUrl, mapOf("Referer" to "https://www.youtube.com/"))
              } else {
                loadUrl(effectiveUrl)
              }
            }
          },
          onRelease = { view ->
            disposeWebViewSafely(view)
          },
          modifier = Modifier.fillMaxSize(),
        )
      }
    }
  }
}
