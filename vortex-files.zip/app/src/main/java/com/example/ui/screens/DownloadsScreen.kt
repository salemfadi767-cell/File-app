package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.VortexAppContainer
import com.example.data.db.DownloadTaskEntity
import com.example.data.prefs.UserPreferences
import com.example.domain.download.FastApiCompanionKit
import com.example.domain.download.MediaResolveResult
import com.example.domain.download.TorrentMetadata
import com.example.domain.download.UniversalDownloadEngine
import com.example.domain.fs.formatFileSize
import com.example.domain.security.AntivirusScanReport
import com.example.i18n.LocalAppStrings
import com.example.ui.components.AntivirusReportDialog
import com.example.ui.components.SmartBrowserSnifferDialog
import java.io.File
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(
  initialTarget: String,
  openSnifferImmediately: Boolean = false,
  defaultDownloadsDir: File,
  container: VortexAppContainer,
  onPlayVideoUrl: (String) -> Unit,
  onOpenDownloadedFile: (String) -> Unit,
  onBack: () -> Unit,
) {
  val context = LocalContext.current
  val strings = LocalAppStrings.current
  val scope = rememberCoroutineScope()
  val snackbar = remember { SnackbarHostState() }
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current

  val engine = container.downloadEngine
  val tasks by engine.allDownloads.collectAsStateWithLifecycle(initialValue = emptyList())
  val prefs by container.preferencesRepo.preferences.collectAsStateWithLifecycle(initialValue = UserPreferences())

  var urlInput by remember(initialTarget) { mutableStateOf(initialTarget) }
  var isResolving by remember { mutableStateOf(false) }
  var resolvedResult by remember { mutableStateOf<MediaResolveResult?>(null) }
  var lastResolvedUrl by remember { mutableStateOf("") }
  var parsedTorrent by remember { mutableStateOf<TorrentMetadata?>(null) }
  var activeTorrentPath by remember { mutableStateOf<String?>(null) }
  var showBrowserSniffer by remember(initialTarget, openSnifferImmediately) { mutableStateOf(openSnifferImmediately) }
  var downloadAvReport by remember { mutableStateOf<AntivirusScanReport?>(null) }
  var autoScannedTaskIds by remember { mutableStateOf<Set<Long>>(emptySet()) }

  DisposableEffect(Unit) {
    onDispose {
      focusManager.clearFocus(force = true)
      keyboardController?.hide()
    }
  }

  LaunchedEffect(tasks, prefs.antivirusAutoScanEnabled) {
    if (!prefs.antivirusAutoScanEnabled) return@LaunchedEffect
    val newlyCompleted = tasks.filter { it.status == "COMPLETED" && it.id !in autoScannedTaskIds }
    if (newlyCompleted.isNotEmpty()) {
      autoScannedTaskIds = autoScannedTaskIds + newlyCompleted.map { it.id }
      for (t in newlyCompleted) {
        val report = runCatching { container.antivirusEngine.scanTarget(t.destinationPath) }.getOrNull()
        if (report != null && report.threatsFound > 0) {
          downloadAvReport = report
          snackbar.showSnackbar("⚠️ ${t.fileName}: ${report.threatsFound} threat(s) detected")
        }
      }
    }
  }

  LaunchedEffect(initialTarget) {
    if (initialTarget.endsWith(".torrent", ignoreCase = true) && File(initialTarget).exists()) {
      activeTorrentPath = initialTarget
      runCatching { engine.parseTorrentBytes(File(initialTarget).readBytes()) }
        .onSuccess { parsedTorrent = it }
        .onFailure { snackbar.showSnackbar(it.message ?: "Invalid torrent file") }
    } else if (initialTarget.startsWith("http", ignoreCase = true)) {
      isResolving = true
      runCatching { engine.resolveMediaLinks(initialTarget, prefs.companionDownloaderUrl) }
        .onSuccess {
          resolvedResult = it
          lastResolvedUrl = initialTarget
        }
        .onFailure { snackbar.showSnackbar(it.message ?: "Resolve failed") }
      isResolving = false
    }
  }

  val torrentPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
      if (uri != null) {
        scope.launch {
          runCatching {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
            val tmpFile = File(context.cacheDir, "picked_${System.currentTimeMillis()}.torrent")
            tmpFile.writeBytes(bytes)
            activeTorrentPath = tmpFile.absolutePath
            urlInput = tmpFile.absolutePath
            parsedTorrent = engine.parseTorrentBytes(bytes)
          }.onFailure {
            snackbar.showSnackbar(it.message ?: "Failed to read .torrent")
          }
        }
      }
    }

  Box(modifier = Modifier.fillMaxSize()) {
  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(snackbar) },
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(strings.downloadManagerTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
              defaultDownloadsDir.absolutePath,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        },
        navigationIcon = {
          IconButton(
            onClick = {
              focusManager.clearFocus(force = true)
              keyboardController?.hide()
              onBack()
            },
            modifier = Modifier.testTag("downloads_back_button"),
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
          }
        },
        actions = {
          IconButton(
            onClick = { scope.launch { engine.clearFinished() } },
            modifier = Modifier.testTag("clear_finished_downloads"),
          ) {
            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear finished")
          }
        },
      )
    },
  ) { padding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .navigationBarsPadding(),
      contentAlignment = Alignment.TopCenter,
    ) {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .widthIn(max = 780.dp)
          .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        item {
          Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
            shape = RoundedCornerShape(18.dp),
          ) {
            Column(
              modifier = Modifier.padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              OutlinedTextField(
                value = urlInput,
                onValueChange = { urlInput = it },
                label = { Text(strings.addDownloadUrl) },
                leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
                trailingIcon = {
                  if (urlInput.isNotEmpty()) {
                    IconButton(onClick = { urlInput = ""; resolvedResult = null; lastResolvedUrl = ""; parsedTorrent = null }) {
                      Icon(Icons.Default.Close, contentDescription = strings.cancel)
                    }
                  }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("download_url_input"),
              )

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Button(
                  onClick = {
                    focusManager.clearFocus(force = true)
                    keyboardController?.hide()
                    val raw = urlInput.trim()
                    if (raw.isBlank()) return@Button
                    scope.launch {
                      when {
                        raw.startsWith("magnet:?", ignoreCase = true) || raw.endsWith(".torrent", ignoreCase = true) -> {
                          engine.enqueueTorrentOrMagnet(raw, defaultDownloadsDir)
                          snackbar.showSnackbar("Torrent/Magnet task queued")
                        }
                        else -> {
                          isResolving = true
                          parsedTorrent = null
                          runCatching { engine.resolveMediaLinks(raw, prefs.companionDownloaderUrl) }
                            .onSuccess {
                              resolvedResult = it
                              lastResolvedUrl = raw
                            }
                            .onFailure { snackbar.showSnackbar(it.message ?: "Failed to inspect URL") }
                          isResolving = false
                        }
                      }
                    }
                  },
                  enabled = urlInput.isNotBlank() && !isResolving,
                  modifier = Modifier.weight(1f).testTag("resolve_url_button"),
                ) {
                  if (isResolving) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                  } else {
                    Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                  }
                  Spacer(Modifier.width(6.dp))
                  Text(strings.resolveStreams, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }

                FilledTonalButton(
                  onClick = {
                    focusManager.clearFocus(force = true)
                    keyboardController?.hide()
                    val raw = urlInput.trim()
                    if (raw.isBlank()) return@FilledTonalButton
                    scope.launch {
                      when {
                        raw.startsWith("magnet:?", true) || raw.endsWith(".torrent", true) -> {
                          engine.enqueueTorrentOrMagnet(raw, defaultDownloadsDir)
                          snackbar.showSnackbar("Added to queue")
                        }
                        UniversalDownloadEngine.isDirectPlayableMediaUrl(raw) -> {
                          engine.enqueueDirectDownload(raw, defaultDownloadsDir)
                          snackbar.showSnackbar("Added to queue")
                        }
                        else -> {
                          val cached = if (lastResolvedUrl == raw) resolvedResult else null
                          val res =
                            if (cached != null && cached.streams.any { !it.isDrmProtected }) {
                              cached
                            } else {
                              isResolving = true
                              val fetched = runCatching {
                                engine.resolveMediaLinks(raw, prefs.companionDownloaderUrl)
                              }.onFailure {
                                snackbar.showSnackbar(it.message ?: "Failed to inspect URL")
                              }.getOrNull()
                              isResolving = false
                              if (fetched != null) {
                                resolvedResult = fetched
                                lastResolvedUrl = raw
                              }
                              fetched
                            }

                          val playable = res?.streams.orEmpty().filter { !it.isDrmProtected }
                          val best =
                            playable.firstOrNull { (it.hasVideo && it.hasAudio) || !it.pairedAudioUrl.isNullOrBlank() || it.isHls }
                              ?: playable.firstOrNull()

                          if (res != null && best != null) {
                            val safeStem = res.pageTitle.replace(Regex("[^A-Za-z0-9._-]"), "_").take(36).ifBlank { "media" }
                            val qTag = best.qualityLabel.replace(Regex("[^A-Za-z0-9_-]"), "_")
                            val pairedAudio = best.pairedAudioUrl
                            if (!pairedAudio.isNullOrBlank()) {
                              engine.enqueueMuxedDownload(
                                videoUrl = best.url,
                                audioUrl = pairedAudio,
                                destDir = defaultDownloadsDir,
                                fileNameOverride = "${safeStem}_${qTag}.mp4",
                              )
                            } else {
                              val ext = when {
                                best.mimeType.contains("audio") -> "m4a"
                                best.mimeType.contains("webm") -> "webm"
                                best.engineUsed == "Direct HTTP" -> ""
                                else -> "mp4"
                              }
                              val fileOverride =
                                if (ext.isNotEmpty()) "${safeStem}_${qTag}.$ext" else null
                              engine.enqueueDirectDownload(
                                url = best.url,
                                destDir = defaultDownloadsDir,
                                fileNameOverride = fileOverride,
                                downloadType = if (best.isHls) "HLS" else "HTTP",
                              )
                            }
                            snackbar.showSnackbar("Queued: ${best.qualityLabel}")
                          } else {
                            snackbar.showSnackbar(res?.note ?: "No downloadable stream found; try Smart Browser Sniffer")
                          }
                        }
                      }
                    }
                  },
                  enabled = urlInput.isNotBlank() && !isResolving,
                  modifier = Modifier.weight(1f).testTag("direct_download_button"),
                ) {
                  Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(Modifier.width(6.dp))
                  Text(strings.downloads, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                OutlinedButton(
                  onClick = {
                    focusManager.clearFocus(force = true)
                    torrentPicker.launch(arrayOf("*/*"))
                  },
                  modifier = Modifier.weight(1f).testTag("pick_torrent_button"),
                ) {
                  Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(Modifier.width(6.dp))
                  Text(strings.torrentMagnetTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                FilledTonalButton(
                  onClick = {
                    focusManager.clearFocus(force = true)
                    keyboardController?.hide()
                    showBrowserSniffer = true
                  },
                  modifier = Modifier.weight(1f).testTag("open_browser_sniffer_btn"),
                ) {
                  Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(Modifier.width(6.dp))
                  Text(strings.smartBrowserSniffer, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                OutlinedButton(
                  onClick = {
                    scope.launch {
                      runCatching {
                        FastApiCompanionKit.exportKitToFolder(defaultDownloadsDir)
                      }.onSuccess { summary ->
                        snackbar.showSnackbar("FastAPI Server (${summary.filesCreated.size} files) -> ${summary.outputDir.absolutePath}")
                      }.onFailure { err ->
                        snackbar.showSnackbar(err.message ?: "Export failed")
                      }
                    }
                  },
                  modifier = Modifier.weight(1f).testTag("export_fastapi_kit_btn"),
                ) {
                  Icon(Icons.Default.Terminal, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(Modifier.width(6.dp))
                  Text(strings.companionExportKit, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
              }
              if (prefs.companionDownloaderUrl.isNotBlank()) {
                Text(
                  text = "${strings.companionServerLabel}: ${prefs.companionDownloaderUrl}",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.primary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
            }
          }
        }

        // Torrent Metadata Preview
        parsedTorrent?.let { meta ->
          item {
            Card(
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
              shape = RoundedCornerShape(16.dp),
            ) {
              Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(meta.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                  "Hash: ${meta.infoHashHex.take(16)}… • ${formatFileSize(meta.totalBytes)} • ${meta.files.size} files",
                  style = MaterialTheme.typography.bodySmall,
                )
                Text(
                  "Trackers: ${meta.trackers.size} • WebSeeds (BEP-19): ${meta.webSeeds.size}",
                  style = MaterialTheme.typography.labelMedium,
                )
                Button(
                  onClick = {
                    val path = activeTorrentPath ?: urlInput.trim()
                    scope.launch { engine.enqueueTorrentOrMagnet(path, defaultDownloadsDir) }
                  },
                  modifier = Modifier.fillMaxWidth().testTag("start_torrent_button"),
                ) {
                  Icon(Icons.Default.CloudDownload, contentDescription = null)
                  Spacer(Modifier.width(8.dp))
                  Text(strings.downloads)
                }
              }
            }
          }
        }

        // Extracted Media Streams (Non-DRM)
        resolvedResult?.let { res ->
          item {
            Card(
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
              shape = RoundedCornerShape(16.dp),
            ) {
              Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(res.pageTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                if (!res.engineSummary.isNullOrBlank()) {
                  Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(8.dp),
                  ) {
                    Text(
                      res.engineSummary!!,
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onPrimaryContainer,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    )
                  }
                }
                if (res.drmRejectedCount > 0 || !res.note.isNullOrBlank()) {
                  Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(10.dp),
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth().padding(10.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                      Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
                      Text(
                        res.note ?: strings.drmProtectedNotice,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                      )
                    }
                  }
                }
                res.streams.take(16).forEach { stream ->
                  Surface(
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    shape = RoundedCornerShape(12.dp),
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth().padding(10.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                      Column(modifier = Modifier.weight(1f)) {
                        Text(stream.qualityLabel, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                        val sizeTxt = if (stream.contentLength > 0) " • ${formatFileSize(stream.contentLength)}" else ""
                        Text(
                          "${stream.engineUsed} • ${stream.mimeType}$sizeTxt",
                          style = MaterialTheme.typography.labelSmall,
                          color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                      }
                      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                          onClick = {
                            focusManager.clearFocus(force = true)
                            keyboardController?.hide()
                            onPlayVideoUrl(stream.url)
                          },
                        ) {
                          Icon(Icons.Default.PlayArrow, contentDescription = strings.playStream)
                        }
                        IconButton(
                          onClick = {
                            focusManager.clearFocus(force = true)
                            scope.launch {
                              val safeStem = res.pageTitle.replace(Regex("[^A-Za-z0-9._-]"), "_").take(36).ifBlank { "media" }
                              val qTag = stream.qualityLabel.replace(Regex("[^A-Za-z0-9_-]"), "_")
                              val pairedAudio = stream.pairedAudioUrl
                              if (!pairedAudio.isNullOrBlank()) {
                                engine.enqueueMuxedDownload(
                                  videoUrl = stream.url,
                                  audioUrl = pairedAudio,
                                  destDir = defaultDownloadsDir,
                                  fileNameOverride = "${safeStem}_${qTag}.mp4",
                                )
                              } else {
                                val ext = when {
                                  stream.mimeType.contains("audio") -> "m4a"
                                  stream.mimeType.contains("webm") -> "webm"
                                  else -> "mp4"
                                }
                                engine.enqueueDirectDownload(
                                  url = stream.url,
                                  destDir = defaultDownloadsDir,
                                  fileNameOverride = "${safeStem}_${qTag}.$ext",
                                  downloadType = if (stream.isHls) "HLS" else "HTTP",
                                )
                              }
                              snackbar.showSnackbar("Queued: ${stream.qualityLabel}")
                            }
                          }
                        ) {
                          Icon(Icons.Default.Download, contentDescription = strings.downloads)
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }

        // Download Tasks Queue
        items(tasks, key = { it.id }) { task ->
          DownloadTaskCard(
            task = task,
            onPause = { scope.launch { engine.pauseTask(task.id) } },
            onResume = { engine.startJob(task.id) },
            onCancel = { scope.launch { engine.cancelTask(task.id, removeFile = false) } },
            onOpen = {
              focusManager.clearFocus(force = true)
              onOpenDownloadedFile(task.destinationPath)
            },
            onScan = {
              scope.launch {
                val rep = runCatching { container.antivirusEngine.scanTarget(task.destinationPath) }.getOrNull()
                if (rep != null) {
                  downloadAvReport = rep
                }
              }
            },
            onDelete = { scope.launch { engine.deleteTaskRecord(task.id) } },
          )
        }
      }
    }
  }

  if (showBrowserSniffer) {
    SmartBrowserSnifferDialog(
      initialUrl = urlInput,
      onPlayStream = { stream ->
        focusManager.clearFocus(force = true)
        keyboardController?.hide()
        showBrowserSniffer = false
        onPlayVideoUrl(stream.url)
      },
      onDownloadStream = { stream ->
        scope.launch {
          val safeStem = stream.title.replace(Regex("[^A-Za-z0-9._-]"), "_").take(36).ifBlank { "web_video" }
          val ext = if (stream.mimeType.contains("audio")) "m4a" else "mp4"
          if (!stream.pairedAudioUrl.isNullOrBlank()) {
            engine.enqueueMuxedDownload(
              videoUrl = stream.url,
              audioUrl = stream.pairedAudioUrl,
              destDir = defaultDownloadsDir,
              fileNameOverride = "${safeStem}.mp4",
            )
          } else {
            engine.enqueueDirectDownload(
              url = stream.url,
              destDir = defaultDownloadsDir,
              fileNameOverride = "${safeStem}.${ext}",
              downloadType = if (stream.isHls) "HLS" else "HTTP",
            )
          }
          snackbar.showSnackbar("Queued: ${stream.qualityLabel}")
        }
      },
      onResolvePageStreams = { pageUrl ->
        runCatching {
          engine.resolveMediaLinks(pageUrl, prefs.companionDownloaderUrl).streams.filter { !it.isDrmProtected }
        }.getOrDefault(emptyList())
      },
      onDismiss = {
        focusManager.clearFocus(force = true)
        keyboardController?.hide()
        showBrowserSniffer = false
      },
    )
  }
  downloadAvReport?.let { report ->
    AntivirusReportDialog(
      report = report,
      onQuarantine = { path ->
        scope.launch {
          val q = container.antivirusEngine.quarantineFile(File(path))
          snackbar.showSnackbar(if (q != null) "Moved to Quarantine Vault" else "Quarantine failed")
          downloadAvReport = null
        }
      },
      onDelete = { path ->
        scope.launch {
          val ok = File(path).delete()
          snackbar.showSnackbar(if (ok) "Deleted threat file" else "Delete failed")
          downloadAvReport = null
        }
      },
      onDismiss = { downloadAvReport = null },
    )
  }
  }
}

@Composable
private fun DownloadTaskCard(
  task: DownloadTaskEntity,
  onPause: () -> Unit,
  onResume: () -> Unit,
  onCancel: () -> Unit,
  onOpen: () -> Unit,
  onScan: () -> Unit,
  onDelete: () -> Unit,
) {
  val progress =
    if (task.totalBytes > 0L) (task.bytesDownloaded.toFloat() / task.totalBytes.toFloat()).coerceIn(0f, 1f)
    else if (task.status == "COMPLETED") 1f
    else 0f

  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    shape = RoundedCornerShape(14.dp),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(task.fileName, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
          val speedTxt = if (task.speedBytesPerSec > 0 && task.status == "DOWNLOADING") " • ${formatFileSize(task.speedBytesPerSec)}/s" else ""
          val totalTxt = if (task.totalBytes > 0) " / ${formatFileSize(task.totalBytes)}" else ""
          Text(
            "${task.downloadType} • ${task.status} • ${formatFileSize(task.bytesDownloaded)}$totalTxt$speedTxt",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        Row {
          when (task.status) {
            "DOWNLOADING", "QUEUED" -> {
              IconButton(onClick = onPause) { Icon(Icons.Default.Pause, contentDescription = "Pause") }
              IconButton(onClick = onCancel) { Icon(Icons.Default.Close, contentDescription = "Cancel") }
            }
            "PAUSED", "FAILED", "CANCELLED" -> {
              IconButton(onClick = onResume) { Icon(Icons.Default.PlayArrow, contentDescription = "Retry") }
              IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
            }
            "COMPLETED" -> {
              IconButton(onClick = onScan) { Icon(Icons.Default.Security, contentDescription = "Scan") }
              IconButton(onClick = onOpen) { Icon(Icons.Default.FileOpen, contentDescription = "Open") }
              IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
            }
          }
        }
      }
      if (task.status == "DOWNLOADING" || task.status == "PAUSED") {
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(6.dp))
      }
      if (!task.errorMessage.isNullOrBlank()) {
        Text(task.errorMessage, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
      }
      if (task.peersInfo.isNotBlank()) {
        Text(task.peersInfo, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
      }
    }
  }
}
