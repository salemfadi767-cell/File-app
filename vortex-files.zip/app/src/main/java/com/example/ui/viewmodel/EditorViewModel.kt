package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.VortexAppContainer
import com.example.data.prefs.SortField
import com.example.domain.editor.AppTargetPlatform
import com.example.domain.editor.BuiltAppArtifact
import com.example.domain.editor.CodeDiagnostic
import com.example.domain.editor.CodeLanguage
import com.example.domain.editor.CodeRunResult
import com.example.domain.editor.CodeSymbol
import com.example.domain.editor.IdeAssistant
import com.example.domain.editor.IdeCompletion
import com.example.domain.editor.InstalledIdePackage
import com.example.domain.editor.PackageEcosystem
import com.example.domain.fs.EditBackupManager
import com.example.domain.fs.VirtualFileNode
import java.io.File
import java.nio.charset.Charset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class EditorCharset(val label: String, val charset: Charset) {
  UTF_8("UTF-8", Charsets.UTF_8),
  UTF_16("UTF-16", Charsets.UTF_16),
  ISO_8859_1("ISO-8859-1", Charsets.ISO_8859_1),
  WINDOWS_1256("Windows-1256 (AR)", Charset.forName("windows-1256")),
}

data class EditorTab(
  val filePath: String,
  val fileName: String,
  val text: String,
  val rawBytes: ByteArray,
  val language: CodeLanguage,
  val charset: EditorCharset = EditorCharset.UTF_8,
  val isHexMode: Boolean = false,
  val isDirty: Boolean = false,
)

data class CodeEditorUiState(
  val filePath: String = "",
  val fileName: String = "",
  val text: String = "",
  val rawBytes: ByteArray = ByteArray(0),
  val language: CodeLanguage = CodeLanguage.PLAIN,
  val charset: EditorCharset = EditorCharset.UTF_8,
  val isHexMode: Boolean = false,
  val isDirty: Boolean = false,
  val isLoading: Boolean = false,
  val canUndo: Boolean = false,
  val canRedo: Boolean = false,
  val statusMessage: String? = null,
  val diagnostics: List<CodeDiagnostic> = emptyList(),
  val symbols: List<CodeSymbol> = emptyList(),
  val completions: List<IdeCompletion> = emptyList(),
  val isRunning: Boolean = false,
  val runResult: CodeRunResult? = null,
  val showConsole: Boolean = false,
  val showHtmlPreview: Boolean = false,
  val openTabs: List<EditorTab> = emptyList(),
  val activeTabIndex: Int = -1,
  val workspaceFolderPath: String = "",
  val workspaceFiles: List<VirtualFileNode> = emptyList(),
  val installedPackages: List<InstalledIdePackage> = emptyList(),
  val isInstallingPackage: Boolean = false,
  val isBuildingApp: Boolean = false,
  val lastBuiltArtifact: BuiltAppArtifact? = null,
)

class EditorViewModel(private val container: VortexAppContainer) : ViewModel() {

  private val _uiState = MutableStateFlow(CodeEditorUiState())
  val uiState: StateFlow<CodeEditorUiState> = _uiState.asStateFlow()

  private val undoStack = ArrayDeque<String>()
  private val redoStack = ArrayDeque<String>()

  fun openFile(path: String, forceHex: Boolean = false) {
    if (path.isBlank()) {
      val fallbackDir = _uiState.value.workspaceFolderPath.ifBlank { container.fileRepository.appWorkspaceDir().absolutePath }
      openWorkspaceDirectory(fallbackDir)
      return
    }
    viewModelScope.launch {
      val currentTabs = snapshotActiveTabIntoList(_uiState.value)
      val existingIdx = currentTabs.indexOfFirst { it.filePath == path }
      if (existingIdx >= 0) {
        val existing = currentTabs[existingIdx].let { tab -> if (forceHex) tab.copy(isHexMode = true) else tab }
        val updatedTabs = currentTabs.mapIndexed { idx, t -> if (idx == existingIdx) existing else t }
        applyTabToState(existing, updatedTabs, existingIdx)
        loadWorkspaceDirectoryInternal(File(path).parent ?: container.fileRepository.appWorkspaceDir().absolutePath)
        return@launch
      }

      val name = path.substringAfterLast('/').ifEmpty { "file" }
      val lang = CodeLanguage.detect(name)
      _uiState.update {
        it.copy(
          filePath = path,
          fileName = name,
          language = lang,
          isHexMode = forceHex,
          isLoading = true,
          openTabs = currentTabs,
        )
      }
      undoStack.clear()
      redoStack.clear()

      val node = VirtualFileNode(name = name, path = path, isDirectory = false, size = 0L, lastModified = 0L)
      val bytes = container.fileRepository.readFileBytes(node, maxBytes = 4 * 1024 * 1024)
      val cs = _uiState.value.charset
      val text = bytes.toString(cs.charset)
      val newTab =
        EditorTab(
          filePath = path,
          fileName = name,
          text = text,
          rawBytes = bytes,
          language = lang,
          charset = cs,
          isHexMode = forceHex,
          isDirty = false,
        )
      val nextTabs = currentTabs + newTab
      applyTabToState(newTab, nextTabs, nextTabs.lastIndex)
      val parentDir = File(path).parent ?: container.fileRepository.appWorkspaceDir().absolutePath
      loadWorkspaceDirectoryInternal(parentDir)
    }
  }

  fun switchTab(index: Int) {
    val st = _uiState.value
    val tabs = snapshotActiveTabIntoList(st)
    if (index !in tabs.indices) return
    applyTabToState(tabs[index], tabs, index)
  }

  fun closeTab(index: Int) {
    val st = _uiState.value
    val tabs = snapshotActiveTabIntoList(st).toMutableList()
    if (index !in tabs.indices) return
    tabs.removeAt(index)
    if (tabs.isEmpty()) {
      undoStack.clear()
      redoStack.clear()
      _uiState.update {
        it.copy(
          filePath = "",
          fileName = "",
          text = "",
          rawBytes = ByteArray(0),
          isDirty = false,
          canUndo = false,
          canRedo = false,
          diagnostics = emptyList(),
          symbols = emptyList(),
          completions = emptyList(),
          openTabs = emptyList(),
          activeTabIndex = -1,
        )
      }
    } else {
      val nextIdx = (if (index <= st.activeTabIndex) index - 1 else st.activeTabIndex).coerceIn(0, tabs.lastIndex)
      applyTabToState(tabs[nextIdx], tabs, nextIdx)
    }
  }

  fun openWorkspaceDirectory(dirPath: String) {
    viewModelScope.launch {
      loadWorkspaceDirectoryInternal(dirPath)
    }
  }

  private suspend fun loadWorkspaceDirectoryInternal(dirPath: String) {
    if (dirPath.isBlank()) return
    val nodes =
      runCatching {
        container.fileRepository.listDirectory(
          path = dirPath,
          showHidden = false,
          sortField = SortField.NAME,
          sortAscending = true,
          useRoot = false,
        )
      }.getOrDefault(emptyList())
    val pkgs = runCatching {
      container.idePackageManager.listInstalledPackages(File(dirPath))
    }.getOrDefault(emptyList())
    _uiState.update {
      it.copy(
        workspaceFolderPath = dirPath,
        workspaceFiles = nodes,
        installedPackages = pkgs,
      )
    }
  }

  private fun snapshotActiveTabIntoList(st: CodeEditorUiState): List<EditorTab> {
    if (st.activeTabIndex !in st.openTabs.indices || st.filePath.isBlank()) return st.openTabs
    return st.openTabs.mapIndexed { idx, tab ->
      if (idx == st.activeTabIndex) {
        tab.copy(
          filePath = st.filePath,
          fileName = st.fileName,
          text = st.text,
          rawBytes = st.rawBytes,
          language = st.language,
          charset = st.charset,
          isHexMode = st.isHexMode,
          isDirty = st.isDirty,
        )
      } else {
        tab
      }
    }
  }

  private fun applyTabToState(tab: EditorTab, tabs: List<EditorTab>, activeIdx: Int) {
    undoStack.clear()
    redoStack.clear()
    _uiState.update {
      it.copy(
        filePath = tab.filePath,
        fileName = tab.fileName,
        text = tab.text,
        rawBytes = tab.rawBytes,
        language = tab.language,
        charset = tab.charset,
        isHexMode = tab.isHexMode,
        isDirty = tab.isDirty,
        isLoading = false,
        canUndo = false,
        canRedo = false,
        diagnostics = IdeAssistant.analyzeDiagnostics(tab.text, tab.language),
        symbols = IdeAssistant.extractSymbols(tab.text, tab.language),
        completions = IdeAssistant.suggestCompletions(tab.text, tab.language),
        openTabs = tabs,
        activeTabIndex = activeIdx,
      )
    }
  }

  fun onTextChanged(newText: String) {
    val current = _uiState.value.text
    if (newText == current) return
    undoStack.addLast(current)
    if (undoStack.size > 60) undoStack.removeFirst()
    redoStack.clear()
    val lang = _uiState.value.language
    _uiState.update { st ->
      val nextState =
        st.copy(
          text = newText,
          isDirty = true,
          canUndo = undoStack.isNotEmpty(),
          canRedo = false,
          diagnostics = IdeAssistant.analyzeDiagnostics(newText, lang),
          symbols = IdeAssistant.extractSymbols(newText, lang),
          completions = IdeAssistant.suggestCompletions(newText, lang),
        )
      nextState.copy(openTabs = snapshotActiveTabIntoList(nextState))
    }
  }

  fun insertSnippet(snippet: String) {
    onTextChanged(_uiState.value.text + snippet)
  }

  fun applyCompletion(completion: IdeCompletion) {
    val cur = _uiState.value.text
    val sep = if (cur.isEmpty() || cur.endsWith('\n') || cur.endsWith(' ')) "" else "\n"
    onTextChanged(cur + sep + completion.insertText)
  }

  fun formatCode() {
    val st = _uiState.value
    val formatted = IdeAssistant.formatCode(st.text, st.language)
    if (formatted != st.text) {
      onTextChanged(formatted)
    }
  }

  fun runCode(useRoot: Boolean, argsInput: String = "") {
    val st = _uiState.value
    if (st.isHexMode || st.filePath.isBlank()) return
    viewModelScope.launch {
      _uiState.update { it.copy(isRunning = true, showConsole = true) }
      val result =
        container.codeRunnerEngine.runCode(
          filePath = st.filePath,
          code = st.text,
          language = st.language,
          useRoot = useRoot,
          argsInput = argsInput,
        )
      _uiState.update {
        it.copy(
          isRunning = false,
          runResult = result,
          showConsole = true,
          showHtmlPreview = result.isHtmlPreviewAvailable && st.fileName.substringAfterLast('.', "").lowercase() in setOf("html", "htm", "svg"),
        )
      }
    }
  }

  fun setShowConsole(show: Boolean) {
    _uiState.update { it.copy(showConsole = show) }
  }

  fun setShowHtmlPreview(show: Boolean) {
    _uiState.update { it.copy(showHtmlPreview = show) }
  }

  fun undo() {
    if (undoStack.isEmpty()) return
    val prev = undoStack.removeLast()
    redoStack.addLast(_uiState.value.text)
    val lang = _uiState.value.language
    _uiState.update { st ->
      val next =
        st.copy(
          text = prev,
          isDirty = true,
          canUndo = undoStack.isNotEmpty(),
          canRedo = redoStack.isNotEmpty(),
          diagnostics = IdeAssistant.analyzeDiagnostics(prev, lang),
          symbols = IdeAssistant.extractSymbols(prev, lang),
          completions = IdeAssistant.suggestCompletions(prev, lang),
        )
      next.copy(openTabs = snapshotActiveTabIntoList(next))
    }
  }

  fun redo() {
    if (redoStack.isEmpty()) return
    val nextText = redoStack.removeLast()
    undoStack.addLast(_uiState.value.text)
    val lang = _uiState.value.language
    _uiState.update { st ->
      val next =
        st.copy(
          text = nextText,
          isDirty = true,
          canUndo = undoStack.isNotEmpty(),
          canRedo = redoStack.isNotEmpty(),
          diagnostics = IdeAssistant.analyzeDiagnostics(nextText, lang),
          symbols = IdeAssistant.extractSymbols(nextText, lang),
          completions = IdeAssistant.suggestCompletions(nextText, lang),
        )
      next.copy(openTabs = snapshotActiveTabIntoList(next))
    }
  }

  fun replaceAll(find: String, replace: String, useRegex: Boolean, caseSensitive: Boolean): Int {
    if (find.isEmpty()) return 0
    val src = _uiState.value.text
    val result: Pair<String, Int> =
      if (useRegex) {
        val opts = if (caseSensitive) emptySet() else setOf(RegexOption.IGNORE_CASE)
        val rx = runCatching { Regex(find, opts) }.getOrNull() ?: return 0
        val count = rx.findAll(src).count()
        rx.replace(src, replace) to count
      } else {
        var count = 0
        var idx = src.indexOf(find, ignoreCase = !caseSensitive)
        while (idx >= 0) {
          count++
          idx = src.indexOf(find, idx + find.length, ignoreCase = !caseSensitive)
        }
        src.replace(find, replace, ignoreCase = !caseSensitive) to count
      }
    if (result.second > 0) onTextChanged(result.first)
    return result.second
  }

  fun setCharset(newCharset: EditorCharset) {
    _uiState.update { st ->
      val decoded = st.rawBytes.toString(newCharset.charset)
      val next = st.copy(charset = newCharset, text = if (!st.isDirty) decoded else st.text)
      next.copy(openTabs = snapshotActiveTabIntoList(next))
    }
  }

  fun setLanguage(lang: CodeLanguage) {
    _uiState.update { st ->
      val next =
        st.copy(
          language = lang,
          diagnostics = IdeAssistant.analyzeDiagnostics(st.text, lang),
          symbols = IdeAssistant.extractSymbols(st.text, lang),
          completions = IdeAssistant.suggestCompletions(st.text, lang),
        )
      next.copy(openTabs = snapshotActiveTabIntoList(next))
    }
  }

  fun toggleHexMode() {
    _uiState.update { st ->
      val next = st.copy(isHexMode = !st.isHexMode)
      next.copy(openTabs = snapshotActiveTabIntoList(next))
    }
  }

  fun save(useRoot: Boolean, successMessage: String) {
    val st = _uiState.value
    if (st.filePath.isBlank()) return
    viewModelScope.launch {
      val autoBackup = runCatching { container.preferencesRepo.preferences.first().autoBackupOnEditEnabled }.getOrDefault(false)
      if (autoBackup) {
        EditBackupManager.createSnapshotBeforeEdit(st.filePath)
      }
      val bytes = st.text.toByteArray(st.charset.charset)
      val ok = container.fileRepository.writeFileBytes(st.filePath, bytes, useRoot)
      _uiState.update { cur ->
        val next =
          cur.copy(
            rawBytes = if (ok) bytes else cur.rawBytes,
            isDirty = !ok,
            statusMessage = if (ok) {
              if (autoBackup) "$successMessage (.vortexbak saved)" else successMessage
            } else "Save failed",
          )
        next.copy(openTabs = snapshotActiveTabIntoList(next))
      }
      if (ok && st.workspaceFolderPath.isNotBlank()) {
        loadWorkspaceDirectoryInternal(st.workspaceFolderPath)
      }
    }
  }

  fun installPackage(ecosystem: PackageEcosystem, spec: String) {
    val wsDir = File(_uiState.value.workspaceFolderPath.ifBlank { container.fileRepository.appWorkspaceDir().absolutePath })
    viewModelScope.launch {
      _uiState.update { it.copy(isInstallingPackage = true) }
      val res = container.idePackageManager.installPackage(wsDir, ecosystem, spec)
      val updated = container.idePackageManager.listInstalledPackages(wsDir)
      _uiState.update { cur ->
        cur.copy(
          isInstallingPackage = false,
          installedPackages = updated,
          statusMessage = res.fold(
            onSuccess = { pkg -> "Installed ${pkg.ecosystem.id}: ${pkg.name} ${pkg.version} (${pkg.filesCount} files)" },
            onFailure = { err -> err.message ?: "Package install failed" },
          ),
        )
      }
    }
  }

  fun uninstallPackage(ecosystem: PackageEcosystem, pkgName: String) {
    val wsDir = File(_uiState.value.workspaceFolderPath.ifBlank { container.fileRepository.appWorkspaceDir().absolutePath })
    viewModelScope.launch {
      container.idePackageManager.uninstallPackage(wsDir, ecosystem, pkgName)
      val updated = container.idePackageManager.listInstalledPackages(wsDir)
      _uiState.update { it.copy(installedPackages = updated, statusMessage = "Removed $pkgName") }
    }
  }

  fun buildMultiOsApp(appName: String, packageId: String, platform: AppTargetPlatform) {
    val projectDir = File(
      _uiState.value.workspaceFolderPath.ifBlank {
        File(_uiState.value.filePath).parent ?: container.fileRepository.appWorkspaceDir().absolutePath
      }
    )
    val outputDir = File(container.fileRepository.downloadsDir())
    viewModelScope.launch {
      _uiState.update { it.copy(isBuildingApp = true, lastBuiltArtifact = null) }
      val res = container.multiPlatformAppBuilder.buildAppPackage(
        projectDir = projectDir,
        appName = appName,
        packageId = packageId,
        platform = platform,
        outputDir = outputDir,
      )
      _uiState.update { cur ->
        cur.copy(
          isBuildingApp = false,
          lastBuiltArtifact = res.getOrNull(),
          statusMessage = res.fold(
            onSuccess = { art -> "Built ${art.outputFile.name} (${art.filesBundled} files)" },
            onFailure = { err -> err.message ?: "App build failed" },
          ),
        )
      }
    }
  }

  fun clearMessage() {
    _uiState.update { it.copy(statusMessage = null) }
  }
}
