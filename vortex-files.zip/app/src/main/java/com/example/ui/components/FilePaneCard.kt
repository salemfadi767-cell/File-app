package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.prefs.LongFilenameMode
import com.example.data.prefs.formatMiddleEllipsisFilename
import com.example.domain.fs.FileCategory
import com.example.domain.fs.FileSourceType
import com.example.domain.fs.VirtualFileNode
import com.example.domain.fs.formatFileSize
import com.example.domain.media.MediaBucketSummary
import com.example.domain.media.MediaThumbnailLoader
import com.example.i18n.LocalAppStrings
import com.example.ui.theme.LocalVortexExtraColors
import com.example.ui.theme.MonoFontFamily
import com.example.ui.viewmodel.FolderViewMode
import com.example.ui.viewmodel.PaneState
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FilePaneCard(
  pane: PaneState,
  isActive: Boolean,
  isBookmarked: Boolean,
  hasAllFilesAccess: Boolean,
  showQuickJumps: Boolean,
  compactMode: Boolean,
  longFilenameMode: LongFilenameMode = LongFilenameMode.MIDDLE_ELLIPSIS,
  thumbnailLoader: MediaThumbnailLoader? = null,
  discoveredBuckets: List<MediaBucketSummary> = emptyList(),
  onActivate: () -> Unit,
  onNavigate: (String) -> Unit,
  onNavigateUp: () -> Unit,
  onRefresh: () -> Unit,
  onToggleBookmark: () -> Unit,
  onAddTab: () -> Unit,
  onSwitchTab: (Int) -> Unit,
  onCloseTab: (Int) -> Unit,
  onQuickJumpInternal: () -> Unit,
  onQuickJumpDownloads: () -> Unit,
  onQuickJumpWorkspace: () -> Unit,
  onQuickJumpRoot: () -> Unit,
  onQuickJumpAndroidData: () -> Unit,
  onChangeViewMode: (FolderViewMode) -> Unit,
  onOpenFolderInMusicHub: (String) -> Unit,
  onItemClick: (VirtualFileNode) -> Unit,
  onItemLongClick: (VirtualFileNode) -> Unit,
  onItemMoreClick: (VirtualFileNode) -> Unit,
  onSelectRange: (Set<String>) -> Unit,
  onGrantAllFiles: () -> Unit,
  onOpenSystemGateway: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val strings = LocalAppStrings.current
  val extra = LocalVortexExtraColors.current
  val borderColor =
    if (isActive) extra.paneActiveBorder else MaterialTheme.colorScheme.outlineVariant

  val displayItems =
    remember(pane.items, pane.viewMode) {
      when (pane.viewMode) {
        FolderViewMode.NORMAL -> pane.items
        FolderViewMode.GALLERY ->
          pane.items.filter { it.isDirectory || it.category == FileCategory.IMAGE || it.category == FileCategory.VIDEO }
        FolderViewMode.MUSIC ->
          pane.items.filter { it.isDirectory || it.category == FileCategory.AUDIO }
        FolderViewMode.VIDEO ->
          pane.items.filter { it.isDirectory || it.category == FileCategory.VIDEO }
        FolderViewMode.CODE_DOCS ->
          pane.items.filter {
            it.isDirectory ||
              it.category in setOf(
                FileCategory.CODE,
                FileCategory.PDF,
                FileCategory.DOCUMENT,
                FileCategory.WORD,
                FileCategory.EXCEL,
                FileCategory.POWERPOINT,
                FileCategory.DATABASE,
              )
          }
      }
    }

  Surface(
    modifier = modifier.clickable(onClick = onActivate),
    shape = MaterialTheme.shapes.medium,
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = if (isActive) 3.dp else 0.dp,
    border = BorderStroke(if (isActive) 1.5.dp else 1.dp, borderColor),
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // Tab strip
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        pane.tabs.forEachIndexed { idx, tab ->
          val tabSelected = idx == pane.activeTabIndex
          Surface(
            shape = MaterialTheme.shapes.small,
            color =
              if (tabSelected) MaterialTheme.colorScheme.primaryContainer
              else MaterialTheme.colorScheme.surfaceContainer,
            modifier =
              Modifier
                .clickable {
                  onActivate()
                  onSwitchTab(idx)
                }
                .testTag("pane_${pane.id.name.lowercase()}_tab_$idx"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              Text(
                text = tab.title,
                style = MaterialTheme.typography.labelMedium,
                color =
                  if (tabSelected) MaterialTheme.colorScheme.primary
                  else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              if (pane.tabs.size > 1) {
                Icon(
                  imageVector = Icons.Default.Close,
                  contentDescription = strings.close,
                  tint = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier =
                    Modifier
                      .size(14.dp)
                      .clickable { onCloseTab(idx) },
                )
              }
            }
          }
        }
        IconButton(
          onClick = {
            onActivate()
            onAddTab()
          },
          modifier =
            Modifier
              .size(28.dp)
              .testTag("pane_${pane.id.name.lowercase()}_add_tab"),
        ) {
          Icon(
            imageVector = Icons.Default.Add,
            contentDescription = "New tab",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(16.dp),
          )
        }
      }

      // Path Breadcrumb Bar + Controls
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(
          onClick = {
            onActivate()
            onNavigateUp()
          },
          modifier = Modifier.size(40.dp).testTag("pane_${pane.id.name.lowercase()}_up"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Up",
            tint = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(18.dp),
          )
        }

        Row(
          modifier =
            Modifier
              .weight(1f)
              .horizontalScroll(rememberScrollState()),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = pane.currentPath,
            style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
            color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
          )
        }

        IconButton(
          onClick = onToggleBookmark,
          modifier = Modifier.size(36.dp).testTag("pane_${pane.id.name.lowercase()}_bookmark"),
        ) {
          Icon(
            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
            contentDescription = strings.bookmarks,
            tint = if (isBookmarked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
          )
        }

        IconButton(
          onClick = onRefresh,
          modifier = Modifier.size(36.dp).testTag("pane_${pane.id.name.lowercase()}_refresh"),
        ) {
          Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = "Refresh",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
          )
        }
      }

      // Quick Storage Jumps
      if (showQuickJumps) {
        Row(
          modifier =
            Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState())
              .padding(horizontal = 8.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          QuickJumpChip(strings.storageInternal, Icons.Default.Storage, onQuickJumpInternal)
          QuickJumpChip(strings.downloads, Icons.Default.Folder, onQuickJumpDownloads)
          QuickJumpChip(strings.storageAppSpace, Icons.Default.Home, onQuickJumpWorkspace)
          QuickJumpChip(strings.storageAndroidData, Icons.Default.Android, onQuickJumpAndroidData)
          QuickJumpChip(strings.storageRoot, Icons.Default.LockOpen, onQuickJumpRoot)
        }
      }

      // Folder View / Player Mode Bar (Normal / Gallery / Music / Video / Code & Docs)
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        ViewModeChip(
          selected = pane.viewMode == FolderViewMode.NORMAL,
          label = strings.viewModeNormal,
          icon = Icons.AutoMirrored.Filled.ViewList,
          testTag = "view_mode_normal_${pane.id.name.lowercase()}",
          onClick = { onChangeViewMode(FolderViewMode.NORMAL) },
        )
        ViewModeChip(
          selected = pane.viewMode == FolderViewMode.GALLERY,
          label = strings.viewModeGallery,
          icon = Icons.Default.PhotoLibrary,
          testTag = "view_mode_gallery_${pane.id.name.lowercase()}",
          onClick = { onChangeViewMode(FolderViewMode.GALLERY) },
        )
        ViewModeChip(
          selected = pane.viewMode == FolderViewMode.MUSIC,
          label = strings.viewModeMusic,
          icon = Icons.Default.MusicNote,
          testTag = "view_mode_music_${pane.id.name.lowercase()}",
          onClick = { onChangeViewMode(FolderViewMode.MUSIC) },
        )
        ViewModeChip(
          selected = pane.viewMode == FolderViewMode.VIDEO,
          label = strings.viewModeVideo,
          icon = Icons.Default.VideoLibrary,
          testTag = "view_mode_video_${pane.id.name.lowercase()}",
          onClick = { onChangeViewMode(FolderViewMode.VIDEO) },
        )
        ViewModeChip(
          selected = pane.viewMode == FolderViewMode.CODE_DOCS,
          label = strings.viewModeCodeDocs,
          icon = Icons.Default.Code,
          testTag = "view_mode_code_${pane.id.name.lowercase()}",
          onClick = { onChangeViewMode(FolderViewMode.CODE_DOCS) },
        )
      }

      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

      if (!hasAllFilesAccess && pane.currentPath.startsWith("/storage/emulated/0")) {
        Surface(
          color = MaterialTheme.colorScheme.secondaryContainer,
          modifier = Modifier.fillMaxWidth().padding(8.dp),
          shape = MaterialTheme.shapes.small,
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = strings.permissionNeededTitle,
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
            Text(
              text = strings.permissionNeededBody,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = onGrantAllFiles,
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.testTag("grant_all_files_btn"),
              ) {
                Text(strings.grantAllFilesAccess, style = MaterialTheme.typography.labelLarge)
              }
              OutlinedButton(
                onClick = onOpenSystemGateway,
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
              ) {
                Text(strings.openSystemGateway, style = MaterialTheme.typography.labelLarge)
              }
            }
          }
        }
      }

      // Music Mode Folder Launch Banner + Auto-Discovered Audio Collections
      if (pane.viewMode == FolderViewMode.MUSIC) {
        val audioTracks = remember(displayItems) { displayItems.filter { !it.isDirectory && it.category == FileCategory.AUDIO } }
        if (audioTracks.isNotEmpty()) {
          Surface(
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            shape = MaterialTheme.shapes.small,
            modifier =
              Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp)
                .clickable { onOpenFolderInMusicHub(audioTracks.first().path) },
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Column {
                  Text(strings.playFolder, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                  Text(strings.itemsCount(audioTracks.size), style = MaterialTheme.typography.labelSmall)
                }
              }
              Icon(Icons.Default.PlayArrow, contentDescription = strings.playFolder, tint = MaterialTheme.colorScheme.primary)
            }
          }
        }
        if (discoveredBuckets.isNotEmpty()) {
          DiscoveredMediaBucketsStrip(
            buckets = discoveredBuckets,
            title = strings.discoveredMediaTitle,
            onBucketClick = { bucket ->
              val firstTrack = bucket.items.firstOrNull()
              if (firstTrack != null) onOpenFolderInMusicHub(firstTrack.path)
              else onNavigate(bucket.folderPath)
            },
          )
        }
      }

      // File List / Gallery Grid
      Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
        when {
          pane.isLoading -> {
            CircularProgressIndicator(
              modifier = Modifier.align(Alignment.Center).size(32.dp),
              color = MaterialTheme.colorScheme.primary,
            )
          }

          displayItems.isEmpty() && !(pane.viewMode in setOf(FolderViewMode.GALLERY, FolderViewMode.VIDEO) && discoveredBuckets.isNotEmpty()) -> {
            Column(
              modifier = Modifier.fillMaxSize().padding(16.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center,
            ) {
              Image(
                painter = painterResource(id = R.drawable.img_empty_vault),
                contentDescription = strings.emptyFolderTitle,
                contentScale = ContentScale.Crop,
                modifier =
                  Modifier
                    .size(if (compactMode) 88.dp else 130.dp)
                    .clip(MaterialTheme.shapes.medium),
              )
              Spacer(Modifier.height(10.dp))
              Text(
                text = strings.emptyFolderTitle,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Spacer(Modifier.height(4.dp))
              Text(
                text = strings.emptyFolderHint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }

          pane.viewMode == FolderViewMode.GALLERY || pane.viewMode == FolderViewMode.VIDEO -> {
            GalleryGridContent(
              items = displayItems,
              selectedPaths = pane.selectedPaths,
              compact = compactMode,
              thumbnailLoader = thumbnailLoader,
              discoveredBuckets = discoveredBuckets,
              onNavigateBucket = onNavigate,
              onItemClick = onItemClick,
              onItemLongClick = onItemLongClick,
              onItemMoreClick = onItemMoreClick,
            )
          }

          else -> {
            DragSelectableFileList(
              items = displayItems,
              selectedPaths = pane.selectedPaths,
              compactMode = compactMode,
              longFilenameMode = longFilenameMode,
              thumbnailLoader = thumbnailLoader,
              onItemClick = onItemClick,
              onItemLongClick = onItemLongClick,
              onItemMoreClick = onItemMoreClick,
              onSelectRange = onSelectRange,
            )
          }
        }
      }

      // Pane Footer
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text =
            if (pane.selectedPaths.isNotEmpty()) strings.selectedCount(pane.selectedPaths.size)
            else strings.itemsCount(displayItems.size),
          style = MaterialTheme.typography.labelSmall,
          color =
            if (pane.selectedPaths.isNotEmpty()) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (!compactMode && pane.selectedPaths.isEmpty()) {
          Text(
            text = strings.dragSelectHint,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
          )
        }
        Text(
          text = strings.paneLabel(pane.id.index + 1),
          style = MaterialTheme.typography.labelSmall,
          color =
            if (isActive) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant,
          fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
        )
      }
    }
  }
}

@Composable
private fun DragSelectableFileList(
  items: List<VirtualFileNode>,
  selectedPaths: Set<String>,
  compactMode: Boolean,
  longFilenameMode: LongFilenameMode,
  thumbnailLoader: MediaThumbnailLoader?,
  onItemClick: (VirtualFileNode) -> Unit,
  onItemLongClick: (VirtualFileNode) -> Unit,
  onItemMoreClick: (VirtualFileNode) -> Unit,
  onSelectRange: (Set<String>) -> Unit,
) {
  val listState = rememberLazyListState()
  val scope = rememberCoroutineScope()
  val haptic = LocalHapticFeedback.current

  val currentItems by rememberUpdatedState(items)
  val currentSelected by rememberUpdatedState(selectedPaths)
  var anchorIdx by remember { mutableIntStateOf(-1) }
  var lastHoveredIdx by remember { mutableIntStateOf(-1) }
  var pointerViewportY by remember { mutableFloatStateOf(0f) }
  var preDragSelection by remember { mutableStateOf<Set<String>>(emptySet()) }

  LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
    itemsIndexed(items, key = { _, node -> node.path }) { idx, node ->
      val selected = node.path in selectedPaths
      FileRowItem(
        node = node,
        selected = selected,
        compact = compactMode,
        longFilenameMode = longFilenameMode,
        thumbnailLoader = thumbnailLoader,
        onClick = { onItemClick(node) },
        onLongClick = { onItemLongClick(node) },
        onMoreClick = { onItemMoreClick(node) },
        thumbnailModifier =
          Modifier
            .clickable { onItemLongClick(node) }
            .pointerInput(node.path) {
              detectDragGesturesAfterLongPress(
                onDragStart = {
                  haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                  anchorIdx = idx
                  lastHoveredIdx = idx
                  preDragSelection = currentSelected
                  val itemInfo = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == idx }
                  pointerViewportY = itemInfo?.let { it.offset + it.size / 2f } ?: 0f
                  val initialPath = currentItems.getOrNull(idx)?.path
                  if (initialPath != null) {
                    onSelectRange(preDragSelection + initialPath)
                  }
                },
                onDrag = { change, dragAmount ->
                  change.consume()
                  if (anchorIdx < 0) return@detectDragGesturesAfterLongPress
                  pointerViewportY += dragAmount.y

                  val layout = listState.layoutInfo
                  val visible = layout.visibleItemsInfo
                  if (visible.isNotEmpty()) {
                    val viewportEnd = layout.viewportEndOffset.toFloat()
                    if (pointerViewportY < 48f) {
                      scope.launch { listState.scrollBy(-22f) }
                    } else if (pointerViewportY > viewportEnd - 48f) {
                      scope.launch { listState.scrollBy(22f) }
                    }

                    val targetInfo =
                      visible.firstOrNull { pointerViewportY >= it.offset && pointerViewportY <= it.offset + it.size }
                        ?: if (pointerViewportY < visible.first().offset) visible.first() else visible.last()

                    val targetIdx = targetInfo.index.coerceIn(0, currentItems.lastIndex)
                    if (targetIdx != lastHoveredIdx) {
                      lastHoveredIdx = targetIdx
                      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                    val start = minOf(anchorIdx, targetIdx).coerceIn(0, currentItems.lastIndex)
                    val end = maxOf(anchorIdx, targetIdx).coerceIn(0, currentItems.lastIndex)
                    val rangeSet = (start..end).map { currentItems[it].path }.toSet()
                    onSelectRange(preDragSelection + rangeSet)
                  }
                },
                onDragEnd = {
                  anchorIdx = -1
                  lastHoveredIdx = -1
                },
                onDragCancel = {
                  anchorIdx = -1
                  lastHoveredIdx = -1
                },
              )
            },
      )
      HorizontalDivider(
        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
        thickness = 0.5.dp,
      )
    }
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GalleryGridContent(
  items: List<VirtualFileNode>,
  selectedPaths: Set<String>,
  compact: Boolean,
  thumbnailLoader: MediaThumbnailLoader?,
  discoveredBuckets: List<MediaBucketSummary> = emptyList(),
  onNavigateBucket: (String) -> Unit = {},
  onItemClick: (VirtualFileNode) -> Unit,
  onItemLongClick: (VirtualFileNode) -> Unit,
  onItemMoreClick: (VirtualFileNode) -> Unit,
) {
  val context = LocalContext.current
  val strings = LocalAppStrings.current
  val dirs = remember(items) { items.filter { it.isDirectory } }
  val media = remember(items) { items.filter { !it.isDirectory } }

  LazyVerticalGrid(
    columns = GridCells.Adaptive(minSize = if (compact) 84.dp else 108.dp),
    contentPadding = PaddingValues(8.dp),
    horizontalArrangement = Arrangement.spacedBy(6.dp),
    verticalArrangement = Arrangement.spacedBy(6.dp),
    modifier = Modifier.fillMaxSize(),
  ) {
    if (discoveredBuckets.isNotEmpty()) {
      item(span = { GridItemSpan(maxLineSpan) }) {
        DiscoveredMediaBucketsStrip(
          buckets = discoveredBuckets,
          title = strings.discoveredMediaTitle,
          onBucketClick = { onNavigateBucket(it.folderPath) },
        )
      }
    }

    if (dirs.isNotEmpty()) {
      item(span = { GridItemSpan(maxLineSpan) }) {
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          dirs.forEach { dir ->
            FilterChip(
              selected = dir.path in selectedPaths,
              onClick = { onItemClick(dir) },
              leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(16.dp)) },
              label = { Text(dir.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            )
          }
        }
      }
    }

    items(media, key = { it.path }) { node ->
      val isSelected = node.path in selectedPaths
      val accent = accentColorForNode(node)
      val ext = node.extension.uppercase(Locale.US).take(4)
      var videoFrame by remember(node.path, node.lastModified) { mutableStateOf<Bitmap?>(null) }

      LaunchedEffect(node.path, node.lastModified, thumbnailLoader) {
        if (thumbnailLoader != null && node.category == FileCategory.VIDEO && node.sourceType == FileSourceType.LOCAL) {
          videoFrame = thumbnailLoader.loadVideoFrame(node.path, node.lastModified, targetPx = 240)
        } else {
          videoFrame = null
        }
      }

      Box(
        modifier =
          Modifier
            .aspectRatio(1f)
            .clip(MaterialTheme.shapes.small)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .then(
              if (isSelected) Modifier.border(2.5.dp, MaterialTheme.colorScheme.primary, MaterialTheme.shapes.small)
              else Modifier
            )
            .combinedClickable(
              onClick = { onItemClick(node) },
              onLongClick = { onItemLongClick(node) },
            ),
      ) {
        when {
          node.category == FileCategory.IMAGE && node.sourceType == FileSourceType.LOCAL -> {
            AsyncImage(
              model = ImageRequest.Builder(context).data(File(node.path)).size(240).crossfade(true).build(),
              contentDescription = node.name,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          }
          node.category == FileCategory.VIDEO && videoFrame != null -> {
            Image(
              bitmap = videoFrame!!.asImageBitmap(),
              contentDescription = node.name,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
            Icon(
              Icons.Default.PlayArrow,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.align(Alignment.Center).size(28.dp).background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(50)),
            )
          }
          else -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
              FormatGlyphIcon(node, accent, 32.dp)
            }
          }
        }

        if (isSelected) {
          Icon(
            Icons.Default.CheckCircle,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.align(Alignment.TopStart).padding(4.dp).size(20.dp),
          )
        }

        IconButton(
          onClick = { onItemMoreClick(node) },
          modifier = Modifier.align(Alignment.TopEnd).size(26.dp),
        ) {
          Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = Color.White, modifier = Modifier.size(16.dp))
        }

        Row(
          modifier =
            Modifier
              .align(Alignment.BottomCenter)
              .fillMaxWidth()
              .background(Color.Black.copy(alpha = 0.55f))
              .padding(horizontal = 5.dp, vertical = 2.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(node.name, color = Color.White, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
          FormatCornerBadge(ext, accent)
        }
      }
    }
  }
}

@Composable
private fun DiscoveredMediaBucketsStrip(
  buckets: List<MediaBucketSummary>,
  title: String,
  onBucketClick: (MediaBucketSummary) -> Unit,
) {
  val context = LocalContext.current
  Column(
    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
    verticalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.labelMedium,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.primary,
      modifier = Modifier.padding(horizontal = 4.dp),
    )
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      buckets.take(12).forEach { bucket ->
        val firstItem = bucket.items.firstOrNull()
        Surface(
          shape = MaterialTheme.shapes.small,
          color = MaterialTheme.colorScheme.surfaceContainerHigh,
          tonalElevation = 2.dp,
          modifier = Modifier
            .width(124.dp)
            .clickable { onBucketClick(bucket) },
        ) {
          Column {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .background(MaterialTheme.colorScheme.surfaceContainerHighest),
              contentAlignment = Alignment.Center,
            ) {
              if (firstItem != null && firstItem.category == FileCategory.IMAGE && firstItem.sourceType == FileSourceType.LOCAL) {
                AsyncImage(
                  model = ImageRequest.Builder(context).data(File(firstItem.path)).size(160).crossfade(true).build(),
                  contentDescription = bucket.bucketName,
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.fillMaxSize(),
                )
              } else {
                Icon(
                  imageVector = when (firstItem?.category) {
                    FileCategory.VIDEO -> Icons.Default.VideoLibrary
                    FileCategory.AUDIO -> Icons.Default.MusicNote
                    else -> Icons.Default.PhotoLibrary
                  },
                  contentDescription = bucket.bucketName,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(28.dp),
                )
              }
            }
            Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
              Text(
                text = bucket.bucketName,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = "${bucket.items.size}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ViewModeChip(
  selected: Boolean,
  label: String,
  icon: ImageVector,
  testTag: String,
  onClick: () -> Unit,
) {
  Surface(
    shape = RoundedCornerShape(50),
    color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer,
    modifier = Modifier.clickable(onClick = onClick).testTag(testTag),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(14.dp),
      )
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        maxLines = 1,
      )
    }
  }
}

@Composable
private fun QuickJumpChip(label: String, icon: ImageVector, onClick: () -> Unit) {
  Surface(
    shape = MaterialTheme.shapes.small,
    color = MaterialTheme.colorScheme.surfaceContainerHigh,
    modifier = Modifier.clickable(onClick = onClick),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(14.dp),
      )
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
      )
    }
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRowItem(
  node: VirtualFileNode,
  selected: Boolean,
  compact: Boolean,
  longFilenameMode: LongFilenameMode,
  thumbnailLoader: MediaThumbnailLoader?,
  onClick: () -> Unit,
  onLongClick: () -> Unit,
  onMoreClick: () -> Unit,
  thumbnailModifier: Modifier = Modifier,
) {
  val bg =
    if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    else Color.Transparent

  Row(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(bg)
        .combinedClickable(onClick = onClick, onLongClick = onLongClick)
        .padding(
          horizontal = if (compact) 6.dp else 10.dp,
          vertical = if (compact) 7.dp else 9.dp,
        )
        .testTag("file_row_${node.name}"),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    SmartFormatThumbnail(
      node = node,
      selected = selected,
      compact = compact,
      thumbnailLoader = thumbnailLoader,
      modifier = thumbnailModifier,
    )

    Spacer(Modifier.width(if (compact) 8.dp else 10.dp))

    Column(modifier = Modifier.weight(1f)) {
      val displayTitle =
        if (longFilenameMode == LongFilenameMode.MIDDLE_ELLIPSIS) {
          formatMiddleEllipsisFilename(node.name, maxChars = if (compact) 22 else 34)
        } else {
          node.name
        }
      Text(
        text = displayTitle,
        style = if (compact) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = if (longFilenameMode == LongFilenameMode.MULTI_LINE) 3 else 1,
        softWrap = longFilenameMode == LongFilenameMode.MULTI_LINE,
        overflow = TextOverflow.Ellipsis,
      )
      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = if (node.isDirectory) "DIR" else formatFileSize(node.size),
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
          text = node.permissions,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
        )
        if (!compact && node.lastModified > 0L) {
          Text(
            text = formatShortDate(node.lastModified),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
          )
        }
      }
    }

    IconButton(
      onClick = onMoreClick,
      modifier = Modifier.size(36.dp),
    ) {
      Icon(
        imageVector = if (selected) Icons.Default.CheckCircle else Icons.Default.MoreVert,
        contentDescription = "Options",
        tint =
          if (selected) MaterialTheme.colorScheme.primary
          else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(18.dp),
      )
    }
  }
}

@Composable
private fun SmartFormatThumbnail(
  node: VirtualFileNode,
  selected: Boolean,
  compact: Boolean,
  thumbnailLoader: MediaThumbnailLoader?,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val boxSize = if (compact) 36.dp else 44.dp
  val tint = accentColorForNode(node)
  val extBadge = node.extension.uppercase(Locale.US).take(4)

  val canExtractLocalMedia =
    node.sourceType == FileSourceType.LOCAL &&
      !node.isDirectory &&
      node.path.startsWith("/")

  var embeddedThumb by remember(node.path, node.lastModified) { mutableStateOf<Bitmap?>(null) }

  LaunchedEffect(node.path, node.lastModified, thumbnailLoader) {
    if (thumbnailLoader != null && canExtractLocalMedia) {
      embeddedThumb =
        when (node.category) {
          FileCategory.AUDIO -> thumbnailLoader.loadAudioAlbumArt(node.path, node.lastModified, targetPx = 144)
          FileCategory.VIDEO -> thumbnailLoader.loadVideoFrame(node.path, node.lastModified, targetPx = 144)
          FileCategory.APK -> thumbnailLoader.loadApkAppIcon(context, node.path, node.lastModified, targetPx = 144)
          else -> null
        }
    } else {
      embeddedThumb = null
    }
  }

  Box(
    modifier =
      modifier
        .size(boxSize)
        .clip(RoundedCornerShape(10.dp))
        .background(tint.copy(alpha = 0.16f)),
    contentAlignment = Alignment.Center,
  ) {
    when {
      selected -> {
        Box(
          modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = node.name,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp),
          )
        }
      }

      node.category == FileCategory.IMAGE && canExtractLocalMedia -> {
        AsyncImage(
          model =
            ImageRequest.Builder(context)
              .data(File(node.path))
              .size(144)
              .crossfade(true)
              .build(),
          contentDescription = node.name,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
        FormatCornerBadge(extBadge, tint, Modifier.align(Alignment.BottomEnd))
      }

      node.category == FileCategory.APK && embeddedThumb != null -> {
        Image(
          bitmap = embeddedThumb!!.asImageBitmap(),
          contentDescription = node.name,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
        FormatCornerBadge(if (extBadge.isNotBlank()) extBadge else "APK", tint, Modifier.align(Alignment.BottomEnd))
      }

      (node.category == FileCategory.AUDIO || node.category == FileCategory.VIDEO) && embeddedThumb != null -> {
        Image(
          bitmap = embeddedThumb!!.asImageBitmap(),
          contentDescription = node.name,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
        if (node.category == FileCategory.VIDEO) {
          Surface(
            color = Color.Black.copy(alpha = 0.45f),
            shape = RoundedCornerShape(50),
            modifier = Modifier.size(18.dp),
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.padding(2.dp))
          }
        }
        FormatCornerBadge(extBadge, tint, Modifier.align(Alignment.BottomEnd))
      }

      else -> {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center,
          modifier = Modifier.padding(2.dp),
        ) {
          FormatGlyphIcon(
            node = node,
            tint = tint,
            iconSize = if (compact) 18.dp else 22.dp,
          )
          if (extBadge.isNotEmpty() && !node.isDirectory) {
            Surface(
              color = tint.copy(alpha = 0.88f),
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier.padding(top = 1.dp),
            ) {
              Text(
                text = extBadge,
                color = Color.White,
                fontSize = 7.sp,
                lineHeight = 8.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = MonoFontFamily,
                maxLines = 1,
                modifier = Modifier.padding(horizontal = 3.dp, vertical = 0.5.dp),
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun FormatCornerBadge(ext: String, color: Color, modifier: Modifier = Modifier) {
  if (ext.isEmpty()) return
  Surface(
    color = color.copy(alpha = 0.9f),
    shape = RoundedCornerShape(topStart = 5.dp),
    modifier = modifier,
  ) {
    Text(
      text = ext,
      color = Color.White,
      fontSize = 7.sp,
      lineHeight = 8.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = MonoFontFamily,
      maxLines = 1,
      modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp),
    )
  }
}

private fun formatShortDate(millis: Long): String {
  return SimpleDateFormat("MM/dd HH:mm", Locale.US).format(Date(millis))
}
