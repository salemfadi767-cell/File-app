package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.fs.FileCategory
import com.example.domain.fs.VirtualFileNode
import com.example.ui.theme.LocalVortexExtraColors
import com.example.ui.theme.MonoFontFamily
import java.util.Locale

@Composable
fun accentColorForNode(node: VirtualFileNode): Color {
  val extra = LocalVortexExtraColors.current
  val ext = node.extension.lowercase(Locale.US)
  return when (node.category) {
    FileCategory.FOLDER -> MaterialTheme.colorScheme.secondary
    FileCategory.APK -> extra.losslessGreen
    FileCategory.ARCHIVE ->
      when (ext) {
        "7z" -> Color(0xFFF59E0B)
        "rar" -> Color(0xFFEC4899)
        "tar", "gz", "xz", "bz2", "tgz", "txz" -> Color(0xFF14B8A6)
        else -> Color(0xFFD97706)
      }
    FileCategory.CODE ->
      when (ext) {
        "py" -> Color(0xFF3776AB)
        "kt", "kts" -> Color(0xFF9333EA)
        "js", "jsx" -> Color(0xFFEAB308)
        "ts", "tsx" -> Color(0xFF2563EB)
        "html", "htm" -> Color(0xFFE34F26)
        "css" -> Color(0xFF264DE4)
        "json", "yaml", "yml" -> Color(0xFF06B6D4)
        "java" -> Color(0xFFEA580C)
        "c", "cpp", "h" -> Color(0xFF00599C)
        "sh", "bash" -> Color(0xFF22C55E)
        "sql" -> Color(0xFF0EA5E9)
        "xml", "svg" -> Color(0xFF10B981)
        "md" -> Color(0xFF6366F1)
        "rs" -> Color(0xFFF97316)
        "go" -> Color(0xFF00ADD8)
        else -> MaterialTheme.colorScheme.primary
      }
    FileCategory.IMAGE -> Color(0xFFF472B6)
    FileCategory.VIDEO -> Color(0xFFFB7185)
    FileCategory.AUDIO ->
      when (ext) {
        "flac", "wav" -> Color(0xFF8B5CF6)
        else -> Color(0xFFA78BFA)
      }
    FileCategory.PDF -> Color(0xFFEF4444)
    FileCategory.WORD -> Color(0xFF2563EB)
    FileCategory.EXCEL -> Color(0xFF16A34A)
    FileCategory.POWERPOINT -> Color(0xFFEA580C)
    FileCategory.TORRENT -> Color(0xFF10B981)
    FileCategory.VAULT -> Color(0xFFF59E0B)
    FileCategory.DATABASE -> Color(0xFF0284C7)
    FileCategory.DOCUMENT -> Color(0xFF4F46E5)
    else -> Color(0xFF64748B)
  }
}

@Composable
fun FormatGlyphIcon(
  node: VirtualFileNode,
  tint: Color,
  iconSize: Dp,
) {
  val ext = node.extension.lowercase(Locale.US)
  when {
    node.isDirectory -> {
      Icon(Icons.Default.Folder, contentDescription = node.name, tint = tint, modifier = Modifier.size(iconSize))
    }

    ext == "py" -> PythonLogoGlyph(iconSize)
    ext == "kt" || ext == "kts" -> KotlinLogoGlyph(iconSize)
    ext == "js" || ext == "jsx" -> MonogramSquareGlyph("JS", Color(0xFFF7DF1E), Color(0xFF111827), iconSize)
    ext == "ts" || ext == "tsx" -> MonogramSquareGlyph("TS", Color(0xFF3178C6), Color.White, iconSize)
    ext == "html" || ext == "htm" -> ShieldBadgeGlyph("H5", Color(0xFFE34F26), iconSize)
    ext == "css" -> ShieldBadgeGlyph("C3", Color(0xFF264DE4), iconSize)
    ext == "json" || ext == "yaml" || ext == "yml" -> CurlyBracesGlyph(tint, iconSize)
    ext == "java" -> JavaCupGlyph(iconSize)
    ext == "c" || ext == "cpp" || ext == "h" -> HexagonBadgeGlyph(if (ext == "cpp") "C+" else ext.uppercase(Locale.US), Color(0xFF00599C), iconSize)
    ext == "sh" || ext == "bash" -> TerminalPromptGlyph(iconSize)
    ext == "sql" || node.category == FileCategory.DATABASE -> DatabaseCylinderGlyph(tint, iconSize)
    ext == "xml" || ext == "svg" -> XmlTagGlyph(tint, iconSize)
    ext == "md" -> MonogramSquareGlyph("M↓", Color(0xFF334155), Color.White, iconSize)
    ext == "rs" -> MonogramSquareGlyph("RS", Color(0xFFEA580C), Color.White, iconSize)
    ext == "go" -> MonogramSquareGlyph("GO", Color(0xFF00ADD8), Color.White, iconSize)
    node.category == FileCategory.ARCHIVE -> ZipperCrateGlyph(tint, iconSize)
    node.category == FileCategory.PDF -> PdfDocumentGlyph(tint, iconSize)
    node.category == FileCategory.WORD -> MonogramSquareGlyph("W", Color(0xFF2563EB), Color.White, iconSize)
    node.category == FileCategory.EXCEL -> MonogramSquareGlyph("X", Color(0xFF16A34A), Color.White, iconSize)
    node.category == FileCategory.POWERPOINT -> MonogramSquareGlyph("P", Color(0xFFEA580C), Color.White, iconSize)
    node.category == FileCategory.TORRENT -> MonogramSquareGlyph("BT", Color(0xFF059669), Color.White, iconSize)
    node.category == FileCategory.VAULT -> MonogramSquareGlyph("🔒", Color(0xFFB45309), Color.White, iconSize)
    node.category == FileCategory.DOCUMENT -> WordDocGlyph(tint, iconSize)
    node.category == FileCategory.APK -> Icon(Icons.Default.Android, contentDescription = node.name, tint = tint, modifier = Modifier.size(iconSize))
    node.category == FileCategory.AUDIO ->
      Icon(
        imageVector = if (ext in setOf("flac", "wav")) Icons.Default.MusicNote else Icons.Default.AudioFile,
        contentDescription = node.name,
        tint = tint,
        modifier = Modifier.size(iconSize),
      )
    node.category == FileCategory.VIDEO -> Icon(Icons.Default.VideoFile, contentDescription = node.name, tint = tint, modifier = Modifier.size(iconSize))
    node.category == FileCategory.IMAGE -> Icon(Icons.Default.Image, contentDescription = node.name, tint = tint, modifier = Modifier.size(iconSize))
    else -> Icon(Icons.AutoMirrored.Filled.InsertDriveFile, contentDescription = node.name, tint = tint, modifier = Modifier.size(iconSize))
  }
}

@Composable
private fun PythonLogoGlyph(iconSize: Dp) {
  Canvas(modifier = Modifier.size(iconSize)) {
    val w = size.width
    val h = size.height
    val blue = Color(0xFF3776AB)
    val yellow = Color(0xFFFFD43B)

    // Top-left blue snake head/body
    drawRoundRect(
      color = blue,
      topLeft = Offset(w * 0.24f, h * 0.08f),
      size = Size(w * 0.50f, h * 0.36f),
      cornerRadius = CornerRadius(w * 0.14f, w * 0.14f),
    )
    drawRoundRect(
      color = blue,
      topLeft = Offset(w * 0.10f, h * 0.28f),
      size = Size(w * 0.42f, h * 0.28f),
      cornerRadius = CornerRadius(w * 0.12f, w * 0.12f),
    )
    // Bottom-right yellow snake head/body
    drawRoundRect(
      color = yellow,
      topLeft = Offset(w * 0.26f, h * 0.56f),
      size = Size(w * 0.50f, h * 0.36f),
      cornerRadius = CornerRadius(w * 0.14f, w * 0.14f),
    )
    drawRoundRect(
      color = yellow,
      topLeft = Offset(w * 0.48f, h * 0.44f),
      size = Size(w * 0.42f, h * 0.28f),
      cornerRadius = CornerRadius(w * 0.12f, w * 0.12f),
    )
    // Snake eyes
    drawCircle(Color.White, radius = w * 0.045f, center = Offset(w * 0.36f, h * 0.19f))
    drawCircle(Color(0xFF1F2937), radius = w * 0.045f, center = Offset(w * 0.64f, h * 0.81f))
  }
}

@Composable
private fun KotlinLogoGlyph(iconSize: Dp) {
  Canvas(modifier = Modifier.size(iconSize)) {
    val w = size.width
    val h = size.height
    val path =
      Path().apply {
        moveTo(w * 0.14f, h * 0.14f)
        lineTo(w * 0.86f, h * 0.14f)
        lineTo(w * 0.50f, h * 0.50f)
        lineTo(w * 0.86f, h * 0.86f)
        lineTo(w * 0.14f, h * 0.86f)
        close()
      }
    drawPath(
      path = path,
      brush = Brush.linearGradient(
        colors = listOf(Color(0xFF7F52FF), Color(0xFFC711E1), Color(0xFFE44857)),
      ),
    )
  }
}

@Composable
private fun MonogramSquareGlyph(label: String, bg: Color, fg: Color, iconSize: Dp) {
  Surface(
    color = bg,
    shape = androidx.compose.foundation.shape.RoundedCornerShape(5.dp),
    modifier = Modifier.size(iconSize),
  ) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
      Text(
        text = label,
        color = fg,
        fontSize = (iconSize.value * 0.45f).sp,
        fontWeight = FontWeight.ExtraBold,
        fontFamily = MonoFontFamily,
        maxLines = 1,
      )
    }
  }
}

@Composable
private fun ShieldBadgeGlyph(label: String, color: Color, iconSize: Dp) {
  Box(modifier = Modifier.size(iconSize), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      val shield =
        Path().apply {
          moveTo(w * 0.14f, h * 0.10f)
          lineTo(w * 0.86f, h * 0.10f)
          lineTo(w * 0.78f, h * 0.78f)
          lineTo(w * 0.50f, h * 0.92f)
          lineTo(w * 0.22f, h * 0.78f)
          close()
        }
      drawPath(shield, color = color)
    }
    Text(
      text = label,
      color = Color.White,
      fontSize = (iconSize.value * 0.36f).sp,
      fontWeight = FontWeight.ExtraBold,
      fontFamily = MonoFontFamily,
    )
  }
}

@Composable
private fun HexagonBadgeGlyph(label: String, color: Color, iconSize: Dp) {
  Box(modifier = Modifier.size(iconSize), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      val hex =
        Path().apply {
          moveTo(w * 0.50f, h * 0.06f)
          lineTo(w * 0.88f, h * 0.28f)
          lineTo(w * 0.88f, h * 0.72f)
          lineTo(w * 0.50f, h * 0.94f)
          lineTo(w * 0.12f, h * 0.72f)
          lineTo(w * 0.12f, h * 0.28f)
          close()
        }
      drawPath(hex, color = color)
    }
    Text(
      text = label,
      color = Color.White,
      fontSize = (iconSize.value * 0.34f).sp,
      fontWeight = FontWeight.ExtraBold,
      fontFamily = MonoFontFamily,
    )
  }
}

@Composable
private fun CurlyBracesGlyph(color: Color, iconSize: Dp) {
  Box(modifier = Modifier.size(iconSize), contentAlignment = Alignment.Center) {
    Text(
      text = "{ }",
      color = color,
      fontSize = (iconSize.value * 0.58f).sp,
      fontWeight = FontWeight.ExtraBold,
      fontFamily = MonoFontFamily,
    )
  }
}

@Composable
private fun JavaCupGlyph(iconSize: Dp) {
  Canvas(modifier = Modifier.size(iconSize)) {
    val w = size.width
    val h = size.height
    val orange = Color(0xFFEA580C)
    val steam = Color(0xFF38BDF8)
    // Steam wisps
    drawLine(steam, Offset(w * 0.38f, h * 0.34f), Offset(w * 0.44f, h * 0.14f), strokeWidth = w * 0.08f, cap = StrokeCap.Round)
    drawLine(steam, Offset(w * 0.56f, h * 0.34f), Offset(w * 0.62f, h * 0.12f), strokeWidth = w * 0.08f, cap = StrokeCap.Round)
    // Cup
    drawRoundRect(
      color = orange,
      topLeft = Offset(w * 0.22f, h * 0.42f),
      size = Size(w * 0.48f, h * 0.36f),
      cornerRadius = CornerRadius(w * 0.08f, w * 0.08f),
    )
    // Handle
    drawArc(
      color = orange,
      startAngle = -90f,
      sweepAngle = 180f,
      useCenter = false,
      topLeft = Offset(w * 0.60f, h * 0.46f),
      size = Size(w * 0.22f, h * 0.24f),
      style = Stroke(width = w * 0.08f),
    )
    // Saucer
    drawLine(orange, Offset(w * 0.16f, h * 0.86f), Offset(w * 0.78f, h * 0.86f), strokeWidth = w * 0.08f, cap = StrokeCap.Round)
  }
}

@Composable
private fun TerminalPromptGlyph(iconSize: Dp) {
  Surface(
    color = Color(0xFF0F172A),
    shape = androidx.compose.foundation.shape.RoundedCornerShape(5.dp),
    modifier = Modifier.size(iconSize),
  ) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(1.dp)) {
      Text(
        text = ">_",
        color = Color(0xFF22C55E),
        fontSize = (iconSize.value * 0.46f).sp,
        fontWeight = FontWeight.ExtraBold,
        fontFamily = MonoFontFamily,
      )
    }
  }
}

@Composable
private fun DatabaseCylinderGlyph(color: Color, iconSize: Dp) {
  Canvas(modifier = Modifier.size(iconSize)) {
    val w = size.width
    val h = size.height
    val stroke = Stroke(width = w * 0.09f)
    drawOval(color = color.copy(alpha = 0.26f), topLeft = Offset(w * 0.16f, h * 0.12f), size = Size(w * 0.68f, h * 0.22f))
    drawOval(color = color, topLeft = Offset(w * 0.16f, h * 0.12f), size = Size(w * 0.68f, h * 0.22f), style = stroke)
    drawLine(color, Offset(w * 0.16f, h * 0.23f), Offset(w * 0.16f, h * 0.76f), strokeWidth = w * 0.09f)
    drawLine(color, Offset(w * 0.84f, h * 0.23f), Offset(w * 0.84f, h * 0.76f), strokeWidth = w * 0.09f)
    drawArc(color, 0f, 180f, false, Offset(w * 0.16f, h * 0.40f), Size(w * 0.68f, h * 0.20f), style = stroke)
    drawArc(color, 0f, 180f, false, Offset(w * 0.16f, h * 0.65f), Size(w * 0.68f, h * 0.22f), style = stroke)
  }
}

@Composable
private fun XmlTagGlyph(color: Color, iconSize: Dp) {
  Box(modifier = Modifier.size(iconSize), contentAlignment = Alignment.Center) {
    Text(
      text = "</>",
      color = color,
      fontSize = (iconSize.value * 0.44f).sp,
      fontWeight = FontWeight.ExtraBold,
      fontFamily = MonoFontFamily,
    )
  }
}

@Composable
private fun ZipperCrateGlyph(color: Color, iconSize: Dp) {
  Canvas(modifier = Modifier.size(iconSize)) {
    val w = size.width
    val h = size.height
    drawRoundRect(
      color = color.copy(alpha = 0.24f),
      topLeft = Offset(w * 0.14f, h * 0.12f),
      size = Size(w * 0.72f, h * 0.76f),
      cornerRadius = CornerRadius(w * 0.12f, w * 0.12f),
    )
    drawRoundRect(
      color = color,
      topLeft = Offset(w * 0.14f, h * 0.12f),
      size = Size(w * 0.72f, h * 0.76f),
      cornerRadius = CornerRadius(w * 0.12f, w * 0.12f),
      style = Stroke(width = w * 0.08f),
    )
    // Zipper teeth down the middle
    for (i in 0..3) {
      val y = h * (0.24f + i * 0.15f)
      val x = if (i % 2 == 0) w * 0.40f else w * 0.50f
      drawRect(color = color, topLeft = Offset(x, y), size = Size(w * 0.12f, h * 0.09f))
    }
  }
}

@Composable
private fun PdfDocumentGlyph(color: Color, iconSize: Dp) {
  Canvas(modifier = Modifier.size(iconSize)) {
    val w = size.width
    val h = size.height
    drawRoundRect(
      color = color,
      topLeft = Offset(w * 0.18f, h * 0.10f),
      size = Size(w * 0.64f, h * 0.80f),
      cornerRadius = CornerRadius(w * 0.10f, w * 0.10f),
    )
    // Ribbon loop inside PDF card
    val path =
      Path().apply {
        moveTo(w * 0.50f, h * 0.28f)
        lineTo(w * 0.34f, h * 0.68f)
        lineTo(w * 0.66f, h * 0.60f)
        close()
      }
    drawPath(path, color = Color.White, style = Stroke(width = w * 0.08f, cap = StrokeCap.Round))
  }
}

@Composable
private fun WordDocGlyph(color: Color, iconSize: Dp) {
  Canvas(modifier = Modifier.size(iconSize)) {
    val w = size.width
    val h = size.height
    drawRoundRect(
      color = color,
      topLeft = Offset(w * 0.18f, h * 0.10f),
      size = Size(w * 0.64f, h * 0.80f),
      cornerRadius = CornerRadius(w * 0.10f, w * 0.10f),
    )
    drawLine(Color.White, Offset(w * 0.30f, h * 0.34f), Offset(w * 0.70f, h * 0.34f), strokeWidth = w * 0.08f, cap = StrokeCap.Round)
    drawLine(Color.White, Offset(w * 0.30f, h * 0.52f), Offset(w * 0.70f, h * 0.52f), strokeWidth = w * 0.08f, cap = StrokeCap.Round)
    drawLine(Color.White, Offset(w * 0.30f, h * 0.70f), Offset(w * 0.56f, h * 0.70f), strokeWidth = w * 0.08f, cap = StrokeCap.Round)
  }
}
