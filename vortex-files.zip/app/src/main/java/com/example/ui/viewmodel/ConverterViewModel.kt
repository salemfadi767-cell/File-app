package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.VortexAppContainer
import com.example.data.db.TaskHistoryEntity
import com.example.domain.archive.ArchiveFormat
import com.example.domain.archive.ImageOutputFormat
import com.example.domain.converter.AudioTargetFormat
import com.example.domain.converter.ConversionCategory
import com.example.domain.converter.TextTargetFormat
import com.example.domain.fs.formatFileSize
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ConverterUiState(
  val category: ConversionCategory = ConversionCategory.VIDEO_TO_AUDIO,
  val sourceFiles: List<File> = emptyList(),
  val outputDir: String = "",
  val audioFormat: AudioTargetFormat = AudioTargetFormat.M4A_AAC,
  val imageFormat: ImageOutputFormat = ImageOutputFormat.WEBP_LOSSLESS,
  val imageQuality: Int = 85,
  val pdfA4Fixed: Boolean = true,
  val textFormat: TextTargetFormat = TextTargetFormat.JSON,
  val archiveFormat: ArchiveFormat = ArchiveFormat.ZIP,
  val archiveLevel: Int = 6,
  val isRunning: Boolean = false,
  val progress: Int = 0,
  val resultMessage: String? = null,
)

class ConverterViewModel(private val container: VortexAppContainer) : ViewModel() {

  private val _uiState =
    MutableStateFlow(
      ConverterUiState(outputDir = container.fileRepository.appWorkspaceDir().absolutePath)
    )
  val uiState: StateFlow<ConverterUiState> = _uiState.asStateFlow()

  val history =
    container.database
      .taskHistoryDao()
      .observeHistory()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  fun setInitialFiles(files: List<File>, outputDir: String? = null) {
    val first = files.firstOrNull()
    val inferred =
      when (first?.extension?.lowercase()) {
        "mp4", "mkv", "webm", "avi", "mov" -> ConversionCategory.VIDEO_TO_AUDIO
        "pdf" -> ConversionCategory.PDF_TO_IMAGES
        "png", "jpg", "jpeg", "webp", "bmp" ->
          if (files.size > 1) ConversionCategory.IMAGES_TO_PDF else ConversionCategory.IMAGE_TO_IMAGE
        "zip", "7z", "rar", "tar", "gz", "xz", "bz2" -> ConversionCategory.ARCHIVE_TO_ARCHIVE
        else -> ConversionCategory.TEXT_DATA
      }
    _uiState.update {
      it.copy(
        category = inferred,
        sourceFiles = files,
        outputDir = outputDir ?: first?.parent ?: it.outputDir,
        resultMessage = null,
      )
    }
  }

  fun setCategory(cat: ConversionCategory) {
    _uiState.update { it.copy(category = cat, resultMessage = null) }
  }

  fun setAudioFormat(fmt: AudioTargetFormat) {
    _uiState.update { it.copy(audioFormat = fmt) }
  }

  fun setImageFormat(fmt: ImageOutputFormat) {
    _uiState.update { it.copy(imageFormat = fmt) }
  }

  fun setImageQuality(q: Int) {
    _uiState.update { it.copy(imageQuality = q.coerceIn(10, 100)) }
  }

  fun setPdfA4Fixed(fixed: Boolean) {
    _uiState.update { it.copy(pdfA4Fixed = fixed) }
  }

  fun setTextFormat(fmt: TextTargetFormat) {
    _uiState.update { it.copy(textFormat = fmt) }
  }

  fun setArchiveFormat(fmt: ArchiveFormat) {
    _uiState.update { it.copy(archiveFormat = fmt) }
  }

  fun setArchiveLevel(lvl: Int) {
    _uiState.update { it.copy(archiveLevel = lvl.coerceIn(0, 9)) }
  }

  fun addFiles(files: List<File>) {
    _uiState.update { it.copy(sourceFiles = (it.sourceFiles + files).distinctBy { f -> f.absolutePath }) }
  }

  fun clearFiles() {
    _uiState.update { it.copy(sourceFiles = emptyList(), resultMessage = null) }
  }

  fun runConversion() {
    val st = _uiState.value
    if (st.sourceFiles.isEmpty() || st.isRunning) return
    val outDir = File(st.outputDir.ifBlank { container.fileRepository.appWorkspaceDir().absolutePath }).apply { mkdirs() }

    viewModelScope.launch {
      _uiState.update { it.copy(isRunning = true, progress = 0, resultMessage = null) }
      try {
        val outDescription: String =
          when (st.category) {
            ConversionCategory.VIDEO_TO_AUDIO -> {
              val src = st.sourceFiles.first()
              val out = File(outDir, "${src.nameWithoutExtension}_audio.${st.audioFormat.ext}")
              container.formatConverterEngine.convertVideoToAudio(src, out, st.audioFormat) { p ->
                _uiState.update { it.copy(progress = p) }
              }
              "${out.name} (${formatFileSize(out.length())})"
            }

            ConversionCategory.IMAGES_TO_PDF -> {
              val out = File(outDir, "${st.sourceFiles.first().nameWithoutExtension}_bundle.pdf")
              container.formatConverterEngine.imagesToPdf(st.sourceFiles, out, st.pdfA4Fixed) { p ->
                _uiState.update { it.copy(progress = p) }
              }
              "${out.name} (${formatFileSize(out.length())})"
            }

            ConversionCategory.PDF_TO_IMAGES -> {
              val src = st.sourceFiles.first()
              val targetDir = File(outDir, "${src.nameWithoutExtension}_pages")
              val imgs =
                container.formatConverterEngine.pdfToImages(src, targetDir, st.imageFormat, st.imageQuality) { p ->
                  _uiState.update { it.copy(progress = p) }
                }
              "${imgs.size} pages -> ${targetDir.name}"
            }

            ConversionCategory.IMAGE_TO_IMAGE -> {
              val imgs =
                container.formatConverterEngine.convertImages(
                  st.sourceFiles,
                  outDir,
                  st.imageFormat,
                  st.imageQuality,
                ) { p -> _uiState.update { it.copy(progress = p) } }
              "${imgs.size} converted (${st.imageFormat.label})"
            }

            ConversionCategory.TEXT_DATA -> {
              val src = st.sourceFiles.first()
              val out = File(outDir, "${src.nameWithoutExtension}_converted.${st.textFormat.ext}")
              container.formatConverterEngine.convertTextOrData(src, out, st.textFormat)
              "${out.name} (${formatFileSize(out.length())})"
            }

            ConversionCategory.ARCHIVE_TO_ARCHIVE -> {
              val src = st.sourceFiles.first()
              val out = File(outDir, "${src.nameWithoutExtension}_converted.${st.archiveFormat.extension}")
              container.formatConverterEngine.convertArchive(
                src,
                out,
                st.archiveFormat,
                st.archiveLevel,
                null,
              ) { p -> _uiState.update { it.copy(progress = p) } }
              "${out.name} (${formatFileSize(out.length())})"
            }
          }

        container.database.taskHistoryDao().insert(
          TaskHistoryEntity(
            title = st.category.name,
            category = "CONVERT",
            sourcePath = st.sourceFiles.first().name,
            outputPath = outDir.absolutePath,
            details = outDescription,
            success = true,
          )
        )
        _uiState.update { it.copy(isRunning = false, progress = 100, resultMessage = outDescription) }
      } catch (t: Throwable) {
        _uiState.update {
          it.copy(isRunning = false, resultMessage = "Error: ${t.message ?: "Conversion failed"}")
        }
      }
    }
  }
}
