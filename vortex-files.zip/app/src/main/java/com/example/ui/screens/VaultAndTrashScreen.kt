package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.VortexAppContainer
import com.example.data.db.TrashEntryEntity
import com.example.data.db.VaultEntryEntity
import com.example.data.prefs.UserPreferences
import com.example.domain.fs.formatFileSize
import com.example.i18n.LocalAppStrings
import java.io.File
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultAndTrashScreen(
  container: VortexAppContainer,
  onFilesChanged: () -> Unit,
  onBack: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val scope = rememberCoroutineScope()
  val snackbar = remember { SnackbarHostState() }

  val vaultEntries by container.database.vaultDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
  val trashEntries by container.database.trashDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
  val prefs by container.preferencesRepo.preferences.collectAsStateWithLifecycle(initialValue = UserPreferences())

  var selectedTab by remember { mutableIntStateOf(0) }
  var unlockTarget by remember { mutableStateOf<VaultEntryEntity?>(null) }
  var unlockSecret by remember { mutableStateOf("") }
  var confirmEmptyTrash by remember { mutableStateOf(false) }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(snackbar) },
    topBar = {
      TopAppBar(
        title = {
          Text(if (selectedTab == 0) strings.vaultTitle else strings.recycleBinTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
        },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("vault_trash_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
          }
        },
        actions = {
          if (selectedTab == 1 && trashEntries.isNotEmpty()) {
            IconButton(
              onClick = { confirmEmptyTrash = true },
              modifier = Modifier.testTag("empty_trash_button"),
            ) {
              Icon(Icons.Default.DeleteSweep, contentDescription = strings.emptyTrashAction)
            }
          }
        },
      )
    },
  ) { padding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .navigationBarsPadding(),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(modifier = Modifier.fillMaxSize().widthIn(max = 780.dp)) {
        PrimaryTabRow(selectedTabIndex = selectedTab) {
          Tab(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            text = { Text("${strings.vaultTitle} (${vaultEntries.size})", maxLines = 1, overflow = TextOverflow.Ellipsis) },
            modifier = Modifier.testTag("tab_vault"),
          )
          Tab(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            text = { Text("${strings.recycleBinTitle} (${trashEntries.size})", maxLines = 1, overflow = TextOverflow.Ellipsis) },
            modifier = Modifier.testTag("tab_recycle_bin"),
          )
        }

        if (selectedTab == 0) {
          LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            if (vaultEntries.isEmpty()) {
              item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                  Column(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.EnhancedEncryption, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(strings.vaultTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(strings.recoveryKeyNotice, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
              }
            } else {
              items(vaultEntries, key = { it.id }) { entry ->
                Card(
                  colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                  shape = RoundedCornerShape(14.dp),
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(entry.displayName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                      Text(
                        "${if (entry.wasDirectory) "Folder" else "File"} • ${formatFileSize(entry.originalSizeBytes)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                      )
                      Text(
                        entry.lockedPath,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                    }
                    FilledTonalButton(
                      onClick = { unlockSecret = ""; unlockTarget = entry },
                      modifier = Modifier.testTag("unlock_vault_entry_${entry.id}"),
                    ) {
                      Icon(Icons.Default.LockOpen, contentDescription = null)
                      Spacer(Modifier.width(4.dp))
                      Text(strings.unlockVault)
                    }
                  }
                }
              }
            }
          }
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            item {
              Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                Row(
                  modifier = Modifier.fillMaxWidth().padding(12.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  val retText = if (prefs.trashRetentionDays <= 0) "Off" else "${prefs.trashRetentionDays}d"
                  Text("${strings.recycleBinRetentionLabel}: $retText", style = MaterialTheme.typography.labelLarge)
                  if (trashEntries.isNotEmpty()) {
                    TextButton(onClick = { confirmEmptyTrash = true }) {
                      Text(strings.emptyTrashAction, color = MaterialTheme.colorScheme.error)
                    }
                  }
                }
              }
            }
            items(trashEntries, key = { it.id }) { entry ->
              TrashItemCard(
                entry = entry,
                onRestore = {
                  scope.launch {
                    val ok = container.recycleBinManager.restoreEntry(entry)
                    onFilesChanged()
                    snackbar.showSnackbar(if (ok) "Restored ${entry.originalName}" else "Restore failed")
                  }
                },
                onPermanentDelete = {
                  scope.launch {
                    container.recycleBinManager.permanentlyDeleteEntry(entry)
                    snackbar.showSnackbar("Permanently deleted ${entry.originalName}")
                  }
                },
              )
            }
          }
        }
      }
    }
  }

  unlockTarget?.let { entry ->
    AlertDialog(
      onDismissRequest = { unlockTarget = null },
      title = { Text("${strings.unlockVault}: ${entry.displayName}") },
      text = {
        OutlinedTextField(
          value = unlockSecret,
          onValueChange = { unlockSecret = it },
          label = { Text(strings.enterPasswordOrKey) },
          visualTransformation = PasswordVisualTransformation(),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val target = entry
            val secret = unlockSecret
            unlockTarget = null
            scope.launch {
              runCatching {
                container.vaultEngine.unlockTarget(File(target.lockedPath), secret, deleteLockedAfter = true)
              }.onSuccess { res ->
                container.database.vaultDao().deleteById(target.id)
                onFilesChanged()
                snackbar.showSnackbar("Unlocked ${res.restoredFile.name}")
              }.onFailure {
                snackbar.showSnackbar(it.message ?: "Incorrect password or recovery key")
              }
            }
          },
          enabled = unlockSecret.isNotBlank(),
        ) {
          Text(strings.unlockVault)
        }
      },
      dismissButton = { TextButton(onClick = { unlockTarget = null }) { Text(strings.cancel) } },
    )
  }

  if (confirmEmptyTrash) {
    AlertDialog(
      onDismissRequest = { confirmEmptyTrash = false },
      title = { Text(strings.emptyTrashAction) },
      text = { Text("${strings.deletePermanentOption} (${trashEntries.size})") },
      confirmButton = {
        Button(
          onClick = {
            confirmEmptyTrash = false
            scope.launch {
              val n = container.recycleBinManager.emptyTrash()
              snackbar.showSnackbar("Cleared $n items")
            }
          }
        ) { Text(strings.confirm) }
      },
      dismissButton = { TextButton(onClick = { confirmEmptyTrash = false }) { Text(strings.cancel) } },
    )
  }
}

@Composable
private fun TrashItemCard(
  entry: TrashEntryEntity,
  onRestore: () -> Unit,
  onPermanentDelete: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val dateStr = remember(entry.expiresAt) {
    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(entry.expiresAt))
  }
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    shape = RoundedCornerShape(14.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(entry.originalName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        Text(
          "${formatFileSize(entry.sizeBytes)} • Expires: $dateStr",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
          entry.originalPath,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Row {
        IconButton(onClick = onRestore) {
          Icon(Icons.Default.RestoreFromTrash, contentDescription = strings.restoreAction, tint = MaterialTheme.colorScheme.primary)
        }
        IconButton(onClick = onPermanentDelete) {
          Icon(Icons.Default.DeleteForever, contentDescription = strings.deletePermanentOption, tint = MaterialTheme.colorScheme.error)
        }
      }
    }
  }
}
