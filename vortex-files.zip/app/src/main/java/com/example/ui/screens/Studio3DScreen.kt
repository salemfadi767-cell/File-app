package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.media.Mesh3DEngine
import com.example.domain.media.Mesh3DFormat
import com.example.domain.media.MeshObject
import com.example.domain.media.Primitive3DType
import com.example.domain.media.Shading3DMode
import com.example.domain.media.Vec3
import com.example.i18n.LocalAppStrings
import java.io.File
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun Studio3DScreen(
  initialPath: String,
  defaultOutputDir: File,
  onFileExported: () -> Unit,
  onBack: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val scope = rememberCoroutineScope()
  val snackbar = remember { SnackbarHostState() }
  val focusManager = LocalFocusManager.current

  var sceneObjects by remember {
    mutableStateOf(
      listOf(Mesh3DEngine.createPrimitive(Primitive3DType.CUBE, "Cube_01"))
    )
  }
  var selectedId by remember { mutableStateOf(sceneObjects.firstOrNull()?.id.orEmpty()) }
  var shadingMode by remember { mutableStateOf(Shading3DMode.SOLID_LIT) }
  var activePanelTab by remember { mutableIntStateOf(0) } // 0=Scene, 1=Transform, 2=Modify, 3=Export

  var yawDeg by remember { mutableFloatStateOf(38f) }
  var pitchDeg by remember { mutableFloatStateOf(24f) }
  var camZoom by remember { mutableFloatStateOf(1.0f) }

  var showAddPrimitiveDialog by remember { mutableStateOf(false) }
  var exportFormat by remember { mutableStateOf(Mesh3DFormat.OBJ) }
  var exportName by remember(initialPath) {
    mutableStateOf(
      File(initialPath).takeIf { initialPath.isNotBlank() }?.nameWithoutExtension ?: "vortex_model"
    )
  }

  DisposableEffect(Unit) {
    onDispose { runCatching { focusManager.clearFocus(force = true) } }
  }
  BackHandler {
    runCatching { focusManager.clearFocus(force = true) }
    onBack()
  }

  LaunchedEffect(initialPath) {
    if (initialPath.isNotBlank()) {
      val f = File(initialPath)
      if (f.exists() && f.isFile) {
        runCatching { Mesh3DEngine.loadMeshFromFile(f) }
          .onSuccess { loaded ->
            if (loaded.isNotEmpty()) {
              sceneObjects = loaded
              selectedId = loaded.first().id
              snackbar.showSnackbar("Loaded ${loaded.size} mesh(es) from ${f.name}")
            } else {
              snackbar.showSnackbar("Could not parse 3D geometry from ${f.name}")
            }
          }
          .onFailure {
            snackbar.showSnackbar(it.message ?: "Failed to load 3D model")
          }
      }
    }
  }

  val selectedObj = sceneObjects.firstOrNull { it.id == selectedId } ?: sceneObjects.firstOrNull()
  fun updateSelected(transform: (MeshObject) -> MeshObject) {
    val targetId = selectedObj?.id ?: return
    sceneObjects = sceneObjects.map { if (it.id == targetId) transform(it) else it }
  }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(snackbar) },
    topBar = {
      TopAppBar(
        modifier = Modifier.statusBarsPadding(),
        title = {
          Column {
            Text(strings.studio3dTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val totalFaces = sceneObjects.sumOf { it.faces.size }
            val totalVerts = sceneObjects.sumOf { it.vertices.size }
            Text(
              "${sceneObjects.size} obj • $totalVerts verts • $totalFaces tris",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        },
        navigationIcon = {
          IconButton(
            onClick = {
              runCatching { focusManager.clearFocus(force = true) }
              onBack()
            },
            modifier = Modifier.testTag("studio3d_back_btn"),
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        actions = {
          IconButton(
            onClick = { showAddPrimitiveDialog = true },
            modifier = Modifier.testTag("studio3d_add_btn"),
          ) {
            Icon(Icons.Default.Add, contentDescription = "Add Primitive")
          }
          IconButton(
            onClick = {
              yawDeg = 38f
              pitchDeg = 24f
              camZoom = 1.0f
            },
          ) {
            Icon(Icons.Default.Refresh, contentDescription = "Reset Camera")
          }
        },
      )
    },
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .navigationBarsPadding()
        .background(Color(0xFF141820)),
    ) {
      // Viewport Shading Toolbar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFF1D232E))
          .horizontalScroll(rememberScrollState())
          .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Shading3DMode.entries.forEach { mode ->
          FilterChip(
            selected = shadingMode == mode,
            onClick = { shadingMode = mode },
            label = {
              Text(
                when (mode) {
                  Shading3DMode.SOLID_LIT -> "Solid Lit"
                  Shading3DMode.WIREFRAME -> "Wireframe"
                  Shading3DMode.NORMALS -> "Normals"
                }
              )
            },
            modifier = Modifier.testTag("shading_${mode.name.lowercase()}"),
          )
        }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { showAddPrimitiveDialog = true }) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(4.dp))
          Text("Mesh")
        }
      }

      // Blender-Style 3D Interactive Viewport
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .background(Color(0xFF1A1F29))
          .pointerInput(Unit) {
            detectTransformGestures { _, pan, zoom, _ ->
              yawDeg = (yawDeg + pan.x * 0.35f) % 360f
              pitchDeg = (pitchDeg + pan.y * 0.35f).coerceIn(-85f, 85f)
              camZoom = (camZoom * zoom).coerceIn(0.35f, 4.5f)
            }
          }
          .testTag("studio3d_viewport"),
      ) {
        Viewport3DCanvas(
          objects = sceneObjects,
          selectedId = selectedObj?.id,
          shadingMode = shadingMode,
          yawDeg = yawDeg,
          pitchDeg = pitchDeg,
          zoom = camZoom,
        )

        // Overlay Axis Legend
        Surface(
          color = Color(0xAA0E131A),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
        ) {
          Text(
            "Drag to Orbit • Pinch to Zoom",
            color = Color(0xFFB4C0D3),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      // Blender Properties / Outliner Dock
      Surface(
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth().height(270.dp),
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          TabRow(selectedTabIndex = activePanelTab) {
            Tab(selected = activePanelTab == 0, onClick = { activePanelTab = 0 }, text = { Text("Scene") })
            Tab(selected = activePanelTab == 1, onClick = { activePanelTab = 1 }, text = { Text("Transform") })
            Tab(selected = activePanelTab == 2, onClick = { activePanelTab = 2 }, text = { Text("Modifiers") })
            Tab(selected = activePanelTab == 3, onClick = { activePanelTab = 3 }, text = { Text("Export") })
          }

          Column(
            modifier = Modifier
              .weight(1f)
              .verticalScroll(rememberScrollState())
              .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            when (activePanelTab) {
              // Tab 0: Outliner Scene Hierarchy
              0 -> {
                sceneObjects.forEach { obj ->
                  val isSel = obj.id == selectedObj?.id
                  Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                    else MaterialTheme.colorScheme.surfaceContainerHigh,
                    border = BorderStroke(if (isSel) 1.5.dp else 0.5.dp, if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth().clickable { selectedId = obj.id },
                  ) {
                    Row(
                      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(Color(obj.colorArgb)))
                        Column {
                          Text(obj.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                          Text("${obj.vertices.size}v / ${obj.faces.size}f", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                      }
                      Row {
                        IconButton(
                          onClick = {
                            sceneObjects = sceneObjects.map { if (it.id == obj.id) it.copy(visible = !it.visible) else it }
                          },
                        ) {
                          Icon(
                            if (obj.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle Visibility",
                          )
                        }
                        if (sceneObjects.size > 1) {
                          IconButton(
                            onClick = {
                              sceneObjects = sceneObjects.filterNot { it.id == obj.id }
                              if (selectedId == obj.id) selectedId = sceneObjects.firstOrNull()?.id.orEmpty()
                            },
                          ) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove Object")
                          }
                        }
                      }
                    }
                  }
                }
              }

              // Tab 1: Transform (Position / Rotation / Scale)
              1 -> {
                if (selectedObj == null) {
                  Text("Select an object in Scene tab.")
                } else {
                  Text("${selectedObj.name} — Transform", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                  AxisSlider("Pos X", selectedObj.position.x, -4f..4f) { nx ->
                    updateSelected { it.copy(position = it.position.copy(x = nx)) }
                  }
                  AxisSlider("Pos Y", selectedObj.position.y, -4f..4f) { ny ->
                    updateSelected { it.copy(position = it.position.copy(y = ny)) }
                  }
                  AxisSlider("Pos Z", selectedObj.position.z, -4f..4f) { nz ->
                    updateSelected { it.copy(position = it.position.copy(z = nz)) }
                  }
                  AxisSlider("Rot X", selectedObj.rotationDeg.x, -180f..180f) { rx ->
                    updateSelected { it.copy(rotationDeg = it.rotationDeg.copy(x = rx)) }
                  }
                  AxisSlider("Rot Y", selectedObj.rotationDeg.y, -180f..180f) { ry ->
                    updateSelected { it.copy(rotationDeg = it.rotationDeg.copy(y = ry)) }
                  }
                  AxisSlider("Scale", selectedObj.scale.x, 0.2f..3.0f) { s ->
                    updateSelected { it.copy(scale = Vec3(s, s, s)) }
                  }
                }
              }

              // Tab 2: Modifiers & Material Color
              2 -> {
                if (selectedObj == null) {
                  Text("Select an object first.")
                } else {
                  FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                      onClick = { updateSelected { Mesh3DEngine.subdivideMesh(it) } },
                      modifier = Modifier.testTag("studio3d_subdivide_btn"),
                    ) {
                      Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                      Spacer(Modifier.width(4.dp))
                      Text("Subdivide")
                    }
                    OutlinedButton(
                      onClick = { updateSelected { Mesh3DEngine.mirrorMesh(it, axisX = true, axisY = false, axisZ = false) } },
                    ) {
                      Icon(Icons.Default.Flip, contentDescription = null, modifier = Modifier.size(16.dp))
                      Spacer(Modifier.width(4.dp))
                      Text("Mirror X")
                    }
                    OutlinedButton(
                      onClick = { updateSelected { Mesh3DEngine.normalizeToUnitBounds(it) } },
                    ) {
                      Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp))
                      Spacer(Modifier.width(4.dp))
                      Text("Normalize")
                    }
                  }
                  Text("Material Color", style = MaterialTheme.typography.labelLarge)
                  val palette = listOf(
                    Color(0xFF4DD0E1), Color(0xFFFF8A65), Color(0xFF81C784),
                    Color(0xFFBA68C8), Color(0xFFFFD54F), Color(0xFFE57373), Color(0xFF90A4AE),
                  )
                  Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    palette.forEach { c ->
                      Box(
                        modifier = Modifier
                          .size(32.dp)
                          .clip(CircleShape)
                          .background(c)
                          .clickable { updateSelected { it.copy(colorArgb = c.toArgb()) } },
                      )
                    }
                  }
                }
              }

              // Tab 3: Universal 3D Export / Format Converter
              3 -> {
                OutlinedTextField(
                  value = exportName,
                  onValueChange = { exportName = it },
                  label = { Text("Output Model Name") },
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth().testTag("studio3d_export_name"),
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Mesh3DFormat.entries.forEach { fmt ->
                    FilterChip(
                      selected = exportFormat == fmt,
                      onClick = { exportFormat = fmt },
                      label = { Text(".${fmt.ext.uppercase()}") },
                    )
                  }
                }
                Button(
                  onClick = {
                    runCatching { focusManager.clearFocus(force = true) }
                    scope.launch {
                      val targetDir = File(initialPath).parentFile?.takeIf { initialPath.isNotBlank() } ?: defaultOutputDir
                      val stem = exportName.trim().ifBlank { "vortex_model" }.replace(Regex("[^A-Za-z0-9._-]"), "_")
                      val outFile = File(targetDir, "$stem.${exportFormat.ext}")
                      runCatching { Mesh3DEngine.exportScene(sceneObjects, outFile, exportFormat) }
                        .onSuccess { f ->
                          onFileExported()
                          snackbar.showSnackbar("Exported ${f.name} (${exportFormat.label})")
                        }
                        .onFailure { err ->
                          snackbar.showSnackbar(err.message ?: "Export failed")
                        }
                    }
                  },
                  modifier = Modifier.fillMaxWidth().testTag("studio3d_export_btn"),
                ) {
                  Icon(Icons.Default.FileDownload, contentDescription = null)
                  Spacer(Modifier.width(6.dp))
                  Text("Export as .${exportFormat.ext.uppercase()}")
                }
              }
            }
          }
        }
      }
    }
  }

  if (showAddPrimitiveDialog) {
    AlertDialog(
      onDismissRequest = { showAddPrimitiveDialog = false },
      title = { Text("Add 3D Primitive Mesh") },
      text = {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Primitive3DType.entries.forEach { pType ->
            OutlinedButton(
              onClick = {
                val created = Mesh3DEngine.createPrimitive(
                  pType,
                  name = "${pType.label}_${sceneObjects.size + 1}",
                )
                sceneObjects = sceneObjects + created
                selectedId = created.id
                showAddPrimitiveDialog = false
              },
            ) {
              Text(pType.label)
            }
          }
        }
      },
      confirmButton = {},
      dismissButton = {
        TextButton(onClick = { showAddPrimitiveDialog = false }) { Text(strings.cancel) }
      },
    )
  }
}

@Composable
private fun AxisSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(52.dp))
    Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
    Text("%.2f".format(value), style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(44.dp))
  }
}

@Composable
private fun Viewport3DCanvas(
  objects: List<MeshObject>,
  selectedId: String?,
  shadingMode: Shading3DMode,
  yawDeg: Float,
  pitchDeg: Float,
  zoom: Float,
) {
  Canvas(modifier = Modifier.fillMaxSize()) {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.5f
    val fovScale = min(w, h) * 0.38f * zoom

    val yawRad = Math.toRadians(yawDeg.toDouble())
    val pitchRad = Math.toRadians(pitchDeg.toDouble())
    val cyaw = cos(yawRad).toFloat(); val syaw = sin(yawRad).toFloat()
    val cpitch = cos(pitchRad).toFloat(); val spitch = sin(pitchRad).toFloat()

    fun viewTransform(v: Vec3): Vec3 {
      val x1 = v.x * cyaw + v.z * syaw
      val z1 = -v.x * syaw + v.z * cyaw
      val y2 = v.y * cpitch - z1 * spitch
      val z2 = v.y * spitch + z1 * cpitch
      return Vec3(x1, y2, z2)
    }

    fun project(vView: Vec3): Offset {
      val camDist = 4.6f
      val denom = (camDist - vView.z).coerceAtLeast(0.6f)
      val factor = fovScale / denom * 2.3f
      return Offset(cx + vView.x * factor, cy - vView.y * factor)
    }

    // 1. Floor Reference Grid
    val gridColor = Color(0xFF2B3445)
    for (g in -4..4) {
      val p1 = project(viewTransform(Vec3(g.toFloat(), -1.05f, -4f)))
      val p2 = project(viewTransform(Vec3(g.toFloat(), -1.05f, 4f)))
      drawLine(gridColor, p1, p2, strokeWidth = 1.2f)
      val p3 = project(viewTransform(Vec3(-4f, -1.05f, g.toFloat())))
      val p4 = project(viewTransform(Vec3(4f, -1.05f, g.toFloat())))
      drawLine(gridColor, p3, p4, strokeWidth = 1.2f)
    }

    // RGB Axis Lines
    val origin = project(viewTransform(Vec3(0f, -1.05f, 0f)))
    drawLine(Color(0xFFEF5350), origin, project(viewTransform(Vec3(1.6f, -1.05f, 0f))), strokeWidth = 2.6f)
    drawLine(Color(0xFF66BB6A), origin, project(viewTransform(Vec3(0f, 0.55f, 0f))), strokeWidth = 2.6f)
    drawLine(Color(0xFF42A5F5), origin, project(viewTransform(Vec3(0f, -1.05f, 1.6f))), strokeWidth = 2.6f)

    // 2. Depth-Sorted Triangle Faces
    data class RenderTri(
      val depth: Float,
      val p0: Offset,
      val p1: Offset,
      val p2: Offset,
      val fillColor: Color,
      val wireColor: Color,
    )

    val lightDir = Vec3(0.45f, 0.8f, 0.55f).normalized()
    val triangles = ArrayList<RenderTri>(1024)

    for (obj in objects) {
      if (!obj.visible) continue
      val worldVerts = Mesh3DEngine.bakeWorldVertices(obj)
      val viewVerts = worldVerts.map(::viewTransform)
      val baseColor = Color(obj.colorArgb)
      val isSel = obj.id == selectedId
      val wireTint = if (isSel) Color(0xFFFFB74D) else Color(0xFF90CAF9)

      for (face in obj.faces) {
        if (face.i0 !in viewVerts.indices || face.i1 !in viewVerts.indices || face.i2 !in viewVerts.indices) continue
        val a = viewVerts[face.i0]
        val b = viewVerts[face.i1]
        val c = viewVerts[face.i2]
        val n = (b - a).cross(c - a).normalized()
        val depth = (a.z + b.z + c.z) / 3f
        val intensity = (0.28f + 0.72f * max(0f, n.dot(lightDir))).coerceIn(0.22f, 1f)
        val fill = when (shadingMode) {
          Shading3DMode.SOLID_LIT -> Color(
            red = (baseColor.red * intensity).coerceIn(0f, 1f),
            green = (baseColor.green * intensity).coerceIn(0f, 1f),
            blue = (baseColor.blue * intensity).coerceIn(0f, 1f),
            alpha = 0.96f,
          )
          Shading3DMode.NORMALS -> Color(
            red = (n.x * 0.5f + 0.5f).coerceIn(0f, 1f),
            green = (n.y * 0.5f + 0.5f).coerceIn(0f, 1f),
            blue = (n.z * 0.5f + 0.5f).coerceIn(0f, 1f),
            alpha = 0.96f,
          )
          Shading3DMode.WIREFRAME -> Color.Transparent
        }
        triangles.add(
          RenderTri(
            depth = depth,
            p0 = project(a),
            p1 = project(b),
            p2 = project(c),
            fillColor = fill,
            wireColor = wireTint,
          )
        )
      }
    }

    triangles.sortBy { it.depth }
    val path = Path()
    for (tri in triangles) {
      path.reset()
      path.moveTo(tri.p0.x, tri.p0.y)
      path.lineTo(tri.p1.x, tri.p1.y)
      path.lineTo(tri.p2.x, tri.p2.y)
      path.close()
      if (shadingMode != Shading3DMode.WIREFRAME) {
        drawPath(path, color = tri.fillColor)
      }
      drawPath(
        path,
        color = if (shadingMode == Shading3DMode.WIREFRAME) tri.wireColor else tri.wireColor.copy(alpha = 0.25f),
        style = Stroke(width = if (shadingMode == Shading3DMode.WIREFRAME) 1.8f else 0.7f),
      )
    }
  }
}
