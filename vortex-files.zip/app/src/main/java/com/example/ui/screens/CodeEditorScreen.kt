package com.example.ui.screens

import android.webkit.RenderProcessGoneDetail
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.FormatIndentIncrease
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.automirrored.filled.WrapText
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFolderUpload
import androidx.compose.material.icons.filled.FindReplace
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import java.io.File
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Extension
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.editor.AppTargetPlatform
import com.example.domain.editor.CodeLanguage
import com.example.domain.editor.PackageEcosystem
import com.example.domain.editor.SyntaxHighlighter
import com.example.i18n.LocalAppStrings
import com.example.ui.theme.LocalVortexExtraColors
import com.example.ui.theme.MonoFontFamily
import com.example.ui.viewmodel.EditorCharset
import com.example.ui.viewmodel.EditorViewModel

@Composable
fun CodeEditorScreen(
  filePath: String,
  forceHex: Boolean,
  editorFontSizeSp: Int,
  wordWrapDefault: Boolean,
  useRoot: Boolean,
  viewModel: EditorViewModel,
  onBack: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val extra = LocalVortexExtraColors.current
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val snackbarHostState = remember { SnackbarHostState() }
  val drawerState = rememberDrawerState(DrawerValue.Closed)
  val scope = rememberCoroutineScope()
  val focusManager = LocalFocusManager.current

  var wordWrap by remember { mutableStateOf(wordWrapDefault) }
  var showFindReplace by remember { mutableStateOf(false) }
  var findQuery by remember { mutableStateOf("") }
  var replaceQuery by remember { mutableStateOf("") }
  var useRegex by remember { mutableStateOf(false) }
  var showLangMenu by remember { mutableStateOf(false) }
  var showCharsetMenu by remember { mutableStateOf(false) }
  var showSymbolsDialog by remember { mutableStateOf(false) }
  var showDiagnosticsDialog by remember { mutableStateOf(false) }
  var showPackagesDialog by remember { mutableStateOf(false) }
  var showBuildAppDialog by remember { mutableStateOf(false) }
  var showIdeSuggestions by remember { mutableStateOf(true) }

  DisposableEffect(Unit) {
    onDispose { runCatching { focusManager.clearFocus(force = true) } }
  }
  BackHandler {
    runCatching { focusManager.clearFocus(force = true) }
    onBack()
  }

  LaunchedEffect(filePath, forceHex) {
    viewModel.openFile(filePath, forceHex)
  }

  LaunchedEffect(state.statusMessage) {
    state.statusMessage?.let {
      snackbarHostState.showSnackbar(it)
      viewModel.clearMessage()
    }
  }

  val syntaxTransformation =
    remember(state.language, extra) {
      VisualTransformation { text ->
        TransformedText(
          SyntaxHighlighter.highlight(text.text, state.language, extra),
          OffsetMapping.Identity,
        )
      }
    }

  ModalNavigationDrawer(
    drawerState = drawerState,
    drawerContent = {
      ModalDrawerSheet(modifier = Modifier.width(300.dp)) {
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("Workspace Explorer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
              Text(
                text = state.workspaceFolderPath.ifBlank { "/" },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            IconButton(
              onClick = {
                val parent = File(state.workspaceFolderPath).parent
                if (!parent.isNullOrBlank()) viewModel.openWorkspaceDirectory(parent)
              },
            ) {
              Icon(Icons.Default.DriveFolderUpload, contentDescription = "Parent folder")
            }
            IconButton(onClick = { viewModel.openWorkspaceDirectory(state.workspaceFolderPath) }) {
              Icon(Icons.Default.Refresh, contentDescription = "Refresh")
            }
          }
          HorizontalDivider()
          LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
            items(state.workspaceFiles, key = { it.path }) { node ->
              NavigationDrawerItem(
                selected = node.path == state.filePath,
                onClick = {
                  if (node.isDirectory) {
                    viewModel.openWorkspaceDirectory(node.path)
                  } else {
                    viewModel.openFile(node.path, false)
                    scope.launch { drawerState.close() }
                  }
                },
                icon = {
                  Icon(
                    imageVector = if (node.isDirectory) Icons.Default.Folder else Icons.Default.Description,
                    contentDescription = null,
                    tint = if (node.isDirectory) extra.rootGold else MaterialTheme.colorScheme.primary,
                  )
                },
                label = {
                  Text(node.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
              )
            }
          }
        }
      }
    },
  ) {
  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      Column(
        modifier =
          Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .statusBarsPadding(),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(
            onClick = {
              runCatching { focusManager.clearFocus(force = true) }
              onBack()
            },
            modifier = Modifier.testTag("editor_back_btn"),
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
          IconButton(
            onClick = { scope.launch { drawerState.open() } },
            modifier = Modifier.testTag("editor_explorer_btn"),
          ) {
            Icon(Icons.Default.FolderOpen, contentDescription = "Workspace Explorer")
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = state.fileName + if (state.isDirty) " •" else "",
              style = MaterialTheme.typography.titleMedium,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = "${state.language.label} • ${state.charset.label} • ${state.text.lines().size} L",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          // Run Code button
          if (!state.isHexMode) {
            IconButton(
              onClick = { viewModel.runCode(useRoot) },
              modifier = Modifier.testTag("editor_run_btn"),
            ) {
              Icon(
                Icons.Default.PlayArrow,
                contentDescription = strings.runCode,
                tint = extra.losslessGreen,
              )
            }
          }
          IconButton(onClick = { viewModel.undo() }, enabled = state.canUndo) {
            Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = strings.undo)
          }
          IconButton(onClick = { viewModel.redo() }, enabled = state.canRedo) {
            Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = strings.redo)
          }
          IconButton(onClick = { showFindReplace = !showFindReplace }) {
            Icon(Icons.Default.FindReplace, contentDescription = strings.findReplace)
          }
          IconButton(
            onClick = { viewModel.save(useRoot, strings.savedSuccess) },
            modifier = Modifier.testTag("editor_save_btn"),
          ) {
            Icon(
              Icons.Default.Save,
              contentDescription = strings.saveFile,
              tint = if (state.isDirty) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
          }
        }

        // VS Code Open Editor Tabs Bar
        if (state.openTabs.isNotEmpty()) {
          Row(
            modifier =
              Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            state.openTabs.forEachIndexed { idx, tab ->
              val isActive = idx == state.activeTabIndex
              Surface(
                shape = MaterialTheme.shapes.small,
                color = if (isActive) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f) else MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(if (isActive) 1.dp else 0.5.dp, if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.clickable { viewModel.switchTab(idx) }.testTag("editor_tab_$idx"),
              ) {
                Row(
                  modifier = Modifier.padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                  Text(
                    text = tab.fileName + if (tab.isDirty) " •" else "",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  IconButton(
                    onClick = { viewModel.closeTab(idx) },
                    modifier = Modifier.size(20.dp),
                  ) {
                    Icon(Icons.Default.Close, contentDescription = strings.close, modifier = Modifier.size(14.dp))
                  }
                }
              }
            }
          }
        }

        // IDE & Editor secondary toolbar
        Row(
          modifier =
            Modifier
              .fillMaxWidth()
              .background(MaterialTheme.colorScheme.surfaceContainerLow)
              .horizontalScroll(rememberScrollState())
              .padding(horizontal = 8.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          FilterChip(
            selected = showIdeSuggestions,
            onClick = { showIdeSuggestions = !showIdeSuggestions },
            label = { Text(strings.ideAssistant) },
            leadingIcon = { Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp)) },
          )
          FilterChip(
            selected = false,
            onClick = { viewModel.formatCode() },
            label = { Text(strings.formatCode) },
            leadingIcon = { Icon(Icons.AutoMirrored.Filled.FormatIndentIncrease, contentDescription = null, modifier = Modifier.size(16.dp)) },
          )
          FilterChip(
            selected = state.diagnostics.isNotEmpty(),
            onClick = { showDiagnosticsDialog = true },
            label = { Text("${strings.diagnosticsLabel} (${state.diagnostics.size})") },
            leadingIcon = {
              Icon(
                Icons.Default.BugReport,
                contentDescription = null,
                tint = if (state.diagnostics.isNotEmpty()) extra.lossyWarning else extra.losslessGreen,
                modifier = Modifier.size(16.dp),
              )
            },
          )
          FilterChip(
            selected = false,
            onClick = { showSymbolsDialog = true },
            label = { Text("${strings.symbolsOutline} (${state.symbols.size})") },
            leadingIcon = { Icon(Icons.Default.AccountTree, contentDescription = null, modifier = Modifier.size(16.dp)) },
          )
          FilterChip(
            selected = state.showConsole,
            onClick = { viewModel.setShowConsole(!state.showConsole) },
            label = { Text(strings.consoleOutput) },
            leadingIcon = { Icon(Icons.Default.Terminal, contentDescription = null, modifier = Modifier.size(16.dp)) },
          )
          FilterChip(
            selected = state.installedPackages.isNotEmpty(),
            onClick = { showPackagesDialog = true },
            label = { Text("Packages (${state.installedPackages.size})") },
            leadingIcon = { Icon(Icons.Default.Extension, contentDescription = null, modifier = Modifier.size(16.dp)) },
            modifier = Modifier.testTag("editor_packages_chip"),
          )
          FilterChip(
            selected = false,
            onClick = { showBuildAppDialog = true },
            label = { Text(strings.buildMultiOsLabel) },
            leadingIcon = { Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp)) },
            modifier = Modifier.testTag("editor_build_app_chip"),
          )
          FilterChip(
            selected = state.isHexMode,
            onClick = { viewModel.toggleHexMode() },
            label = { Text(if (state.isHexMode) strings.textMode else strings.hexMode) },
            leadingIcon = { Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp)) },
          )
          FilterChip(
            selected = wordWrap,
            onClick = { wordWrap = !wordWrap },
            label = { Text(strings.wordWrap) },
            leadingIcon = { Icon(Icons.AutoMirrored.Filled.WrapText, contentDescription = null, modifier = Modifier.size(16.dp)) },
          )
          Box {
            TextButton(onClick = { showLangMenu = true }) {
              Text(state.language.label)
            }
            DropdownMenu(expanded = showLangMenu, onDismissRequest = { showLangMenu = false }) {
              CodeLanguage.entries.forEach { lang ->
                DropdownMenuItem(
                  text = { Text(lang.label) },
                  onClick = {
                    viewModel.setLanguage(lang)
                    showLangMenu = false
                  },
                )
              }
            }
          }
          Box {
            TextButton(onClick = { showCharsetMenu = true }) {
              Text(state.charset.label)
            }
            DropdownMenu(expanded = showCharsetMenu, onDismissRequest = { showCharsetMenu = false }) {
              EditorCharset.entries.forEach { cs ->
                DropdownMenuItem(
                  text = { Text(cs.label) },
                  onClick = {
                    viewModel.setCharset(cs)
                    showCharsetMenu = false
                  },
                )
              }
            }
          }
        }

        AnimatedVisibility(visible = showFindReplace) {
          Column(
            modifier =
              Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              OutlinedTextField(
                value = findQuery,
                onValueChange = { findQuery = it },
                label = { Text(strings.findHint) },
                singleLine = true,
                modifier = Modifier.weight(1f),
              )
              OutlinedTextField(
                value = replaceQuery,
                onValueChange = { replaceQuery = it },
                label = { Text(strings.replaceHint) },
                singleLine = true,
                modifier = Modifier.weight(1f),
              )
            }
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Regex", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.width(6.dp))
                Switch(checked = useRegex, onCheckedChange = { useRegex = it })
              }
              Button(onClick = { viewModel.replaceAll(findQuery, replaceQuery, useRegex, false) }) {
                Text(strings.replaceAll)
              }
            }
          }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
      }
    },
    bottomBar = {
      if (!state.isHexMode) {
        Column(
          modifier =
            Modifier
              .fillMaxWidth()
              .background(MaterialTheme.colorScheme.surfaceContainer)
              .navigationBarsPadding()
              .imePadding(),
        ) {
          // IDE Autocomplete Suggestions Ribbon
          AnimatedVisibility(visible = showIdeSuggestions && state.completions.isNotEmpty()) {
            Row(
              modifier =
                Modifier
                  .fillMaxWidth()
                  .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                  .horizontalScroll(rememberScrollState())
                  .padding(horizontal = 8.dp, vertical = 5.dp),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              state.completions.forEach { comp ->
                Surface(
                  shape = MaterialTheme.shapes.small,
                  color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                  border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                  modifier = Modifier.clickable { viewModel.applyCompletion(comp) },
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Text(
                      text = comp.label,
                      style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
                      color = MaterialTheme.colorScheme.primary,
                      fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                      text = comp.detail,
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
              }
            }
          }

          // Quick Code Symbols Bar
          Row(
            modifier =
              Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            listOf("{", "}", "(", ")", "[", "]", "=", ";", "\"", "/", "<", ">", "->", "  ").forEach { sym ->
              Surface(
                shape = MaterialTheme.shapes.extraSmall,
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier.clickable { viewModel.insertSnippet(sym) },
              ) {
                Text(
                  text = if (sym == "  ") "TAB" else sym,
                  style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                )
              }
            }
          }
        }
      }
    },
  ) { innerPadding ->
    Column(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .background(MaterialTheme.colorScheme.background),
    ) {
      Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
        when {
          state.isLoading -> {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
          }

          state.isHexMode -> {
            HexInspectorView(bytes = state.rawBytes)
          }

          else -> {
            val lines = state.text.split('\n')
            val vScroll = rememberScrollState()
            val hScroll = rememberScrollState()

            Row(
              modifier =
                Modifier
                  .fillMaxSize()
                  .verticalScroll(vScroll)
                  .padding(vertical = 8.dp),
            ) {
              Column(
                modifier =
                  Modifier
                    .background(MaterialTheme.colorScheme.surfaceContainerLow)
                    .padding(horizontal = 8.dp),
                horizontalAlignment = Alignment.End,
              ) {
                for (i in 1..lines.size.coerceAtLeast(1)) {
                  val hasErr = state.diagnostics.any { it.line == i }
                  Text(
                    text = i.toString(),
                    style =
                      TextStyle(
                        fontFamily = MonoFontFamily,
                        fontSize = editorFontSizeSp.sp,
                        lineHeight = (editorFontSizeSp + 6).sp,
                        color =
                          if (hasErr) extra.lossyWarning
                          else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                        fontWeight = if (hasErr) FontWeight.Bold else FontWeight.Normal,
                      ),
                  )
                }
              }

              val editorModifier =
                if (wordWrap) {
                  Modifier.weight(1f).padding(horizontal = 10.dp)
                } else {
                  Modifier.weight(1f).horizontalScroll(hScroll).padding(horizontal = 10.dp)
                }

              BasicTextField(
                value = state.text,
                onValueChange = { viewModel.onTextChanged(it) },
                textStyle =
                  TextStyle(
                    fontFamily = MonoFontFamily,
                    fontSize = editorFontSizeSp.sp,
                    lineHeight = (editorFontSizeSp + 6).sp,
                    color = MaterialTheme.colorScheme.onBackground,
                  ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                visualTransformation = syntaxTransformation,
                modifier = editorModifier.testTag("code_editor_field"),
              )
            }
          }
        }
      }

      // Interactive Code Runner Output Console
      AnimatedVisibility(visible = state.showConsole) {
        Surface(
          color = MaterialTheme.colorScheme.surfaceContainerLowest,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 240.dp),
        ) {
          Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Terminal, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Text(strings.consoleOutput, style = MaterialTheme.typography.titleSmall)
                state.runResult?.let { res ->
                  Text(
                    text = "${res.durationMs} ms",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (res.success) extra.losslessGreen else extra.lossyWarning,
                  )
                }
              }
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (state.runResult?.isHtmlPreviewAvailable == true) {
                  FilledTonalButton(onClick = { viewModel.setShowHtmlPreview(true) }) {
                    Icon(Icons.Default.Preview, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(strings.livePreview)
                  }
                }
                IconButton(onClick = { viewModel.setShowConsole(false) }, modifier = Modifier.size(28.dp)) {
                  Icon(Icons.Default.Close, contentDescription = strings.close, modifier = Modifier.size(16.dp))
                }
              }
            }
            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
            Box(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
              if (state.isRunning) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp))
              } else {
                val res = state.runResult
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  if (res == null) {
                    Text("Tap ▶ to run code", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  } else {
                    if (res.stdout.isNotBlank()) {
                      Text(
                        text = res.stdout,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.testTag("console_stdout_text"),
                      )
                    }
                    if (res.stderr.isNotBlank()) {
                      Text(
                        text = res.stderr,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
                        color = MaterialTheme.colorScheme.error,
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showDiagnosticsDialog) {
    AlertDialog(
      onDismissRequest = { showDiagnosticsDialog = false },
      title = { Text(strings.diagnosticsLabel) },
      text = {
        Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          if (state.diagnostics.isEmpty()) {
            Text("0 errors or warnings found.", color = extra.losslessGreen)
          } else {
            state.diagnostics.forEach { d ->
              Text("Line ${d.line}: ${d.message}", style = MaterialTheme.typography.bodySmall, color = extra.lossyWarning)
            }
          }
        }
      },
      confirmButton = { TextButton(onClick = { showDiagnosticsDialog = false }) { Text(strings.close) } },
    )
  }

  if (showSymbolsDialog) {
    AlertDialog(
      onDismissRequest = { showSymbolsDialog = false },
      title = { Text(strings.symbolsOutline) },
      text = {
        Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          if (state.symbols.isEmpty()) {
            Text("No symbols detected.", style = MaterialTheme.typography.bodySmall)
          } else {
            state.symbols.forEach { sym ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text("${sym.kind} ${sym.name}", style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily))
                Text("L${sym.lineNumber}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
              }
            }
          }
        }
      },
      confirmButton = { TextButton(onClick = { showSymbolsDialog = false }) { Text(strings.close) } },
    )
  }

  if (state.showHtmlPreview && state.runResult?.htmlPreviewContent != null) {
    AlertDialog(
      onDismissRequest = { viewModel.setShowHtmlPreview(false) },
      title = { Text(strings.livePreview) },
      text = {
        AndroidView(
          factory = { ctx ->
            WebView(ctx).apply {
              setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)
              settings.javaScriptEnabled = true
              if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                settings.safeBrowsingEnabled = false
              }
              webViewClient = object : WebViewClient() {
                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                  android.os.Handler(android.os.Looper.getMainLooper()).post {
                    runCatching {
                      view?.stopLoading()
                      view?.destroy()
                    }
                  }
                  return true
                }
              }
              loadDataWithBaseURL(null, state.runResult?.htmlPreviewContent.orEmpty(), "text/html", "utf-8", null)
            }
          },
          onRelease = { view ->
            runCatching {
              view.stopLoading()
              view.destroy()
            }
          },
          modifier = Modifier.fillMaxWidth().heightIn(min = 280.dp, max = 420.dp),
        )
      },
      confirmButton = { TextButton(onClick = { viewModel.setShowHtmlPreview(false) }) { Text(strings.close) } },
    )
  }

  @OptIn(ExperimentalLayoutApi::class)
  if (showPackagesDialog) {
    var selectedEco by remember { mutableStateOf(PackageEcosystem.PIP) }
    var pkgSpec by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = {
        runCatching { focusManager.clearFocus(force = true) }
        showPackagesDialog = false
      },
      title = { Text(strings.packagesManagerLabel) },
      text = {
        Column(
          modifier = Modifier.verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            PackageEcosystem.entries.forEach { eco ->
              FilterChip(
                selected = selectedEco == eco,
                onClick = { selectedEco = eco },
                label = { Text(eco.id.uppercase()) },
              )
            }
          }
          OutlinedTextField(
            value = pkgSpec,
            onValueChange = { pkgSpec = it },
            label = { Text("${selectedEco.commandHint} ...") },
            placeholder = { Text(if (selectedEco == PackageEcosystem.PIP) "requests or numpy" else if (selectedEco == PackageEcosystem.MAVEN) "com.google.code.gson:gson:2.11.0" else "package") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("ide_package_input"),
          )
          Button(
            onClick = {
              runCatching { focusManager.clearFocus(force = true) }
              viewModel.installPackage(selectedEco, pkgSpec)
            },
            enabled = pkgSpec.isNotBlank() && !state.isInstallingPackage,
            modifier = Modifier.fillMaxWidth().testTag("ide_install_package_btn"),
          ) {
            if (state.isInstallingPackage) {
              CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
              Spacer(Modifier.width(8.dp))
            }
            Text("Install into .vortex_libs/${selectedEco.id}")
          }
          if (state.installedPackages.isNotEmpty()) {
            HorizontalDivider()
            state.installedPackages.forEach { pkg ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text("[${pkg.ecosystem.id}] ${pkg.name} ${pkg.version}", style = MaterialTheme.typography.labelLarge)
                  Text("${pkg.filesCount} files", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { viewModel.uninstallPackage(pkg.ecosystem, pkg.name) }) {
                  Icon(Icons.Default.Delete, contentDescription = "Remove")
                }
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = {
          runCatching { focusManager.clearFocus(force = true) }
          showPackagesDialog = false
        }) { Text(strings.close) }
      },
    )
  }

  @OptIn(ExperimentalLayoutApi::class)
  if (showBuildAppDialog) {
    val defaultName = File(state.workspaceFolderPath.ifBlank { state.filePath }).nameWithoutExtension.ifBlank { "VortexApp" }
    var appNameDraft by remember { mutableStateOf(defaultName) }
    var pkgIdDraft by remember { mutableStateOf("com.vortex.${defaultName.lowercase().replace(Regex("[^a-z0-9]"), "")}") }
    var targetPlatform by remember { mutableStateOf(AppTargetPlatform.ANDROID_APK) }

    AlertDialog(
      onDismissRequest = {
        runCatching { focusManager.clearFocus(force = true) }
        showBuildAppDialog = false
      },
      title = { Text(strings.buildMultiOsLabel) },
      text = {
        Column(
          modifier = Modifier.verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedTextField(
            value = appNameDraft,
            onValueChange = { appNameDraft = it },
            label = { Text("App Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("build_app_name_input"),
          )
          OutlinedTextField(
            value = pkgIdDraft,
            onValueChange = { pkgIdDraft = it },
            label = { Text("Bundle / Package ID") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            AppTargetPlatform.entries.forEach { plat ->
              FilterChip(
                selected = targetPlatform == plat,
                onClick = { targetPlatform = plat },
                label = { Text(plat.label) },
                modifier = Modifier.testTag("build_plat_${plat.id}"),
              )
            }
          }
          state.lastBuiltArtifact?.let { art ->
            Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.small) {
              Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                Text(art.outputFile.name, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Text(art.summary, style = MaterialTheme.typography.bodySmall)
              }
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            runCatching { focusManager.clearFocus(force = true) }
            viewModel.buildMultiOsApp(appNameDraft, pkgIdDraft, targetPlatform)
          },
          enabled = !state.isBuildingApp,
          modifier = Modifier.testTag("build_app_confirm_btn"),
        ) {
          if (state.isBuildingApp) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(6.dp))
          }
          Text("Build")
        }
      },
      dismissButton = {
        TextButton(onClick = {
          runCatching { focusManager.clearFocus(force = true) }
          showBuildAppDialog = false
        }) { Text(strings.close) }
      },
    )
  }
  }
}

@Composable
fun HexInspectorView(bytes: ByteArray) {
  val totalRows = ((bytes.size + 15) / 16).coerceAtMost(4096)
  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(2.dp),
  ) {
    itemsIndexed((0 until totalRows).toList()) { _, rowIdx ->
      val offset = rowIdx * 16
      val end = minOf(offset + 16, bytes.size)
      val slice = bytes.copyOfRange(offset, end)
      val addr = "%08X".format(offset)
      val hex = slice.joinToString(" ") { "%02X".format(it) }.padEnd(47, ' ')
      val ascii =
        slice.map { b ->
          val c = b.toInt() and 0xFF
          if (c in 32..126) c.toChar() else '.'
        }.joinToString("")

      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(addr, style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily), color = MaterialTheme.colorScheme.secondary)
        Text(hex, style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily), color = MaterialTheme.colorScheme.onBackground)
        Text(ascii, style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily), color = MaterialTheme.colorScheme.primary)
      }
    }
  }
}
