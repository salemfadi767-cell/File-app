package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.archive.ArchiveFormat
import com.example.domain.archive.ImageOutputFormat
import com.example.domain.converter.AudioTargetFormat
import com.example.domain.converter.ConversionCategory
import com.example.domain.converter.TextTargetFormat
import com.example.domain.fs.formatFileSize
import com.example.i18n.LocalAppStrings
import com.example.ui.theme.LocalVortexExtraColors
import com.example.ui.viewmodel.ConverterViewModel
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConverterScreen(
  initialPaths: List<String>,
  viewModel: ConverterViewModel,
  onBack: () -> Unit,
) {
  val context = LocalContext.current
  val strings = LocalAppStrings.current
  val extra = LocalVortexExtraColors.current
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val history by viewModel.history.collectAsStateWithLifecycle()

  LaunchedEffect(initialPaths) {
    if (initialPaths.isNotEmpty()) {
      viewModel.setInitialFiles(initialPaths.map { File(it) }.filter { it.exists() })
    }
  }

  val filePicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
      val imported = uris.mapNotNull { copyUriToWorkspaceCache(context, it) }
      if (imported.isNotEmpty()) {
        viewModel.addFiles(imported)
      }
    }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    topBar = {
      TopAppBar(
        modifier = Modifier.statusBarsPadding(),
        title = { Text(strings.converterTitle) },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("converter_back_btn")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
  ) { innerPadding ->
    LazyColumn(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .navigationBarsPadding()
          .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        // Category Chips
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          val categories =
            listOf(
              Triple(ConversionCategory.VIDEO_TO_AUDIO, strings.videoToAudio, Icons.Default.AudioFile),
              Triple(ConversionCategory.IMAGES_TO_PDF, strings.imagesToPdf, Icons.Default.PictureAsPdf),
              Triple(ConversionCategory.PDF_TO_IMAGES, strings.pdfToImages, Icons.Default.Image),
              Triple(ConversionCategory.IMAGE_TO_IMAGE, strings.imageConverter, Icons.Default.Image),
              Triple(ConversionCategory.TEXT_DATA, strings.textDataConverter, Icons.Default.Code),
              Triple(ConversionCategory.ARCHIVE_TO_ARCHIVE, strings.archiveConverter, Icons.Default.Archive),
            )
          categories.forEach { (cat, label, icon) ->
            FilterChip(
              selected = state.category == cat,
              onClick = { viewModel.setCategory(cat) },
              label = { Text(label) },
              leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
            )
          }
        }
      }

      item {
        // Source Files Card
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(strings.sourceFileLabel, style = MaterialTheme.typography.titleMedium)
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (state.sourceFiles.isNotEmpty()) {
                  IconButton(onClick = { viewModel.clearFiles() }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Clear, contentDescription = strings.clearSelection, modifier = Modifier.size(18.dp))
                  }
                }
                OutlinedButton(
                  onClick = { filePicker.launch(arrayOf("*/*")) },
                  modifier = Modifier.testTag("converter_pick_files_btn"),
                ) {
                  Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(Modifier.size(4.dp))
                  Text(strings.pickFiles)
                }
              }
            }
            if (state.sourceFiles.isEmpty()) {
              Text(
                strings.emptyFolderHint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            } else {
              state.sourceFiles.forEach { file ->
                Text(
                  "• ${file.name} (${formatFileSize(file.length())})",
                  style = MaterialTheme.typography.bodySmall,
                )
              }
            }
          }
        }
      }

      item {
        // Target Options Card
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(strings.targetFormatLabel, style = MaterialTheme.typography.titleMedium)

            when (state.category) {
              ConversionCategory.VIDEO_TO_AUDIO -> {
                AudioTargetFormat.entries.forEach { fmt ->
                  FilterChip(
                    selected = state.audioFormat == fmt,
                    onClick = { viewModel.setAudioFormat(fmt) },
                    label = { Text(fmt.label) },
                  )
                }
                QualityNoticeBadge(
                  isLossless = state.audioFormat.isLossless,
                  text = if (state.audioFormat.isLossless) strings.conversionLosslessNote else strings.conversionLossyNote,
                )
              }

              ConversionCategory.IMAGES_TO_PDF -> {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Text("A4 Page Fit (vs Original Dimensions)", style = MaterialTheme.typography.bodyMedium)
                  Switch(checked = state.pdfA4Fixed, onCheckedChange = { viewModel.setPdfA4Fixed(it) })
                }
                QualityNoticeBadge(isLossless = true, text = strings.conversionLosslessNote)
              }

              ConversionCategory.PDF_TO_IMAGES,
              ConversionCategory.IMAGE_TO_IMAGE -> {
                Row(
                  modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  ImageOutputFormat.entries.forEach { fmt ->
                    FilterChip(
                      selected = state.imageFormat == fmt,
                      onClick = { viewModel.setImageFormat(fmt) },
                      label = { Text(fmt.label) },
                    )
                  }
                }
                if (!state.imageFormat.supportsLossless) {
                  Text("${strings.imageQualityLabel}: ${state.imageQuality}%", style = MaterialTheme.typography.bodySmall)
                  Slider(
                    value = state.imageQuality.toFloat(),
                    onValueChange = { viewModel.setImageQuality(it.roundToInt()) },
                    valueRange = 10f..95f,
                  )
                }
                QualityNoticeBadge(
                  isLossless = state.imageFormat.supportsLossless,
                  text = if (state.imageFormat.supportsLossless) strings.conversionLosslessNote else strings.conversionLossyNote,
                )
              }

              ConversionCategory.TEXT_DATA -> {
                Row(
                  modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  TextTargetFormat.entries.forEach { fmt ->
                    FilterChip(
                      selected = state.textFormat == fmt,
                      onClick = { viewModel.setTextFormat(fmt) },
                      label = { Text(fmt.label) },
                    )
                  }
                }
              }

              ConversionCategory.ARCHIVE_TO_ARCHIVE -> {
                Row(
                  modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  ArchiveFormat.creatableFormats.forEach { fmt ->
                    FilterChip(
                      selected = state.archiveFormat == fmt,
                      onClick = { viewModel.setArchiveFormat(fmt) },
                      label = { Text(fmt.displayName) },
                    )
                  }
                }
                Text("${strings.compressionLevelLabel}: ${state.archiveLevel}/9", style = MaterialTheme.typography.bodySmall)
                Slider(
                  value = state.archiveLevel.toFloat(),
                  onValueChange = { viewModel.setArchiveLevel(it.roundToInt()) },
                  valueRange = 0f..9f,
                  steps = 8,
                )
                QualityNoticeBadge(isLossless = true, text = strings.conversionLosslessNote)
              }
            }

            if (state.isRunning) {
              LinearProgressIndicator(progress = { state.progress / 100f }, modifier = Modifier.fillMaxWidth())
            }

            state.resultMessage?.let { msg ->
              Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = MaterialTheme.shapes.small,
              ) {
                Text(
                  text = msg,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                  modifier = Modifier.fillMaxWidth().padding(10.dp),
                )
              }
            }

            Button(
              onClick = { viewModel.runConversion() },
              enabled = state.sourceFiles.isNotEmpty() && !state.isRunning,
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("run_conversion_btn"),
            ) {
              Icon(Icons.Default.Transform, contentDescription = null)
              Spacer(Modifier.size(8.dp))
              Text(strings.startConversion)
            }
          }
        }
      }

      if (history.isNotEmpty()) {
        item {
          HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
          Text(strings.conversionHistory, style = MaterialTheme.typography.titleMedium)
        }
        items(history.take(15)) { entry ->
          Surface(
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            shape = MaterialTheme.shapes.small,
          ) {
            Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
              Text("${entry.title} • ${entry.sourcePath}", style = MaterialTheme.typography.labelLarge)
              Text(entry.details, style = MaterialTheme.typography.bodySmall, color = extra.losslessGreen)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun QualityNoticeBadge(isLossless: Boolean, text: String) {
  val extra = LocalVortexExtraColors.current
  val color = if (isLossless) extra.losslessGreen else extra.lossyWarning
  Surface(
    color = color.copy(alpha = 0.14f),
    shape = MaterialTheme.shapes.small,
    border = BorderStroke(1.dp, color.copy(alpha = 0.45f)),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        if (isLossless) Icons.Default.VerifiedUser else Icons.Default.WarningAmber,
        contentDescription = null,
        tint = color,
      )
      Text(text, style = MaterialTheme.typography.bodySmall, color = color)
    }
  }
}

private fun copyUriToWorkspaceCache(context: Context, uri: Uri): File? {
  return runCatching {
    var displayName = "imported_${System.currentTimeMillis()}"
    context.contentResolver.query(uri, null, null, null, null)?.use { c ->
      val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
      if (idx >= 0 && c.moveToFirst()) displayName = c.getString(idx) ?: displayName
    }
    val cacheDir = File(context.cacheDir, "converter_inputs").apply { mkdirs() }
    val outFile = File(cacheDir, displayName)
    context.contentResolver.openInputStream(uri)?.use { inp ->
      FileOutputStream(outFile).use { out -> inp.copyTo(out) }
    }
    outFile
  }.getOrNull()
}
