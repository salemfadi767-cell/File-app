package com.example.ui.theme

import androidx.compose.ui.graphics.Color

enum class ThemePreset(val id: String) {
  CYBER_EMERALD("cyber_emerald"),
  MIDNIGHT_COBALT("midnight_cobalt"),
  AMOLED_OBSIDIAN("amoled_obsidian"),
  MATERIAL_LIGHT("material_light"),
}

enum class AccentStyle(val id: String, val darkColor: Color, val lightColor: Color) {
  DEFAULT("default", Color(0xFF00E5A3), Color(0xFF007A5A)),
  EMERALD("emerald", Color(0xFF00E5A3), Color(0xFF007A5A)),
  AMBER_GOLD("amber_gold", Color(0xFFF5B041), Color(0xFFB4690E)),
  NEON_COBALT("neon_cobalt", Color(0xFF38BDF8), Color(0xFF0284C7)),
  ELECTRIC_VIOLET("electric_violet", Color(0xFFA78BFA), Color(0xFF6D28D9)),
  CRIMSON_CORAL("crimson_coral", Color(0xFFFF5C77), Color(0xFFBE123C)),
}

// Cyber Emerald (Default Dark Workbench)
val CyberBg = Color(0xFF0B1016)
val CyberSurface = Color(0xFF121923)
val CyberSurfaceElevated = Color(0xFF1A2433)
val CyberSurfaceHigh = Color(0xFF222F42)
val CyberEmeraldPrimary = Color(0xFF00E5A3)
val CyberGoldSecondary = Color(0xFFF5B041)
val CyberCyanTertiary = Color(0xFF38BDF8)
val CyberTextPrimary = Color(0xFFEBF2FA)
val CyberTextMuted = Color(0xFF8B9BB4)
val CyberOutline = Color(0xFF2B3A4F)

// Midnight Cobalt
val CobaltBg = Color(0xFF080D17)
val CobaltSurface = Color(0xFF101829)
val CobaltSurfaceElevated = Color(0xFF17233B)
val CobaltPrimary = Color(0xFF38BDF8)
val CobaltSecondary = Color(0xFF818CF8)
val CobaltTertiary = Color(0xFF2DD4BF)

// AMOLED Obsidian
val AmoledBg = Color(0xFF000000)
val AmoledSurface = Color(0xFF0A0D12)
val AmoledSurfaceElevated = Color(0xFF131822)
val AmoledOutline = Color(0xFF1F2937)

// Material Light
val LightBg = Color(0xFFF3F6FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFE9EFF6)
val LightPrimary = Color(0xFF007A5A)
val LightSecondary = Color(0xFFC77700)
val LightTertiary = Color(0xFF0284C7)
val LightTextPrimary = Color(0xFF101828)
val LightTextMuted = Color(0xFF526077)
val LightOutline = Color(0xFFD0D9E6)

// Semantic Status Colors
val LosslessGreenDark = Color(0xFF10B981)
val LosslessGreenLight = Color(0xFF059669)
val LossyCoralDark = Color(0xFFFF5C77)
val LossyCoralLight = Color(0xFFE11D48)
val ShizukuCyanDark = Color(0xFF38BDF8)
val ShizukuCyanLight = Color(0xFF0284C7)
val RootGoldDark = Color(0xFFF5B041)
val RootGoldLight = Color(0xFFD97706)
