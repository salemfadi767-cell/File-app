package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.db.PlaylistEntity
import com.example.domain.media.EqBandUi
import com.example.domain.media.EqPreset
import com.example.domain.media.OnlineLyricsHit
import com.example.domain.media.ReverbPresetMode
import com.example.i18n.LocalAppStrings
import com.example.ui.theme.LocalVortexExtraColors
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundBoosterAndEqSheet(
  loudnessGainMb: Int,
  bassStrength: Int,
  eqBands: List<EqBandUi>,
  eq10Bands: List<EqBandUi>,
  use10BandEq: Boolean,
  activePreset: EqPreset,
  reverbMode: ReverbPresetMode,
  onLoudnessChange: (Int) -> Unit,
  onBassChange: (Int) -> Unit,
  onSelectPreset: (EqPreset) -> Unit,
  onReverbChange: (ReverbPresetMode) -> Unit,
  onToggle10Band: (Boolean) -> Unit,
  onBandLevelChange: (Int, Int) -> Unit,
  onBand10LevelChange: (Int, Int) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp)
          .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.GraphicEq, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Text(strings.soundBoosterTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer,
          shape = MaterialTheme.shapes.small,
        ) {
          Text(
            text = "+${String.format(Locale.US, "%.1f", loudnessGainMb / 100f)} dB",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      // Loudness Enhancer Slider (0..20 dB)
      Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text(strings.loudnessBoostLabel, style = MaterialTheme.typography.bodyMedium)
          Text(
            "${(loudnessGainMb / 20f).roundToInt()}%",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
          )
        }
        Slider(
          value = loudnessGainMb.toFloat(),
          onValueChange = { onLoudnessChange(it.roundToInt()) },
          valueRange = 0f..2000f,
          modifier = Modifier.testTag("music_loudness_slider"),
        )
      }

      // Bass Boost Slider (0..1000)
      Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text(strings.bassBoostLabel, style = MaterialTheme.typography.bodyMedium)
          Text(
            "${(bassStrength / 10f).roundToInt()}%",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.secondary,
          )
        }
        Slider(
          value = bassStrength.toFloat(),
          onValueChange = { onBassChange(it.roundToInt()) },
          valueRange = 0f..1000f,
          modifier = Modifier.testTag("music_bass_slider"),
        )
      }

      // Spatial Reverb Presets (Lark Player Style)
      Text(strings.reverbLabel, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        ReverbPresetMode.entries.forEach { rev ->
          FilterChip(
            selected = reverbMode == rev,
            onClick = { onReverbChange(rev) },
            label = { Text(rev.label) },
          )
        }
      }

      HorizontalDivider()

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(strings.equalizerTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          FilterChip(selected = !use10BandEq, onClick = { onToggle10Band(false) }, label = { Text("5-Band") })
          FilterChip(selected = use10BandEq, onClick = { onToggle10Band(true) }, label = { Text("10-Band") })
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        EqPreset.entries.forEach { preset ->
          FilterChip(
            selected = activePreset == preset,
            onClick = { onSelectPreset(preset) },
            label = { Text(preset.label) },
          )
        }
      }

      val shownBands = if (use10BandEq) eq10Bands else eqBands
      shownBands.forEach { band ->
        val freqLabel =
          if (band.centerFreqHz >= 1000) "${String.format(Locale.US, "%.1f", band.centerFreqHz / 1000f)} kHz"
          else "${band.centerFreqHz} Hz"
        val dbValue = band.currentLevelMb / 100f
        Column(modifier = Modifier.fillMaxWidth()) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(freqLabel, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface)
            Text(
              text = "${if (dbValue >= 0) "+" else ""}${String.format(Locale.US, "%.1f", dbValue)} dB",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary,
            )
          }
          Slider(
            value = band.currentLevelMb.toFloat(),
            onValueChange = {
              if (use10BandEq) onBand10LevelChange(band.index, it.roundToInt())
              else onBandLevelChange(band.index, it.roundToInt())
            },
            valueRange = band.minLevelMb.toFloat()..band.maxLevelMb.toFloat(),
          )
        }
      }

      Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
        Text(strings.close)
      }
      Spacer(Modifier.height(8.dp))
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoverVisualEnhanceSheet(
  brightness: Float,
  contrast: Float,
  saturation: Float,
  glowEnabled: Boolean,
  onChange: (brightness: Float, contrast: Float, saturation: Float, glow: Boolean) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp)
          .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(strings.enhancePicture, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      }

      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        FilterChip(
          selected = brightness == 0f && contrast == 1f && saturation == 1f,
          onClick = { onChange(0f, 1f, 1f, glowEnabled) },
          label = { Text("Original") },
        )
        FilterChip(
          selected = false,
          onClick = { onChange(10f, 1.2f, 1.45f, true) },
          label = { Text("Vivid Glow") },
        )
        FilterChip(
          selected = false,
          onClick = { onChange(4f, 1.25f, 1.15f, true) },
          label = { Text("Crisp HD") },
        )
        FilterChip(
          selected = false,
          onClick = { onChange(-6f, 1.3f, 0f, false) },
          label = { Text("Noir B&W") },
        )
      }

      Text("${strings.brightnessLabel}: ${brightness.roundToInt()}", style = MaterialTheme.typography.bodySmall)
      Slider(
        value = brightness,
        onValueChange = { onChange(it, contrast, saturation, glowEnabled) },
        valueRange = -60f..60f,
      )

      Text("${strings.contrastLabel}: ${String.format(Locale.US, "%.2f", contrast)}", style = MaterialTheme.typography.bodySmall)
      Slider(
        value = contrast,
        onValueChange = { onChange(brightness, it, saturation, glowEnabled) },
        valueRange = 0.6f..1.8f,
      )

      Text("${strings.saturationLabel}: ${String.format(Locale.US, "%.2f", saturation)}", style = MaterialTheme.typography.bodySmall)
      Slider(
        value = saturation,
        onValueChange = { onChange(brightness, contrast, it, glowEnabled) },
        valueRange = 0f..2f,
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text("Ambient Aura Glow", style = MaterialTheme.typography.bodyMedium)
        Switch(
          checked = glowEnabled,
          onCheckedChange = { onChange(brightness, contrast, saturation, it) },
        )
      }

      Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
        Text(strings.confirm)
      }
      Spacer(Modifier.height(8.dp))
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SleepTimerSheet(
  remainingMs: Long,
  stopAfterCurrentTrack: Boolean,
  onStartMinutes: (Int) -> Unit,
  onToggleStopAfterTrack: (Boolean) -> Unit,
  onCancelTimer: () -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  var customMinutes by remember { mutableStateOf("20") }

  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.Timer, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(strings.sleepTimerTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      }

      if (remainingMs > 0L) {
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer,
          shape = MaterialTheme.shapes.small,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            val sec = (remainingMs / 1000L).toInt()
            Text(
              text = String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60),
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.Bold,
            )
            OutlinedButton(onClick = onCancelTimer) {
              Text(strings.sleepTimerOff)
            }
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        listOf(10, 15, 30, 45, 60).forEach { mins ->
          FilterChip(
            selected = false,
            onClick = {
              onStartMinutes(mins)
              onDismiss()
            },
            label = { Text("${mins}m") },
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        OutlinedTextField(
          value = customMinutes,
          onValueChange = { txt -> customMinutes = txt.filter { it.isDigit() }.take(3) },
          label = { Text("Minutes") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.weight(1f),
        )
        Button(
          onClick = {
            val m = customMinutes.toIntOrNull()?.coerceIn(1, 360) ?: 15
            onStartMinutes(m)
            onDismiss()
          },
          modifier = Modifier.height(52.dp),
        ) {
          Text(strings.confirm)
        }
      }

      HorizontalDivider()

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(strings.stopAfterTrack, style = MaterialTheme.typography.bodyMedium)
        Switch(
          checked = stopAfterCurrentTrack,
          onCheckedChange = {
            onToggleStopAfterTrack(it)
            if (it) onDismiss()
          },
        )
      }
      Spacer(Modifier.height(8.dp))
    }
  }
}

@Composable
fun OnlineLyricsSearchDialog(
  initialTrack: String,
  initialArtist: String,
  isSearching: Boolean,
  hits: List<OnlineLyricsHit>,
  onSearch: (String, String) -> Unit,
  onSelectHit: (OnlineLyricsHit) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val extra = LocalVortexExtraColors.current
  var trackQuery by remember(initialTrack) { mutableStateOf(initialTrack) }
  var artistQuery by remember(initialArtist) {
    mutableStateOf(if (initialArtist.equals("Unknown Artist", ignoreCase = true)) "" else initialArtist)
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.searchLyricsOnline) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
          value = trackQuery,
          onValueChange = { trackQuery = it },
          label = { Text("Track / Title") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = artistQuery,
          onValueChange = { artistQuery = it },
          label = { Text("Artist") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        Button(
          onClick = { onSearch(trackQuery, artistQuery) },
          enabled = !isSearching && trackQuery.isNotBlank(),
          modifier = Modifier.fillMaxWidth().testTag("lyrics_online_search_btn"),
        ) {
          Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(6.dp))
          Text(strings.searchLyricsOnline)
        }

        if (isSearching) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(strings.lyricsSearching, style = MaterialTheme.typography.bodySmall)
          }
        }

        LazyColumn(
          modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          items(hits, key = { it.id }) { hit ->
            Surface(
              color = MaterialTheme.colorScheme.surfaceContainer,
              shape = MaterialTheme.shapes.small,
              modifier =
                Modifier
                  .fillMaxWidth()
                  .clickable {
                    onSelectHit(hit)
                    onDismiss()
                  },
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(hit.trackName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                  Text(
                    text = listOfNotNull(hit.artistName.takeIf { it.isNotBlank() }, hit.albumName.takeIf { it.isNotBlank() }).joinToString(" • "),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
                Spacer(Modifier.width(6.dp))
                Surface(
                  color =
                    if (hit.hasSyncedTimestamps) extra.losslessGreen.copy(alpha = 0.2f)
                    else MaterialTheme.colorScheme.surfaceContainerHigh,
                  shape = MaterialTheme.shapes.extraSmall,
                ) {
                  Text(
                    text = if (hit.hasSyncedTimestamps) "SYNC LRC" else "PLAIN",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (hit.hasSyncedTimestamps) extra.losslessGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                  )
                }
              }
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text(strings.close) }
    },
  )
}

@Composable
fun NewPlaylistDialog(
  title: String,
  onConfirm: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  var name by remember { mutableStateOf("") }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title) },
    text = {
      OutlinedTextField(
        value = name,
        onValueChange = { name = it },
        label = { Text(strings.createPlaylist) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )
    },
    confirmButton = {
      Button(
        onClick = {
          if (name.isNotBlank()) {
            onConfirm(name.trim())
            onDismiss()
          }
        },
        enabled = name.isNotBlank(),
      ) {
        Text(strings.confirm)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(strings.cancel) }
    },
  )
}

@Composable
fun AddToPlaylistDialog(
  playlists: List<PlaylistEntity>,
  onPickPlaylist: (PlaylistEntity) -> Unit,
  onCreateAndAdd: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  var newName by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.addToPlaylist) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          OutlinedTextField(
            value = newName,
            onValueChange = { newName = it },
            label = { Text(strings.createPlaylist) },
            singleLine = true,
            modifier = Modifier.weight(1f),
          )
          Button(
            onClick = {
              if (newName.isNotBlank()) {
                onCreateAndAdd(newName.trim())
                onDismiss()
              }
            },
            enabled = newName.isNotBlank(),
            modifier = Modifier.height(50.dp),
          ) {
            Icon(Icons.Default.Add, contentDescription = strings.createPlaylist)
          }
        }

        if (playlists.isNotEmpty()) {
          HorizontalDivider()
          LazyColumn(
            modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            items(playlists, key = { it.id }) { pl ->
              Surface(
                color = MaterialTheme.colorScheme.surfaceContainer,
                shape = MaterialTheme.shapes.small,
                modifier =
                  Modifier
                    .fillMaxWidth()
                    .clickable {
                      onPickPlaylist(pl)
                      onDismiss()
                    },
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                  Text(pl.name, style = MaterialTheme.typography.titleSmall)
                }
              }
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text(strings.close) }
    },
  )
}
