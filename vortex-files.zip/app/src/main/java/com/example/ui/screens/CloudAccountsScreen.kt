package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.VortexAppContainer
import com.example.data.db.CloudAccountEntity
import com.example.domain.cloud.CloudProtocol
import com.example.domain.cloud.CloudStorageClient
import com.example.i18n.LocalAppStrings
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CloudAccountsScreen(
  container: VortexAppContainer,
  onBrowseCloudUri: (String) -> Unit,
  onBack: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val scope = rememberCoroutineScope()
  val snackbar = remember { SnackbarHostState() }

  val accounts by container.database.cloudAccountDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
  var showAddDialog by remember { mutableStateOf(false) }

  var label by remember { mutableStateOf("") }
  var selectedProtocol by remember { mutableStateOf(CloudProtocol.WEBDAV) }
  var hostUrl by remember { mutableStateOf("https://") }
  var username by remember { mutableStateOf("") }
  var secret by remember { mutableStateOf("") }
  var basePath by remember { mutableStateOf("/") }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(snackbar) },
    topBar = {
      TopAppBar(
        title = { Text(strings.cloudAccountsTitle, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("cloud_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
          }
        },
      )
    },
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        modifier = Modifier.navigationBarsPadding().testTag("add_cloud_account_fab"),
      ) {
        Icon(Icons.Default.Add, contentDescription = strings.addCloudAccount)
      }
    },
  ) { padding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(padding).navigationBarsPadding(),
      contentAlignment = Alignment.TopCenter,
    ) {
      LazyColumn(
        modifier = Modifier.fillMaxSize().widthIn(max = 780.dp).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        if (accounts.isEmpty()) {
          item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
              Column(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Cloud, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text(strings.cloudAccountsTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                  "Connect your email-linked cloud drives (OneDrive, Dropbox, Yandex Disk, Nextcloud, OwnCloud, WebDAV, FTP, or HTTP Bearer) without Google Drive and manage files inside any pane.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = { showAddDialog = true }) { Text(strings.addCloudAccount) }
              }
            }
          }
        } else {
          items(accounts, key = { it.id }) { acc ->
            Card(
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
              shape = RoundedCornerShape(14.dp),
            ) {
              Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(acc.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(
                      "${acc.protocol} • ${acc.hostUrl}",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                  IconButton(onClick = { scope.launch { container.database.cloudAccountDao().deleteById(acc.id) } }) {
                    Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                  }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  OutlinedButton(
                    onClick = {
                      scope.launch {
                        val res = container.cloudClient.testConnection(acc)
                        snackbar.showSnackbar(res.getOrElse { it.message ?: "Connection failed" })
                      }
                    },
                    modifier = Modifier.weight(1f),
                  ) {
                    Icon(Icons.Default.NetworkCheck, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Test")
                  }
                  Button(
                    onClick = {
                      onBrowseCloudUri(CloudStorageClient.buildCloudUri(acc.id, acc.basePath))
                    },
                    modifier = Modifier.weight(1f).testTag("browse_cloud_${acc.id}"),
                  ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(strings.browseCloud)
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showAddDialog) {
    AlertDialog(
      onDismissRequest = { showAddDialog = false },
      title = { Text(strings.addCloudAccount) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CloudProtocol.entries.forEach { proto ->
              FilterChip(
                selected = selectedProtocol == proto,
                onClick = {
                  selectedProtocol = proto
                  hostUrl = proto.defaultHost
                  if (label.isBlank()) label = proto.displayName
                },
                label = { Text(proto.displayName) },
              )
            }
          }
          OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Account Name") }, singleLine = true)
          OutlinedTextField(value = hostUrl, onValueChange = { hostUrl = it }, label = { Text("Host / API Base URL") }, singleLine = true)
          OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text(if (selectedProtocol.usesBearerToken) "Account Email" else "Email / Username") },
            singleLine = true,
          )
          OutlinedTextField(
            value = secret,
            onValueChange = { secret = it },
            label = { Text(if (selectedProtocol.usesBearerToken) "OAuth Access Token" else "Password / App Password") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
          )
          OutlinedTextField(value = basePath, onValueChange = { basePath = it }, label = { Text("Root Path") }, singleLine = true)
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (label.isNotBlank() && hostUrl.isNotBlank()) {
              scope.launch {
                container.database.cloudAccountDao().insert(
                  CloudAccountEntity(
                    label = label.trim(),
                    protocol = selectedProtocol.id,
                    hostUrl = hostUrl.trim(),
                    username = username.trim(),
                    secretOrToken = secret.trim(),
                    basePath = basePath.ifBlank { "/" },
                  )
                )
                label = ""; username = ""; secret = ""; basePath = "/"
                showAddDialog = false
              }
            }
          }
        ) { Text(strings.confirm) }
      },
      dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text(strings.cancel) } },
    )
  }
}
