package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.domain.download.ExtractedMediaStream
import com.example.domain.download.UniversalDownloadEngine
import com.example.domain.fs.EditBackupManager
import com.example.domain.fs.FileCategory
import com.example.domain.fs.VirtualFileNode
import com.example.domain.media.AiPhotoStudioEngine
import com.example.domain.media.DlnaCastManager
import com.example.domain.media.DlnaDevice
import com.example.domain.media.LyricsEngine
import com.example.domain.media.MediaCastService
import com.example.domain.media.OnlineLyricsService
import com.example.domain.media.OnlineSubtitleHit
import com.example.domain.media.OnlineSubtitleService
import com.example.domain.media.SubtitleAutoMatcher
import com.example.domain.media.SubtitleCue
import com.example.domain.media.SubtitleEngine
import com.example.domain.media.SubtitleStyleConfig
import com.example.domain.media.VideoCastPresentation
import com.example.domain.media.VideoEditorEngine
import com.example.i18n.LocalAppStrings
import com.example.ui.components.AiPhotoStudioSheet
import com.example.ui.components.AudioDubbingSheet
import com.example.ui.components.EmbeddedWebVideoPlayer
import com.example.ui.components.OnlineSubtitleSearchDialog
import com.example.ui.components.ScreenCastSheet
import com.example.ui.components.SubtitleManagerSheet
import com.example.ui.components.VideoEnhancementSheet
import com.example.ui.components.VideoStudioSheet
import com.example.ui.theme.MonoFontFamily
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@kotlin.OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewerScreen(
  filePath: String,
  forcedMode: String = "auto",
  onlineSubtitleService: OnlineSubtitleService,
  onlineLyricsService: OnlineLyricsService? = null,
  autoSubtitlesEnabled: Boolean = true,
  subtitlesFolderPath: String = "",
  subtitleLanguages: List<String> = listOf("ar", "en"),
  autoBackupOnEditEnabled: Boolean = false,
  companionDownloaderUrl: String = "",
  aiPhotoStudioEngine: AiPhotoStudioEngine? = null,
  videoEditorEngine: VideoEditorEngine? = null,
  downloadEngine: UniversalDownloadEngine? = null,
  onEnterPiP: () -> Unit,
  onOpenEditor: (String, Boolean) -> Unit,
  onOpenApkInspector: (String) -> Unit = {},
  onOpenExternal: (String) -> Unit = {},
  onDownloadStream: (String) -> Unit = {},
  onBack: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val focusManager = LocalFocusManager.current
  var activePath by remember(filePath) { mutableStateOf(filePath) }
  var activeMode by remember(forcedMode, filePath) { mutableStateOf(forcedMode) }
  var showReadAsMenu by remember { mutableStateOf(false) }

  DisposableEffect(Unit) {
    onDispose { focusManager.clearFocus(force = true) }
  }

  BackHandler {
    focusManager.clearFocus(force = true)
    onBack()
  }

  val isRemoteStream =
    remember(activePath) {
      activePath.startsWith("http://", ignoreCase = true) ||
        activePath.startsWith("https://", ignoreCase = true) ||
        activePath.startsWith("rtsp://", ignoreCase = true)
    }
  val needsPreResolve =
    remember(activePath, isRemoteStream) {
      isRemoteStream && !UniversalDownloadEngine.isDirectPlayableMediaUrl(activePath)
    }
  var isResolvingStream by remember(activePath) { mutableStateOf(needsPreResolve) }
  var resolvedStreams by remember(activePath) { mutableStateOf<List<ExtractedMediaStream>>(emptyList()) }
  var selectedStreamIdx by remember(activePath) { mutableIntStateOf(0) }
  var resolvedStreamUrl by remember(activePath) { mutableStateOf<String?>(null) }
  var streamResolveNote by remember(activePath) { mutableStateOf<String?>(null) }
  var useWebFallback by remember(activePath) { mutableStateOf(false) }
  var sniffedWebStreamUrl by remember(activePath) { mutableStateOf<String?>(null) }
  val file = remember(activePath) { File(activePath) }
  val node =
    remember(activePath, isRemoteStream) {
      val name =
        if (isRemoteStream) activePath.substringAfterLast('/').substringBefore('?').ifBlank { "Web Stream" }
        else file.name
      VirtualFileNode(
        name = name,
        path = activePath,
        isDirectory = false,
        size = if (isRemoteStream) 0L else file.length(),
        lastModified = if (isRemoteStream) 0L else file.lastModified(),
      )
    }

  val resolvedCategory =
    when (activeMode) {
      "image" -> FileCategory.IMAGE
      "video" -> FileCategory.VIDEO
      "audio" -> FileCategory.AUDIO
      "pdf" -> FileCategory.PDF
      "db" -> FileCategory.DATABASE
      else -> if (isRemoteStream) FileCategory.VIDEO else node.category
    }

  // Sibling media navigation for Gallery & Video folder browsing
  val siblingMedia =
    remember(activePath, resolvedCategory, isRemoteStream) {
      if (isRemoteStream || resolvedCategory !in setOf(FileCategory.IMAGE, FileCategory.VIDEO)) {
        emptyList()
      } else {
        val parent = file.parentFile
        parent?.listFiles()
          ?.asSequence()
          ?.filter { it.isFile }
          ?.map {
            VirtualFileNode(
              name = it.name,
              path = it.absolutePath,
              isDirectory = false,
              size = it.length(),
              lastModified = it.lastModified(),
            )
          }
          ?.filter { it.category == resolvedCategory }
          ?.sortedBy { it.name.lowercase() }
          ?.map { it.path }
          ?.toList()
          ?: emptyList()
      }
    }
  val siblingIndex = siblingMedia.indexOf(activePath)

  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      TopAppBar(
        modifier = Modifier.statusBarsPadding(),
        title = {
          Text(node.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
        },
        navigationIcon = {
          IconButton(
            onClick = {
              focusManager.clearFocus(force = true)
              onBack()
            },
            modifier = Modifier.testTag("viewer_back_btn"),
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        actions = {
          if (isRemoteStream) {
            IconButton(
              onClick = {
                focusManager.clearFocus(force = true)
                val target = sniffedWebStreamUrl ?: activePath
                onDownloadStream(target)
              },
              modifier = Modifier.testTag("viewer_download_stream_btn"),
            ) {
              Icon(Icons.Default.Download, contentDescription = strings.downloadActiveStream)
            }
          } else {
            Box {
              IconButton(
                onClick = { showReadAsMenu = true },
                modifier = Modifier.testTag("viewer_read_as_btn"),
              ) {
                Icon(Icons.Default.Transform, contentDescription = strings.readAsTitle)
              }
              DropdownMenu(expanded = showReadAsMenu, onDismissRequest = { showReadAsMenu = false }) {
                DropdownMenuItem(
                  text = { Text(strings.readAsCode) },
                  onClick = { activeMode = "text"; showReadAsMenu = false },
                )
                DropdownMenuItem(
                  text = { Text(strings.readAsHex) },
                  onClick = { activeMode = "hex"; showReadAsMenu = false },
                )
                DropdownMenuItem(
                  text = { Text(strings.readAsImage) },
                  onClick = { activeMode = "image"; showReadAsMenu = false },
                )
                DropdownMenuItem(
                  text = { Text(strings.readAsVideo) },
                  onClick = { activeMode = "video"; showReadAsMenu = false },
                )
                DropdownMenuItem(
                  text = { Text(strings.readAsAudio) },
                  onClick = { activeMode = "audio"; showReadAsMenu = false },
                )
                DropdownMenuItem(
                  text = { Text(strings.readAsPdf) },
                  onClick = { activeMode = "pdf"; showReadAsMenu = false },
                )
                DropdownMenuItem(
                  text = { Text(strings.readAsDatabase) },
                  onClick = { activeMode = "db"; showReadAsMenu = false },
                )
                HorizontalDivider()
                DropdownMenuItem(
                  text = { Text(strings.openInEditor) },
                  onClick = { showReadAsMenu = false; onOpenEditor(activePath, false) },
                )
                DropdownMenuItem(
                  text = { Text(strings.readAsApk) },
                  onClick = { showReadAsMenu = false; onOpenApkInspector(activePath) },
                )
              }
            }
            IconButton(
              onClick = { onOpenExternal(activePath) },
              modifier = Modifier.testTag("viewer_open_external_btn"),
            ) {
              Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = strings.openWithExternalApp)
            }
          }
        },
      )
    },
  ) { innerPadding ->
    Box(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .navigationBarsPadding(),
    ) {
      when {
        activeMode == "text" ->
          TextPreviewView(
            file = file,
            onOpenInCodeIde = { onOpenEditor(activePath, false) },
          )

        activeMode == "hex" -> {
          var bytes by remember { mutableStateOf(ByteArray(0)) }
          LaunchedEffect(activePath) {
            bytes = withContext(Dispatchers.IO) { runCatching { file.readBytes().take(65536).toByteArray() }.getOrDefault(ByteArray(0)) }
          }
          HexInspectorView(bytes)
        }

        resolvedCategory == FileCategory.IMAGE ->
          AdvancedImageViewer(
            file = file,
            autoBackupOnEditEnabled = autoBackupOnEditEnabled,
            aiPhotoStudioEngine = aiPhotoStudioEngine,
            onSavedNewImage = { newPath -> activePath = newPath },
            onMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } },
          )

        resolvedCategory == FileCategory.VIDEO ||
          resolvedCategory == FileCategory.AUDIO -> {
          LaunchedEffect(activePath, needsPreResolve) {
            if (!needsPreResolve) {
              isResolvingStream = false
              resolvedStreams = emptyList()
              resolvedStreamUrl = null
              streamResolveNote = null
              useWebFallback = false
              return@LaunchedEffect
            }
            if (downloadEngine == null) {
              isResolvingStream = false
              useWebFallback = true
              return@LaunchedEffect
            }
            isResolvingStream = true
            val res = runCatching { downloadEngine.resolveMediaLinks(activePath, companionDownloaderUrl) }.getOrNull()
            val playable = res?.streams.orEmpty().filter { !it.isDrmProtected }
            resolvedStreams = playable
            streamResolveNote = res?.note
            val bestIdx = playable.indexOfFirst { (it.hasVideo && it.hasAudio) || it.isHls }
              .takeIf { it >= 0 } ?: if (playable.isNotEmpty()) 0 else -1
            if (bestIdx >= 0) {
              selectedStreamIdx = bestIdx
              resolvedStreamUrl = playable[bestIdx].url
              useWebFallback = false
            } else {
              resolvedStreamUrl = null
              useWebFallback = true
            }
            isResolvingStream = false
          }

          Column(modifier = Modifier.fillMaxSize()) {
            if (!streamResolveNote.isNullOrBlank()) {
              Surface(color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
                Text(
                  streamResolveNote!!,
                  style = MaterialTheme.typography.labelSmall,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                )
              }
            }
            when {
              isResolvingStream -> {
                Box(
                  modifier = Modifier.fillMaxSize().background(Color.Black),
                  contentAlignment = Alignment.Center,
                ) {
                  Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(24.dp),
                  ) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    Text(
                      strings.resolvingStreamLabel,
                      color = Color.White,
                      style = MaterialTheme.typography.bodyMedium,
                    )
                    OutlinedButton(
                      onClick = {
                        isResolvingStream = false
                        useWebFallback = true
                      },
                      modifier = Modifier.testTag("viewer_switch_web_while_resolving"),
                    ) {
                      Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                      Spacer(Modifier.width(6.dp))
                      Text(strings.webPlayerMode)
                    }
                  }
                }
              }

              useWebFallback -> {
                Column(modifier = Modifier.fillMaxSize()) {
                  EmbeddedWebVideoPlayer(
                    url = activePath,
                    onStreamCaptured = { capturedUrl ->
                      if (sniffedWebStreamUrl.isNullOrBlank()) {
                        sniffedWebStreamUrl = capturedUrl
                      }
                    },
                    modifier = Modifier.weight(1f),
                  )
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .background(MaterialTheme.colorScheme.surfaceContainer)
                      .horizontalScroll(rememberScrollState())
                      .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    if (resolvedStreams.isNotEmpty() || !sniffedWebStreamUrl.isNullOrBlank()) {
                      FilterChip(
                        selected = false,
                        onClick = {
                          if (resolvedStreams.isEmpty() && !sniffedWebStreamUrl.isNullOrBlank()) {
                            resolvedStreamUrl = sniffedWebStreamUrl
                          }
                          useWebFallback = false
                        },
                        label = { Text("ExoPlayer") },
                      )
                    }
                    FilterChip(
                      selected = false,
                      onClick = { onDownloadStream(sniffedWebStreamUrl ?: activePath) },
                      label = { Text(strings.downloadActiveStream) },
                      leadingIcon = { Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    )
                  }
                }
              }

              else -> {
                val activeStreamObj = resolvedStreams.getOrNull(selectedStreamIdx)
                val activePlayableUrl = activeStreamObj?.url ?: resolvedStreamUrl ?: activePath
                val activeHeaders = remember(activePlayableUrl, activeStreamObj) {
                  downloadEngine?.getHeadersForUrl(activePlayableUrl, activeStreamObj) ?: emptyMap()
                }
                AdvancedMedia3PlayerView(
                  source = activePlayableUrl,
                  rawOriginalSource = sniffedWebStreamUrl ?: activePath,
                  displayTitle = node.name,
                  isRemoteStream = isRemoteStream,
                  streamHeaders = activeHeaders,
                  isAudioMode = resolvedCategory == FileCategory.AUDIO,
                  autoSubtitlesEnabled = autoSubtitlesEnabled,
                  subtitlesFolderPath = subtitlesFolderPath,
                  subtitleLanguages = subtitleLanguages,
                  availableStreams = resolvedStreams,
                  selectedStreamIndex = selectedStreamIdx,
                  onSelectStreamIndex = { idx ->
                    selectedStreamIdx = idx
                    resolvedStreamUrl = resolvedStreams.getOrNull(idx)?.url
                  },
                  onFallbackToWebPlayer = { useWebFallback = true },
                  onlineSubtitleService = onlineSubtitleService,
                  onlineLyricsService = onlineLyricsService,
                  videoEditorEngine = videoEditorEngine,
                  onEnterPiP = onEnterPiP,
                  onDownloadStream = { url -> onDownloadStream(url) },
                  onVideoExported = { newPath -> activePath = newPath },
                  onMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } },
                )
              }
            }
          }
        }

        resolvedCategory == FileCategory.PDF -> PdfPagesViewer(file)
        resolvedCategory == FileCategory.DATABASE -> SqliteInspectorView(file)
        else -> {
          var bytes by remember { mutableStateOf(ByteArray(0)) }
          LaunchedEffect(activePath) {
            bytes = withContext(Dispatchers.IO) { runCatching { file.readBytes().take(65536).toByteArray() }.getOrDefault(ByteArray(0)) }
          }
          HexInspectorView(bytes)
        }
      }

      // Gallery / Video folder carousel pager when multiple siblings exist
      if (siblingMedia.size > 1 && siblingIndex >= 0 && activeMode !in setOf("text", "hex")) {
        Surface(
          color = Color.Black.copy(alpha = 0.55f),
          shape = RoundedCornerShape(50),
          modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp),
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 6.dp),
          ) {
            IconButton(
              onClick = {
                val prev = (siblingIndex - 1 + siblingMedia.size) % siblingMedia.size
                activePath = siblingMedia[prev]
              },
              modifier = Modifier.size(48.dp).testTag("viewer_prev_media"),
            ) {
              Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous", tint = Color.White)
            }
            Text(
              text = "${siblingIndex + 1} / ${siblingMedia.size}",
              style = MaterialTheme.typography.labelMedium,
              color = Color.White,
            )
            IconButton(
              onClick = {
                val next = (siblingIndex + 1) % siblingMedia.size
                activePath = siblingMedia[next]
              },
              modifier = Modifier.size(48.dp).testTag("viewer_next_media"),
            ) {
              Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next", tint = Color.White)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AdvancedImageViewer(
  file: File,
  autoBackupOnEditEnabled: Boolean = false,
  aiPhotoStudioEngine: AiPhotoStudioEngine? = null,
  onSavedNewImage: (String) -> Unit = {},
  onMessage: (String) -> Unit,
) {
  val strings = LocalAppStrings.current
  val scope = rememberCoroutineScope()
  var scale by remember(file.absolutePath) { mutableFloatStateOf(1f) }
  var rotationDeg by remember(file.absolutePath) { mutableFloatStateOf(0f) }
  var flipH by remember(file.absolutePath) { mutableStateOf(false) }
  var brightness by remember(file.absolutePath) { mutableFloatStateOf(0f) }
  var contrast by remember(file.absolutePath) { mutableFloatStateOf(1f) }
  var saturation by remember(file.absolutePath) { mutableFloatStateOf(1f) }
  var showAdjust by remember { mutableStateOf(false) }
  var studioSourceBitmap by remember { mutableStateOf<Bitmap?>(null) }

  val transformState = rememberTransformableState { zoomChange, _, _ ->
    scale = (scale * zoomChange).coerceIn(1f, 6f)
  }

  val matrix =
    remember(brightness, contrast, saturation) {
      val cm = ColorMatrix()
      cm.setSaturation(saturation)
      val c = contrast
      val t = (1f - c) / 2f * 255f + brightness
      val bc = ColorMatrix(
        floatArrayOf(
          c, 0f, 0f, 0f, t,
          0f, c, 0f, 0f, t,
          0f, 0f, c, 0f, t,
          0f, 0f, 0f, 1f, 0f,
        )
      )
      cm.postConcat(bc)
      cm
    }

  Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    Box(
      modifier = Modifier.weight(1f).fillMaxWidth().transformable(transformState),
      contentAlignment = Alignment.Center,
    ) {
      AsyncImage(
        model = file,
        contentDescription = file.name,
        contentScale = ContentScale.Fit,
        colorFilter = ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(matrix.array)),
        modifier =
          Modifier
            .fillMaxSize()
            .graphicsLayer(
              scaleX = scale * (if (flipH) -1f else 1f),
              scaleY = scale,
              rotationZ = rotationDeg,
            ),
      )
    }

    if (showAdjust) {
      Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = false, onClick = { brightness = 0f; contrast = 1f; saturation = 1f }, label = { Text("Reset") })
            FilterChip(selected = false, onClick = { brightness = 8f; contrast = 1.2f; saturation = 1.35f }, label = { Text("Vivid") })
            FilterChip(selected = false, onClick = { brightness = 0f; contrast = 1.2f; saturation = 0f }, label = { Text("B&W") })
          }
          Text("${strings.brightnessLabel}: ${brightness.toInt()}", style = MaterialTheme.typography.labelSmall)
          Slider(value = brightness, onValueChange = { brightness = it }, valueRange = -80f..80f)
          Text("${strings.contrastLabel}: ${"%.2f".format(contrast)}", style = MaterialTheme.typography.labelSmall)
          Slider(value = contrast, onValueChange = { contrast = it }, valueRange = 0.5f..1.8f)
          Text("${strings.saturationLabel}: ${"%.2f".format(saturation)}", style = MaterialTheme.typography.labelSmall)
          Slider(value = saturation, onValueChange = { saturation = it }, valueRange = 0f..2f)
        }
      }
    }

    Row(
      modifier =
        Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surfaceContainer)
          .horizontalScroll(rememberScrollState())
          .padding(8.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      FilterChip(
        selected = showAdjust,
        onClick = { showAdjust = !showAdjust },
        label = { Text(strings.enhancePicture) },
        leadingIcon = { Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp)) },
      )
      FilterChip(
        selected = false,
        onClick = { rotationDeg = (rotationDeg + 90f) % 360f },
        label = { Text("90°") },
        leadingIcon = { Icon(Icons.AutoMirrored.Filled.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp)) },
      )
      FilterChip(
        selected = flipH,
        onClick = { flipH = !flipH },
        label = { Text("Flip") },
        leadingIcon = { Icon(Icons.Default.Flip, contentDescription = null, modifier = Modifier.size(16.dp)) },
      )
      FilterChip(
        selected = false,
        onClick = {
          scope.launch(Dispatchers.IO) {
            if (autoBackupOnEditEnabled && file.exists()) {
              EditBackupManager.createSnapshotBeforeEdit(file.absolutePath)
            }
            val out = File(file.parentFile, "${file.nameWithoutExtension}_enhanced.jpg")
            val srcBmp = BitmapFactory.decodeFile(file.absolutePath)
            if (srcBmp != null) {
              val m = Matrix().apply {
                postRotate(rotationDeg)
                if (flipH) postScale(-1f, 1f)
              }
              val rotated = Bitmap.createBitmap(srcBmp, 0, 0, srcBmp.width, srcBmp.height, m, true)
              val outBmp = Bitmap.createBitmap(rotated.width, rotated.height, Bitmap.Config.ARGB_8888)
              val canvas = Canvas(outBmp)
              val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(matrix) }
              canvas.drawBitmap(rotated, 0f, 0f, paint)
              FileOutputStream(out).use { outBmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
              srcBmp.recycle()
              if (rotated !== srcBmp) rotated.recycle()
              outBmp.recycle()
              onMessage("Saved: ${out.name}")
            }
          }
        },
        label = { Text(strings.saveFile) },
        leadingIcon = { Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp)) },
      )
      if (aiPhotoStudioEngine != null) {
        FilterChip(
          selected = studioSourceBitmap != null,
          onClick = {
            scope.launch(Dispatchers.IO) {
              if (autoBackupOnEditEnabled && file.exists()) {
                EditBackupManager.createSnapshotBeforeEdit(file.absolutePath)
              }
              val bmp = BitmapFactory.decodeFile(file.absolutePath)
              withContext(Dispatchers.Main) {
                if (bmp != null) studioSourceBitmap = bmp else onMessage("Could not decode image")
              }
            }
          },
          label = { Text(strings.aiPhotoStudioTitle) },
          leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp)) },
          modifier = Modifier.testTag("viewer_ai_photo_studio_btn"),
        )
      }
    }
  }

  val loadedStudioBmp = studioSourceBitmap
  if (loadedStudioBmp != null && aiPhotoStudioEngine != null) {
    AiPhotoStudioSheet(
      sourceFile = file,
      sourceBitmap = loadedStudioBmp,
      engine = aiPhotoStudioEngine,
      onSavedImage = { saved ->
        studioSourceBitmap = null
        onMessage("Saved: ${saved.name}")
        onSavedNewImage(saved.absolutePath)
      },
      onDismiss = { studioSourceBitmap = null },
    )
  }
}

@OptIn(UnstableApi::class)
@Composable
private fun AdvancedMedia3PlayerView(
  source: String,
  rawOriginalSource: String,
  displayTitle: String,
  isRemoteStream: Boolean,
  streamHeaders: Map<String, String> = emptyMap(),
  isAudioMode: Boolean = false,
  autoSubtitlesEnabled: Boolean = true,
  subtitlesFolderPath: String = "",
  subtitleLanguages: List<String> = listOf("ar", "en"),
  availableStreams: List<ExtractedMediaStream> = emptyList(),
  selectedStreamIndex: Int = 0,
  onSelectStreamIndex: (Int) -> Unit = {},
  onFallbackToWebPlayer: () -> Unit = {},
  onlineSubtitleService: OnlineSubtitleService,
  onlineLyricsService: OnlineLyricsService? = null,
  videoEditorEngine: VideoEditorEngine? = null,
  onEnterPiP: () -> Unit,
  onDownloadStream: (String) -> Unit = {},
  onVideoExported: (String) -> Unit = {},
  onMessage: (String) -> Unit,
) {
  val context = LocalContext.current
  val strings = LocalAppStrings.current
  val scope = rememberCoroutineScope()
  val audioManager = remember { context.getSystemService(AudioManager::class.java) }
  var gestureHudLabel by remember { mutableStateOf<String?>(null) }
  var brightnessLevel by remember { mutableFloatStateOf(0.75f) }
  var showVideoStudio by remember { mutableStateOf(false) }
  var playbackErrorMsg by remember(source) { mutableStateOf<String?>(null) }
  var autoFailoverCount by remember(rawOriginalSource) { mutableIntStateOf(0) }
  var showQualityMenu by remember { mutableStateOf(false) }

  val mediaUri =
    remember(source, isRemoteStream) {
      if (isRemoteStream) Uri.parse(source) else Uri.fromFile(File(source))
    }

  val exoPlayer =
    remember(source, streamHeaders) {
      val builder = MediaItem.Builder().setUri(mediaUri)
      when {
        source.contains(".m3u8", ignoreCase = true) -> builder.setMimeType(MimeTypes.APPLICATION_M3U8)
        source.contains(".mpd", ignoreCase = true) -> builder.setMimeType(MimeTypes.APPLICATION_MPD)
      }
      val httpFactory = DefaultHttpDataSource.Factory()
        .setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(20_000)
        .setReadTimeoutMs(30_000)
      val ua = streamHeaders["User-Agent"]
      if (!ua.isNullOrBlank()) httpFactory.setUserAgent(ua)
      val extraHeaders = streamHeaders.filterKeys { !it.equals("User-Agent", ignoreCase = true) }
      if (extraHeaders.isNotEmpty()) httpFactory.setDefaultRequestProperties(extraHeaders)
      val dataSourceFactory = DefaultDataSource.Factory(context, httpFactory)

      ExoPlayer.Builder(context)
        .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
        .build()
        .apply {
          setMediaItem(builder.build())
          prepare()
          playWhenReady = true
        }
    }

  // Secondary ExoPlayer for External or Recorded Audio Dubbing
  val dubPlayer = remember(source) { ExoPlayer.Builder(context).build() }
  var hasDubTrack by remember { mutableStateOf(false) }
  var originalVol by remember { mutableFloatStateOf(0.25f) }
  var dubVol by remember { mutableFloatStateOf(1.0f) }

  // Picture Enhancement (Media3 VideoEffects)
  var brightness by remember { mutableFloatStateOf(0f) }
  var contrast by remember { mutableFloatStateOf(0f) }
  var saturation by remember { mutableFloatStateOf(0f) }
  var showEnhanceSheet by remember { mutableStateOf(false) }

  // Subtitles & Styling
  var subtitleCues by remember { mutableStateOf<List<SubtitleCue>>(emptyList()) }
  var activeSubtitleFile by remember(source) { mutableStateOf<File?>(null) }
  var subtitleStyle by remember { mutableStateOf(SubtitleStyleConfig()) }
  var activeSubtitleText by remember { mutableStateOf<String?>(null) }
  var showSubtitleSheet by remember { mutableStateOf(false) }
  var showOnlineSubDialog by remember { mutableStateOf(false) }
  var onlineSearching by remember { mutableStateOf(false) }
  var onlineHits by remember { mutableStateOf<List<OnlineSubtitleHit>>(emptyList()) }

  // Dubbing & Recording & TTS
  var showDubbingSheet by remember { mutableStateOf(false) }
  var isRecordingDub by remember { mutableStateOf(false) }
  var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
  var recordedDubFile by remember { mutableStateOf<File?>(null) }
  var ttsAutoDub by remember { mutableStateOf(false) }
  var lastSpokenCueIndex by remember { mutableIntStateOf(-1) }
  val ttsEngine = remember {
    var engine: TextToSpeech? = null
    engine =
      TextToSpeech(context) { status ->
        if (status == TextToSpeech.SUCCESS) {
          engine?.language = Locale.forLanguageTag("ar")
        }
      }
    engine
  }

  // Screen Cast Presentation, Background Cast & Smart TV DLNA
  var showCastSheet by remember { mutableStateOf(false) }
  var activePresentation by remember { mutableStateOf<VideoCastPresentation?>(null) }
  var dlnaDevices by remember { mutableStateOf<List<DlnaDevice>>(emptyList()) }
  var isDiscoveringDlna by remember { mutableStateOf(false) }
  val bgCastState by MediaCastService.state.collectAsStateWithLifecycle()

  // Pro Controls: Speed, Lock, A-B Loop
  var speed by remember { mutableFloatStateOf(1.0f) }
  var showSpeedMenu by remember { mutableStateOf(false) }
  var isLocked by remember { mutableStateOf(false) }
  var loopA by remember { mutableLongStateOf(-1L) }
  var loopB by remember { mutableLongStateOf(-1L) }

  // Embedded Audio Tracks list
  var embeddedAudioTracks by remember { mutableStateOf<List<Pair<Int, String>>>(emptyList()) }
  var selectedAudioTrackIdx by remember { mutableIntStateOf(0) }

  // Auto-load local matching subtitle/lyrics (exact stem or episode match + dedicated folder), then online fallback
  LaunchedEffect(source, autoSubtitlesEnabled, subtitlesFolderPath, subtitleLanguages, isAudioMode) {
    if (!autoSubtitlesEnabled) return@LaunchedEffect

    val targetDir =
      SubtitleAutoMatcher.resolveTargetStorageDir(
        subtitlesFolderPath,
        if (!isRemoteStream) {
          File(source).parentFile ?: File(context.cacheDir, "subs")
        } else {
          File(context.cacheDir, "subs")
        },
      )

    if (isAudioMode) {
      if (!isRemoteStream) {
        val localLrc = withContext(Dispatchers.IO) {
          SubtitleAutoMatcher.findBestLocalLyrics(source, subtitlesFolderPath)
        }
        if (localLrc != null) {
          val lines = withContext(Dispatchers.IO) {
            runCatching { LyricsEngine.parseLyrics(localLrc.readText()) }.getOrDefault(emptyList())
          }
          if (lines.isNotEmpty()) {
            subtitleCues = lines.map { SubtitleCue(it.index, it.startMs, it.endMs, it.text) }
            return@LaunchedEffect
          }
        }
      }
      if (onlineLyricsService != null) {
        val hits = onlineLyricsService.searchLyrics(displayTitle, "", subtitleLanguages)
        val best = hits.firstOrNull()
        val raw = best?.syncedLrc ?: best?.plainLyrics
        if (!raw.isNullOrBlank()) {
          val lines = LyricsEngine.parseLyrics(raw)
          if (lines.isNotEmpty()) {
            if (!isRemoteStream) {
              withContext(Dispatchers.IO) {
                runCatching {
                  File(targetDir, "${File(source).nameWithoutExtension}.lrc").writeText(raw)
                }
              }
            }
            subtitleCues = lines.map { SubtitleCue(it.index, it.startMs, it.endMs, it.text) }
          }
        }
      }
    } else {
      if (!isRemoteStream) {
        val localSub = withContext(Dispatchers.IO) {
          SubtitleAutoMatcher.findBestLocalSubtitle(source, subtitlesFolderPath)
        }
        if (localSub != null) {
          val parsed = withContext(Dispatchers.IO) { SubtitleEngine.parseFile(localSub) }
          if (parsed.isNotEmpty()) {
            activeSubtitleFile = localSub
            subtitleCues = parsed
            return@LaunchedEffect
          }
        }
      }

      val hits = onlineSubtitleService.searchSubtitlesMultiLang(displayTitle, subtitleLanguages)
      val firstHit = hits.firstOrNull() ?: return@LaunchedEffect
      val stem =
        if (!isRemoteStream) File(source).nameWithoutExtension
        else displayTitle.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]"), "_")
      val downloaded =
        onlineSubtitleService.downloadSubtitle(
          url = firstHit.downloadUrl,
          outputDir = targetDir,
          preferredStem = stem,
        )
      if (downloaded != null) {
        val parsed = withContext(Dispatchers.IO) { SubtitleEngine.parseFile(downloaded) }
        if (parsed.isNotEmpty()) {
          activeSubtitleFile = downloaded
          subtitleCues = parsed
        }
      }
    }
  }

  // Sync ExoPlayer tracks & playback state with dubPlayer
  DisposableEffect(exoPlayer) {
    val listener =
      object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
          if (hasDubTrack) {
            if (isPlaying) {
              dubPlayer.seekTo(exoPlayer.currentPosition)
              dubPlayer.play()
            } else {
              dubPlayer.pause()
            }
          }
        }

        override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
          if (hasDubTrack) {
            dubPlayer.seekTo(newPosition.positionMs)
          }
        }

        override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
          val found = mutableListOf<Pair<Int, String>>()
          var counter = 0
          tracks.groups.forEachIndexed { gIdx, group ->
            if (group.type == C.TRACK_TYPE_AUDIO) {
              val fmt = group.getTrackFormat(0)
              val label = fmt.label ?: fmt.language?.uppercase() ?: "Track ${++counter}"
              found.add(gIdx to label)
            }
          }
          embeddedAudioTracks = found
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
          if (playbackState == Player.STATE_READY) {
            playbackErrorMsg = null
          }
        }

        override fun onPlayerError(error: PlaybackException) {
          if (isRemoteStream && availableStreams.isNotEmpty() && autoFailoverCount < 4) {
            val nextIdx =
              (selectedStreamIndex + 1 until availableStreams.size)
                .firstOrNull { idx ->
                  val s = availableStreams[idx]
                  !s.isDrmProtected && ((s.hasVideo && s.hasAudio) || s.isHls || (isAudioMode && s.hasAudio))
                }
            if (nextIdx != null) {
              autoFailoverCount++
              onMessage("Switching stream (${availableStreams[nextIdx].qualityLabel})...")
              onSelectStreamIndex(nextIdx)
              return
            }
          }
          if (isRemoteStream && UniversalDownloadEngine.extractYouTubeVideoId(rawOriginalSource) != null) {
            onMessage("Switching to Built-in YouTube Web Player...")
            onFallbackToWebPlayer()
            return
          }
          playbackErrorMsg = error.localizedMessage ?: "Stream playback error"
        }
      }
    exoPlayer.addListener(listener)
    onDispose {
      exoPlayer.removeListener(listener)
      exoPlayer.release()
      dubPlayer.release()
      runCatching { recorder?.stop(); recorder?.release() }
      activePresentation?.dismiss()
      ttsEngine.stop()
      ttsEngine.shutdown()
    }
  }

  // Sync loop for live Subtitles, TTS Auto-Dub, A-B Loop, and Cast Presentation
  LaunchedEffect(subtitleCues, subtitleStyle, ttsAutoDub, loopA, loopB, activePresentation) {
    while (true) {
      val pos = exoPlayer.currentPosition
      if (loopA >= 0L && loopB > loopA && pos >= loopB) {
        exoPlayer.seekTo(loopA)
      }
      val cue = SubtitleEngine.findActiveCue(subtitleCues, pos, subtitleStyle.syncOffsetMs)
      activeSubtitleText = cue?.text
      activePresentation?.updateSubtitle(cue?.text, subtitleStyle)

      if (ttsAutoDub && cue != null && cue.index != lastSpokenCueIndex && exoPlayer.isPlaying) {
        lastSpokenCueIndex = cue.index
        val hasArabic = cue.text.any { it in '\u0600'..'\u06FF' }
        ttsEngine.language = if (hasArabic) Locale.forLanguageTag("ar") else Locale.US
        exoPlayer.volume = 0.25f
        ttsEngine.speak(cue.text, TextToSpeech.QUEUE_FLUSH, null, "cue_${cue.index}")
      } else if (!ttsAutoDub && !hasDubTrack && exoPlayer.volume != 1.0f) {
        exoPlayer.volume = 1.0f
      }
      delay(120)
    }
  }

  val subtitlePicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) {
        scope.launch(Dispatchers.IO) {
          val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
          val parsed = SubtitleEngine.parseString(text)
          val cachedSub = runCatching {
            val subDir = File(context.cacheDir, "subs").apply { mkdirs() }
            val out = File(subDir, "picked_${System.currentTimeMillis()}.srt")
            out.writeText(text)
            out
          }.getOrNull()
          withContext(Dispatchers.Main) {
            activeSubtitleFile = cachedSub
            subtitleCues = parsed
            onMessage("Loaded ${parsed.size} subtitle cues")
          }
        }
      }
    }

  val dubAudioPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) {
        dubPlayer.setMediaItem(MediaItem.fromUri(uri))
        dubPlayer.prepare()
        dubPlayer.volume = dubVol
        exoPlayer.volume = originalVol
        hasDubTrack = true
        if (exoPlayer.isPlaying) {
          dubPlayer.seekTo(exoPlayer.currentPosition)
          dubPlayer.play()
        }
        onMessage("Dub audio attached")
      }
    }

  fun startOrStopVoiceDubRecording() {
    if (isRecordingDub) {
      runCatching {
        recorder?.stop()
        recorder?.release()
      }
      recorder = null
      isRecordingDub = false
      recordedDubFile?.let { dubF ->
        if (dubF.exists() && dubF.length() > 0) {
          dubPlayer.setMediaItem(MediaItem.fromUri(Uri.fromFile(dubF)))
          dubPlayer.prepare()
          dubPlayer.volume = dubVol
          exoPlayer.volume = originalVol
          hasDubTrack = true
          exoPlayer.seekTo(0)
          dubPlayer.seekTo(0)
          onMessage("Voice dub applied: ${dubF.name}")
        }
      }
    } else {
      val outF = File(context.cacheDir, "vortex_dub_${System.currentTimeMillis()}.m4a")
      recordedDubFile = outF
      val rec =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context)
        else @Suppress("DEPRECATION") MediaRecorder()
      rec.apply {
        setAudioSource(MediaRecorder.AudioSource.MIC)
        setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        setAudioEncodingBitRate(96_000)
        setAudioSamplingRate(44_100)
        setOutputFile(outF.absolutePath)
        prepare()
        start()
      }
      recorder = rec
      isRecordingDub = true
      onMessage("Recording voice dubbing...")
    }
  }

  val micPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      if (granted) startOrStopVoiceDubRecording() else onMessage("Microphone permission denied")
    }

  fun applyVideoEnhancements() {
    val effects =
      listOf(
        Contrast(contrast),
        HslAdjustment.Builder()
          .adjustLightness(brightness)
          .adjustSaturation(saturation)
          .build(),
      )
    exoPlayer.setVideoEffects(effects)
  }

  Column(modifier = Modifier.fillMaxSize().background(Color.Black)) {
    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .pointerInput(isLocked) {
          if (isLocked) return@pointerInput
          detectVerticalDragGestures(
            onDragEnd = { gestureHudLabel = null },
            onDragCancel = { gestureHudLabel = null },
          ) { change, dragAmount ->
            val isLeftSide = change.position.x < size.width / 2f
            if (isLeftSide) {
              brightnessLevel = (brightnessLevel - dragAmount / 500f).coerceIn(0.05f, 1f)
              (context as? android.app.Activity)?.window?.let { win ->
                val lp = win.attributes
                lp.screenBrightness = brightnessLevel
                win.attributes = lp
              }
              gestureHudLabel = "${strings.brightnessLabel}: ${(brightnessLevel * 100).toInt()}%"
            } else if (audioManager != null) {
              val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
              val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
              val delta = if (dragAmount < -18f) 1 else if (dragAmount > 18f) -1 else 0
              val nextVol = (curVol + delta).coerceIn(0, maxVol)
              if (delta != 0) audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
              gestureHudLabel = "Volume: ${(nextVol * 100) / maxVol}%"
            }
          }
        }
        .pointerInput(isLocked, exoPlayer) {
          if (isLocked) return@pointerInput
          var accumDragX = 0f
          detectHorizontalDragGestures(
            onDragStart = { accumDragX = 0f },
            onDragEnd = {
              val deltaMs = (accumDragX * 60f).toLong()
              if (kotlin.math.abs(deltaMs) > 600L) {
                exoPlayer.seekTo((exoPlayer.currentPosition + deltaMs).coerceAtLeast(0L))
              }
              gestureHudLabel = null
            },
            onDragCancel = { gestureHudLabel = null },
          ) { _, dragAmount ->
            accumDragX += dragAmount
            val sec = (accumDragX * 60f / 1000f).toInt()
            gestureHudLabel = if (sec >= 0) "+${sec}s" else "${sec}s"
          }
        },
    ) {
      AndroidView(
        factory = { ctx ->
          PlayerView(ctx).apply {
            player = exoPlayer
            useController = !isLocked
          }
        },
        update = { view ->
          if (view.player !== exoPlayer) {
            view.player = exoPlayer
          }
          view.useController = !isLocked
        },
        modifier = Modifier.fillMaxSize(),
      )

      if (!gestureHudLabel.isNullOrBlank()) {
        Surface(
          color = Color.Black.copy(alpha = 0.72f),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.align(Alignment.Center),
        ) {
          Text(
            gestureHudLabel!!,
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
          )
        }
      }

      // Live Styled Subtitle Overlay
      if (!activeSubtitleText.isNullOrBlank()) {
        Box(
          modifier =
            Modifier
              .align(Alignment.BottomCenter)
              .padding(bottom = subtitleStyle.bottomOffsetDp.dp, start = 16.dp, end = 16.dp),
        ) {
          Surface(
            color = Color.Black.copy(alpha = subtitleStyle.backgroundAlpha),
            shape = MaterialTheme.shapes.small,
          ) {
            Text(
              text = activeSubtitleText.orEmpty(),
              color = subtitleStyle.textColor,
              fontSize = subtitleStyle.fontSizeSp.sp,
              fontWeight = FontWeight.SemiBold,
              textAlign = TextAlign.Center,
              style =
                MaterialTheme.typography.bodyLarge.copy(
                  shadow = if (subtitleStyle.hasShadow) Shadow(color = Color.Black, blurRadius = 6f) else null,
                ),
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            )
          }
        }
      }

      if (isLocked) {
        IconButton(
          onClick = { isLocked = false },
          modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
        ) {
          Icon(Icons.Default.Lock, contentDescription = "Unlock", tint = Color.White)
        }
      }

      val err = playbackErrorMsg
      if (err != null && isRemoteStream) {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
          modifier = Modifier.align(Alignment.Center).padding(20.dp),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text(
              err,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onErrorContainer,
              textAlign = TextAlign.Center,
            )
            Button(
              onClick = onFallbackToWebPlayer,
              modifier = Modifier.testTag("player_error_web_fallback_btn"),
            ) {
              Text(strings.webPlayerMode)
            }
          }
        }
      }
    }

    // Pro Player Action Strip
    if (!isLocked) {
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        FilterChip(
          selected = brightness != 0f || contrast != 0f || saturation != 0f,
          onClick = { showEnhanceSheet = true },
          label = { Text(strings.enhancePicture) },
          leadingIcon = { Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp)) },
          modifier = Modifier.testTag("player_enhance_btn"),
        )
        FilterChip(
          selected = subtitleCues.isNotEmpty(),
          onClick = { showSubtitleSheet = true },
          label = { Text(strings.subtitlesTitle) },
          leadingIcon = { Icon(Icons.Default.ClosedCaption, contentDescription = null, modifier = Modifier.size(16.dp)) },
          modifier = Modifier.testTag("player_subtitles_btn"),
        )
        FilterChip(
          selected = hasDubTrack || ttsAutoDub || isRecordingDub,
          onClick = { showDubbingSheet = true },
          label = { Text(strings.audioDubbingTitle) },
          leadingIcon = { Icon(Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(16.dp)) },
          modifier = Modifier.testTag("player_dubbing_btn"),
        )
        FilterChip(
          selected = activePresentation != null || bgCastState.isRunning,
          onClick = { showCastSheet = true },
          label = { Text(strings.screenCastTitle) },
          leadingIcon = { Icon(Icons.Default.Cast, contentDescription = null, modifier = Modifier.size(16.dp)) },
          modifier = Modifier.testTag("player_cast_btn"),
        )
        Box {
          FilterChip(
            selected = speed != 1.0f,
            onClick = { showSpeedMenu = true },
            label = { Text("${speed}x") },
            leadingIcon = { Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp)) },
          )
          DropdownMenu(expanded = showSpeedMenu, onDismissRequest = { showSpeedMenu = false }) {
            listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { sp ->
              DropdownMenuItem(
                text = { Text("${sp}x") },
                onClick = {
                  speed = sp
                  exoPlayer.setPlaybackSpeed(sp)
                  dubPlayer.setPlaybackSpeed(sp)
                  showSpeedMenu = false
                },
              )
            }
          }
        }
        FilterChip(
          selected = false,
          onClick = onEnterPiP,
          label = { Text("PiP") },
          leadingIcon = { Icon(Icons.Default.PictureInPictureAlt, contentDescription = null, modifier = Modifier.size(16.dp)) },
        )
        if (!isRemoteStream) {
          FilterChip(
            selected = false,
            onClick = {
              val posUs = exoPlayer.currentPosition * 1000L
              scope.launch(Dispatchers.IO) {
                runCatching {
                  val mmr = MediaMetadataRetriever()
                  mmr.setDataSource(source)
                  val frame = mmr.getFrameAtTime(posUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                  mmr.release()
                  if (frame != null) {
                    val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
                    dir.mkdirs()
                    val snap = File(dir, "Vortex_Shot_${System.currentTimeMillis()}.png")
                    FileOutputStream(snap).use { frame.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    frame.recycle()
                    onMessage("Screenshot saved: ${snap.name}")
                  }
                }
              }
            },
            label = { Text(strings.takeScreenshot) },
            leadingIcon = { Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp)) },
          )
        }
        FilterChip(
          selected = loopA >= 0L,
          onClick = {
            when {
              loopA < 0L -> loopA = exoPlayer.currentPosition
              loopB < 0L -> loopB = exoPlayer.currentPosition.coerceAtLeast(loopA + 500L)
              else -> {
                loopA = -1L
                loopB = -1L
              }
            }
          },
          label = {
            Text(
              when {
                loopA < 0L -> "A-B"
                loopB < 0L -> "Set B"
                else -> "Clear A-B"
              }
            )
          },
        )
        if (isRemoteStream) {
          if (availableStreams.size > 1) {
            Box {
              val curQuality = availableStreams.getOrNull(selectedStreamIndex)?.qualityLabel ?: "Auto"
              FilterChip(
                selected = false,
                onClick = { showQualityMenu = true },
                label = { Text("${strings.qualityLabel}: $curQuality") },
                modifier = Modifier.testTag("player_quality_chip"),
              )
              DropdownMenu(expanded = showQualityMenu, onDismissRequest = { showQualityMenu = false }) {
                availableStreams.forEachIndexed { idx, stream ->
                  DropdownMenuItem(
                    text = { Text(stream.qualityLabel) },
                    onClick = {
                      showQualityMenu = false
                      onSelectStreamIndex(idx)
                    },
                  )
                }
              }
            }
          }
          FilterChip(
            selected = false,
            onClick = onFallbackToWebPlayer,
            label = { Text(strings.webPlayerMode) },
            leadingIcon = { Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(16.dp)) },
            modifier = Modifier.testTag("player_web_mode_chip"),
          )
          FilterChip(
            selected = false,
            onClick = { onDownloadStream(rawOriginalSource) },
            label = { Text(strings.downloadActiveStream) },
            leadingIcon = { Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp)) },
            modifier = Modifier.testTag("player_download_stream_chip"),
          )
        } else if (videoEditorEngine != null) {
          FilterChip(
            selected = showVideoStudio,
            onClick = { showVideoStudio = true },
            label = { Text(strings.videoStudioTitle) },
            leadingIcon = { Icon(Icons.Default.MovieCreation, contentDescription = null, modifier = Modifier.size(16.dp)) },
            modifier = Modifier.testTag("viewer_video_studio_btn"),
          )
        }
        FilterChip(
          selected = false,
          onClick = { isLocked = true },
          label = { Text("Lock") },
          leadingIcon = { Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(16.dp)) },
        )
      }
    }
  }

  if (showVideoStudio && videoEditorEngine != null && !isRemoteStream) {
    VideoStudioSheet(
      sourceVideo = File(source),
      durationMs = exoPlayer.duration.coerceAtLeast(1000L),
      engine = videoEditorEngine,
      onExportedVideo = { out ->
        showVideoStudio = false
        onMessage("Exported: ${out.name}")
        onVideoExported(out.absolutePath)
      },
      onDismiss = { showVideoStudio = false },
    )
  }

  if (showEnhanceSheet) {
    VideoEnhancementSheet(
      brightness = brightness,
      contrast = contrast,
      saturation = saturation,
      onBrightnessChange = { brightness = it },
      onContrastChange = { contrast = it },
      onSaturationChange = { saturation = it },
      onSelectPreset = { b, c, s ->
        brightness = b
        contrast = c
        saturation = s
      },
      onApplyEffects = { applyVideoEnhancements() },
      onDismiss = { showEnhanceSheet = false },
    )
  }

  if (showSubtitleSheet) {
    SubtitleManagerSheet(
      cueCount = subtitleCues.size,
      style = subtitleStyle,
      onStyleChange = { subtitleStyle = it },
      onPickLocalSubtitle = {
        showSubtitleSheet = false
        subtitlePicker.launch(arrayOf("*/*"))
      },
      onOpenOnlineSearch = {
        showSubtitleSheet = false
        showOnlineSubDialog = true
      },
      onClearSubtitles = { subtitleCues = emptyList() },
      onDismiss = { showSubtitleSheet = false },
    )
  }

  if (showOnlineSubDialog) {
    val subOutDir =
      SubtitleAutoMatcher.resolveTargetStorageDir(
        subtitlesFolderPath,
        File(context.cacheDir, "subs"),
      )
    val subStem = if (!isRemoteStream) File(source).nameWithoutExtension else null
    OnlineSubtitleSearchDialog(
      initialQuery = displayTitle.substringBeforeLast('.'),
      isSearching = onlineSearching,
      hits = onlineHits,
      onSearch = { q, l ->
        scope.launch {
          onlineSearching = true
          val ordered =
            if (l.isNotBlank()) listOf(l) + subtitleLanguages.filterNot { it.equals(l, true) }
            else subtitleLanguages
          onlineHits = onlineSubtitleService.searchSubtitlesMultiLang(q, ordered)
          onlineSearching = false
        }
      },
      onDownloadHit = { hit ->
        scope.launch {
          onlineSearching = true
          val f = onlineSubtitleService.downloadSubtitle(hit.downloadUrl, subOutDir, subStem)
          onlineSearching = false
          if (f != null) {
            activeSubtitleFile = f
            subtitleCues = withContext(Dispatchers.IO) { SubtitleEngine.parseFile(f) }
            onMessage("Subtitle loaded (${subtitleCues.size} cues)")
            showOnlineSubDialog = false
          } else {
            onMessage("Could not download subtitle")
          }
        }
      },
      onDownloadDirectUrl = { url ->
        scope.launch {
          onlineSearching = true
          val f = onlineSubtitleService.downloadSubtitle(url, subOutDir, subStem)
          onlineSearching = false
          if (f != null) {
            activeSubtitleFile = f
            subtitleCues = withContext(Dispatchers.IO) { SubtitleEngine.parseFile(f) }
            onMessage("Subtitle loaded (${subtitleCues.size} cues)")
            showOnlineSubDialog = false
          } else {
            onMessage("Invalid subtitle URL")
          }
        }
      },
      onDismiss = { showOnlineSubDialog = false },
    )
  }

  if (showDubbingSheet) {
    AudioDubbingSheet(
      embeddedAudioTracks = embeddedAudioTracks,
      selectedTrackIdx = selectedAudioTrackIdx,
      onSelectEmbeddedTrack = { gIdx ->
        selectedAudioTrackIdx = gIdx
        val group = exoPlayer.currentTracks.groups.getOrNull(gIdx) ?: return@AudioDubbingSheet
        exoPlayer.trackSelectionParameters =
          exoPlayer.trackSelectionParameters
            .buildUpon()
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, 0))
            .build()
      },
      hasDubAudio = hasDubTrack,
      isRecordingDub = isRecordingDub,
      ttsAutoDubEnabled = ttsAutoDub,
      originalVolume = originalVol,
      dubVolume = dubVol,
      onPickDubAudioFile = { dubAudioPicker.launch(arrayOf("audio/*")) },
      onToggleRecordDub = {
        val perm = Manifest.permission.RECORD_AUDIO
        if (ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED) {
          startOrStopVoiceDubRecording()
        } else {
          micPermissionLauncher.launch(perm)
        }
      },
      onToggleTtsAutoDub = { enabled ->
        ttsAutoDub = enabled
        if (!enabled) ttsEngine.stop()
      },
      onOriginalVolumeChange = {
        originalVol = it
        exoPlayer.volume = it
      },
      onDubVolumeChange = {
        dubVol = it
        dubPlayer.volume = it
      },
      onClearDub = {
        hasDubTrack = false
        dubPlayer.stop()
        exoPlayer.volume = 1.0f
      },
      onDismiss = { showDubbingSheet = false },
    )
  }

  if (showCastSheet) {
    val displays = remember(showCastSheet) { VideoCastPresentation.getPresentationDisplays(context) }
    ScreenCastSheet(
      displayNames = displays.map { it.name },
      isCastingExternal = activePresentation != null,
      dlnaDevices = dlnaDevices,
      isDiscoveringDlna = isDiscoveringDlna,
      isBackgroundCasting = bgCastState.isRunning,
      backgroundCastTitle = bgCastState.title,
      hasLoadedSubtitles = activeSubtitleFile != null || subtitleCues.isNotEmpty(),
      onStartExternalCast = { idx ->
        displays.getOrNull(idx)?.let { disp ->
          activePresentation?.dismiss()
          val pres = VideoCastPresentation(context, disp, exoPlayer)
          pres.show()
          activePresentation = pres
          onMessage("Casting to ${disp.name}")
          showCastSheet = false
        }
      },
      onStopExternalCast = {
        activePresentation?.dismiss()
        activePresentation = null
      },
      onDiscoverDlna = {
        scope.launch {
          isDiscoveringDlna = true
          dlnaDevices = DlnaCastManager.discoverTvRenderers(context)
          isDiscoveringDlna = false
          if (dlnaDevices.isEmpty()) {
            onMessage("No DLNA Smart TVs found on Wi-Fi")
          }
        }
      },
      onCastToDlna = { device ->
        scope.launch {
          val urls = DlnaCastManager.ensureServerStarted(source, activeSubtitleFile?.absolutePath)
          if (urls == null) {
            onMessage("Connect Wi-Fi or select a valid media file to cast")
          } else {
            val res = DlnaCastManager.castVideoToDevice(device, displayTitle, urls.first, urls.second)
            if (res.isSuccess) {
              MediaCastService.startBackgroundCast(
                context = context,
                mediaPath = source,
                subtitlePath = activeSubtitleFile?.absolutePath,
                title = displayTitle,
                deviceName = device.friendlyName,
                positionMs = exoPlayer.currentPosition,
              )
              exoPlayer.pause()
              onMessage("Casting to ${device.friendlyName} (${strings.castBackgroundNote})")
              showCastSheet = false
            } else {
              onMessage(res.exceptionOrNull()?.message ?: "DLNA cast failed")
            }
          }
        }
      },
      onToggleBackgroundCast = {
        if (bgCastState.isRunning) {
          MediaCastService.stopBackgroundCast(context)
          onMessage("Background cast stopped")
        } else {
          val pos = exoPlayer.currentPosition
          exoPlayer.pause()
          MediaCastService.startBackgroundCast(
            context = context,
            mediaPath = source,
            subtitlePath = activeSubtitleFile?.absolutePath,
            title = displayTitle,
            deviceName = "TV / Background Cast",
            positionMs = pos,
          )
          onMessage(strings.castBackgroundNote)
          showCastSheet = false
        }
      },
      onOpenWirelessCastSettings = {
        runCatching {
          context.startActivity(Intent(Settings.ACTION_CAST_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure {
          onMessage("Cast settings unavailable")
        }
      },
      onDismiss = { showCastSheet = false },
    )
  }
}

@Composable
private fun PdfPagesViewer(file: File) {
  var pages by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
  LaunchedEffect(file.absolutePath) {
    pages =
      withContext(Dispatchers.IO) {
        runCatching {
          val list = mutableListOf<Bitmap>()
          val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
          pfd.use { fd ->
            PdfRenderer(fd).use { renderer ->
              val limit = minOf(renderer.pageCount, 30)
              for (i in 0 until limit) {
                renderer.openPage(i).use { p ->
                  val bmp = Bitmap.createBitmap(p.width * 2, p.height * 2, Bitmap.Config.ARGB_8888)
                  bmp.eraseColor(android.graphics.Color.WHITE)
                  p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                  list.add(bmp)
                }
              }
            }
          }
          list
        }.getOrDefault(emptyList())
      }
  }
  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    items(pages) { bmp ->
      Image(
        bitmap = bmp.asImageBitmap(),
        contentDescription = "PDF Page",
        contentScale = ContentScale.FillWidth,
        modifier = Modifier.fillMaxWidth(),
      )
    }
  }
}

@Composable
private fun SqliteInspectorView(file: File) {
  var tables by remember { mutableStateOf<List<String>>(emptyList()) }
  var selectedTable by remember { mutableStateOf<String?>(null) }
  var rows by remember { mutableStateOf<List<String>>(emptyList()) }

  LaunchedEffect(file.absolutePath) {
    tables =
      withContext(Dispatchers.IO) {
        runCatching {
          SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY).use { db ->
            val list = mutableListOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
              while (c.moveToNext()) list.add(c.getString(0))
            }
            list
          }
        }.getOrDefault(emptyList())
      }
    selectedTable = tables.firstOrNull()
  }

  LaunchedEffect(selectedTable) {
    val tbl = selectedTable ?: return@LaunchedEffect
    rows =
      withContext(Dispatchers.IO) {
        runCatching {
          SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY).use { db ->
            val list = mutableListOf<String>()
            db.rawQuery("SELECT * FROM \"$tbl\" LIMIT 100", null).use { c ->
              val cols = c.columnNames
              list.add(cols.joinToString(" | "))
              while (c.moveToNext()) {
                list.add((0 until c.columnCount).joinToString(" | ") { idx -> c.getString(idx) ?: "NULL" })
              }
            }
            list
          }
        }.getOrDefault(emptyList())
      }
  }

  Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      tables.forEach { tbl ->
        FilterChip(selected = selectedTable == tbl, onClick = { selectedTable = tbl }, label = { Text(tbl) })
      }
    }
    LazyColumn(modifier = Modifier.weight(1f)) {
      items(rows) { row ->
        Surface(
          color = MaterialTheme.colorScheme.surfaceContainerLow,
          modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        ) {
          Text(
            text = row,
            style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
            modifier = Modifier.padding(8.dp).horizontalScroll(rememberScrollState()),
          )
        }
      }
    }
  }
}

@Composable
private fun TextPreviewView(
  file: File,
  onOpenInCodeIde: () -> Unit,
) {
  val strings = LocalAppStrings.current
  var lines by remember { mutableStateOf<List<String>>(emptyList()) }
  LaunchedEffect(file.absolutePath) {
    lines =
      withContext(Dispatchers.IO) {
        runCatching {
          file.bufferedReader().useLines { seq -> seq.take(1000).toList() }
        }.getOrDefault(listOf("(Unable to decode text)"))
      }
  }
  Column(modifier = Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "${file.name} • ${lines.size} lines",
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
      )
      Button(onClick = onOpenInCodeIde) {
        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(strings.openInEditor)
      }
    }
    LazyColumn(
      modifier =
        Modifier
          .weight(1f)
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surfaceContainerLowest, MaterialTheme.shapes.small)
          .padding(8.dp),
    ) {
      items(lines.size) { idx ->
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          Text(
            text = "${idx + 1}",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(34.dp),
          )
          Text(
            text = lines[idx],
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
            color = MaterialTheme.colorScheme.onSurface,
          )
        }
      }
    }
  }
}
