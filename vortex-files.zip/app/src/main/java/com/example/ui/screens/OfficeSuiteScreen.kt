package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Title
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.VortexAppContainer
import com.example.domain.fs.EditBackupManager
import com.example.domain.office.DocParagraphStyle
import com.example.domain.office.ExcelSheetModel
import com.example.domain.office.ExcelWorkbookModel
import com.example.domain.office.PdfStrokeAnnotation
import com.example.domain.office.PdfTextAnnotation
import com.example.domain.office.PptDeckModel
import com.example.domain.office.PptSlideModel
import com.example.domain.office.WordDocumentModel
import com.example.domain.office.WordParagraph
import com.example.i18n.LocalAppStrings
import java.io.File
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfficeSuiteScreen(
  initialPath: String,
  defaultWorkspaceDir: File,
  container: VortexAppContainer,
  onFilesSaved: () -> Unit,
  onBack: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val scope = rememberCoroutineScope()
  val snackbar = remember { SnackbarHostState() }
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val engine = container.officeEngine

  DisposableEffect(Unit) {
    onDispose {
      focusManager.clearFocus(force = true)
      keyboardController?.hide()
    }
  }

  BackHandler {
    focusManager.clearFocus(force = true)
    keyboardController?.hide()
    onBack()
  }

  val ext = initialPath.substringAfterLast('.', "").lowercase()
  var selectedTab by remember(initialPath) {
    mutableIntStateOf(
      when (ext) {
        "xlsx", "xls" -> 1
        "pptx", "ppt" -> 2
        "pdf" -> 3
        else -> 0
      }
    )
  }

  // Word State
  var wordTitle by remember { mutableStateOf(File(initialPath).nameWithoutExtension.ifBlank { "Document" }) }
  val wordParas = remember { mutableStateListOf(WordParagraph("p0", "Vortex Word Document", DocParagraphStyle.HEADING1)) }

  // Excel State
  var workbook by remember {
    mutableStateOf(
      ExcelWorkbookModel(
        mutableListOf(
          ExcelSheetModel(
            "Sheet1",
            MutableList(10) { r ->
              MutableList(5) { c ->
                when {
                  r == 0 && c == 0 -> "Item"
                  r == 0 && c == 1 -> "Qty"
                  r == 0 && c == 2 -> "Price"
                  r == 0 && c == 3 -> "Total"
                  else -> ""
                }
              }
            },
          )
        )
      )
    )
  }
  var activeSheetIdx by remember { mutableIntStateOf(0) }
  var selectedCell by remember { mutableStateOf(0 to 0) }
  var formulaInput by remember { mutableStateOf("Item") }

  // PowerPoint State
  val slides = remember { mutableStateListOf(PptSlideModel(1, "Presentation Title", "Slide bullet 1\nSlide bullet 2")) }
  var activeSlideIdx by remember { mutableIntStateOf(0) }

  // PDF Annotator State
  var pdfBitmaps by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
  val pageOrder = remember { mutableStateListOf<Int>() }
  val strokes = remember { mutableStateListOf<PdfStrokeAnnotation>() }
  val textAnns = remember { mutableStateListOf<PdfTextAnnotation>() }
  var activePdfPagePos by remember { mutableIntStateOf(0) }
  var pdfDrawColor by remember { mutableStateOf(Color.Red) }
  var showAddPdfText by remember { mutableStateOf(false) }
  var pendingPdfText by remember { mutableStateOf("") }

  LaunchedEffect(initialPath) {
    val file = File(initialPath)
    if (!file.exists() || !file.isFile) return@LaunchedEffect
    runCatching {
      when (ext) {
        "docx", "doc" -> {
          val doc = engine.readDocx(file)
          wordTitle = doc.title
          wordParas.clear()
          wordParas.addAll(doc.paragraphs)
        }
        "xlsx", "xls" -> {
          val wb = engine.readXlsx(file)
          workbook = wb
          activeSheetIdx = 0
          selectedCell = 0 to 0
          formulaInput = wb.sheets.firstOrNull()?.rows?.getOrNull(0)?.getOrNull(0).orEmpty()
        }
        "pptx", "ppt" -> {
          val deck = engine.readPptx(file)
          slides.clear()
          slides.addAll(deck.slides)
          activeSlideIdx = 0
        }
        "pdf" -> {
          val pages = engine.renderPdfPages(file, 1.4f)
          pdfBitmaps = pages
          pageOrder.clear()
          pageOrder.addAll(pages.indices)
          activePdfPagePos = 0
        }
      }
    }.onFailure { snackbar.showSnackbar(it.message ?: "Failed to load document") }
  }

  fun targetFile(defaultExt: String): File {
    val orig = File(initialPath)
    return if (initialPath.isNotBlank() && orig.extension.equals(defaultExt, true)) orig
    else File(defaultWorkspaceDir, "${wordTitle.ifBlank { "vortex_doc" }}.$defaultExt")
  }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(snackbar) },
    topBar = {
      TopAppBar(
        title = { Text(strings.officeSuiteTitle, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        navigationIcon = {
          IconButton(
            onClick = {
              focusManager.clearFocus(force = true)
              keyboardController?.hide()
              onBack()
            },
            modifier = Modifier.testTag("office_back_button"),
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
          }
        },
        actions = {
          IconButton(
            onClick = {
              scope.launch {
                runCatching {
                  val autoBak = runCatching { container.preferencesRepo.preferences.first().autoBackupOnEditEnabled }.getOrDefault(false)
                  suspend fun maybeSnapshot(file: File) {
                    if (autoBak && file.exists() && file.isFile) {
                      EditBackupManager.createSnapshotBeforeEdit(file.absolutePath)
                    }
                  }
                  when (selectedTab) {
                    0 -> {
                      val dest = targetFile("docx")
                      maybeSnapshot(dest)
                      val out = engine.saveDocx(WordDocumentModel(wordTitle, wordParas.toList()), dest)
                      onFilesSaved()
                      "Saved ${out.name}"
                    }
                    1 -> {
                      val dest = targetFile("xlsx")
                      maybeSnapshot(dest)
                      val out = engine.saveXlsx(workbook, dest)
                      onFilesSaved()
                      "Saved ${out.name}"
                    }
                    2 -> {
                      val dest = targetFile("pptx")
                      maybeSnapshot(dest)
                      val out = engine.savePptx(PptDeckModel(slides.toMutableList()), dest)
                      onFilesSaved()
                      "Saved ${out.name}"
                    }
                    else -> {
                      val src = File(initialPath)
                      val out = File(src.parentFile ?: defaultWorkspaceDir, "${src.nameWithoutExtension}_annotated.pdf")
                      maybeSnapshot(out)
                      engine.exportAnnotatedPdf(src, out, pageOrder.toList(), strokes.toList(), textAnns.toList())
                      onFilesSaved()
                      "Exported ${out.name}"
                    }
                  }
                }.onSuccess { snackbar.showSnackbar(it) }.onFailure { snackbar.showSnackbar(it.message ?: "Save failed") }
              }
            },
            modifier = Modifier.testTag("office_save_button"),
          ) {
            Icon(Icons.Default.Save, contentDescription = strings.saveFile)
          }

          IconButton(
            onClick = {
              scope.launch {
                runCatching {
                  val pdfOut = File(defaultWorkspaceDir, "${wordTitle.ifBlank { "export" }}_${System.currentTimeMillis() % 10000}.pdf")
                  when (selectedTab) {
                    0 -> engine.exportDocxToPdf(WordDocumentModel(wordTitle, wordParas.toList()), pdfOut)
                    1 -> engine.exportXlsxToPdf(workbook.sheets[activeSheetIdx], pdfOut)
                    2 -> engine.exportPptxToPdf(PptDeckModel(slides.toMutableList()), pdfOut)
                    else -> {
                      val src = File(initialPath)
                      engine.exportAnnotatedPdf(src, pdfOut, pageOrder.toList(), strokes.toList(), textAnns.toList())
                    }
                  }
                  onFilesSaved()
                  "PDF: ${pdfOut.name}"
                }.onSuccess { snackbar.showSnackbar(it) }.onFailure { snackbar.showSnackbar(it.message ?: "Export failed") }
              }
            },
            modifier = Modifier.testTag("office_export_pdf_button"),
          ) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = strings.exportPdf)
          }
        },
      )
    },
  ) { padding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(padding).navigationBarsPadding(),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(modifier = Modifier.fillMaxSize().widthIn(max = 860.dp)) {
        PrimaryTabRow(selectedTabIndex = selectedTab) {
          listOf("Word (.docx)", "Excel (.xlsx)", "PowerPoint (.pptx)", "PDF Studio").forEachIndexed { idx, label ->
            Tab(
              selected = selectedTab == idx,
              onClick = { selectedTab = idx },
              text = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            )
          }
        }

        when (selectedTab) {
          0 -> {
            // WORD EDITOR
            LazyColumn(
              modifier = Modifier.fillMaxSize().padding(14.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  Button(onClick = { wordParas.add(WordParagraph(UUID.randomUUID().toString(), "", DocParagraphStyle.HEADING1)) }) {
                    Text("+ H1")
                  }
                  Button(onClick = { wordParas.add(WordParagraph(UUID.randomUUID().toString(), "", DocParagraphStyle.BODY)) }) {
                    Text("+ Body")
                  }
                  Button(onClick = { wordParas.add(WordParagraph(UUID.randomUUID().toString(), "", DocParagraphStyle.BULLET)) }) {
                    Text("+ Bullet")
                  }
                }
              }
              itemsIndexed(wordParas, key = { _, p -> p.id }) { idx, p ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
                  Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        DocParagraphStyle.entries.forEach { st ->
                          FilterChip(
                            selected = p.style == st,
                            onClick = { wordParas[idx] = p.copy(style = st) },
                            label = { Text(st.name) },
                          )
                        }
                      }
                      if (wordParas.size > 1) {
                        IconButton(onClick = { wordParas.removeAt(idx) }) {
                          Icon(Icons.Default.Delete, contentDescription = strings.delete)
                        }
                      }
                    }
                    OutlinedTextField(
                      value = p.text,
                      onValueChange = { wordParas[idx] = p.copy(text = it) },
                      modifier = Modifier.fillMaxWidth(),
                      minLines = 1,
                    )
                  }
                }
              }
            }
          }

          1 -> {
            // EXCEL SPREADSHEET + FORMULA ENGINE
            val sheet = workbook.sheets.getOrElse(activeSheetIdx) { workbook.sheets.first() }
            Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                workbook.sheets.forEachIndexed { idx, s ->
                  FilterChip(
                    selected = activeSheetIdx == idx,
                    onClick = { activeSheetIdx = idx },
                    label = { Text(s.name) },
                  )
                }
                TextButton(
                  onClick = {
                    workbook.sheets.add(ExcelSheetModel("Sheet${workbook.sheets.size + 1}", MutableList(10) { MutableList(5) { "" } }))
                    activeSheetIdx = workbook.sheets.lastIndex
                  }
                ) { Text("+ Sheet") }
                TextButton(
                  onClick = {
                    val colCount = sheet.rows.firstOrNull()?.size ?: 5
                    sheet.rows.add(MutableList(colCount) { "" })
                    workbook = workbook.copy()
                  }
                ) { Text("+ Row") }
              }

              OutlinedTextField(
                value = formulaInput,
                onValueChange = { newVal ->
                  formulaInput = newVal
                  val (r, c) = selectedCell
                  if (r < sheet.rows.size && c < sheet.rows[r].size) {
                    sheet.rows[r][c] = newVal
                  }
                },
                label = { Text("fx ${engine.colIndexToLetter(selectedCell.second)}${selectedCell.first + 1} (e.g. =SUM(B2:B5))") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
              )

              LazyColumn(modifier = Modifier.fillMaxSize()) {
                item {
                  Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    Box(modifier = Modifier.size(44.dp, 36.dp).border(1.dp, MaterialTheme.colorScheme.outlineVariant), contentAlignment = Alignment.Center) {
                      Text("#", style = MaterialTheme.typography.labelSmall)
                    }
                    val cols = sheet.rows.maxOfOrNull { it.size } ?: 5
                    for (c in 0 until cols) {
                      Box(
                        modifier = Modifier.width(104.dp).height(36.dp)
                          .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                          .border(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        contentAlignment = Alignment.Center,
                      ) {
                        Text(engine.colIndexToLetter(c), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                      }
                    }
                  }
                }
                itemsIndexed(sheet.rows) { rIdx, row ->
                  Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    Box(
                      modifier = Modifier.size(44.dp, 40.dp)
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant),
                      contentAlignment = Alignment.Center,
                    ) {
                      Text("${rIdx + 1}", style = MaterialTheme.typography.labelSmall)
                    }
                    row.forEachIndexed { cIdx, _ ->
                      val isSel = selectedCell == (rIdx to cIdx)
                      val evaluated = engine.evaluateCellDisplay(sheet, rIdx, cIdx)
                      Box(
                        modifier = Modifier
                          .width(104.dp)
                          .height(40.dp)
                          .background(if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
                          .border(if (isSel) 2.dp else 1.dp, if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                          .clickable {
                            selectedCell = rIdx to cIdx
                            formulaInput = sheet.rows[rIdx][cIdx]
                          }
                          .padding(horizontal = 6.dp),
                        contentAlignment = Alignment.CenterStart,
                      ) {
                        Text(evaluated, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                      }
                    }
                  }
                }
              }
            }
          }

          2 -> {
            // POWERPOINT SLIDE EDITOR
            val current = slides.getOrElse(activeSlideIdx) { slides.first() }
            Column(modifier = Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                slides.forEachIndexed { idx, _ ->
                  FilterChip(
                    selected = activeSlideIdx == idx,
                    onClick = { activeSlideIdx = idx },
                    label = { Text("Slide ${idx + 1}") },
                  )
                }
                Button(onClick = {
                  slides.add(PptSlideModel(slides.size + 1, "Slide ${slides.size + 1}", ""))
                  activeSlideIdx = slides.lastIndex
                }) {
                  Icon(Icons.Default.Add, contentDescription = null)
                  Text("Slide")
                }
              }
              Surface(
                color = Color(0xFF0F172A),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
              ) {
                Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                  Text(current.title, color = Color(0xFF38BDF8), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                  Text(current.body, color = Color(0xFFE2E8F0), style = MaterialTheme.typography.bodyMedium)
                }
              }
              OutlinedTextField(
                value = current.title,
                onValueChange = { slides[activeSlideIdx] = current.copy(title = it) },
                label = { Text("Slide Title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
              )
              OutlinedTextField(
                value = current.body,
                onValueChange = { slides[activeSlideIdx] = current.copy(body = it) },
                label = { Text("Slide Content") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth(),
              )
            }
          }

          else -> {
            // PDF STUDIO (DRAW, TEXT, PAGE REORDER)
            Column(modifier = Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              if (pdfBitmaps.isEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                  Text(
                    "Open a .pdf file from the workbench or export a Word/Excel/PowerPoint document above to annotate and reorder PDF pages.",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium,
                  )
                }
              } else {
                val origPageIdx = pageOrder.getOrElse(activePdfPagePos) { 0 }
                val bmp = pdfBitmaps.getOrNull(origPageIdx)
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Page ${activePdfPagePos + 1}/${pageOrder.size}", fontWeight = FontWeight.Bold)
                    IconButton(onClick = { if (activePdfPagePos > 0) activePdfPagePos-- }) {
                      Icon(Icons.Default.ArrowUpward, contentDescription = "Prev")
                    }
                    IconButton(onClick = { if (activePdfPagePos < pageOrder.lastIndex) activePdfPagePos++ }) {
                      Icon(Icons.Default.ArrowDownward, contentDescription = "Next")
                    }
                    IconButton(onClick = {
                      if (activePdfPagePos > 0) {
                        val item = pageOrder.removeAt(activePdfPagePos)
                        pageOrder.add(activePdfPagePos - 1, item)
                        activePdfPagePos--
                      }
                    }) { Text("Move↑") }
                  }
                  Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = { showAddPdfText = true }) {
                      Icon(Icons.Default.Title, contentDescription = "Add Text")
                    }
                    Icon(Icons.Default.Draw, contentDescription = "Draw", tint = pdfDrawColor, modifier = Modifier.padding(top = 10.dp))
                  }
                }

                if (bmp != null) {
                  var livePoints by remember { mutableStateOf<List<Pair<Float, Float>>>(emptyList()) }
                  Box(
                    modifier = Modifier
                      .fillMaxWidth()
                      .weight(1f)
                      .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp)),
                  ) {
                    Image(
                      bitmap = bmp.asImageBitmap(),
                      contentDescription = "PDF Page",
                      contentScale = ContentScale.Fit,
                      modifier = Modifier.fillMaxSize(),
                    )
                    Canvas(
                      modifier = Modifier.fillMaxSize().pointerInput(origPageIdx, pdfDrawColor) {
                        detectDragGestures(
                          onDragStart = { pos ->
                            livePoints = listOf((pos.x / size.width) to (pos.y / size.height))
                          },
                          onDrag = { change, _ ->
                            change.consume()
                            val p = change.position
                            livePoints = livePoints + ((p.x / size.width).coerceIn(0f, 1f) to (p.y / size.height).coerceIn(0f, 1f))
                          },
                          onDragEnd = {
                            if (livePoints.size >= 2) {
                              strokes.add(PdfStrokeAnnotation(origPageIdx, livePoints, pdfDrawColor.toArgb(), 6f))
                            }
                            livePoints = emptyList()
                          },
                        )
                      }
                    ) {
                      fun drawStroke(pts: List<Pair<Float, Float>>, col: Color, width: Float) {
                        if (pts.size < 2) return
                        val path = Path()
                        pts.forEachIndexed { idx, (nx, ny) ->
                          val px = nx * size.width
                          val py = ny * size.height
                          if (idx == 0) path.moveTo(px, py) else path.lineTo(px, py)
                        }
                        drawPath(path, color = col, style = Stroke(width = width))
                      }
                      strokes.filter { it.pageIndex == origPageIdx }.forEach {
                        drawStroke(it.points, Color(it.colorArgb), it.strokeWidth)
                      }
                      drawStroke(livePoints, pdfDrawColor, 6f)
                    }
                    textAnns.filter { it.pageIndex == origPageIdx }.forEach { ann ->
                      Surface(
                        color = Color.Yellow.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = 24.dp),
                      ) {
                        Text(ann.text, color = Color.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showAddPdfText) {
    AlertDialog(
      onDismissRequest = { showAddPdfText = false },
      title = { Text("Add PDF Note / Signature Text") },
      text = {
        OutlinedTextField(value = pendingPdfText, onValueChange = { pendingPdfText = it }, label = { Text("Text") }, singleLine = true)
      },
      confirmButton = {
        Button(
          onClick = {
            if (pendingPdfText.isNotBlank() && pageOrder.isNotEmpty()) {
              textAnns.add(PdfTextAnnotation(pageOrder[activePdfPagePos], 0.15f, 0.12f, pendingPdfText.trim(), Color.Blue.toArgb()))
              pendingPdfText = ""
              showAddPdfText = false
            }
          }
        ) { Text(strings.confirm) }
      },
      dismissButton = { TextButton(onClick = { showAddPdfText = false }) { Text(strings.cancel) } },
    )
  }
}
