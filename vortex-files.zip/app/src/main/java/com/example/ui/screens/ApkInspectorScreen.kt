package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.apk.ApkInspectionReport
import com.example.domain.apk.ApkPermissionInfo
import com.example.domain.fs.formatFileSize
import com.example.i18n.LocalAppStrings
import com.example.ui.theme.LocalVortexExtraColors
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.VortexExtraColors
import com.example.ui.viewmodel.ApkInspectorViewModel
import com.example.ui.viewmodel.ApkUiState
import kotlinx.coroutines.launch

private enum class PermissionFilterMode {
  ALL,
  DANGEROUS,
  NORMAL,
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkInspectorScreen(
  apkPath: String,
  viewModel: ApkInspectorViewModel,
  onOpenEditor: (String, Boolean) -> Unit,
  onBack: () -> Unit,
) {
  val context = LocalContext.current
  val strings = LocalAppStrings.current
  val extra = LocalVortexExtraColors.current
  val scope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }

  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  var selectedTab by remember { mutableIntStateOf(0) }
  var dexFilter by remember { mutableStateOf("") }
  var permFilterQuery by remember { mutableStateOf("") }
  var permFilterMode by remember { mutableStateOf(PermissionFilterMode.ALL) }
  var manifestQuery by remember { mutableStateOf("") }
  var showComponentsExpanded by remember { mutableStateOf(false) }

  LaunchedEffect(apkPath) {
    viewModel.loadApk(apkPath)
  }

  val focusManager = LocalFocusManager.current
  val readyState = uiState as? ApkUiState.Ready
  LaunchedEffect(readyState?.statusMessage) {
    readyState?.statusMessage?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.clearStatusMessage()
    }
  }

  DisposableEffect(Unit) {
    onDispose {
      focusManager.clearFocus(force = true)
    }
  }

  BackHandler {
    focusManager.clearFocus(force = true)
    if (selectedTab == 3 && readyState != null && readyState.internalSubPath.isNotEmpty()) {
      val up = readyState.internalSubPath.substringBeforeLast('/', "")
      viewModel.browseInternal(up)
    } else {
      onBack()
    }
  }

  fun copyText(label: String, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    scope.launch { snackbarHostState.showSnackbar("$label copied") }
  }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      TopAppBar(
        modifier = Modifier.statusBarsPadding(),
        title = {
          Column {
            Text(strings.apkInspectorTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (readyState != null) {
              Text(
                text = readyState.report.fileName,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("apk_back_btn")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
          }
        },
      )
    },
  ) { innerPadding ->
    Box(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .navigationBarsPadding(),
    ) {
      when (val st = uiState) {
        ApkUiState.Loading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))

        is ApkUiState.Error ->
          Column(
            modifier = Modifier.align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Icon(Icons.Default.Android, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.error)
            Text(st.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
          }

        is ApkUiState.Ready -> {
          val report = st.report
          Column(modifier = Modifier.fillMaxSize()) {
            ScrollableTabRow(selectedTabIndex = selectedTab) {
              Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(strings.apkOverviewTab) },
                modifier = Modifier.testTag("apk_tab_overview"),
              )
              Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(strings.apkManifestTab) },
                modifier = Modifier.testTag("apk_tab_manifest"),
              )
              Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("${strings.apkDexTab} (${report.dexClasses.size})") },
                modifier = Modifier.testTag("apk_tab_dex"),
              )
              Tab(
                selected = selectedTab == 3,
                onClick = { selectedTab = 3 },
                text = { Text("${strings.apkFilesTab} (${report.entryCount})") },
                modifier = Modifier.testTag("apk_tab_files"),
              )
            }

            when (selectedTab) {
              0 -> {
                OverviewTabContent(
                  report = report,
                  extractedManifestPath = st.extractedManifestPath,
                  permFilterQuery = permFilterQuery,
                  onPermFilterQueryChange = { permFilterQuery = it },
                  permFilterMode = permFilterMode,
                  onPermFilterModeChange = { permFilterMode = it },
                  showComponentsExpanded = showComponentsExpanded,
                  onToggleComponents = { showComponentsExpanded = !showComponentsExpanded },
                  onCopyPackage = { copyText(strings.apkPackageName, report.packageName) },
                  onExtractManifest = { viewModel.extractManifestToDisk() },
                  onOpenExtractedManifest = { path -> onOpenEditor(path, false) },
                  onUnpackApk = { viewModel.unpackApkToWorkspace() },
                  onJumpToManifest = { selectedTab = 1 },
                  extra = extra,
                )
              }

              1 -> {
                ManifestTabContent(
                  report = report,
                  extractedManifestPath = st.extractedManifestPath,
                  manifestQuery = manifestQuery,
                  onManifestQueryChange = { manifestQuery = it },
                  onExtractManifest = { viewModel.extractManifestToDisk() },
                  onOpenExtractedManifest = { path -> onOpenEditor(path, false) },
                  onCopyManifest = { copyText("AndroidManifest.xml", report.decodedManifestXml) },
                  onOpenHex = { onOpenEditor(viewModel.buildEntryArchiveUri("AndroidManifest.xml"), true) },
                  extra = extra,
                )
              }

              2 -> {
                Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  OutlinedTextField(
                    value = dexFilter,
                    onValueChange = { dexFilter = it },
                    label = { Text("Filter DEX classes (${report.dexClasses.size} loaded)") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("apk_dex_filter"),
                  )
                  val filtered =
                    remember(report.dexClasses, dexFilter) {
                      if (dexFilter.isBlank()) report.dexClasses
                      else report.dexClasses.filter { it.contains(dexFilter, ignoreCase = true) }
                    }
                  if (filtered.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                      Text(strings.emptyFolderTitle, style = MaterialTheme.typography.bodyMedium)
                    }
                  } else {
                    LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                      items(filtered) { cls ->
                        Surface(
                          color = MaterialTheme.colorScheme.surfaceContainerLow,
                          shape = MaterialTheme.shapes.extraSmall,
                          modifier = Modifier.fillMaxWidth(),
                        ) {
                          Text(
                            text = cls,
                            style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                          )
                        }
                      }
                    }
                  }
                }
              }

              3 -> {
                Column(modifier = Modifier.fillMaxSize()) {
                  if (st.internalSubPath.isNotEmpty()) {
                    Row(
                      modifier =
                        Modifier
                          .fillMaxWidth()
                          .clickable {
                            val up = st.internalSubPath.substringBeforeLast('/', "")
                            viewModel.browseInternal(up)
                          }
                          .padding(12.dp),
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Up")
                      Spacer(Modifier.size(8.dp))
                      Text(".. / ${st.internalSubPath}", style = MaterialTheme.typography.labelMedium, fontFamily = MonoFontFamily)
                    }
                    HorizontalDivider()
                  }
                  LazyColumn(modifier = Modifier.weight(1f)) {
                    items(st.internalEntries, key = { it.path }) { entry ->
                      Row(
                        modifier =
                          Modifier
                            .fillMaxWidth()
                            .clickable {
                              if (entry.isDirectory) {
                                viewModel.browseInternal(entry.entryPathInArchive ?: "")
                              } else {
                                onOpenEditor(entry.path, entry.extension in setOf("arsc", "dex", "so", "bin"))
                              }
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                      ) {
                        Icon(
                          if (entry.isDirectory) Icons.Default.Folder else Icons.AutoMirrored.Filled.InsertDriveFile,
                          contentDescription = null,
                          tint = if (entry.isDirectory) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                        )
                        Spacer(Modifier.size(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                          Text(entry.name, style = MaterialTheme.typography.bodyMedium)
                          if (!entry.isDirectory) {
                            Text(formatFileSize(entry.size), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                          }
                        }
                      }
                      HorizontalDivider(thickness = 0.5.dp)
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun OverviewTabContent(
  report: ApkInspectionReport,
  extractedManifestPath: String?,
  permFilterQuery: String,
  onPermFilterQueryChange: (String) -> Unit,
  permFilterMode: PermissionFilterMode,
  onPermFilterModeChange: (PermissionFilterMode) -> Unit,
  showComponentsExpanded: Boolean,
  onToggleComponents: () -> Unit,
  onCopyPackage: () -> Unit,
  onExtractManifest: () -> Unit,
  onOpenExtractedManifest: (String) -> Unit,
  onUnpackApk: () -> Unit,
  onJumpToManifest: () -> Unit,
  extra: VortexExtraColors,
) {
  val strings = LocalAppStrings.current
  val dangerousCount = remember(report.permissionDetails) { report.permissionDetails.count { it.isDangerous } }
  val normalCount = remember(report.permissionDetails) { report.permissionDetails.count { !it.isDangerous } }

  val filteredPerms =
    remember(report.permissionDetails, permFilterQuery, permFilterMode) {
      report.permissionDetails.filter { perm ->
        val matchesMode =
          when (permFilterMode) {
            PermissionFilterMode.ALL -> true
            PermissionFilterMode.DANGEROUS -> perm.isDangerous
            PermissionFilterMode.NORMAL -> !perm.isDangerous
          }
        val matchesQuery =
          permFilterQuery.isBlank() ||
            perm.fullName.contains(permFilterQuery, ignoreCase = true) ||
            perm.categoryLabel.contains(permFilterQuery, ignoreCase = true)
        matchesMode && matchesQuery
      }
    }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(14.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    // Hero Identity Card
    item {
      Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
      ) {
        Box(
          modifier =
            Modifier
              .fillMaxWidth()
              .background(
                Brush.linearGradient(
                  listOf(
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                    MaterialTheme.colorScheme.surfaceContainer,
                  )
                )
              )
              .padding(14.dp),
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              val bmp = remember(report.iconDrawable) { report.iconDrawable?.toBitmap(144, 144)?.asImageBitmap() }
              Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier.size(62.dp),
              ) {
                Box(contentAlignment = Alignment.Center) {
                  if (bmp != null) {
                    Image(bitmap = bmp, contentDescription = report.appName, modifier = Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)))
                  } else {
                    Icon(Icons.Default.Android, contentDescription = report.appName, modifier = Modifier.size(38.dp), tint = extra.losslessGreen)
                  }
                }
              }

              Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                  text = report.appName,
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  maxLines = 2,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.testTag("apk_app_name"),
                )
                Surface(
                  color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.clickable(onClick = onCopyPackage).testTag("apk_package_pill"),
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                  ) {
                    Text(
                      text = report.packageName,
                      style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
                      color = MaterialTheme.colorScheme.primary,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                    Icon(Icons.Default.ContentCopy, contentDescription = strings.apkCopyPackage, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                  }
                }
              }
            }

            // Version + SDK + Size Pills Row
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              MetaBadgePill(
                label = "${strings.apkVersion}: v${report.versionName} (${report.versionCode})",
                color = MaterialTheme.colorScheme.secondary,
                testTag = "apk_version_pill",
              )
              MetaBadgePill(
                label = "SDK ${report.minSdk} -> ${report.targetSdk}",
                color = extra.shizukuCyan,
              )
              MetaBadgePill(
                label = "${formatFileSize(report.fileSize)} • ${report.entryCount} files",
                color = MaterialTheme.colorScheme.primary,
              )
            }
          }
        }
      }
    }

    // Quick Action Row
    item {
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Button(onClick = onJumpToManifest, modifier = Modifier.testTag("apk_view_manifest_btn")) {
          Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(6.dp))
          Text(strings.apkManifestTab)
        }
        OutlinedButton(onClick = onExtractManifest, modifier = Modifier.testTag("apk_extract_manifest_btn")) {
          Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(6.dp))
          Text(strings.apkExtractManifest)
        }
        if (extractedManifestPath != null) {
          OutlinedButton(onClick = { onOpenExtractedManifest(extractedManifestPath) }) {
            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(strings.apkOpenExtractedManifest)
          }
        }
        OutlinedButton(onClick = onUnpackApk, modifier = Modifier.testTag("apk_unpack_btn")) {
          Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(6.dp))
          Text(strings.apkExtractAllFiles)
        }
      }
    }

    // Technical Metadata Cards
    item {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        InfoCard(strings.apkPackageName, report.packageName)
        InfoCard(strings.apkVersion, "${report.versionName} (versionCode ${report.versionCode})")
        InfoCard(strings.apkSdkInfo, "minSdk ${report.minSdk}  ->  targetSdk ${report.targetSdk}")
        InfoCard(strings.apkSignature, report.signingDigestSha256)
        InfoCard(
          "DEX & Native Libraries",
          "DEX: ${if (report.dexFiles.isEmpty()) "None" else report.dexFiles.joinToString()}  •  Native .so: ${report.nativeLibs.size}",
        )
      }
    }

    // Declared Components Card (Expandable)
    item {
      val totalComponents = report.activities.size + report.services.size + report.receivers.size + report.providers.size
      Surface(
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onToggleComponents),
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("${strings.apkComponentsLabel} ($totalComponents)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
              Text(
                "Activities: ${report.activities.size} • Services: ${report.services.size} • Receivers: ${report.receivers.size} • Providers: ${report.providers.size}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Icon(
              imageVector = if (showComponentsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
              contentDescription = strings.apkComponentsLabel,
            )
          }
          AnimatedVisibility(visible = showComponentsExpanded) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
              ComponentGroupBlock("Activities", report.activities)
              ComponentGroupBlock("Services", report.services)
              ComponentGroupBlock("Receivers", report.receivers)
              ComponentGroupBlock("Providers", report.providers)
            }
          }
        }
      }
    }

    // Permissions Inspector Header & Filters
    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Text(
              "${strings.apkPermissionsCount} (${report.permissionDetails.size})",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
          }
        }

        if (report.permissionDetails.isNotEmpty()) {
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            FilterChip(
              selected = permFilterMode == PermissionFilterMode.ALL,
              onClick = { onPermFilterModeChange(PermissionFilterMode.ALL) },
              label = { Text("${strings.apkPermAll} (${report.permissionDetails.size})") },
            )
            FilterChip(
              selected = permFilterMode == PermissionFilterMode.DANGEROUS,
              onClick = { onPermFilterModeChange(PermissionFilterMode.DANGEROUS) },
              label = { Text("${strings.apkPermDangerous} ($dangerousCount)") },
            )
            FilterChip(
              selected = permFilterMode == PermissionFilterMode.NORMAL,
              onClick = { onPermFilterModeChange(PermissionFilterMode.NORMAL) },
              label = { Text("${strings.apkPermNormal} ($normalCount)") },
            )
          }

          OutlinedTextField(
            value = permFilterQuery,
            onValueChange = onPermFilterQueryChange,
            label = { Text(strings.apkPermFilterHint) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("apk_perm_filter_input"),
          )
        }
      }
    }

    if (report.permissionDetails.isEmpty()) {
      item {
        Surface(
          color = MaterialTheme.colorScheme.surfaceContainerLow,
          shape = MaterialTheme.shapes.small,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = extra.losslessGreen)
            Text("0 permissions requested", style = MaterialTheme.typography.bodyMedium)
          }
        }
      }
    } else {
      items(filteredPerms, key = { it.fullName }) { perm ->
        PermissionRowCard(perm = perm, extra = extra)
      }
    }
  }
}

@Composable
private fun ManifestTabContent(
  report: ApkInspectionReport,
  extractedManifestPath: String?,
  manifestQuery: String,
  onManifestQueryChange: (String) -> Unit,
  onExtractManifest: () -> Unit,
  onOpenExtractedManifest: (String) -> Unit,
  onCopyManifest: () -> Unit,
  onOpenHex: () -> Unit,
  extra: VortexExtraColors,
) {
  val strings = LocalAppStrings.current
  val allLines = remember(report.decodedManifestXml) { report.decodedManifestXml.lines() }
  val displayedLines =
    remember(allLines, manifestQuery) {
      if (manifestQuery.isBlank()) {
        allLines.mapIndexed { idx, text -> (idx + 1) to text }
      } else {
        allLines.mapIndexedNotNull { idx, text ->
          if (text.contains(manifestQuery, ignoreCase = true)) (idx + 1) to text else null
        }
      }
    }

  Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Button(onClick = onExtractManifest, modifier = Modifier.testTag("manifest_extract_btn")) {
        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(strings.apkExtractManifest)
      }
      if (extractedManifestPath != null) {
        OutlinedButton(onClick = { onOpenExtractedManifest(extractedManifestPath) }) {
          Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(4.dp))
          Text(strings.apkOpenExtractedManifest)
        }
      }
      OutlinedButton(onClick = onCopyManifest, modifier = Modifier.testTag("manifest_copy_btn")) {
        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(strings.apkCopyManifest)
      }
      OutlinedButton(onClick = onOpenHex, modifier = Modifier.testTag("manifest_hex_btn")) {
        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text("Hex")
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      OutlinedTextField(
        value = manifestQuery,
        onValueChange = onManifestQueryChange,
        label = { Text(strings.apkManifestSearchHint) },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        singleLine = true,
        modifier = Modifier.weight(1f).testTag("manifest_search_input"),
      )
      Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = MaterialTheme.shapes.small) {
        Text(
          text =
            if (manifestQuery.isBlank()) "${allLines.size} L"
            else "${displayedLines.size} hits",
          style = MaterialTheme.typography.labelMedium,
          fontFamily = MonoFontFamily,
          color = MaterialTheme.colorScheme.primary,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
        )
      }
    }

    Surface(
      color = MaterialTheme.colorScheme.surfaceContainerLowest,
      shape = MaterialTheme.shapes.medium,
      modifier = Modifier.weight(1f).fillMaxWidth(),
    ) {
      SelectionContainer {
        LazyColumn(
          modifier = Modifier.fillMaxSize().padding(8.dp),
          verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
          items(displayedLines, key = { it.first }) { (lineNum, lineText) ->
            val styled = remember(lineText, extra) { highlightXmlLine(lineText, extra) }
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              verticalAlignment = Alignment.Top,
            ) {
              Text(
                text = lineNum.toString().padStart(4, ' '),
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f),
                modifier = Modifier.padding(end = 8.dp),
              )
              Text(
                text = styled,
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
                maxLines = 1,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun MetaBadgePill(label: String, color: Color, testTag: String? = null) {
  Surface(
    color = color.copy(alpha = 0.16f),
    shape = RoundedCornerShape(50),
    modifier = if (testTag != null) Modifier.testTag(testTag) else Modifier,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = color,
      fontWeight = FontWeight.SemiBold,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
    )
  }
}

@Composable
private fun PermissionRowCard(perm: ApkPermissionInfo, extra: VortexExtraColors) {
  val strings = LocalAppStrings.current
  val accent = if (perm.isDangerous) extra.lossyWarning else extra.losslessGreen
  Surface(
    color = MaterialTheme.colorScheme.surfaceContainerLow,
    shape = MaterialTheme.shapes.small,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Icon(
        imageVector = if (perm.isDangerous) Icons.Default.Security else Icons.Default.Shield,
        contentDescription = null,
        tint = accent,
        modifier = Modifier.size(18.dp),
      )
      Column(modifier = Modifier.weight(1f)) {
        Text(perm.shortName, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
          perm.fullName,
          style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Surface(color = accent.copy(alpha = 0.16f), shape = MaterialTheme.shapes.extraSmall) {
        Text(
          text = if (perm.isDangerous) strings.apkPermDangerous else perm.categoryLabel,
          style = MaterialTheme.typography.labelSmall,
          color = accent,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
        )
      }
    }
  }
}

@Composable
private fun ComponentGroupBlock(title: String, items: List<String>) {
  if (items.isEmpty()) return
  Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
    Text("$title (${items.size})", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    items.take(30).forEach { name ->
      Text(
        text = "• $name",
        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
    if (items.size > 30) {
      Text("... +${items.size - 30} more", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}

@Composable
private fun InfoCard(label: String, value: String) {
  Surface(
    color = MaterialTheme.colorScheme.surfaceContainerLow,
    shape = MaterialTheme.shapes.small,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
      Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
      Text(value, style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily))
    }
  }
}

private fun highlightXmlLine(line: String, extra: VortexExtraColors): AnnotatedString {
  return buildAnnotatedString {
    append(line)
    Regex("""</?[a-zA-Z0-9_:-]+|>""").findAll(line).forEach { m ->
      addStyle(SpanStyle(color = extra.syntaxTag, fontWeight = FontWeight.SemiBold), m.range.first, m.range.last + 1)
    }
    Regex("""\b([a-zA-Z0-9_:-]+)=""").findAll(line).forEach { m ->
      val g = m.groups[1] ?: return@forEach
      addStyle(SpanStyle(color = extra.syntaxType), g.range.first, g.range.last + 1)
    }
    Regex(""""[^"]*"""").findAll(line).forEach { m ->
      addStyle(SpanStyle(color = extra.syntaxString), m.range.first, m.range.last + 1)
    }
  }
}
