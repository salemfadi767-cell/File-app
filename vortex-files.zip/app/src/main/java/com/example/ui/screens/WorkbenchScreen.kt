package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.automirrored.filled.DriveFileMove
import androidx.compose.material.icons.automirrored.filled.NoteAdd
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.prefs.LayoutMode
import com.example.data.prefs.SortField
import com.example.domain.archive.ArchiveEngine
import com.example.domain.fs.ConflictAction
import com.example.domain.fs.DiffResult
import com.example.domain.fs.EditBackupManager
import com.example.domain.fs.FileCategory
import com.example.domain.fs.MagicDetectionResult
import com.example.domain.fs.VirtualFileNode
import com.example.domain.media.DiscoveredMediaKind
import com.example.domain.media.MediaBucketSummary
import com.example.domain.media.Mesh3DFormat
import com.example.i18n.LocalAppStrings
import com.example.shizuku.ShizukuStatus
import com.example.ui.components.AntivirusReportDialog
import com.example.ui.components.ArchiveCompressionDialog
import com.example.ui.components.BackupRestoreDialog
import com.example.ui.components.BatchRenameDialog
import com.example.ui.components.ChmodDialog
import com.example.ui.components.CompareResultDialog
import com.example.ui.components.DeepSearchDialog
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.FileConflictDialog
import com.example.ui.components.FileContextActionSheet
import com.example.ui.components.FilePaneCard
import com.example.ui.components.MagicFormatDialog
import com.example.ui.components.OpenAsDialog
import com.example.ui.components.OpenAsMode
import com.example.ui.components.PropertiesAndHashDialog
import com.example.ui.components.StorageAnalyzerDialog
import com.example.ui.components.StreamUrlDialog
import com.example.ui.components.TextInputDialog
import com.example.ui.components.VaultLockDialog
import com.example.ui.components.VaultUnlockDialog
import com.example.ui.theme.LocalVortexExtraColors
import com.example.ui.viewmodel.FolderViewMode
import com.example.ui.viewmodel.PaneId
import com.example.ui.viewmodel.PaneState
import com.example.ui.viewmodel.WorkbenchViewModel
import kotlinx.coroutines.launch

@Composable
fun WorkbenchScreen(
  viewModel: WorkbenchViewModel,
  onOpenEditor: (String, Boolean) -> Unit,
  onOpenViewer: (String, String) -> Unit,
  onOpenApkInspector: (String) -> Unit,
  onOpenConverter: (List<String>) -> Unit,
  onOpenSystemAccess: () -> Unit,
  onOpenSettings: () -> Unit,
  onOpenAppManager: () -> Unit,
  onOpenMusicHub: (String) -> Unit,
  onOpenDownloads: (String?) -> Unit = {},
  onOpenVaultAndTrash: () -> Unit = {},
  onOpenCloudAccounts: () -> Unit = {},
  onOpenOfficeSuite: (String) -> Unit = {},
  onOpenStudio3D: (String) -> Unit = {},
) {
  val context = LocalContext.current
  val strings = LocalAppStrings.current
  val extra = LocalVortexExtraColors.current
  val scope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }
  val focusManager = LocalFocusManager.current

  DisposableEffect(Unit) {
    onDispose { focusManager.clearFocus(force = true) }
  }

  val prefs by viewModel.preferences.collectAsStateWithLifecycle()
  val allPanes by viewModel.panes.collectAsStateWithLifecycle()
  val activePaneId by viewModel.activePane.collectAsStateWithLifecycle()
  val clipboard by viewModel.clipboard.collectAsStateWithLifecycle()
  val tasks by viewModel.tasks.collectAsStateWithLifecycle()
  val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
  val shizukuStatus by viewModel.shizukuStatus.collectAsStateWithLifecycle()
  val isRoot by viewModel.isRootAvailable.collectAsStateWithLifecycle()
  val hasAllFiles by viewModel.hasAllFilesAccess.collectAsStateWithLifecycle()
  val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
  val isSearching by viewModel.isSearching.collectAsStateWithLifecycle()
  val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
  val pendingConflict by viewModel.pendingConflict.collectAsStateWithLifecycle()
  val antivirusReport by viewModel.antivirusReport.collectAsStateWithLifecycle()
  val isAntivirusScanning by viewModel.isAntivirusScanning.collectAsStateWithLifecycle()
  val pendingBackupRestore by viewModel.pendingBackupRestore.collectAsStateWithLifecycle()
  val mediaBucketsMap by viewModel.mediaLibraryBuckets.collectAsStateWithLifecycle()

  val activePane = allPanes.getOrElse(activePaneId.index) { allPanes.first() }
  val paneCount = prefs.paneCount.coerceIn(1, 4)
  val visiblePanes = allPanes.take(paneCount)

  // Dialog & Sheet states
  var contextNode by remember { mutableStateOf<VirtualFileNode?>(null) }
  var openAsTarget by remember { mutableStateOf<VirtualFileNode?>(null) }
  var magicInspectPair by remember { mutableStateOf<Pair<VirtualFileNode, MagicDetectionResult>?>(null) }
  var showDeleteConfirm by remember { mutableStateOf(false) }
  var vaultLockTarget by remember { mutableStateOf<VirtualFileNode?>(null) }
  var vaultUnlockTarget by remember { mutableStateOf<VirtualFileNode?>(null) }
  var recoveryKeyBanner by remember { mutableStateOf<String?>(null) }
  var showArchiveDialog by remember { mutableStateOf(false) }
  var showNewFolderDialog by remember { mutableStateOf(false) }
  var showNewFileDialog by remember { mutableStateOf(false) }
  var renameTarget by remember { mutableStateOf<VirtualFileNode?>(null) }
  var chmodTarget by remember { mutableStateOf<VirtualFileNode?>(null) }
  var propsTarget by remember { mutableStateOf<VirtualFileNode?>(null) }
  var compareResult by remember { mutableStateOf<DiffResult?>(null) }
  var showDeepSearch by remember { mutableStateOf(false) }
  var showBookmarksDialog by remember { mutableStateOf(false) }
  var showSortMenu by remember { mutableStateOf(false) }
  var showStreamUrlDialog by remember { mutableStateOf(false) }
  var showBatchRenameDialog by remember { mutableStateOf(false) }
  var showStorageAnalyzer by remember { mutableStateOf(false) }

  val allFilesLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
      viewModel.refreshPermissionState()
    }

  val safAndroidDataLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
      if (uri != null) {
        try {
          context.contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
          )
        } catch (_: Throwable) {}
        viewModel.onSafTreeGranted(uri)
      }
    }

  LaunchedEffect(statusBanner) {
    statusBanner?.let {
      snackbarHostState.showSnackbar(it)
      viewModel.clearBanner()
    }
  }

  BackHandler(enabled = activePane.selectedPaths.isNotEmpty() || activePane.currentPath != "/") {
    focusManager.clearFocus(force = true)
    if (activePane.selectedPaths.isNotEmpty()) {
      viewModel.clearSelection(activePaneId)
    } else {
      viewModel.navigateUp(activePaneId)
    }
  }

  fun openNode(paneId: PaneId, node: VirtualFileNode) {
    focusManager.clearFocus(force = true)
    viewModel.setActivePane(paneId)
    if (node.isDirectory) {
      viewModel.navigatePane(paneId, node.path)
      return
    }
    viewModel.recordRecentFile(node)
    val paneViewMode = allPanes.getOrElse(paneId.index) { activePane }.viewMode
    when {
      EditBackupManager.isBackupFile(node.name) -> viewModel.inspectAndPromptBackup(node.path)
      Mesh3DFormat.is3DFile(node.name) -> onOpenStudio3D(node.path)
      paneViewMode == FolderViewMode.MUSIC && node.category == FileCategory.AUDIO -> onOpenMusicHub(node.path)
      paneViewMode == FolderViewMode.GALLERY && node.category == FileCategory.IMAGE -> onOpenViewer(node.path, "image")
      paneViewMode == FolderViewMode.GALLERY && node.category == FileCategory.VIDEO -> onOpenViewer(node.path, "video")
      paneViewMode == FolderViewMode.VIDEO && node.category == FileCategory.VIDEO -> onOpenViewer(node.path, "video")
      paneViewMode == FolderViewMode.CODE_DOCS && node.category == FileCategory.CODE -> onOpenEditor(node.path, false)
      node.category == FileCategory.VAULT -> vaultUnlockTarget = node
      node.category == FileCategory.TORRENT -> onOpenDownloads(node.path)
      node.isOfficeDocument -> onOpenOfficeSuite(node.path)
      node.category == FileCategory.APK -> onOpenApkInspector(node.path)
      node.category == FileCategory.ARCHIVE ->
        viewModel.navigatePane(paneId, ArchiveEngine.buildArchiveUri(node.path, ""))
      node.category == FileCategory.CODE -> onOpenEditor(node.path, false)
      node.category == FileCategory.AUDIO -> onOpenMusicHub(node.path)
      node.category == FileCategory.IMAGE ||
        node.category == FileCategory.VIDEO ||
        node.category == FileCategory.PDF ||
        node.category == FileCategory.DATABASE -> onOpenViewer(node.path, "auto")
      else -> onOpenViewer(node.path, "auto")
    }
  }

  @Composable
  fun RenderPane(pane: PaneState, compact: Boolean, modifier: Modifier) {
    val bucketsForPane =
      when (pane.viewMode) {
        FolderViewMode.GALLERY -> mediaBucketsMap[DiscoveredMediaKind.PHOTOS].orEmpty()
        FolderViewMode.VIDEO -> mediaBucketsMap[DiscoveredMediaKind.VIDEOS].orEmpty()
        FolderViewMode.MUSIC -> mediaBucketsMap[DiscoveredMediaKind.AUDIO].orEmpty()
        else -> emptyList()
      }
    PaneContainer(
      paneId = pane.id,
      pane = pane,
      isActive = activePaneId == pane.id,
      compact = compact,
      bookmarks = bookmarks.map { it.path }.toSet(),
      hasAllFiles = hasAllFiles,
      discoveredBuckets = bucketsForPane,
      viewModel = viewModel,
      onOpenNode = { openNode(pane.id, it) },
      onContextNode = { contextNode = it },
      onOpenMusicHub = onOpenMusicHub,
      onGrantAllFiles = { allFilesLauncher.launch(viewModel.buildAllFilesPermissionIntent()) },
      onOpenSystemGateway = onOpenSystemAccess,
      onAndroidDataJump = {
        if (shizukuStatus == ShizukuStatus.CONNECTED || isRoot) {
          viewModel.navigatePane(pane.id, "/storage/emulated/0/Android/data")
        } else {
          safAndroidDataLauncher.launch(viewModel.androidDataSafInitialUri())
        }
      },
      modifier = modifier,
    )
  }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      WorkbenchTopBar(
        shizukuStatus = shizukuStatus,
        isRoot = isRoot,
        hasAllFiles = hasAllFiles,
        paneCount = paneCount,
        onCyclePaneCount = {
          val nextCount = if (paneCount >= 4) 1 else paneCount + 1
          viewModel.setPaneCount(nextCount)
        },
        onOpenSearch = { showDeepSearch = true },
        onOpenBookmarks = { showBookmarksDialog = true },
        onOpenSortMenu = { showSortMenu = true },
        onOpenConverter = {
          val sel = activePane.selectedNodes.map { it.path }
          onOpenConverter(sel)
        },
        onOpenSystemAccess = onOpenSystemAccess,
        onOpenSettings = onOpenSettings,
        sortMenuExpanded = showSortMenu,
        onDismissSortMenu = { showSortMenu = false },
        sortField = prefs.sortField,
        sortAsc = prefs.sortAscending,
        showHidden = prefs.showHiddenFiles,
        onSelectSort = { field ->
          val asc = if (prefs.sortField == field) !prefs.sortAscending else true
          viewModel.setSort(field, asc)
          showSortMenu = false
        },
        onToggleHidden = {
          viewModel.setShowHidden(!prefs.showHiddenFiles)
          showSortMenu = false
        },
      )
    },
    bottomBar = {
      Column(
        modifier =
          Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .navigationBarsPadding(),
      ) {
        // Antivirus Scanning Indicator
        AnimatedVisibility(visible = isAntivirusScanning) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .background(MaterialTheme.colorScheme.secondaryContainer)
              .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Text(
              text = "${strings.antivirusSection}…",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
          }
        }

        // Active Background Tasks Strip
        AnimatedVisibility(visible = tasks.isNotEmpty()) {
          Column(
            modifier =
              Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            tasks.take(2).forEach { task ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "${task.title} (${task.progress}%)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  LinearProgressIndicator(
                    progress = { task.progress / 100f },
                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                  )
                }
                IconButton(
                  onClick = { viewModel.cancelTask(task.id) },
                  modifier = Modifier.size(28.dp),
                ) {
                  Icon(Icons.Default.Close, contentDescription = strings.cancel, modifier = Modifier.size(16.dp))
                }
              }
            }
          }
        }

        // Clipboard Bar
        AnimatedVisibility(visible = clipboard.items.isNotEmpty()) {
          Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                text = strings.clipboardReady(clipboard.items.size, clipboard.isCut),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
              )
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { viewModel.pasteToPane(activePaneId) }) {
                  Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(Modifier.width(4.dp))
                  Text(strings.paste)
                }
              }
            }
          }
        }

        // MT-Style Action Dock
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Row(
          modifier =
            Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState())
              .padding(horizontal = 6.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          val hasSel = activePane.selectedPaths.isNotEmpty()
          if (hasSel) {
            DockActionButton(Icons.AutoMirrored.Filled.DriveFileMove, strings.copyToOtherPane) {
              viewModel.transferToOppositePane(activePaneId, isMove = false)
            }
            DockActionButton(Icons.Default.SwapHoriz, strings.moveToOtherPane) {
              viewModel.transferToOppositePane(activePaneId, isMove = true)
            }
            DockActionButton(Icons.Default.ContentCopy, strings.copy) {
              viewModel.copyToClipboard(activePaneId, isCut = false)
            }
            DockActionButton(Icons.Default.ContentCut, strings.cut) {
              viewModel.copyToClipboard(activePaneId, isCut = true)
            }
            DockActionButton(Icons.Default.Archive, strings.compress, testTag = "dock_compress_btn") {
              showArchiveDialog = true
            }
            DockActionButton(Icons.Default.DriveFileRenameOutline, strings.batchRename) {
              showBatchRenameDialog = true
            }
            DockActionButton(Icons.Default.Transform, strings.convertFormat) {
              onOpenConverter(activePane.selectedNodes.map { it.path })
            }
            val allSelected =
              activePane.items.isNotEmpty() &&
                activePane.selectedPaths.size >= activePane.items.size &&
                activePane.items.all { it.path in activePane.selectedPaths }
            DockActionButton(
              icon = Icons.Default.SelectAll,
              label = strings.selectAll,
              tint = if (allSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
              testTag = "dock_select_all_btn",
            ) {
              viewModel.selectAll(activePaneId)
            }
            DockActionButton(Icons.Default.Close, strings.clearSelection, testTag = "dock_clear_sel_btn") {
              viewModel.clearSelection(activePaneId)
            }
            DockActionButton(Icons.Default.Delete, strings.delete, tint = extra.lossyWarning, testTag = "dock_delete_btn") {
              showDeleteConfirm = true
            }
          } else {
            DockActionButton(Icons.Default.CreateNewFolder, strings.newFolder, testTag = "dock_new_folder_btn") {
              showNewFolderDialog = true
            }
            DockActionButton(Icons.AutoMirrored.Filled.NoteAdd, strings.newFile, testTag = "dock_new_file_btn") {
              showNewFileDialog = true
            }
            DockActionButton(Icons.Default.CloudDownload, strings.downloadManagerTitle, testTag = "dock_downloads_btn") {
              onOpenDownloads(null)
            }
            DockActionButton(Icons.Default.LiveTv, strings.streamUrlTitle, testTag = "dock_stream_btn") {
              showStreamUrlDialog = true
            }
            DockActionButton(Icons.Default.MusicNote, strings.musicHubTitle, testTag = "dock_music_btn") {
              onOpenMusicHub("")
            }
            DockActionButton(Icons.Default.Description, strings.officeSuiteTitle, testTag = "dock_office_btn") {
              focusManager.clearFocus(force = true)
              onOpenOfficeSuite("")
            }
            DockActionButton(Icons.Default.ViewInAr, strings.studio3dTitle, testTag = "dock_studio3d_btn") {
              focusManager.clearFocus(force = true)
              onOpenStudio3D("")
            }
            DockActionButton(Icons.Default.EnhancedEncryption, strings.vaultTitle, testTag = "dock_vault_btn") {
              focusManager.clearFocus(force = true)
              onOpenVaultAndTrash()
            }
            DockActionButton(Icons.Default.Cloud, strings.cloudAccountsTitle, testTag = "dock_cloud_btn") {
              onOpenCloudAccounts()
            }
            DockActionButton(Icons.Default.Apps, strings.appManagerTitle, testTag = "dock_apps_btn") {
              onOpenAppManager()
            }
            DockActionButton(Icons.Default.PieChart, strings.storageAnalyzerTitle) {
              showStorageAnalyzer = true
            }
            DockActionButton(Icons.Default.SelectAll, strings.selectAll, testTag = "dock_select_all_empty_btn") {
              viewModel.selectAll(activePaneId)
            }
            DockActionButton(Icons.AutoMirrored.Filled.CompareArrows, strings.compare) {
              scope.launch { compareResult = viewModel.compareAcrossPanes() }
            }
            DockActionButton(Icons.Default.Transform, strings.converterHub) {
              onOpenConverter(emptyList())
            }
            DockActionButton(Icons.Default.AdminPanelSettings, strings.systemAccess) {
              onOpenSystemAccess()
            }
          }
        }
      }
    },
  ) { innerPadding ->
    BoxWithConstraints(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .padding(horizontal = 6.dp, vertical = 6.dp),
    ) {
      val wideScreen = maxWidth >= 600.dp
      when {
        prefs.layoutMode == LayoutMode.SINGLE_PANE || prefs.layoutMode == LayoutMode.TABBED || paneCount == 1 -> {
          RenderPane(activePane, compact = false, modifier = Modifier.fillMaxSize())
        }

        paneCount == 2 -> {
          Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(if (wideScreen) 6.dp else 5.dp),
          ) {
            RenderPane(visiblePanes[0], compact = !wideScreen, modifier = Modifier.weight(1f).fillMaxHeight())
            RenderPane(visiblePanes[1], compact = !wideScreen, modifier = Modifier.weight(1f).fillMaxHeight())
          }
        }

        paneCount == 3 -> {
          if (wideScreen) {
            Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              visiblePanes.forEach { p ->
                RenderPane(p, compact = true, modifier = Modifier.weight(1f).fillMaxHeight())
              }
            }
          } else {
            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
              Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                RenderPane(visiblePanes[0], compact = true, modifier = Modifier.weight(1f).fillMaxHeight())
                RenderPane(visiblePanes[1], compact = true, modifier = Modifier.weight(1f).fillMaxHeight())
              }
              RenderPane(visiblePanes[2], compact = true, modifier = Modifier.weight(1f).fillMaxWidth())
            }
          }
        }

        else -> {
          // 4 panes: 2x2 grid on portrait, or 4 columns on ultra-wide / 2x2 grid
          if (maxWidth >= 900.dp) {
            Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              visiblePanes.forEach { p ->
                RenderPane(p, compact = true, modifier = Modifier.weight(1f).fillMaxHeight())
              }
            }
          } else {
            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
              Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                RenderPane(visiblePanes[0], compact = true, modifier = Modifier.weight(1f).fillMaxHeight())
                RenderPane(visiblePanes[1], compact = true, modifier = Modifier.weight(1f).fillMaxHeight())
              }
              Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                RenderPane(visiblePanes[2], compact = true, modifier = Modifier.weight(1f).fillMaxHeight())
                RenderPane(visiblePanes[3], compact = true, modifier = Modifier.weight(1f).fillMaxHeight())
              }
            }
          }
        }
      }
    }
  }

  // Context Action Sheet
  contextNode?.let { node ->
    FileContextActionSheet(
      node = node,
      onDismiss = { contextNode = null },
      onOpenViewer = { onOpenViewer(node.path, "auto") },
      onOpenOffice = { onOpenOfficeSuite(node.path) },
      onOpenAs = { openAsTarget = node },
      onDetectFormat = {
        scope.launch {
          val res = viewModel.inspectMagicFormat(node)
          magicInspectPair = node to res
        }
      },
      onOpenEditor = { onOpenEditor(node.path, false) },
      onOpenHex = { onOpenEditor(node.path, true) },
      onInspectApk = { onOpenApkInspector(node.path) },
      onConvertSignApk = { viewModel.convertAndSignApk(activePaneId, node) },
      onLockOrUnlockVault = {
        if (node.category == FileCategory.VAULT) vaultUnlockTarget = node
        else vaultLockTarget = node
      },
      onBrowseArchive = {
        viewModel.navigatePane(activePaneId, ArchiveEngine.buildArchiveUri(node.path, ""))
      },
      onExtractHere = { viewModel.extractArchive(activePaneId, node, toOppositePane = false) },
      onExtractToOther = { viewModel.extractArchive(activePaneId, node, toOppositePane = true) },
      onConvert = { onOpenConverter(listOf(node.path)) },
      onCompress = {
        viewModel.clearSelection(activePaneId)
        viewModel.toggleSelection(activePaneId, node.path)
        showArchiveDialog = true
      },
      onRename = { renameTarget = node },
      onChmod = { chmodTarget = node },
      onProperties = { propsTarget = node },
      onAntivirusScan = { viewModel.scanPathWithAntivirus(node.path) },
      onShare = { viewModel.shareFile(node) },
      onOpenExternal = { viewModel.openExternalApp(node) },
      onDelete = {
        viewModel.clearSelection(activePaneId)
        viewModel.toggleSelection(activePaneId, node.path)
        showDeleteConfirm = true
      },
    )
  }

  if (showDeleteConfirm && activePane.selectedPaths.isNotEmpty()) {
    DeleteConfirmDialog(
      count = activePane.selectedPaths.size,
      trashRetentionDays = prefs.trashRetentionDays,
      onDismiss = { showDeleteConfirm = false },
      onConfirmDelete = { permanent -> viewModel.deleteSelected(activePaneId, permanent) },
    )
  }

  magicInspectPair?.let { (node, res) ->
    MagicFormatDialog(
      node = node,
      result = res,
      onOpenReader = { readerId ->
        when (readerId) {
          "word", "excel", "pptx" -> onOpenOfficeSuite(node.path)
          "apk" -> onOpenApkInspector(node.path)
          "archive" -> viewModel.navigatePane(activePaneId, ArchiveEngine.buildArchiveUri(node.path, ""))
          "hex" -> onOpenEditor(node.path, true)
          "text" -> onOpenEditor(node.path, false)
          else -> onOpenViewer(node.path, readerId)
        }
      },
      onFixExtension = { ext -> viewModel.repairExtension(activePaneId, node, ext) },
      onDismiss = { magicInspectPair = null },
    )
  }

  vaultLockTarget?.let { target ->
    VaultLockDialog(
      targetName = target.name,
      onDismiss = { vaultLockTarget = null },
      onConfirmLock = { pwd ->
        viewModel.lockNodeToVault(activePaneId, target, pwd) { key ->
          recoveryKeyBanner = key
        }
      },
    )
  }

  vaultUnlockTarget?.let { target ->
    VaultUnlockDialog(
      targetName = target.name,
      onDismiss = { vaultUnlockTarget = null },
      onConfirmUnlock = { secret -> viewModel.unlockVaultFile(activePaneId, target, secret) },
    )
  }

  recoveryKeyBanner?.let { recKey ->
    AlertDialog(
      onDismissRequest = { recoveryKeyBanner = null },
      title = { Text(strings.vaultTitle) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(strings.recoveryKeyNotice, style = MaterialTheme.typography.bodySmall)
          Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.small) {
            Text(
              recKey,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(12.dp),
            )
          }
        }
      },
      confirmButton = { TextButton(onClick = { recoveryKeyBanner = null }) { Text(strings.close) } },
    )
  }

  openAsTarget?.let { target ->
    OpenAsDialog(
      node = target,
      onSelectMode = { mode ->
        viewModel.recordRecentFile(target)
        when (mode) {
          OpenAsMode.TEXT_CODE -> onOpenEditor(target.path, false)
          OpenAsMode.HEX -> onOpenEditor(target.path, true)
          OpenAsMode.IMAGE,
          OpenAsMode.VIDEO,
          OpenAsMode.AUDIO,
          OpenAsMode.PDF,
          OpenAsMode.DATABASE -> onOpenViewer(target.path, mode.routeParam)
          OpenAsMode.ARCHIVE ->
            viewModel.navigatePane(activePaneId, ArchiveEngine.buildArchiveUri(target.path, ""))
          OpenAsMode.APK -> onOpenApkInspector(target.path)
          OpenAsMode.EXTERNAL -> viewModel.openExternalApp(target)
        }
      },
      onDismiss = { openAsTarget = null },
    )
  }

  if (showArchiveDialog) {
    ArchiveCompressionDialog(
      selectedNodes = activePane.selectedNodes,
      estimateMediaSize = viewModel::estimateMediaCompression,
      onDismiss = { showArchiveDialog = false },
      onCompressArchive = { name, format, level, pwd ->
        viewModel.compressSelectedArchive(activePaneId, name, format, level, pwd)
      },
      onCompressImages = { mode, quality, scale, fmt ->
        viewModel.compressSelectedImages(activePaneId, mode, quality, scale, fmt)
      },
      onReduceUniversal = { req ->
        viewModel.reduceFilesUniversal(activePaneId, req)
      },
    )
  }

  if (showStreamUrlDialog) {
    StreamUrlDialog(
      onDismiss = { showStreamUrlDialog = false },
      onPlayUrl = { url -> onOpenViewer(url, "video") },
      onDownloadUrl = { url -> onOpenDownloads(url) },
    )
  }

  if (showBatchRenameDialog) {
    BatchRenameDialog(
      selectedCount = activePane.selectedPaths.size,
      sampleNames = activePane.selectedNodes.map { it.name },
      onDismiss = { showBatchRenameDialog = false },
      onConfirm = { p, s, f, r, cnt, start ->
        viewModel.batchRename(activePaneId, p, s, f, r, cnt, start)
      },
    )
  }

  if (showStorageAnalyzer) {
    StorageAnalyzerDialog(
      rootPath = activePane.currentPath,
      analyze = viewModel::analyzeDirectoryStorage,
      onNavigateTo = { path -> viewModel.navigatePane(activePaneId, path) },
      onDismiss = { showStorageAnalyzer = false },
    )
  }

  if (showNewFolderDialog) {
    TextInputDialog(
      title = strings.newFolder,
      label = strings.newFolder,
      initialValue = "NewFolder",
      onDismiss = { showNewFolderDialog = false },
      onConfirm = { viewModel.createFolder(activePaneId, it) },
    )
  }

  if (showNewFileDialog) {
    TextInputDialog(
      title = strings.newFile,
      label = strings.newFile,
      initialValue = "script.py",
      onDismiss = { showNewFileDialog = false },
      onConfirm = { viewModel.createFile(activePaneId, it) },
    )
  }

  renameTarget?.let { target ->
    TextInputDialog(
      title = strings.rename,
      label = strings.rename,
      initialValue = target.name,
      onDismiss = { renameTarget = null },
      onConfirm = { viewModel.renameNode(activePaneId, target, it) },
    )
  }

  chmodTarget?.let { target ->
    ChmodDialog(
      node = target,
      onDismiss = { chmodTarget = null },
      onApply = { octal -> viewModel.chmodNode(activePaneId, target, octal) },
    )
  }

  propsTarget?.let { target ->
    PropertiesAndHashDialog(
      node = target,
      computeHashes = viewModel::computeHashes,
      onDismiss = { propsTarget = null },
    )
  }

  compareResult?.let { diff ->
    CompareResultDialog(diff = diff, onDismiss = { compareResult = null })
  }

  if (showDeepSearch) {
    DeepSearchDialog(
      results = searchResults,
      isSearching = isSearching,
      onSearch = { q, content, rx -> viewModel.runDeepSearch(activePaneId, q, content, rx) },
      onHitClick = { hit ->
        if (hit.node.isDirectory) {
          viewModel.navigatePane(activePaneId, hit.node.path)
        } else {
          openNode(activePaneId, hit.node)
        }
      },
      onDismiss = {
        showDeepSearch = false
        viewModel.clearSearch()
      },
    )
  }

  if (showBookmarksDialog) {
    AlertDialog(
      onDismissRequest = { showBookmarksDialog = false },
      title = { Text(strings.bookmarks) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          if (bookmarks.isEmpty()) {
            Text(strings.emptyFolderHint, style = MaterialTheme.typography.bodySmall)
          } else {
            bookmarks.forEach { bm ->
              Surface(
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier =
                  Modifier
                    .fillMaxWidth()
                    .clickable {
                      viewModel.navigatePane(activePaneId, bm.path)
                      showBookmarksDialog = false
                    },
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(bm.label, style = MaterialTheme.typography.titleSmall)
                    Text(bm.path, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                  IconButton(onClick = { viewModel.toggleBookmark(bm.path) }) {
                    Icon(Icons.Default.Delete, contentDescription = strings.delete, modifier = Modifier.size(18.dp))
                  }
                }
              }
            }
          }
        }
      },
      confirmButton = { TextButton(onClick = { showBookmarksDialog = false }) { Text(strings.close) } },
    )
  }

  pendingConflict?.let { conflictUi ->
    FileConflictDialog(
      conflict = conflictUi.info,
      onResolve = { action, applyAll ->
        viewModel.resolvePendingConflict(action, applyAll)
      },
    )
  }

  antivirusReport?.let { report ->
    AntivirusReportDialog(
      report = report,
      onQuarantine = { path -> viewModel.quarantineFileFromAntivirus(path) },
      onDelete = { path -> viewModel.deleteFileFromAntivirus(path) },
      onDismiss = { viewModel.dismissAntivirusReport() },
    )
  }

  pendingBackupRestore?.let { meta ->
    BackupRestoreDialog(
      meta = meta,
      onRestore = { viewModel.confirmRestoreBackup(activePaneId, meta) },
      onDismiss = { viewModel.dismissBackupRestore() },
    )
  }
}

@Composable
private fun PaneContainer(
  paneId: PaneId,
  pane: PaneState,
  isActive: Boolean,
  compact: Boolean,
  bookmarks: Set<String>,
  hasAllFiles: Boolean,
  discoveredBuckets: List<MediaBucketSummary> = emptyList(),
  viewModel: WorkbenchViewModel,
  onOpenNode: (VirtualFileNode) -> Unit,
  onContextNode: (VirtualFileNode) -> Unit,
  onOpenMusicHub: (String) -> Unit,
  onGrantAllFiles: () -> Unit,
  onOpenSystemGateway: () -> Unit,
  onAndroidDataJump: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val prefs by viewModel.preferences.collectAsStateWithLifecycle()
  FilePaneCard(
    pane = pane,
    isActive = isActive,
    isBookmarked = pane.currentPath in bookmarks,
    hasAllFilesAccess = hasAllFiles,
    showQuickJumps = true,
    compactMode = compact,
    longFilenameMode = prefs.longFilenameMode,
    thumbnailLoader = viewModel.thumbnailLoader,
    discoveredBuckets = discoveredBuckets,
    onActivate = { viewModel.setActivePane(paneId) },
    onNavigate = { viewModel.navigatePane(paneId, it) },
    onNavigateUp = { viewModel.navigateUp(paneId) },
    onRefresh = { viewModel.loadPane(paneId) },
    onToggleBookmark = { viewModel.toggleBookmark(pane.currentPath) },
    onAddTab = { viewModel.addTab(paneId) },
    onSwitchTab = { viewModel.switchTab(paneId, it) },
    onCloseTab = { viewModel.closeTab(paneId, it) },
    onQuickJumpInternal = { viewModel.navigatePane(paneId, viewModel.internalRootPath) },
    onQuickJumpDownloads = { viewModel.navigatePane(paneId, viewModel.downloadsPath) },
    onQuickJumpWorkspace = { viewModel.navigatePane(paneId, viewModel.appWorkspacePath) },
    onQuickJumpRoot = { viewModel.navigatePane(paneId, "/") },
    onQuickJumpAndroidData = onAndroidDataJump,
    onChangeViewMode = { mode -> viewModel.setPaneViewMode(paneId, mode) },
    onOpenFolderInMusicHub = { firstTrackPath -> onOpenMusicHub(firstTrackPath) },
    onItemClick = { node ->
      if (pane.selectedPaths.isNotEmpty()) {
        viewModel.toggleSelection(paneId, node.path)
      } else {
        onOpenNode(node)
      }
    },
    onItemLongClick = { node -> viewModel.toggleSelection(paneId, node.path) },
    onItemMoreClick = { node ->
      viewModel.setActivePane(paneId)
      onContextNode(node)
    },
    onSelectRange = { paths -> viewModel.setSelectedRange(paneId, paths) },
    onGrantAllFiles = onGrantAllFiles,
    onOpenSystemGateway = onOpenSystemGateway,
    modifier = modifier,
  )
}

@Composable
private fun WorkbenchTopBar(
  shizukuStatus: ShizukuStatus,
  isRoot: Boolean,
  hasAllFiles: Boolean,
  paneCount: Int,
  onCyclePaneCount: () -> Unit,
  onOpenSearch: () -> Unit,
  onOpenBookmarks: () -> Unit,
  onOpenSortMenu: () -> Unit,
  onOpenConverter: () -> Unit,
  onOpenSystemAccess: () -> Unit,
  onOpenSettings: () -> Unit,
  sortMenuExpanded: Boolean,
  onDismissSortMenu: () -> Unit,
  sortField: SortField,
  sortAsc: Boolean,
  showHidden: Boolean,
  onSelectSort: (SortField) -> Unit,
  onToggleHidden: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val extra = LocalVortexExtraColors.current

  val (badgeText, badgeColor) =
    when {
      isRoot -> strings.accessModeRoot to extra.rootGold
      shizukuStatus == ShizukuStatus.CONNECTED -> strings.accessModeShizuku to extra.shizukuCyan
      hasAllFiles -> strings.accessModeAllFiles to extra.losslessGreen
      else -> strings.accessModeStandard to MaterialTheme.colorScheme.onSurfaceVariant
    }

  Box(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surface)
        .statusBarsPadding(),
  ) {
    Image(
      painter = painterResource(id = R.drawable.img_workspace_hero),
      contentDescription = null,
      contentScale = ContentScale.Crop,
      modifier = Modifier.matchParentSize().alpha(0.18f),
    )
    Box(
      modifier =
        Modifier
          .matchParentSize()
          .background(
            Brush.verticalGradient(
              listOf(
                MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                MaterialTheme.colorScheme.background.copy(alpha = 0.92f),
              )
            )
          ),
    )

    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = strings.appTitle,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Surface(
            color = badgeColor.copy(alpha = 0.16f),
            shape = RoundedCornerShape(50),
            modifier = Modifier.clickable(onClick = onOpenSystemAccess).testTag("access_badge"),
          ) {
            Text(
              text = badgeText,
              style = MaterialTheme.typography.labelSmall,
              color = badgeColor,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            )
          }
        }
        Text(
          text = strings.subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onOpenSearch, modifier = Modifier.testTag("top_search_btn")) {
          Icon(Icons.Default.Search, contentDescription = strings.deepSearch)
        }
        Surface(
          shape = MaterialTheme.shapes.small,
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
          modifier = Modifier.clickable(onClick = onCyclePaneCount).testTag("top_layout_btn"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp),
          ) {
            Icon(Icons.Default.ViewColumn, contentDescription = "Panes", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Text("${paneCount}P", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
          }
        }
        IconButton(onClick = onOpenConverter, modifier = Modifier.testTag("top_converter_btn")) {
          Icon(Icons.Default.Transform, contentDescription = strings.converterHub)
        }
        IconButton(onClick = onOpenBookmarks) {
          Icon(Icons.Default.Bookmarks, contentDescription = strings.bookmarks)
        }
        Box {
          IconButton(onClick = onOpenSortMenu) {
            Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort")
          }
          DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = onDismissSortMenu) {
            listOf(
              SortField.NAME to strings.sortName,
              SortField.SIZE to strings.sortSize,
              SortField.DATE to strings.sortDate,
              SortField.TYPE to strings.sortType,
            ).forEach { (field, label) ->
              val indicator = if (sortField == field) (if (sortAsc) " ↑" else " ↓") else ""
              DropdownMenuItem(text = { Text("$label$indicator") }, onClick = { onSelectSort(field) })
            }
            HorizontalDivider()
            DropdownMenuItem(
              text = { Text("${strings.showHidden}: ${if (showHidden) "ON" else "OFF"}") },
              onClick = onToggleHidden,
            )
          }
        }
        IconButton(onClick = onOpenSettings, modifier = Modifier.testTag("top_settings_btn")) {
          Icon(Icons.Default.Palette, contentDescription = strings.themeStudio)
        }
      }
    }
  }
}

@Composable
private fun DockActionButton(
  icon: ImageVector,
  label: String,
  tint: Color = MaterialTheme.colorScheme.onSurface,
  testTag: String? = null,
  onClick: () -> Unit,
) {
  Surface(
    shape = MaterialTheme.shapes.small,
    color = MaterialTheme.colorScheme.surfaceContainerHigh,
    modifier =
      Modifier
        .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
        .clickable(onClick = onClick),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
      Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = tint,
        maxLines = 1,
      )
    }
  }
}
