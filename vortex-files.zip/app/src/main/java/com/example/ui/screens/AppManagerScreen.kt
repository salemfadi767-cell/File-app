package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.fs.formatFileSize
import com.example.i18n.LocalAppStrings
import com.example.ui.viewmodel.InstalledAppInfo
import com.example.ui.viewmodel.WorkbenchViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppManagerScreen(
  viewModel: WorkbenchViewModel,
  onInspectApk: (String) -> Unit,
  onBack: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val activePaneId by viewModel.activePane.collectAsStateWithLifecycle()
  val focusManager = LocalFocusManager.current
  var apps by remember { mutableStateOf<List<InstalledAppInfo>>(emptyList()) }
  var isLoading by remember { mutableStateOf(true) }
  var query by remember { mutableStateOf("") }
  var showSystemApps by remember { mutableStateOf(false) }

  DisposableEffect(Unit) {
    onDispose { runCatching { focusManager.clearFocus(force = true) } }
  }
  BackHandler {
    runCatching { focusManager.clearFocus(force = true) }
    onBack()
  }

  LaunchedEffect(Unit) {
    isLoading = true
    apps = viewModel.listInstalledApps()
    isLoading = false
  }

  val filtered =
    remember(apps, query, showSystemApps) {
      apps.filter { app ->
        (showSystemApps || !app.isSystemApp) &&
          (query.isBlank() ||
            app.appName.contains(query, ignoreCase = true) ||
            app.packageName.contains(query, ignoreCase = true))
      }
    }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    topBar = {
      TopAppBar(
        modifier = Modifier.statusBarsPadding(),
        title = { Text(strings.appManagerTitle) },
        navigationIcon = {
          IconButton(
            onClick = {
              runCatching { focusManager.clearFocus(force = true) }
              onBack()
            },
            modifier = Modifier.testTag("app_manager_back"),
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
  ) { innerPadding ->
    Column(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .navigationBarsPadding()
          .padding(12.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        label = { Text(strings.searchHint) },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("app_manager_search_input"),
      )
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(
          selected = !showSystemApps,
          onClick = { showSystemApps = false },
          label = { Text("User Apps (${apps.count { !it.isSystemApp }})") },
        )
        FilterChip(
          selected = showSystemApps,
          onClick = { showSystemApps = true },
          label = { Text("All + System (${apps.size})") },
        )
      }

      if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          CircularProgressIndicator()
        }
      } else {
        LazyColumn(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          items(filtered, key = { it.packageName }) { app ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
              Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  InstalledAppIcon(packageName = app.packageName)
                  Column(modifier = Modifier.weight(1f)) {
                    Text(app.appName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                      "${app.packageName} • v${app.versionName}",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                  Column(horizontalAlignment = Alignment.End) {
                    Text(formatFileSize(app.apkSizeBytes), style = MaterialTheme.typography.labelMedium)
                    if (app.splitPaths.isNotEmpty()) {
                      AssistChip(
                        onClick = {},
                        label = { Text("+${app.splitPaths.size} Splits") },
                      )
                    }
                  }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  Button(
                    onClick = {
                      runCatching { focusManager.clearFocus(force = true) }
                      viewModel.extractInstalledApk(activePaneId, app)
                      onBack()
                    },
                    modifier = Modifier.testTag("extract_apk_${app.packageName}"),
                  ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(strings.extractApkAction)
                  }
                  OutlinedButton(
                    onClick = {
                      runCatching { focusManager.clearFocus(force = true) }
                      onInspectApk(app.apkPath)
                    },
                  ) {
                    Text(strings.inspectApk)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun InstalledAppIcon(packageName: String) {
  val context = LocalContext.current
  val iconBitmap by produceState<ImageBitmap?>(initialValue = null, packageName) {
    value = withContext(Dispatchers.IO) {
      runCatching {
        val drawable = context.packageManager.getApplicationIcon(packageName)
        val w = drawable.intrinsicWidth.coerceIn(48, 128)
        val h = drawable.intrinsicHeight.coerceIn(48, 128)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, w, h)
        drawable.draw(canvas)
        bmp.asImageBitmap()
      }.getOrNull()
    }
  }
  if (iconBitmap != null) {
    Image(
      bitmap = iconBitmap!!,
      contentDescription = packageName,
      modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)),
    )
  } else {
    Icon(
      Icons.Default.Android,
      contentDescription = packageName,
      tint = MaterialTheme.colorScheme.primary,
      modifier = Modifier.size(36.dp),
    )
  }
}
