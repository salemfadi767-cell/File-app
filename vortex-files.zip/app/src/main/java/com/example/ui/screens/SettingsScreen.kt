package com.example.ui.screens

import android.os.Environment
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.prefs.LayoutMode
import com.example.data.prefs.LongFilenameMode
import com.example.i18n.AppLanguage
import com.example.i18n.LocalAppStrings
import com.example.ui.theme.AccentStyle
import com.example.ui.theme.AmoledBg
import com.example.ui.theme.CobaltBg
import com.example.ui.theme.CobaltPrimary
import com.example.ui.theme.CyberBg
import com.example.ui.theme.CyberEmeraldPrimary
import com.example.ui.theme.CyberGoldSecondary
import com.example.ui.theme.LightBg
import com.example.ui.theme.LightPrimary
import com.example.ui.theme.ThemePreset
import com.example.ui.viewmodel.WorkbenchViewModel
import java.io.File
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
  viewModel: WorkbenchViewModel,
  onBack: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val prefs by viewModel.preferences.collectAsStateWithLifecycle()
  val focusManager = LocalFocusManager.current
  var showFolderEditDialog by remember { mutableStateOf(false) }

  DisposableEffect(Unit) {
    onDispose { runCatching { focusManager.clearFocus(force = true) } }
  }
  BackHandler {
    runCatching { focusManager.clearFocus(force = true) }
    onBack()
  }

  val folderPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
      if (uri != null) {
        val lastSeg = uri.lastPathSegment.orEmpty()
        val resolvedPath =
          if (lastSeg.startsWith("primary:")) {
            val rel = lastSeg.removePrefix("primary:")
            File(Environment.getExternalStorageDirectory(), rel).absolutePath
          } else {
            lastSeg
          }
        if (resolvedPath.isNotBlank()) {
          viewModel.setSubtitlesFolderPath(resolvedPath)
        }
      }
    }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    topBar = {
      TopAppBar(
        modifier = Modifier.statusBarsPadding(),
        title = { Text(strings.settingsTitle) },
        navigationIcon = {
          IconButton(
            onClick = {
              runCatching { focusManager.clearFocus(force = true) }
              onBack()
            },
            modifier = Modifier.testTag("settings_back_btn"),
          ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
  ) { innerPadding ->
    Column(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .navigationBarsPadding()
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Language
      @OptIn(ExperimentalLayoutApi::class)
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(strings.languageSection, style = MaterialTheme.typography.titleMedium)
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            AppLanguage.entries.forEach { lang ->
              val dirTag = if (lang.isRtl) "RTL" else "LTR"
              FilterChip(
                selected = prefs.language == lang,
                onClick = { viewModel.setLanguage(lang) },
                label = { Text("${lang.displayName} ($dirTag)") },
                modifier = Modifier.testTag("lang_${lang.code}_chip"),
              )
            }
          }
        }
      }

      // Layout Mode & Pane Count (1..4)
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(strings.layoutSection, style = MaterialTheme.typography.titleMedium)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
              selected = prefs.layoutMode == LayoutMode.DUAL_PANE,
              onClick = { viewModel.setLayoutMode(LayoutMode.DUAL_PANE) },
              label = { Text(strings.dualPane) },
            )
            FilterChip(
              selected = prefs.layoutMode == LayoutMode.TABBED,
              onClick = { viewModel.setLayoutMode(LayoutMode.TABBED) },
              label = { Text(strings.tabbedMode) },
            )
            FilterChip(
              selected = prefs.layoutMode == LayoutMode.SINGLE_PANE,
              onClick = { viewModel.setLayoutMode(LayoutMode.SINGLE_PANE) },
              label = { Text(strings.singlePane) },
            )
          }
          Text(strings.paneCountSection, style = MaterialTheme.typography.titleSmall)
          Text(
            strings.paneCountHint,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..4).forEach { count ->
              FilterChip(
                selected = prefs.paneCount == count,
                onClick = { viewModel.setPaneCount(count) },
                label = { Text("$count") },
                modifier = Modifier.testTag("pane_count_$count"),
              )
            }
          }
        }
      }

      // Theme Presets
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(strings.themePresetSection, style = MaterialTheme.typography.titleMedium)

          val presets =
            listOf(
              Triple(ThemePreset.CYBER_EMERALD, "Cyber Emerald", Triple(CyberBg, CyberEmeraldPrimary, CyberGoldSecondary)),
              Triple(ThemePreset.MIDNIGHT_COBALT, "Midnight Cobalt", Triple(CobaltBg, CobaltPrimary, Color(0xFF818CF8))),
              Triple(ThemePreset.AMOLED_OBSIDIAN, "AMOLED Obsidian", Triple(AmoledBg, CyberEmeraldPrimary, CyberGoldSecondary)),
              Triple(ThemePreset.MATERIAL_LIGHT, "Material Light", Triple(LightBg, LightPrimary, Color(0xFFC77700))),
            )

          presets.forEach { (preset, label, palette) ->
            val selected = prefs.themePreset == preset
            Surface(
              shape = MaterialTheme.shapes.medium,
              color = MaterialTheme.colorScheme.surfaceContainerHigh,
              border =
                BorderStroke(
                  if (selected) 2.dp else 1.dp,
                  if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                ),
              modifier =
                Modifier
                  .fillMaxWidth()
                  .clickable { viewModel.setThemePreset(preset) }
                  .testTag("theme_preset_${preset.id}"),
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                  Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    ColorDot(palette.first)
                    ColorDot(palette.second)
                    ColorDot(palette.third)
                  }
                  Text(label, style = MaterialTheme.typography.titleSmall)
                }
                if (selected) {
                  Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
              }
            }
          }

          Spacer(Modifier.size(4.dp))
          Text(strings.accentColorSection, style = MaterialTheme.typography.titleSmall)
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AccentStyle.entries.forEach { accent ->
              val isSel = prefs.accentStyle == accent
              Box(
                modifier =
                  Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(accent.darkColor)
                    .clickable { viewModel.setAccentStyle(accent) },
                contentAlignment = Alignment.Center,
              ) {
                if (isSel) {
                  Icon(Icons.Default.Check, contentDescription = accent.id, tint = Color.Black, modifier = Modifier.size(18.dp))
                }
              }
            }
          }
        }
      }

      // Editor & Browser Settings
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(strings.editorSettingsSection, style = MaterialTheme.typography.titleMedium)

          Text("${strings.editorFontSize}: ${prefs.editorFontSizeSp} sp", style = MaterialTheme.typography.bodySmall)
          Slider(
            value = prefs.editorFontSizeSp.toFloat(),
            onValueChange = { viewModel.setEditorFontSize(it.roundToInt()) },
            valueRange = 10f..22f,
            steps = 11,
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(strings.wordWrap, style = MaterialTheme.typography.bodyMedium)
            Switch(checked = prefs.editorWordWrap, onCheckedChange = { viewModel.setEditorWordWrap(it) })
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(strings.showHidden, style = MaterialTheme.typography.bodyMedium)
            Switch(checked = prefs.showHiddenFiles, onCheckedChange = { viewModel.setShowHidden(it) })
          }
        }
      }

      // Long Filename Display Mode
      @OptIn(ExperimentalLayoutApi::class)
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(strings.longFilenameSection, style = MaterialTheme.typography.titleMedium)
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            FilterChip(
              selected = prefs.longFilenameMode == LongFilenameMode.MIDDLE_ELLIPSIS,
              onClick = { viewModel.setLongFilenameMode(LongFilenameMode.MIDDLE_ELLIPSIS) },
              label = { Text(strings.longFilenameEllipsis) },
              modifier = Modifier.testTag("filename_mode_ellipsis"),
            )
            FilterChip(
              selected = prefs.longFilenameMode == LongFilenameMode.MULTI_LINE,
              onClick = { viewModel.setLongFilenameMode(LongFilenameMode.MULTI_LINE) },
              label = { Text(strings.longFilenameMultiLine) },
              modifier = Modifier.testTag("filename_mode_multiline"),
            )
          }
        }
      }

      // Recycle Bin Auto-Purge Retention
      @OptIn(ExperimentalLayoutApi::class)
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(strings.recycleBinTitle, style = MaterialTheme.typography.titleMedium)
          Text(
            strings.recycleBinRetentionLabel,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            listOf(0, 1, 7, 14, 30).forEach { days ->
              FilterChip(
                selected = prefs.trashRetentionDays == days,
                onClick = { viewModel.setTrashRetentionDays(days) },
                label = { Text(if (days == 0) "Off" else "${days}d") },
                modifier = Modifier.testTag("trash_retention_$days"),
              )
            }
          }
        }
      }

      // Auto Subtitles & Lyrics Section
      @OptIn(ExperimentalLayoutApi::class)
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(Icons.Default.Subtitles, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(strings.autoSubtitlesSection, style = MaterialTheme.typography.titleMedium)
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text(strings.autoSubtitlesToggle, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
              Text(
                strings.autoSubtitlesHint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = prefs.autoSubtitlesEnabled,
              onCheckedChange = { viewModel.setAutoSubtitlesEnabled(it) },
              modifier = Modifier.testTag("auto_subtitles_switch"),
            )
          }

          val activeFolderDisplay =
            prefs.subtitlesFolderPath.ifBlank { File(viewModel.downloadsPath, "Subtitles").absolutePath }
          Surface(
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            shape = MaterialTheme.shapes.small,
          ) {
            Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(strings.subtitlesFolderLabel, style = MaterialTheme.typography.labelMedium)
              Text(
                activeFolderDisplay,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
              )
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                  onClick = { folderPicker.launch(null) },
                  modifier = Modifier.testTag("pick_subtitles_folder_btn"),
                ) {
                  Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(Modifier.size(6.dp))
                  Text(strings.pickSubtitlesFolder)
                }
                TextButton(
                  onClick = { showFolderEditDialog = true },
                  modifier = Modifier.testTag("edit_subtitles_folder_btn"),
                ) {
                  Text(strings.rename)
                }
              }
            }
          }

          Text(strings.subtitleLanguagesLabel, style = MaterialTheme.typography.titleSmall)
          Text(
            strings.subtitleLanguagesHint,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )

          val supportedLangs = listOf(
            "ar" to "العربية (ar)",
            "en" to "English (en)",
            "fr" to "Français (fr)",
            "es" to "Español (es)",
            "de" to "Deutsch (de)",
            "tr" to "Türkçe (tr)",
            "ru" to "Русский (ru)",
          )
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            supportedLangs.forEach { (code, label) ->
              val orderIdx = prefs.subtitleLanguages.indexOf(code)
              val isSelected = orderIdx >= 0
              FilterChip(
                selected = isSelected,
                onClick = {
                  val cur = prefs.subtitleLanguages.toMutableList()
                  if (isSelected && cur.size > 1) {
                    cur.remove(code)
                  } else if (!isSelected) {
                    cur.add(code)
                  }
                  viewModel.setSubtitleLanguages(cur)
                },
                label = {
                  Text(if (isSelected) "${orderIdx + 1}. $label" else label)
                },
                modifier = Modifier.testTag("sub_lang_chip_$code"),
              )
            }
          }

          if (prefs.subtitleLanguages.size > 1) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              prefs.subtitleLanguages.forEachIndexed { idx, code ->
                val label = supportedLangs.firstOrNull { it.first == code }?.second ?: code
                Surface(
                  color = MaterialTheme.colorScheme.surfaceContainerLow,
                  shape = MaterialTheme.shapes.small,
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Text("${idx + 1}. $label", style = MaterialTheme.typography.bodySmall)
                    Row {
                      IconButton(
                        onClick = {
                          if (idx > 0) {
                            val list = prefs.subtitleLanguages.toMutableList()
                            val item = list.removeAt(idx)
                            list.add(idx - 1, item)
                            viewModel.setSubtitleLanguages(list)
                          }
                        },
                        enabled = idx > 0,
                      ) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = "Up", modifier = Modifier.size(16.dp))
                      }
                      IconButton(
                        onClick = {
                          if (idx < prefs.subtitleLanguages.lastIndex) {
                            val list = prefs.subtitleLanguages.toMutableList()
                            val item = list.removeAt(idx)
                            list.add(idx + 1, item)
                            viewModel.setSubtitleLanguages(list)
                          }
                        },
                        enabled = idx < prefs.subtitleLanguages.lastIndex,
                      ) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = "Down", modifier = Modifier.size(16.dp))
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Antivirus & File Shield
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(strings.antivirusSection, style = MaterialTheme.typography.titleMedium)
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text(strings.antivirusAutoScanToggle, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
              Text(
                strings.antivirusAutoScanHint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = prefs.antivirusAutoScanEnabled,
              onCheckedChange = { viewModel.setAntivirusAutoScanEnabled(it) },
              modifier = Modifier.testTag("antivirus_auto_scan_switch"),
            )
          }
        }
      }

      // Compressed Edit Snapshots (.vortexbak)
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(strings.autoBackupSection, style = MaterialTheme.typography.titleMedium)
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text(strings.autoBackupToggle, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
              Text(
                strings.autoBackupHint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = prefs.autoBackupOnEditEnabled,
              onCheckedChange = { viewModel.setAutoBackupOnEditEnabled(it) },
              modifier = Modifier.testTag("auto_backup_switch"),
            )
          }
        }
      }

      // Optional Companion FastAPI Media Engine Server URL
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        var companionUrlDraft by remember(prefs.companionDownloaderUrl) { mutableStateOf(prefs.companionDownloaderUrl) }
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.CloudQueue, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(strings.companionServerLabel, style = MaterialTheme.typography.titleMedium)
          }
          OutlinedTextField(
            value = companionUrlDraft,
            onValueChange = { companionUrlDraft = it },
            placeholder = { Text("http://192.168.1.50:8787") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("companion_server_url_input"),
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
              onClick = {
                runCatching { focusManager.clearFocus(force = true) }
                viewModel.setCompanionDownloaderUrl(companionUrlDraft.trim())
              },
              modifier = Modifier.testTag("save_companion_url_btn"),
            ) {
              Text(strings.saveFile)
            }
            if (prefs.companionDownloaderUrl.isNotBlank()) {
              TextButton(onClick = {
                companionUrlDraft = ""
                viewModel.setCompanionDownloaderUrl("")
              }) {
                Text(strings.clearSelection)
              }
            }
          }
        }
      }
    }
  }

  if (showFolderEditDialog) {
    var pathDraft by remember(prefs.subtitlesFolderPath) {
      mutableStateOf(prefs.subtitlesFolderPath.ifBlank { File(viewModel.downloadsPath, "Subtitles").absolutePath })
    }
    AlertDialog(
      onDismissRequest = { showFolderEditDialog = false },
      title = { Text(strings.subtitlesFolderLabel) },
      text = {
        OutlinedTextField(
          value = pathDraft,
          onValueChange = { pathDraft = it },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("subtitles_folder_path_input"),
        )
      },
      confirmButton = {
        TextButton(
          onClick = {
            viewModel.setSubtitlesFolderPath(pathDraft.trim())
            showFolderEditDialog = false
          },
        ) {
          Text(strings.saveFile)
        }
      },
      dismissButton = {
        TextButton(onClick = { showFolderEditDialog = false }) { Text(strings.cancel) }
      },
    )
  }
}

@Composable
private fun ColorDot(color: Color) {
  Box(
    modifier =
      Modifier
        .size(18.dp)
        .clip(CircleShape)
        .background(color),
  )
}
