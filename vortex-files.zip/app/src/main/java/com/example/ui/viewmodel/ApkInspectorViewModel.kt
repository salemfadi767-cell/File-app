package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.VortexAppContainer
import com.example.domain.apk.ApkInspectionReport
import com.example.domain.archive.ArchiveEngine
import com.example.domain.fs.VirtualFileNode
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface ApkUiState {
  data object Loading : ApkUiState
  data class Ready(
    val report: ApkInspectionReport,
    val internalSubPath: String,
    val internalEntries: List<VirtualFileNode>,
    val extractedManifestPath: String? = null,
    val statusMessage: String? = null,
  ) : ApkUiState
  data class Error(val message: String) : ApkUiState
}

class ApkInspectorViewModel(private val container: VortexAppContainer) : ViewModel() {

  private val _uiState = MutableStateFlow<ApkUiState>(ApkUiState.Loading)
  val uiState: StateFlow<ApkUiState> = _uiState.asStateFlow()

  private var resolvedApkFile: File? = null

  fun loadApk(apkPath: String) {
    viewModelScope.launch {
      _uiState.value = ApkUiState.Loading
      runCatching {
        val cacheDir = container.fileRepository.appWorkspaceDir()
        val file = container.apkInspectorEngine.resolveInspectableApkFile(apkPath, cacheDir)
        resolvedApkFile = file
        val report = container.apkInspectorEngine.inspectApk(file)
        val entries = container.apkInspectorEngine.listInternalFiles(file, "")
        ApkUiState.Ready(report, "", entries)
      }.onSuccess { _uiState.value = it }
        .onFailure { _uiState.value = ApkUiState.Error(it.message ?: "Failed to inspect APK") }
    }
  }

  fun browseInternal(subPath: String) {
    val curr = _uiState.value as? ApkUiState.Ready ?: return
    val apkFile = resolvedApkFile ?: File(curr.report.filePath)
    viewModelScope.launch {
      val entries = container.apkInspectorEngine.listInternalFiles(apkFile, subPath)
      _uiState.value = curr.copy(internalSubPath = subPath, internalEntries = entries)
    }
  }

  fun extractManifestToDisk() {
    val curr = _uiState.value as? ApkUiState.Ready ?: return
    val apkFile = resolvedApkFile ?: File(curr.report.filePath)
    viewModelScope.launch {
      runCatching {
        val targetDir =
          apkFile.parentFile?.takeIf { it.canWrite() }
            ?: container.fileRepository.appWorkspaceDir()
        val outFile = File(targetDir, "${apkFile.nameWithoutExtension}_AndroidManifest.xml")
        container.apkInspectorEngine.extractManifestToFile(curr.report.decodedManifestXml, outFile)
      }.onSuccess { outFile ->
        _uiState.update { state ->
          if (state is ApkUiState.Ready) {
            state.copy(
              extractedManifestPath = outFile.absolutePath,
              statusMessage = "Extracted: ${outFile.name}",
            )
          } else {
            state
          }
        }
      }.onFailure { err ->
        _uiState.update { state ->
          if (state is ApkUiState.Ready) {
            state.copy(statusMessage = err.message ?: "Failed to extract AndroidManifest.xml")
          } else {
            state
          }
        }
      }
    }
  }

  fun unpackApkToWorkspace() {
    val curr = _uiState.value as? ApkUiState.Ready ?: return
    val apkFile = resolvedApkFile ?: File(curr.report.filePath)
    viewModelScope.launch {
      runCatching {
        val baseDir =
          apkFile.parentFile?.takeIf { it.canWrite() }
            ?: container.fileRepository.appWorkspaceDir()
        val destDir = File(baseDir, "${apkFile.nameWithoutExtension}_unpacked")
        val count = container.apkInspectorEngine.unpackApkToDirectory(apkFile, destDir)
        destDir to count
      }.onSuccess { (destDir, count) ->
        _uiState.update { state ->
          if (state is ApkUiState.Ready) {
            state.copy(statusMessage = "Unpacked $count files to ${destDir.name}/")
          } else {
            state
          }
        }
      }.onFailure { err ->
        _uiState.update { state ->
          if (state is ApkUiState.Ready) {
            state.copy(statusMessage = err.message ?: "Failed to unpack APK")
          } else {
            state
          }
        }
      }
    }
  }

  fun clearStatusMessage() {
    _uiState.update { state ->
      if (state is ApkUiState.Ready) state.copy(statusMessage = null) else state
    }
  }

  fun buildEntryArchiveUri(entryPath: String): String {
    val apkPath = resolvedApkFile?.absolutePath ?: (uiState.value as? ApkUiState.Ready)?.report?.filePath.orEmpty()
    return ArchiveEngine.buildArchiveUri(apkPath, entryPath)
  }
}
