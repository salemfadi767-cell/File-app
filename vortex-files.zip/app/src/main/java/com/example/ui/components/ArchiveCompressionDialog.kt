package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.archive.ArchiveFormat
import com.example.domain.archive.AudioTargetBitrate
import com.example.domain.archive.CompressionMode
import com.example.domain.archive.ImageOutputFormat
import com.example.domain.archive.UniversalReductionRequest
import com.example.domain.archive.VideoTargetResolution
import com.example.domain.fs.FileCategory
import com.example.domain.fs.VirtualFileNode
import com.example.i18n.LocalAppStrings
import com.example.ui.theme.LocalVortexExtraColors
import kotlin.math.roundToInt

@Composable
fun ArchiveCompressionDialog(
  selectedNodes: List<VirtualFileNode>,
  estimateMediaSize: (List<VirtualFileNode>, CompressionMode, Int, Int) -> Pair<String, String>,
  onDismiss: () -> Unit,
  onCompressArchive: (name: String, format: ArchiveFormat, level: Int, password: String?) -> Unit,
  onCompressImages: (mode: CompressionMode, quality: Int, scalePercent: Int, format: ImageOutputFormat) -> Unit,
  onReduceUniversal: (UniversalReductionRequest) -> Unit,
) {
  val strings = LocalAppStrings.current
  val extra = LocalVortexExtraColors.current
  val hasImages = remember(selectedNodes) { selectedNodes.any { it.category == FileCategory.IMAGE } }
  val hasVideos = remember(selectedNodes) { selectedNodes.any { it.category == FileCategory.VIDEO } }
  val hasAudio = remember(selectedNodes) { selectedNodes.any { it.category == FileCategory.AUDIO } }
  val hasPdf = remember(selectedNodes) { selectedNodes.any { it.category == FileCategory.PDF } }

  var selectedTab by remember { mutableIntStateOf(0) } // 0 = Archive (Lossless), 1 = Images, 2 = Universal Size Reducer
  var archiveName by remember {
    mutableStateOf(
      selectedNodes.firstOrNull()?.name?.substringBeforeLast('.') ?: "Archive_${System.currentTimeMillis() % 1000}"
    )
  }
  var archiveFormat by remember { mutableStateOf(ArchiveFormat.ZIP) }
  var level by remember { mutableIntStateOf(6) }
  var password by remember { mutableStateOf("") }

  var mediaMode by remember { mutableStateOf(CompressionMode.LOSSY) }
  var imageQuality by remember { mutableIntStateOf(78) }
  var imageScale by remember { mutableIntStateOf(100) }
  var imageFormat by remember { mutableStateOf(ImageOutputFormat.JPEG) }

  // Universal Reducer params
  var univQuality by remember { mutableIntStateOf(65) }
  var univScale by remember { mutableIntStateOf(75) }
  var videoRes by remember { mutableStateOf(VideoTargetResolution.RES_480P) }
  var stripVideoAudio by remember { mutableStateOf(false) }
  var audioBitrate by remember { mutableStateOf(AudioTargetBitrate.KBPS_96) }
  var pdfQuality by remember { mutableIntStateOf(60) }
  var pdfScale by remember { mutableIntStateOf(70) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.Archive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(strings.archiveTitle, style = MaterialTheme.typography.titleLarge)
      }
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        TabRow(selectedTabIndex = selectedTab) {
          Tab(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            text = { Text("Archive") },
          )
          if (hasImages) {
            Tab(
              selected = selectedTab == 1,
              onClick = { selectedTab = 1 },
              text = { Text("Images") },
            )
          }
          Tab(
            selected = selectedTab == (if (hasImages) 2 else 1),
            onClick = { selectedTab = if (hasImages) 2 else 1 },
            text = { Text("Shrink All") },
          )
        }

        val isUniversalTab = (!hasImages && selectedTab == 1) || (hasImages && selectedTab == 2)
        val isImageTab = hasImages && selectedTab == 1

        if (selectedTab == 0) {
          Surface(
            color = extra.losslessGreen.copy(alpha = 0.14f),
            shape = MaterialTheme.shapes.small,
            border = BorderStroke(1.dp, extra.losslessGreen.copy(alpha = 0.4f)),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = extra.losslessGreen)
              Column {
                Text(
                  strings.losslessModeTitle,
                  style = MaterialTheme.typography.labelLarge,
                  color = extra.losslessGreen,
                )
                Text(strings.losslessModeDesc, style = MaterialTheme.typography.bodySmall)
              }
            }
          }

          OutlinedTextField(
            value = archiveName,
            onValueChange = { archiveName = it },
            label = { Text(strings.archiveNameLabel) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("archive_name_input"),
          )

          Text(strings.archiveFormatLabel, style = MaterialTheme.typography.titleSmall)
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            ArchiveFormat.creatableFormats.forEach { fmt ->
              FilterChip(
                selected = archiveFormat == fmt,
                onClick = { archiveFormat = fmt },
                label = { Text(fmt.displayName) },
              )
            }
          }
          Text(
            text = strings.rarNoteLabel,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )

          Text(
            "${strings.compressionLevelLabel}: $level / 9",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
          )
          Slider(
            value = level.toFloat(),
            onValueChange = { level = it.roundToInt().coerceIn(0, 9) },
            valueRange = 0f..9f,
            steps = 8,
            modifier = Modifier.testTag("compression_level_slider"),
          )
          Text(
            text =
              when {
                level == 0 -> strings.levelStore
                level <= 3 -> strings.levelFast
                level <= 6 -> strings.levelBalanced
                else -> strings.levelUltra
              },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )

          if (archiveFormat.supportsPassword) {
            OutlinedTextField(
              value = password,
              onValueChange = { password = it },
              label = { Text(strings.passwordOptional) },
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
            )
          }
        } else if (isImageTab) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Icon(
                if (mediaMode == CompressionMode.LOSSLESS) Icons.Default.VerifiedUser else Icons.Default.HighQuality,
                contentDescription = null,
                tint = if (mediaMode == CompressionMode.LOSSLESS) extra.losslessGreen else extra.lossyWarning,
              )
              Text(
                if (mediaMode == CompressionMode.LOSSLESS) strings.losslessModeTitle else strings.lossyModeTitle,
                style = MaterialTheme.typography.titleSmall,
              )
            }
            Switch(
              checked = mediaMode == CompressionMode.LOSSY,
              onCheckedChange = { isLossy ->
                mediaMode = if (isLossy) CompressionMode.LOSSY else CompressionMode.LOSSLESS
                imageFormat =
                  if (isLossy) ImageOutputFormat.JPEG else ImageOutputFormat.WEBP_LOSSLESS
              },
            )
          }

          if (mediaMode == CompressionMode.LOSSY) {
            LossyWarningBox(strings.lossyWarningBanner)
            Text("${strings.imageQualityLabel}: $imageQuality%", style = MaterialTheme.typography.titleSmall)
            Slider(
              value = imageQuality.toFloat(),
              onValueChange = { imageQuality = it.roundToInt() },
              valueRange = 10f..95f,
            )
          } else {
            Surface(
              color = extra.losslessGreen.copy(alpha = 0.14f),
              shape = MaterialTheme.shapes.small,
            ) {
              Text(
                strings.losslessModeDesc,
                style = MaterialTheme.typography.bodySmall,
                color = extra.losslessGreen,
                modifier = Modifier.padding(10.dp),
              )
            }
          }

          Text("${strings.imageScaleLabel}: $imageScale%", style = MaterialTheme.typography.titleSmall)
          Slider(
            value = imageScale.toFloat(),
            onValueChange = { imageScale = it.roundToInt() },
            valueRange = 25f..100f,
            steps = 2,
          )

          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            val candidates =
              if (mediaMode == CompressionMode.LOSSLESS) {
                listOf(ImageOutputFormat.PNG, ImageOutputFormat.WEBP_LOSSLESS, ImageOutputFormat.BMP)
              } else {
                listOf(ImageOutputFormat.JPEG, ImageOutputFormat.WEBP_LOSSY)
              }
            candidates.forEach { fmt ->
              FilterChip(
                selected = imageFormat == fmt,
                onClick = { imageFormat = fmt },
                label = { Text(fmt.label) },
              )
            }
          }

          val (origStr, estStr) = estimateMediaSize(selectedNodes, mediaMode, imageQuality, imageScale)
          Text(
            text = strings.estimatedSizeText(origStr, estStr),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
          )
        } else if (isUniversalTab) {
          Text(strings.universalReducerTab, style = MaterialTheme.typography.titleSmall)
          Text(
            strings.universalReducerDesc,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          LossyWarningBox(strings.lossyWarningBanner)

          if (hasImages || (!hasVideos && !hasAudio && !hasPdf)) {
            Text("${strings.imageQualityLabel}: $univQuality%", style = MaterialTheme.typography.titleSmall)
            Slider(value = univQuality.toFloat(), onValueChange = { univQuality = it.roundToInt() }, valueRange = 15f..95f)
            Text("${strings.imageScaleLabel}: $univScale%", style = MaterialTheme.typography.titleSmall)
            Slider(value = univScale.toFloat(), onValueChange = { univScale = it.roundToInt() }, valueRange = 25f..100f, steps = 2)
          }

          if (hasVideos) {
            Text(strings.videoResolutionLabel, style = MaterialTheme.typography.titleSmall)
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              VideoTargetResolution.entries.forEach { res ->
                FilterChip(
                  selected = videoRes == res,
                  onClick = { videoRes = res },
                  label = { Text(res.label) },
                )
              }
            }
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text("Mute Audio (Max Savings)", style = MaterialTheme.typography.bodySmall)
              Switch(checked = stripVideoAudio, onCheckedChange = { stripVideoAudio = it })
            }
          }

          if (hasAudio) {
            Text(strings.audioBitrateLabel, style = MaterialTheme.typography.titleSmall)
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              AudioTargetBitrate.entries.forEach { br ->
                FilterChip(
                  selected = audioBitrate == br,
                  onClick = { audioBitrate = br },
                  label = { Text(br.label) },
                )
              }
            }
          }

          if (hasPdf) {
            Text("${strings.pdfDpiScaleLabel}: $pdfScale% • Q=$pdfQuality%", style = MaterialTheme.typography.titleSmall)
            Slider(value = pdfQuality.toFloat(), onValueChange = { pdfQuality = it.roundToInt() }, valueRange = 20f..90f)
            Slider(value = pdfScale.toFloat(), onValueChange = { pdfScale = it.roundToInt() }, valueRange = 30f..100f)
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val isUniversal = (!hasImages && selectedTab == 1) || (hasImages && selectedTab == 2)
          when {
            selectedTab == 0 ->
              onCompressArchive(archiveName.ifBlank { "Archive" }, archiveFormat, level, password.ifBlank { null })
            isUniversal ->
              onReduceUniversal(
                UniversalReductionRequest(
                  qualityPercent = univQuality,
                  scalePercent = univScale,
                  videoResolution = videoRes,
                  stripVideoAudio = stripVideoAudio,
                  audioBitrate = audioBitrate,
                  pdfQualityPercent = pdfQuality,
                  pdfScalePercent = pdfScale,
                )
              )
            else -> onCompressImages(mediaMode, imageQuality, imageScale, imageFormat)
          }
          onDismiss()
        },
        modifier = Modifier.testTag("start_compression_btn"),
      ) {
        Text(strings.startCompression)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(strings.cancel) }
    },
  )
}

@Composable
private fun LossyWarningBox(text: String) {
  val extra = LocalVortexExtraColors.current
  Surface(
    color = extra.lossyWarning.copy(alpha = 0.14f),
    shape = MaterialTheme.shapes.small,
    border = BorderStroke(1.dp, extra.lossyWarning.copy(alpha = 0.5f)),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(Icons.Default.WarningAmber, contentDescription = null, tint = extra.lossyWarning)
      Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = extra.lossyWarning,
      )
    }
  }
}
