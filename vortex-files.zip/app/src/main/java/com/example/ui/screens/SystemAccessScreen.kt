package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.i18n.LocalAppStrings
import com.example.shizuku.ShizukuStatus
import com.example.ui.theme.LocalVortexExtraColors
import com.example.ui.theme.MonoFontFamily
import com.example.ui.viewmodel.WorkbenchViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SystemAccessScreen(
  viewModel: WorkbenchViewModel,
  onBack: () -> Unit,
) {
  val context = LocalContext.current
  val strings = LocalAppStrings.current
  val extra = LocalVortexExtraColors.current
  val scope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }

  val shizukuStatus by viewModel.shizukuStatus.collectAsStateWithLifecycle()
  val isRoot by viewModel.isRootAvailable.collectAsStateWithLifecycle()
  val hasAllFiles by viewModel.hasAllFilesAccess.collectAsStateWithLifecycle()

  val allFilesLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
      viewModel.refreshPermissionState()
    }

  val safLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
      if (uri != null) {
        viewModel.onSafTreeGranted(uri)
        onBack()
      }
    }

  val adbStartCmd = "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh"
  var adbPairIpPort by remember { mutableStateOf("192.168.1.10:37123") }
  var adbPairCode by remember { mutableStateOf("") }
  val isUsbDebuggingOn =
    remember {
      runCatching {
        Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
      }.getOrDefault(false)
    }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      TopAppBar(
        modifier = Modifier.statusBarsPadding(),
        title = { Text(strings.shizukuTitle) },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("system_back_btn")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
  ) { innerPadding ->
    Column(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .navigationBarsPadding()
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      // Shizuku Card
      val statusColor =
        when (shizukuStatus) {
          ShizukuStatus.CONNECTED -> extra.shizukuCyan
          ShizukuStatus.NEEDS_PERMISSION -> extra.rootGold
          else -> extra.lossyWarning
        }
      val statusLabel =
        when (shizukuStatus) {
          ShizukuStatus.CONNECTED -> strings.shizukuStatusConnected
          ShizukuStatus.NEEDS_PERMISSION -> strings.shizukuStatusNeedsPermission
          ShizukuStatus.NOT_RUNNING -> strings.shizukuStatusNotRunning
          ShizukuStatus.NOT_INSTALLED -> strings.shizukuStatusNotInstalled
        }

      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.5f)),
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = statusColor)
            Text("Shizuku Bridge", style = MaterialTheme.typography.titleMedium)
          }
          Text(statusLabel, style = MaterialTheme.typography.bodyMedium, color = statusColor)

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = { viewModel.requestShizukuPermission() },
              modifier = Modifier.weight(1f).testTag("shizuku_request_btn"),
            ) {
              Text(strings.shizukuRequestPerm)
            }
            OutlinedButton(
              onClick = { viewModel.openShizukuApp() },
              modifier = Modifier.weight(1f),
            ) {
              Text(strings.shizukuOpenApp)
            }
          }
        }
      }

      // Developer Options & Wireless Debugging Assistant
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.DeveloperMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text("Developer Mode & Wireless Debugging", style = MaterialTheme.typography.titleMedium)
          }
          strings.devGuideSteps.forEach { step ->
            Text(step, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
              onClick = {
                val intent =
                  Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                  }
                runCatching { context.startActivity(intent) }
                  .onFailure {
                    runCatching {
                      context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                  }
              },
              modifier = Modifier.weight(1f),
            ) {
              Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(Modifier.size(4.dp))
              Text(strings.devOptionsButton)
            }

            OutlinedButton(
              onClick = {
                val intent =
                  Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                  }
                runCatching { context.startActivity(intent) }
              },
              modifier = Modifier.weight(1f),
            ) {
              Icon(Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(Modifier.size(4.dp))
              Text(strings.wirelessDebugButton)
            }
          }

          Surface(
            color = MaterialTheme.colorScheme.surfaceContainerLowest,
            shape = MaterialTheme.shapes.small,
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                text = adbStartCmd,
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                modifier = Modifier.weight(1f),
              )
              IconButton(
                onClick = {
                  val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                  cm.setPrimaryClip(ClipData.newPlainText("adb_shizuku", adbStartCmd))
                  scope.launch { snackbarHostState.showSnackbar(strings.adbCommandCopied) }
                },
              ) {
                Icon(Icons.Default.ContentCopy, contentDescription = strings.copyAdbCommand)
              }
            }
          }
        }
      }

      // Wireless ADB Pairing & USB Debugging Card
      val pairCmd =
        "adb pair ${adbPairIpPort.ifBlank { "<ip:port>" }} ${adbPairCode.ifBlank { "<code>" }}"
      val connectCmd = "adb connect ${adbPairIpPort.ifBlank { "<ip:port>" }}"
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Icon(Icons.Default.Wifi, contentDescription = null, tint = extra.shizukuCyan)
              Text(strings.adbPairAction, style = MaterialTheme.typography.titleMedium)
            }
            Text(
              text = if (isUsbDebuggingOn) "USB ADB: ON" else "USB ADB: OFF",
              style = MaterialTheme.typography.labelSmall,
              color = if (isUsbDebuggingOn) extra.losslessGreen else extra.lossyWarning,
            )
          }

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = adbPairIpPort,
              onValueChange = { adbPairIpPort = it },
              label = { Text("IP:Port") },
              singleLine = true,
              modifier = Modifier.weight(1.4f),
            )
            OutlinedTextField(
              value = adbPairCode,
              onValueChange = { adbPairCode = it },
              label = { Text("Pair Code") },
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
          }

          listOf("pair" to pairCmd, "connect" to connectCmd).forEach { (tag, cmd) ->
            Surface(
              color = MaterialTheme.colorScheme.surfaceContainerLowest,
              shape = MaterialTheme.shapes.small,
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text(
                  text = cmd,
                  style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                  modifier = Modifier.weight(1f),
                )
                IconButton(
                  onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("adb_$tag", cmd))
                    scope.launch { snackbarHostState.showSnackbar(strings.adbCommandCopied) }
                  },
                ) {
                  Icon(Icons.Default.ContentCopy, contentDescription = strings.copyAdbCommand)
                }
              }
            }
          }
        }
      }

      // Root & SAF & All-Files
      Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Key, contentDescription = null, tint = extra.rootGold)
            Text("Root & Storage Frameworks", style = MaterialTheme.typography.titleMedium)
          }

          Button(
            onClick = { viewModel.testAndToggleRoot() },
            modifier = Modifier.fillMaxWidth().testTag("root_test_btn"),
          ) {
            Text(strings.rootTestButton)
          }
          Text(
            text = if (isRoot) strings.rootAvailable else strings.rootUnavailable,
            style = MaterialTheme.typography.bodySmall,
            color = if (isRoot) extra.losslessGreen else MaterialTheme.colorScheme.onSurfaceVariant,
          )

          OutlinedButton(
            onClick = { safLauncher.launch(viewModel.androidDataSafInitialUri()) },
            modifier = Modifier.fillMaxWidth(),
          ) {
            Icon(Icons.Default.Android, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.size(6.dp))
            Text(strings.safAndroidDataButton)
          }

          if (!hasAllFiles) {
            OutlinedButton(
              onClick = { allFilesLauncher.launch(viewModel.buildAllFilesPermissionIntent()) },
              modifier = Modifier.fillMaxWidth(),
            ) {
              Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(Modifier.size(6.dp))
              Text(strings.grantAllFilesAccess)
            }
          }
        }
      }
    }
  }
}
