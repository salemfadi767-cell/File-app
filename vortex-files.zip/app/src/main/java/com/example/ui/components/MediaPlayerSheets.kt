package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.media.DlnaDevice
import com.example.domain.media.OnlineSubtitleHit
import com.example.domain.media.SubtitleStyleConfig
import com.example.i18n.LocalAppStrings
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoEnhancementSheet(
  brightness: Float,
  contrast: Float,
  saturation: Float,
  onBrightnessChange: (Float) -> Unit,
  onContrastChange: (Float) -> Unit,
  onSaturationChange: (Float) -> Unit,
  onSelectPreset: (b: Float, c: Float, s: Float) -> Unit,
  onApplyEffects: () -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(16.dp).verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(strings.enhancePicture, style = MaterialTheme.typography.titleMedium)
      }

      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        FilterChip(selected = brightness == 0f && contrast == 0f && saturation == 0f, onClick = { onSelectPreset(0f, 0f, 0f) }, label = { Text("Original") })
        FilterChip(selected = false, onClick = { onSelectPreset(6f, 0.22f, 32f) }, label = { Text("Vivid HDR") })
        FilterChip(selected = false, onClick = { onSelectPreset(-4f, 0.28f, -10f) }, label = { Text("Cinema") })
        FilterChip(selected = false, onClick = { onSelectPreset(-12f, 0.1f, -20f) }, label = { Text("Night") })
        FilterChip(selected = false, onClick = { onSelectPreset(0f, 0.15f, -100f) }, label = { Text("B&W") })
      }

      Text("${strings.brightnessLabel}: ${brightness.roundToInt()}", style = MaterialTheme.typography.bodySmall)
      Slider(value = brightness, onValueChange = onBrightnessChange, valueRange = -50f..50f)

      Text("${strings.contrastLabel}: ${"%.2f".format(contrast)}", style = MaterialTheme.typography.bodySmall)
      Slider(value = contrast, onValueChange = onContrastChange, valueRange = -0.6f..0.8f)

      Text("${strings.saturationLabel}: ${saturation.roundToInt()}", style = MaterialTheme.typography.bodySmall)
      Slider(value = saturation, onValueChange = onSaturationChange, valueRange = -100f..80f)

      Button(
        onClick = {
          onApplyEffects()
          onDismiss()
        },
        modifier = Modifier.fillMaxWidth().testTag("apply_video_effects_btn"),
      ) {
        Text(strings.confirm)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubtitleManagerSheet(
  cueCount: Int,
  style: SubtitleStyleConfig,
  onStyleChange: (SubtitleStyleConfig) -> Unit,
  onPickLocalSubtitle: () -> Unit,
  onOpenOnlineSearch: () -> Unit,
  onClearSubtitles: () -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(16.dp).verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.ClosedCaption, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text("${strings.subtitlesTitle} ($cueCount cues)", style = MaterialTheme.typography.titleMedium)
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onPickLocalSubtitle, modifier = Modifier.weight(1f)) {
          Text(strings.addLocalSubtitle, maxLines = 1)
        }
        OutlinedButton(onClick = onOpenOnlineSearch, modifier = Modifier.weight(1f)) {
          Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(4.dp))
          Text(strings.searchOnlineSubtitles, maxLines = 1)
        }
      }
      if (cueCount > 0) {
        TextButton(onClick = onClearSubtitles) { Text(strings.delete) }
      }

      HorizontalDivider()
      Text(strings.subtitleStyleTitle, style = MaterialTheme.typography.titleSmall)

      Text("${strings.subtitleFontSize}: ${style.fontSizeSp} sp", style = MaterialTheme.typography.bodySmall)
      Slider(
        value = style.fontSizeSp.toFloat(),
        onValueChange = { onStyleChange(style.copy(fontSizeSp = it.roundToInt())) },
        valueRange = 12f..32f,
      )

      Text(
        "${strings.subtitleSyncDelay}: ${"%.1f".format(style.syncOffsetMs / 1000f)}s",
        style = MaterialTheme.typography.bodySmall,
      )
      Slider(
        value = style.syncOffsetMs / 1000f,
        onValueChange = { onStyleChange(style.copy(syncOffsetMs = (it * 1000f).toLong())) },
        valueRange = -10f..10f,
      )

      Text(strings.subtitleColor, style = MaterialTheme.typography.bodySmall)
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf(Color.White, Color(0xFFFFD54F), Color(0xFF4DD0E1), Color(0xFF81C784)).forEach { c ->
          Box(
            modifier =
              Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(c)
                .clickable { onStyleChange(style.copy(textColor = c)) },
          )
        }
      }

      Text("Background Opacity: ${(style.backgroundAlpha * 100).roundToInt()}%", style = MaterialTheme.typography.bodySmall)
      Slider(
        value = style.backgroundAlpha,
        onValueChange = { onStyleChange(style.copy(backgroundAlpha = it)) },
        valueRange = 0f..0.95f,
      )
    }
  }
}

@Composable
fun OnlineSubtitleSearchDialog(
  initialQuery: String,
  isSearching: Boolean,
  hits: List<OnlineSubtitleHit>,
  onSearch: (query: String, lang: String) -> Unit,
  onDownloadHit: (OnlineSubtitleHit) -> Unit,
  onDownloadDirectUrl: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  var query by remember { mutableStateOf(initialQuery) }
  var lang by remember { mutableStateOf("ar") }
  var directUrl by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.searchOnlineSubtitles) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
          value = query,
          onValueChange = { query = it },
          label = { Text("Movie / Episode Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(selected = lang == "ar", onClick = { lang = "ar" }, label = { Text("العربية") })
          FilterChip(selected = lang == "en", onClick = { lang = "en" }, label = { Text("English") })
          Button(onClick = { onSearch(query, lang) }, modifier = Modifier.weight(1f)) {
            Text(strings.searchOnlineSubtitles, maxLines = 1)
          }
        }
        OutlinedTextField(
          value = directUrl,
          onValueChange = { directUrl = it },
          label = { Text("Direct .srt / .vtt / .zip URL") },
          singleLine = true,
          trailingIcon = {
            TextButton(onClick = { if (directUrl.isNotBlank()) onDownloadDirectUrl(directUrl.trim()) }) {
              Text("Load")
            }
          },
          modifier = Modifier.fillMaxWidth(),
        )

        if (isSearching) {
          Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
          }
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            items(hits) { hit ->
              Surface(
                color = MaterialTheme.colorScheme.surfaceContainer,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth().clickable { onDownloadHit(hit) },
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(hit.title, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    Text("${hit.language} • ${hit.sourceName}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                  }
                  Icon(Icons.Default.CloudDownload, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
              }
            }
          }
        }
      }
    },
    confirmButton = { TextButton(onClick = onDismiss) { Text(strings.close) } },
  )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioDubbingSheet(
  embeddedAudioTracks: List<Pair<Int, String>>,
  selectedTrackIdx: Int,
  onSelectEmbeddedTrack: (Int) -> Unit,
  hasDubAudio: Boolean,
  isRecordingDub: Boolean,
  ttsAutoDubEnabled: Boolean,
  originalVolume: Float,
  dubVolume: Float,
  onPickDubAudioFile: () -> Unit,
  onToggleRecordDub: () -> Unit,
  onToggleTtsAutoDub: (Boolean) -> Unit,
  onOriginalVolumeChange: (Float) -> Unit,
  onDubVolumeChange: (Float) -> Unit,
  onClearDub: () -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(16.dp).verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.GraphicEq, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(strings.audioDubbingTitle, style = MaterialTheme.typography.titleMedium)
      }

      if (embeddedAudioTracks.isNotEmpty()) {
        Text("Built-in Audio Tracks", style = MaterialTheme.typography.titleSmall)
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          embeddedAudioTracks.forEach { (idx, label) ->
            FilterChip(
              selected = selectedTrackIdx == idx,
              onClick = { onSelectEmbeddedTrack(idx) },
              label = { Text(label) },
            )
          }
        }
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = onPickDubAudioFile, modifier = Modifier.weight(1f)) {
          Text(strings.addDubAudioFile, maxLines = 1)
        }
        Button(onClick = onToggleRecordDub, modifier = Modifier.weight(1f)) {
          Icon(
            if (isRecordingDub) Icons.Default.Stop else Icons.Default.Mic,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
          )
          Spacer(Modifier.width(4.dp))
          Text(if (isRecordingDub) strings.stopRecordingDub else strings.recordVoiceDub, maxLines = 1)
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(strings.ttsAutoDub, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = ttsAutoDubEnabled, onCheckedChange = onToggleTtsAutoDub)
      }

      Text("${strings.originalVolume}: ${(originalVolume * 100).roundToInt()}%", style = MaterialTheme.typography.bodySmall)
      Slider(value = originalVolume, onValueChange = onOriginalVolumeChange, valueRange = 0f..1f)

      if (hasDubAudio) {
        Text("${strings.dubVolume}: ${(dubVolume * 100).roundToInt()}%", style = MaterialTheme.typography.bodySmall)
        Slider(value = dubVolume, onValueChange = onDubVolumeChange, valueRange = 0f..1f)
        TextButton(onClick = onClearDub) { Text("Remove Dub Track") }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenCastSheet(
  displayNames: List<String>,
  isCastingExternal: Boolean,
  dlnaDevices: List<DlnaDevice> = emptyList(),
  isDiscoveringDlna: Boolean = false,
  isBackgroundCasting: Boolean = false,
  backgroundCastTitle: String = "",
  hasLoadedSubtitles: Boolean = false,
  onStartExternalCast: (Int) -> Unit,
  onStopExternalCast: () -> Unit,
  onDiscoverDlna: () -> Unit = {},
  onCastToDlna: (DlnaDevice) -> Unit = {},
  onToggleBackgroundCast: () -> Unit = {},
  onOpenWirelessCastSettings: () -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .navigationBarsPadding()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.Cast, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(strings.screenCastTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      }

      // 1. Background Cast & Use Phone Freely
      Card(
        colors = CardDefaults.cardColors(
          containerColor =
            if (isBackgroundCasting) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceContainerHigh,
        ),
        shape = RoundedCornerShape(14.dp),
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(strings.castBackgroundNote, style = MaterialTheme.typography.bodySmall)
          if (isBackgroundCasting && backgroundCastTitle.isNotBlank()) {
            Text(
              "Active: $backgroundCastTitle",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.primary,
            )
          }
          Button(
            onClick = onToggleBackgroundCast,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Icon(
              if (isBackgroundCasting) Icons.Default.Stop else Icons.Default.PlayArrow,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(if (isBackgroundCasting) "Stop Background Cast" else "Start Background Cast")
          }
        }
      }

      HorizontalDivider()

      // 2. Wi-Fi Smart TV (DLNA + Subtitles)
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.Tv, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
          Text(strings.castToSmartTv, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        }
        FilledTonalButton(
          onClick = onDiscoverDlna,
          enabled = !isDiscoveringDlna,
        ) {
          if (isDiscoveringDlna) {
            CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
          } else {
            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
          }
          Spacer(Modifier.width(4.dp))
          Text(if (isDiscoveringDlna) "..." else "Scan TV")
        }
      }

      if (hasLoadedSubtitles) {
        Surface(
          color = MaterialTheme.colorScheme.secondaryContainer,
          shape = RoundedCornerShape(8.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Icon(Icons.Default.ClosedCaption, contentDescription = null, modifier = Modifier.size(16.dp))
            Text(
              "Subtitles attached & served to TV / Display",
              style = MaterialTheme.typography.labelSmall,
            )
          }
        }
      }

      if (dlnaDevices.isNotEmpty()) {
        dlnaDevices.forEach { device ->
          Surface(
            color = MaterialTheme.colorScheme.surfaceContainer,
            shape = RoundedCornerShape(12.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(device.friendlyName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(device.hostAddress, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Button(onClick = { onCastToDlna(device) }) {
                Text("Cast")
              }
            }
          }
        }
      } else {
        Text(
          "Tap Scan TV to discover DLNA / UPnP Smart TVs on the same Wi-Fi network.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      HorizontalDivider()

      // 3. External / Presentation Display + Miracast
      if (displayNames.isEmpty()) {
        Text(
          "No wired/presentation display currently attached. Connect via Wireless Cast / Miracast below or plug in an external display.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      } else {
        displayNames.forEachIndexed { idx, name ->
          Button(
            onClick = {
              if (isCastingExternal) onStopExternalCast() else onStartExternalCast(idx)
            },
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(if (isCastingExternal) "Stop Casting ($name)" else "${strings.castExternalDisplay}: $name")
          }
        }
      }

      OutlinedButton(
        onClick = onOpenWirelessCastSettings,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(strings.openSystemCast)
      }
    }
  }
}
