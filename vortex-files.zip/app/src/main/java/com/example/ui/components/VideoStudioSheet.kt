package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.media.VideoEditSpec
import com.example.domain.media.VideoEditorEngine
import com.example.i18n.LocalAppStrings
import java.io.File
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun VideoStudioSheet(
  sourceVideo: File,
  durationMs: Long,
  engine: VideoEditorEngine,
  onExportedVideo: (File) -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val scope = rememberCoroutineScope()
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  val safeDuration = durationMs.coerceAtLeast(1000L).toFloat()
  var trimRange by remember { mutableStateOf(0f..safeDuration) }
  var speedMultiplier by remember { mutableFloatStateOf(1f) }
  var contrast by remember { mutableFloatStateOf(0f) }
  var saturation by remember { mutableFloatStateOf(0f) }
  var hueShift by remember { mutableFloatStateOf(0f) }
  var lightness by remember { mutableFloatStateOf(0f) }
  var muteAudio by remember { mutableStateOf(false) }
  var audioGain by remember { mutableFloatStateOf(1f) }
  var noiseGate by remember { mutableStateOf(false) }

  var isExporting by remember { mutableStateOf(false) }
  var exportProgress by remember { mutableIntStateOf(0) }
  var exportError by remember { mutableStateOf<String?>(null) }

  ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(strings.videoStudioTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = strings.close) }
      }

      Text(
        "${strings.trimRangeLabel}: ${(trimRange.start / 1000).toInt()}s - ${(trimRange.endInclusive / 1000).toInt()}s",
        style = MaterialTheme.typography.labelLarge,
      )
      RangeSlider(
        value = trimRange,
        onValueChange = { trimRange = it },
        valueRange = 0f..safeDuration,
      )

      Text("${strings.playbackSpeed}: ${speedMultiplier}x", style = MaterialTheme.typography.labelLarge)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { spd ->
          FilterChip(
            selected = speedMultiplier == spd,
            onClick = { speedMultiplier = spd },
            label = { Text("${spd}x") },
          )
        }
      }

      Text("Color Grading (Contrast ${"%.2f".format(contrast)} / Sat ${saturation.toInt()} / Hue ${hueShift.toInt()}°)")
      Slider(value = contrast, onValueChange = { contrast = it }, valueRange = -0.5f..0.5f)
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Slider(value = saturation, onValueChange = { saturation = it }, valueRange = -100f..100f, modifier = Modifier.weight(1f))
        Slider(value = hueShift, onValueChange = { hueShift = it }, valueRange = -180f..180f, modifier = Modifier.weight(1f))
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Mute Original Audio")
        Switch(checked = muteAudio, onCheckedChange = { muteAudio = it })
      }
      if (!muteAudio) {
        Text("Audio Gain: ${"%.1f".format(audioGain)}x")
        Slider(value = audioGain, onValueChange = { audioGain = it }, valueRange = 0.2f..3f)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
          Text(strings.noiseReduction)
          Switch(checked = noiseGate, onCheckedChange = { noiseGate = it })
        }
      }

      if (isExporting) {
        LinearProgressIndicator(progress = { exportProgress / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp))
        Text("Exporting... $exportProgress%", style = MaterialTheme.typography.labelMedium)
      }
      if (!exportError.isNullOrBlank()) {
        Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(8.dp)) {
          Text(exportError!!, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(10.dp))
        }
      }

      Button(
        onClick = {
          isExporting = true
          exportError = null
          exportProgress = 0
          scope.launch {
            val out = File(sourceVideo.parentFile, "${sourceVideo.nameWithoutExtension}_edited_${System.currentTimeMillis() % 10000}.mp4")
            runCatching {
              engine.exportEditedVideo(
                inputVideo = sourceVideo,
                outputVideo = out,
                spec = VideoEditSpec(
                  trimStartMs = trimRange.start.toLong(),
                  trimEndMs = trimRange.endInclusive.toLong(),
                  speedMultiplier = speedMultiplier,
                  contrast = contrast,
                  saturation = saturation,
                  hueShift = hueShift,
                  lightness = lightness,
                  muteAudio = muteAudio,
                  audioGainMultiplier = audioGain,
                  simpleNoiseGate = noiseGate,
                ),
                onProgress = { exportProgress = it },
              )
            }.onSuccess { exported ->
              isExporting = false
              onExportedVideo(exported)
            }.onFailure { err ->
              isExporting = false
              exportError = err.localizedMessage ?: "Export failed"
            }
          }
        },
        enabled = !isExporting,
        modifier = Modifier.fillMaxWidth().testTag("video_studio_export_button"),
      ) {
        Icon(Icons.Default.MovieCreation, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text("Export Edited MP4")
      }
      Spacer(Modifier.height(10.dp))
    }
  }
}
