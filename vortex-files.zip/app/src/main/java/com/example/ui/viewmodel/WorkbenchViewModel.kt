package com.example.ui.viewmodel

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.VortexAppContainer
import com.example.data.db.BookmarkEntity
import com.example.data.db.RecentFileEntity
import com.example.data.db.TaskHistoryEntity
import com.example.data.db.VaultEntryEntity
import com.example.data.prefs.LayoutMode
import com.example.data.prefs.LongFilenameMode
import com.example.data.prefs.SortField
import com.example.data.prefs.UserPreferences
import com.example.domain.archive.ArchiveEngine
import com.example.domain.archive.ArchiveFormat
import com.example.domain.archive.CompressionMode
import com.example.domain.archive.ImageOutputFormat
import com.example.domain.archive.UniversalReductionRequest
import com.example.domain.cloud.CloudStorageClient
import com.example.domain.fs.ConflictAction
import com.example.domain.fs.ConflictChoice
import com.example.domain.fs.DiffResult
import com.example.domain.fs.EditBackupManager
import com.example.domain.fs.FileConflictInfo
import com.example.domain.fs.FileHashes
import com.example.domain.fs.FileSourceType
import com.example.domain.fs.MagicDetectionResult
import com.example.domain.fs.SearchHit
import com.example.domain.fs.VirtualFileNode
import com.example.domain.fs.VortexBackupMetadata
import com.example.domain.fs.formatFileSize
import com.example.domain.fs.mimeTypeFromExtension
import com.example.domain.fs.nextAvailableNumberedFile
import com.example.domain.media.DiscoveredMediaKind
import com.example.domain.media.MediaBucketSummary
import com.example.domain.security.AntivirusScanReport
import com.example.i18n.AppLanguage
import com.example.shizuku.ShizukuStatus
import com.example.ui.theme.AccentStyle
import com.example.ui.theme.ThemePreset
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

enum class PaneId(val index: Int) {
  LEFT(0),
  RIGHT(1),
  THIRD(2),
  FOURTH(3);

  companion object {
    fun byIndex(idx: Int): PaneId = entries.getOrElse(idx) { LEFT }
  }
}

enum class FolderViewMode {
  NORMAL,
  GALLERY,
  MUSIC,
  VIDEO,
  CODE_DOCS,
}

data class FileTab(
  val id: String,
  val title: String,
  val path: String,
)

data class PaneState(
  val id: PaneId,
  val currentPath: String,
  val tabs: List<FileTab>,
  val activeTabIndex: Int = 0,
  val items: List<VirtualFileNode> = emptyList(),
  val selectedPaths: Set<String> = emptySet(),
  val viewMode: FolderViewMode = FolderViewMode.NORMAL,
  val isLoading: Boolean = false,
  val error: String? = null,
) {
  val selectedNodes: List<VirtualFileNode>
    get() = items.filter { it.path in selectedPaths }
}

data class ClipboardState(
  val items: List<VirtualFileNode> = emptyList(),
  val isCut: Boolean = false,
)

data class BackgroundTaskState(
  val id: Long,
  val title: String,
  val progress: Int,
  val isCompleted: Boolean = false,
  val error: String? = null,
)

data class StorageFolderStat(
  val name: String,
  val path: String,
  val isDirectory: Boolean,
  val bytes: Long,
)

data class StorageAnalysisSummary(
  val rootPath: String,
  val totalBytes: Long,
  val fileCount: Int,
  val folderCount: Int,
  val topEntries: List<StorageFolderStat>,
)

data class InstalledAppInfo(
  val packageName: String,
  val appName: String,
  val versionName: String,
  val apkPath: String,
  val apkSizeBytes: Long,
  val isSystemApp: Boolean,
  val splitPaths: List<String> = emptyList(),
)

data class PendingConflictUi(
  val info: FileConflictInfo,
  val deferred: CompletableDeferred<ConflictChoice>,
)

class WorkbenchViewModel(
  private val appContext: Context,
  private val container: VortexAppContainer,
) : ViewModel() {

  val preferences: StateFlow<UserPreferences> =
    container.preferencesRepo.preferences.stateIn(
      viewModelScope,
      SharingStarted.Eagerly,
      UserPreferences(),
    )

  val bookmarks =
    container.database
      .bookmarkDao()
      .observeBookmarks()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val recentFiles =
    container.database
      .recentFileDao()
      .observeRecent()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val shizukuStatus: StateFlow<ShizukuStatus> = container.shizukuManager.status
  val isRootAvailable: StateFlow<Boolean> = container.rootShellManager.isRootAvailable
  val thumbnailLoader = container.mediaThumbnailLoader

  private val defaultLeftPath: String =
    if (container.fileRepository.hasAllFilesPermission() &&
      File(container.fileRepository.internalStorageRoot()).canRead()
    ) {
      container.fileRepository.internalStorageRoot()
    } else {
      container.fileRepository.appWorkspaceDir().absolutePath
    }

  private val defaultRightPath: String =
    File(container.fileRepository.downloadsDir()).let { dl ->
      if (dl.exists() && dl.canRead()) dl.absolutePath
      else container.fileRepository.appWorkspaceDir().absolutePath
    }

  private val defaultThirdPath: String = container.fileRepository.appWorkspaceDir().absolutePath
  private val defaultFourthPath: String =
    File(container.fileRepository.internalStorageRoot(), "DCIM").let { dcim ->
      if (dcim.exists() && dcim.canRead()) dcim.absolutePath
      else container.fileRepository.appWorkspaceDir().absolutePath
    }

  private fun createInitialPane(id: PaneId, path: String): PaneState =
    PaneState(
      id = id,
      currentPath = path,
      tabs = listOf(FileTab("${id.name}_0", displayTitleForPath(path), path)),
    )

  private val _panes =
    MutableStateFlow(
      listOf(
        createInitialPane(PaneId.LEFT, defaultLeftPath),
        createInitialPane(PaneId.RIGHT, defaultRightPath),
        createInitialPane(PaneId.THIRD, defaultThirdPath),
        createInitialPane(PaneId.FOURTH, defaultFourthPath),
      )
    )
  val panes: StateFlow<List<PaneState>> = _panes.asStateFlow()

  private val _activePane = MutableStateFlow(PaneId.LEFT)
  val activePane: StateFlow<PaneId> = _activePane.asStateFlow()

  private val _clipboard = MutableStateFlow(ClipboardState())
  val clipboard: StateFlow<ClipboardState> = _clipboard.asStateFlow()

  private val _tasks = MutableStateFlow<List<BackgroundTaskState>>(emptyList())
  val tasks: StateFlow<List<BackgroundTaskState>> = _tasks.asStateFlow()

  private val _searchResults = MutableStateFlow<List<SearchHit>?>(null)
  val searchResults: StateFlow<List<SearchHit>?> = _searchResults.asStateFlow()

  private val _isSearching = MutableStateFlow(false)
  val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

  private val _statusBanner = MutableStateFlow<String?>(null)
  val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

  private val _pendingConflict = MutableStateFlow<PendingConflictUi?>(null)
  val pendingConflict: StateFlow<PendingConflictUi?> = _pendingConflict.asStateFlow()
  private val conflictMutex = Mutex()

  private val _antivirusReport = MutableStateFlow<AntivirusScanReport?>(null)
  val antivirusReport: StateFlow<AntivirusScanReport?> = _antivirusReport.asStateFlow()

  private val _isAntivirusScanning = MutableStateFlow(false)
  val isAntivirusScanning: StateFlow<Boolean> = _isAntivirusScanning.asStateFlow()

  private val _pendingBackupRestore = MutableStateFlow<VortexBackupMetadata?>(null)
  val pendingBackupRestore: StateFlow<VortexBackupMetadata?> = _pendingBackupRestore.asStateFlow()

  private val _mediaLibraryBuckets = MutableStateFlow<Map<DiscoveredMediaKind, List<MediaBucketSummary>>>(emptyMap())
  val mediaLibraryBuckets: StateFlow<Map<DiscoveredMediaKind, List<MediaBucketSummary>>> = _mediaLibraryBuckets.asStateFlow()

  private val _hasAllFilesAccess =
    MutableStateFlow(container.fileRepository.hasAllFilesPermission())
  val hasAllFilesAccess: StateFlow<Boolean> = _hasAllFilesAccess.asStateFlow()

  private val taskJobs = mutableMapOf<Long, Job>()

  init {
    viewModelScope.launch {
      runCatching { container.recycleBinManager.purgeExpired() }
    }
    refreshAll()
  }

  private fun getPane(paneId: PaneId): PaneState = _panes.value.getOrElse(paneId.index) { _panes.value.first() }

  private inline fun updatePane(paneId: PaneId, crossinline transform: (PaneState) -> PaneState) {
    _panes.update { list ->
      list.map { if (it.id == paneId) transform(it) else it }
    }
  }

  fun refreshPermissionState() {
    val granted = container.fileRepository.hasAllFilesPermission()
    _hasAllFilesAccess.value = granted
    container.shizukuManager.refreshStatus()
    refreshAll()
  }

  fun refreshAll() {
    val count = preferences.value.paneCount.coerceIn(1, 4)
    PaneId.entries.take(count).forEach { loadPane(it) }
  }

  fun setActivePane(paneId: PaneId) {
    _activePane.value = paneId
  }

  fun setPaneCount(count: Int) {
    val clamped = count.coerceIn(1, 4)
    viewModelScope.launch {
      container.preferencesRepo.setPaneCount(clamped)
      if (_activePane.value.index >= clamped) {
        _activePane.value = PaneId.LEFT
      }
      PaneId.entries.take(clamped).forEach { loadPane(it) }
    }
  }

  fun navigatePane(paneId: PaneId, path: String) {
    updatePane(paneId) { st ->
      val updatedTabs =
        st.tabs.mapIndexed { i, tab ->
          if (i == st.activeTabIndex) tab.copy(path = path, title = displayTitleForPath(path))
          else tab
        }
      st.copy(currentPath = path, tabs = updatedTabs, selectedPaths = emptySet())
    }
    _activePane.value = paneId
    loadPane(paneId)
  }

  fun navigateUp(paneId: PaneId): Boolean {
    val curr = getPane(paneId).currentPath
    val arcParsed = ArchiveEngine.parseArchiveUri(curr)
    if (arcParsed != null) {
      val (arcFile, sub) = arcParsed
      if (sub.isEmpty()) {
        val parent = File(arcFile).parent ?: container.fileRepository.internalStorageRoot()
        navigatePane(paneId, parent)
      } else {
        val parentSub = sub.substringBeforeLast('/', "")
        navigatePane(paneId, ArchiveEngine.buildArchiveUri(arcFile, parentSub))
      }
      return true
    }
    val cloudParsed = CloudStorageClient.parseCloudUri(curr)
    if (cloudParsed != null) {
      val (id, remote) = cloudParsed
      val clean = remote.trimEnd('/')
      if (clean.isEmpty() || clean == "/") {
        navigatePane(paneId, container.fileRepository.internalStorageRoot())
      } else {
        val parentRemote = clean.substringBeforeLast('/', "").ifEmpty { "/" }
        navigatePane(paneId, CloudStorageClient.buildCloudUri(id, parentRemote))
      }
      return true
    }
    if (curr.startsWith("content://")) {
      navigatePane(paneId, container.fileRepository.internalStorageRoot())
      return true
    }
    if (curr == "/" || curr.isEmpty()) return false
    val parent = File(curr).parent ?: return false
    navigatePane(paneId, parent)
    return true
  }

  fun addTab(paneId: PaneId) {
    updatePane(paneId) { st ->
      val newPath = st.currentPath
      val newTab =
        FileTab(
          id = "${paneId.name}_${System.currentTimeMillis()}",
          title = displayTitleForPath(newPath),
          path = newPath,
        )
      st.copy(tabs = st.tabs + newTab, activeTabIndex = st.tabs.size, selectedPaths = emptySet())
    }
    loadPane(paneId)
  }

  fun switchTab(paneId: PaneId, index: Int) {
    updatePane(paneId) { st ->
      val tab = st.tabs.getOrNull(index) ?: return@updatePane st
      st.copy(activeTabIndex = index, currentPath = tab.path, selectedPaths = emptySet())
    }
    loadPane(paneId)
  }

  fun closeTab(paneId: PaneId, index: Int) {
    updatePane(paneId) { st ->
      if (st.tabs.size <= 1) return@updatePane st
      val newTabs = st.tabs.filterIndexed { i, _ -> i != index }
      val newIdx = st.activeTabIndex.coerceAtMost(newTabs.lastIndex)
      st.copy(
        tabs = newTabs,
        activeTabIndex = newIdx,
        currentPath = newTabs[newIdx].path,
        selectedPaths = emptySet(),
      )
    }
    loadPane(paneId)
  }

  private fun displayTitleForPath(path: String): String {
    val arcParsed = ArchiveEngine.parseArchiveUri(path)
    if (arcParsed != null) {
      return arcParsed.second.ifEmpty { File(arcParsed.first).name }
    }
    val cloudParsed = CloudStorageClient.parseCloudUri(path)
    if (cloudParsed != null) {
      return cloudParsed.second.trim('/').substringAfterLast('/').ifEmpty { "Cloud #${cloudParsed.first}" }
    }
    if (path.startsWith("content://")) return "Android/data"
    if (path == "/") return "/"
    return File(path).name.ifEmpty { path }
  }

  fun loadPane(paneId: PaneId) {
    viewModelScope.launch {
      updatePane(paneId) { it.copy(isLoading = true, error = null) }
      val prefs = preferences.value
      val currentPath = getPane(paneId).currentPath
      val items =
        runCatching {
          container.fileRepository.listDirectory(
            path = currentPath,
            showHidden = prefs.showHiddenFiles,
            sortField = prefs.sortField,
            sortAscending = prefs.sortAscending,
            useRoot = prefs.rootModeEnabled,
          )
        }
      items.fold(
        onSuccess = { list -> updatePane(paneId) { it.copy(items = list, isLoading = false) } },
        onFailure = { e -> updatePane(paneId) { it.copy(isLoading = false, error = e.message) } },
      )
    }
  }

  fun toggleSelection(paneId: PaneId, path: String) {
    _activePane.value = paneId
    updatePane(paneId) { st ->
      val next = if (path in st.selectedPaths) st.selectedPaths - path else st.selectedPaths + path
      st.copy(selectedPaths = next)
    }
  }

  fun setSelectedRange(paneId: PaneId, paths: Set<String>) {
    _activePane.value = paneId
    updatePane(paneId) { st -> st.copy(selectedPaths = paths) }
  }

  fun setPaneViewMode(paneId: PaneId, mode: FolderViewMode) {
    _activePane.value = paneId
    updatePane(paneId) { st -> st.copy(viewMode = mode) }
    when (mode) {
      FolderViewMode.GALLERY -> discoverMediaBuckets(DiscoveredMediaKind.PHOTOS)
      FolderViewMode.MUSIC -> discoverMediaBuckets(DiscoveredMediaKind.AUDIO)
      FolderViewMode.VIDEO -> discoverMediaBuckets(DiscoveredMediaKind.VIDEOS)
      else -> {}
    }
  }

  fun discoverMediaBuckets(kind: DiscoveredMediaKind) {
    viewModelScope.launch {
      val buckets = runCatching {
        container.mediaLibraryScanner.discoverMediaBuckets(appContext, kind)
      }.getOrDefault(emptyList())
      _mediaLibraryBuckets.update { it + (kind to buckets) }
    }
  }

  fun selectAll(paneId: PaneId) {
    updatePane(paneId) { st ->
      val allPaths = st.items.map { it.path }.toSet()
      val allSelected = allPaths.isNotEmpty() && st.selectedPaths.containsAll(allPaths)
      st.copy(selectedPaths = if (allSelected) emptySet() else allPaths)
    }
  }

  fun clearSelection(paneId: PaneId) {
    updatePane(paneId) { st -> st.copy(selectedPaths = emptySet()) }
  }

  fun copyToClipboard(paneId: PaneId, isCut: Boolean) {
    val nodes = getPane(paneId).selectedNodes
    if (nodes.isNotEmpty()) {
      _clipboard.value = ClipboardState(items = nodes, isCut = isCut)
      clearSelection(paneId)
    }
  }

  private suspend fun promptConflict(info: FileConflictInfo): ConflictChoice =
    conflictMutex.withLock {
      val deferred = CompletableDeferred<ConflictChoice>()
      _pendingConflict.value = PendingConflictUi(info, deferred)
      try {
        deferred.await()
      } finally {
        if (_pendingConflict.value?.deferred === deferred) {
          _pendingConflict.value = null
        }
      }
    }

  fun resolvePendingConflict(action: ConflictAction, applyToAll: Boolean) {
    val current = _pendingConflict.value ?: return
    _pendingConflict.value = null
    current.deferred.complete(ConflictChoice(action = action, applyToAll = applyToAll))
  }

  fun pasteToPane(targetPaneId: PaneId) {
    val clip = _clipboard.value
    if (clip.items.isEmpty()) return
    val targetDir = getPane(targetPaneId).currentPath
    launchBackgroundTask(if (clip.isCut) "Move ${clip.items.size} items" else "Copy ${clip.items.size} items") { onProg ->
      container.fileRepository.copyOrMove(
        sources = clip.items,
        targetDir = targetDir,
        isMove = clip.isCut,
        useRoot = preferences.value.rootModeEnabled,
        onProgress = onProg,
        onConflict = ::promptConflict,
      )
      if (clip.isCut) _clipboard.value = ClipboardState()
      refreshAll()
    }
  }

  fun transferToOppositePane(sourcePaneId: PaneId, isMove: Boolean, explicitTarget: PaneId? = null) {
    val nodes = getPane(sourcePaneId).selectedNodes
    if (nodes.isEmpty()) return
    val count = preferences.value.paneCount.coerceIn(1, 4)
    val targetPane =
      explicitTarget
        ?: if (count <= 1) PaneId.RIGHT else PaneId.byIndex((sourcePaneId.index + 1) % count)
    val targetDir = getPane(targetPane).currentPath
    clearSelection(sourcePaneId)
    launchBackgroundTask(if (isMove) "Move -> ${displayTitleForPath(targetDir)}" else "Copy -> ${displayTitleForPath(targetDir)}") { onProg ->
      container.fileRepository.copyOrMove(
        sources = nodes,
        targetDir = targetDir,
        isMove = isMove,
        useRoot = preferences.value.rootModeEnabled,
        onProgress = onProg,
        onConflict = ::promptConflict,
      )
      refreshAll()
    }
  }

  fun createFolder(paneId: PaneId, name: String) {
    val cleanName = name.trim()
    if (cleanName.isBlank()) return
    val dir = getPane(paneId).currentPath
    viewModelScope.launch {
      var targetName = cleanName
      val existing = File(dir, cleanName)
      if (!dir.startsWith("cloud://") && !dir.startsWith("content://") && existing.exists()) {
        val choice = promptConflict(
          FileConflictInfo(
            fileName = cleanName,
            destPath = existing.absolutePath,
            sourceSize = 0L,
            existingSize = if (existing.isFile) existing.length() else 0L,
            sourceModified = System.currentTimeMillis(),
            existingModified = existing.lastModified(),
            remainingItems = 0,
          )
        )
        when (choice.action) {
          ConflictAction.SKIP -> return@launch
          ConflictAction.REPLACE -> {
            withContext(Dispatchers.IO) { existing.deleteRecursively() }
          }
          ConflictAction.KEEP_BOTH -> {
            targetName = nextAvailableNumberedFile(existing).name
          }
        }
      }
      val ok = container.fileRepository.createDirectory(dir, targetName, preferences.value.rootModeEnabled)
      if (ok) loadPane(paneId) else _statusBanner.value = "Failed to create folder"
    }
  }

  fun createFile(paneId: PaneId, name: String) {
    val cleanName = name.trim()
    if (cleanName.isBlank()) return
    val dir = getPane(paneId).currentPath
    viewModelScope.launch {
      var targetName = cleanName
      val existing = File(dir, cleanName)
      if (!dir.startsWith("cloud://") && !dir.startsWith("content://") && existing.exists()) {
        val choice = promptConflict(
          FileConflictInfo(
            fileName = cleanName,
            destPath = existing.absolutePath,
            sourceSize = 0L,
            existingSize = if (existing.isFile) existing.length() else 0L,
            sourceModified = System.currentTimeMillis(),
            existingModified = existing.lastModified(),
            remainingItems = 0,
          )
        )
        when (choice.action) {
          ConflictAction.SKIP -> return@launch
          ConflictAction.REPLACE -> {
            withContext(Dispatchers.IO) { existing.deleteRecursively() }
          }
          ConflictAction.KEEP_BOTH -> {
            targetName = nextAvailableNumberedFile(existing).name
          }
        }
      }
      val ok = container.fileRepository.createFile(dir, targetName, preferences.value.rootModeEnabled)
      if (ok) loadPane(paneId) else _statusBanner.value = "Failed to create file"
    }
  }

  fun renameNode(paneId: PaneId, node: VirtualFileNode, newName: String) {
    if (newName.isBlank()) return
    viewModelScope.launch {
      val ok = container.fileRepository.rename(node, newName.trim(), preferences.value.rootModeEnabled)
      if (ok) {
        clearSelection(paneId)
        loadPane(paneId)
      } else {
        _statusBanner.value = "Rename failed"
      }
    }
  }

  fun batchRename(
    paneId: PaneId,
    prefix: String,
    suffix: String,
    findText: String,
    replaceText: String,
    addCounter: Boolean,
    startNumber: Int,
  ) {
    val nodes = getPane(paneId).selectedNodes
    if (nodes.isEmpty()) return
    viewModelScope.launch {
      var counter = startNumber
      var successCount = 0
      nodes.forEach { node ->
        val base = if (node.isDirectory) node.name else node.name.substringBeforeLast('.')
        val ext = if (node.isDirectory || !node.name.contains('.')) "" else ".${node.name.substringAfterLast('.')}"
        var nextBase = if (findText.isNotEmpty()) base.replace(findText, replaceText) else base
        nextBase = "$prefix$nextBase$suffix"
        if (addCounter) {
          nextBase = "${nextBase}_${counter++}"
        }
        val finalName = "$nextBase$ext"
        if (finalName.isNotBlank() && finalName != node.name) {
          if (container.fileRepository.rename(node, finalName, preferences.value.rootModeEnabled)) {
            successCount++
          }
        }
      }
      clearSelection(paneId)
      loadPane(paneId)
      _statusBanner.value = "Renamed $successCount / ${nodes.size}"
    }
  }

  fun deleteSelected(paneId: PaneId, permanent: Boolean = false) {
    val nodes = getPane(paneId).selectedNodes
    if (nodes.isEmpty()) return
    val retention = preferences.value.trashRetentionDays
    viewModelScope.launch {
      val localNodes = nodes.filter { it.sourceType == FileSourceType.LOCAL }
      val nonLocalNodes = nodes.filter { it.sourceType != FileSourceType.LOCAL }
      var affected = 0
      if (!permanent && retention > 0 && localNodes.isNotEmpty()) {
        affected += container.recycleBinManager.moveToTrash(localNodes, retention)
      } else if (localNodes.isNotEmpty()) {
        affected += container.fileRepository.deleteNodes(localNodes, preferences.value.rootModeEnabled)
      }
      if (nonLocalNodes.isNotEmpty()) {
        affected += container.fileRepository.deleteNodes(nonLocalNodes, preferences.value.rootModeEnabled)
      }
      clearSelection(paneId)
      refreshAll()
      _statusBanner.value =
        if (!permanent && retention > 0 && localNodes.isNotEmpty()) "Moved $affected item(s) to Recycle Bin"
        else "Deleted $affected item(s)"
    }
  }

  suspend fun inspectMagicFormat(node: VirtualFileNode): MagicDetectionResult =
    withContext(Dispatchers.IO) {
      val f = File(node.path)
      if (node.sourceType == FileSourceType.LOCAL && f.exists() && f.isFile && f.canRead()) {
        container.magicDetector.inspectFile(f)
      } else {
        val bytes = container.fileRepository.readFileBytes(node, maxBytes = 2048)
        container.magicDetector.inspectBytes(bytes, node.extension)
      }
    }

  fun repairExtension(paneId: PaneId, node: VirtualFileNode, suggestedExt: String) {
    val stem = node.name.substringBeforeLast('.', node.name)
    val fixedName = "$stem.$suggestedExt"
    renameNode(paneId, node, fixedName)
  }

  fun lockNodeToVault(
    paneId: PaneId,
    node: VirtualFileNode,
    password: String,
    onRecoveryKeyReady: (String) -> Unit,
  ) {
    val target = File(node.path)
    if (!target.exists()) {
      _statusBanner.value = "Only local files/folders can be encrypted"
      return
    }
    launchBackgroundTask("Lock ${node.name}") { onProg ->
      onProg(25)
      val res = container.vaultEngine.lockTarget(target, password, deleteOriginal = true)
      container.database.vaultDao().insert(
        VaultEntryEntity(
          originalPath = res.originalPath,
          displayName = res.originalName,
          lockedPath = res.lockedFile.absolutePath,
          wasDirectory = res.wasDirectory,
          originalSizeBytes = res.originalSizeBytes,
          recoveryKeyHash = res.recoveryKeyHash,
        )
      )
      onProg(100)
      withContext(Dispatchers.Main) { onRecoveryKeyReady(res.recoveryKey) }
      clearSelection(paneId)
      refreshAll()
    }
  }

  fun unlockVaultFile(paneId: PaneId, node: VirtualFileNode, secretOrRecoveryKey: String) {
    val locked = File(node.path)
    if (!locked.exists()) return
    launchBackgroundTask("Unlock ${node.name}") { onProg ->
      onProg(30)
      val res = container.vaultEngine.unlockTarget(locked, secretOrRecoveryKey, deleteLockedAfter = true)
      container.database.vaultDao().deleteByLockedPath(locked.absolutePath)
      onProg(100)
      _statusBanner.value = "Restored ${res.restoredFile.name}"
      clearSelection(paneId)
      refreshAll()
    }
  }

  fun convertAndSignApk(paneId: PaneId, node: VirtualFileNode) {
    val src = File(node.path)
    if (!src.exists()) {
      _statusBanner.value = "Select a local APK / APKS / XAPK / APKM / AAB / folder"
      return
    }
    val parent = src.parentFile ?: container.fileRepository.appWorkspaceDir()
    val stem = src.nameWithoutExtension.ifBlank { src.name }
    val outApk = File(parent, "${stem}_signed.apk")
    launchBackgroundTask("Build & Sign ${outApk.name}") { onProg ->
      val res = container.apkSignerAndBuilder.convertToSignedApk(src, outApk, onProgress = onProg)
      _statusBanner.value = "Signed APK ready (${res.entriesCount} entries, v1+v2)"
      loadPane(paneId)
    }
  }

  fun chmodNode(paneId: PaneId, node: VirtualFileNode, octal: String) {
    viewModelScope.launch {
      val ok = container.fileRepository.chmod(node.path, octal, preferences.value.rootModeEnabled)
      if (ok) loadPane(paneId) else _statusBanner.value = "chmod $octal failed"
    }
  }

  suspend fun computeHashes(node: VirtualFileNode): FileHashes? {
    val f = File(node.path)
    return if (f.exists() && f.isFile && f.canRead()) container.fileRepository.computeHashes(f) else null
  }

  suspend fun compareAcrossPanes(): DiffResult? {
    val pane1 = getPane(PaneId.LEFT)
    val pane2 = getPane(PaneId.RIGHT)
    val lSel = pane1.selectedNodes.firstOrNull()
    val rSel = pane2.selectedNodes.firstOrNull()
    val left =
      lSel
        ?: VirtualFileNode(
          displayTitleForPath(pane1.currentPath),
          pane1.currentPath,
          true,
          0L,
          0L,
        )
    val right =
      rSel
        ?: VirtualFileNode(
          displayTitleForPath(pane2.currentPath),
          pane2.currentPath,
          true,
          0L,
          0L,
        )
    return container.fileRepository.compareNodes(left, right)
  }

  fun compressSelectedArchive(
    paneId: PaneId,
    outputName: String,
    format: ArchiveFormat,
    level: Int,
    password: String?,
  ) {
    val pane = getPane(paneId)
    val sources = pane.selectedNodes.map { File(it.path) }.filter { it.exists() }
    if (sources.isEmpty()) return
    val outFile = File(pane.currentPath, "$outputName.${format.extension}")
    clearSelection(paneId)

    launchBackgroundTask("Archive ${outFile.name} (L$level)") { onProg ->
      container.archiveEngine.createArchive(sources, outFile, format, level, password, onProg)
      container.database.taskHistoryDao().insert(
        TaskHistoryEntity(
          title = "Archive (${format.displayName} L$level)",
          category = "ARCHIVE",
          sourcePath = sources.joinToString { it.name },
          outputPath = outFile.absolutePath,
          details = "Lossless • ${formatFileSize(outFile.length())}",
          success = true,
        )
      )
      refreshAll()
    }
  }

  fun compressSelectedImages(
    paneId: PaneId,
    mode: CompressionMode,
    quality: Int,
    scalePercent: Int,
    targetFormat: ImageOutputFormat,
  ) {
    val pane = getPane(paneId)
    val imgFiles = pane.selectedNodes.map { File(it.path) }.filter { it.exists() && it.isFile }
    if (imgFiles.isEmpty()) return
    val outDir = File(pane.currentPath, "Compressed_${System.currentTimeMillis() % 10000}")
    clearSelection(paneId)

    val label = if (mode == CompressionMode.LOSSLESS) "Lossless Images" else "Lossy Images ($quality%)"
    launchBackgroundTask(label) { onProg ->
      val summary =
        container.mediaCompressionEngine.compressImages(
          imgFiles,
          outDir,
          mode,
          quality,
          scalePercent,
          targetFormat,
          onProg,
        )
      _statusBanner.value =
        "${summary.outputFiles.size} files • ${formatFileSize(summary.originalTotalBytes)} -> ${formatFileSize(summary.outputTotalBytes)} (${summary.savedPercent}% saved)"
      container.database.taskHistoryDao().insert(
        TaskHistoryEntity(
          title = label,
          category = if (summary.isLossless) "LOSSLESS" else "LOSSY",
          sourcePath = "${imgFiles.size} images",
          outputPath = outDir.absolutePath,
          details = "${formatFileSize(summary.originalTotalBytes)} -> ${formatFileSize(summary.outputTotalBytes)}",
          success = true,
        )
      )
      refreshAll()
    }
  }

  fun reduceFilesUniversal(paneId: PaneId, request: UniversalReductionRequest) {
    val pane = getPane(paneId)
    val nodes = pane.selectedNodes
    if (nodes.isEmpty()) return
    val outDir = File(pane.currentPath, "Reduced_${System.currentTimeMillis() % 10000}")
    clearSelection(paneId)

    launchBackgroundTask("Reduce Quality/Size (${nodes.size} items)") { onProg ->
      val result = container.universalSizeReducer.reduceFiles(nodes, outDir, request, onProg)
      _statusBanner.value =
        "${result.outputFiles.size} files • ${formatFileSize(result.originalBytes)} -> ${formatFileSize(result.reducedBytes)} (${result.savedPercent}% saved)"
      container.database.taskHistoryDao().insert(
        TaskHistoryEntity(
          title = "Universal Size Reducer",
          category = "LOSSY",
          sourcePath = "${nodes.size} files",
          outputPath = outDir.absolutePath,
          details = "${formatFileSize(result.originalBytes)} -> ${formatFileSize(result.reducedBytes)}",
          success = true,
        )
      )
      refreshAll()
    }
  }

  fun extractArchive(paneId: PaneId, archiveNode: VirtualFileNode, toOppositePane: Boolean, password: String? = null) {
    val countPanes = preferences.value.paneCount.coerceIn(1, 4)
    val targetBase =
      if (toOppositePane) {
        val nextId = if (countPanes <= 1) PaneId.RIGHT else PaneId.byIndex((paneId.index + 1) % countPanes)
        getPane(nextId).currentPath
      } else {
        getPane(paneId).currentPath
      }
    val arcFile = File(archiveNode.path)
    val destDir = File(targetBase, arcFile.nameWithoutExtension)
    launchBackgroundTask("Extract ${arcFile.name}") { onProg ->
      val count =
        container.archiveEngine.extractArchive(
          archiveFile = arcFile,
          destDir = destDir,
          password = password,
          onProgress = onProg,
          onConflict = ::promptConflict,
        )
      if (preferences.value.antivirusAutoScanEnabled && destDir.exists()) {
        val report = container.antivirusEngine.scanTarget(destDir.absolutePath)
        if (report.threatsFound > 0) {
          _antivirusReport.value = report
        }
      }
      _statusBanner.value = "Extracted $count files to ${destDir.name}"
      refreshAll()
    }
  }

  fun scanPathWithAntivirus(path: String) {
    viewModelScope.launch {
      _isAntivirusScanning.value = true
      val report = runCatching {
        container.antivirusEngine.scanTarget(path)
      }.getOrNull()
      _isAntivirusScanning.value = false
      if (report != null) {
        _antivirusReport.value = report
      } else {
        _statusBanner.value = "Antivirus scan failed"
      }
    }
  }

  fun quarantineFileFromAntivirus(filePath: String) {
    viewModelScope.launch {
      val q = container.antivirusEngine.quarantineFile(File(filePath))
      if (q != null) {
        _statusBanner.value = "Quarantined: ${File(filePath).name}"
        refreshAll()
        val prev = _antivirusReport.value
        if (prev != null) {
          _antivirusReport.value = prev.copy(
            findings = prev.findings.filterNot { it.filePath == filePath },
            threatsFound = prev.findings.count { it.filePath != filePath && it.riskScore >= 35 },
          )
        }
      }
    }
  }

  fun deleteFileFromAntivirus(filePath: String) {
    viewModelScope.launch(Dispatchers.IO) {
      val f = File(filePath)
      if (f.exists() && f.delete()) {
        withContext(Dispatchers.Main) {
          _statusBanner.value = "Deleted threat: ${f.name}"
          refreshAll()
          val prev = _antivirusReport.value
          if (prev != null) {
            _antivirusReport.value = prev.copy(
              findings = prev.findings.filterNot { it.filePath == filePath },
              threatsFound = prev.findings.count { it.filePath != filePath && it.riskScore >= 35 },
            )
          }
        }
      }
    }
  }

  fun dismissAntivirusReport() {
    _antivirusReport.value = null
  }

  fun inspectAndPromptBackup(filePath: String) {
    viewModelScope.launch {
      val meta = EditBackupManager.inspectBackup(File(filePath))
      if (meta != null) {
        _pendingBackupRestore.value = meta
      } else {
        _statusBanner.value = "Invalid or unreadable .vortexbak snapshot"
      }
    }
  }

  fun confirmRestoreBackup(paneId: PaneId, meta: VortexBackupMetadata) {
    viewModelScope.launch {
      val res = EditBackupManager.restoreBackup(File(meta.backupFilePath))
      _pendingBackupRestore.value = null
      res.fold(
        onSuccess = { restored ->
          _statusBanner.value = "Restored original: ${restored.name}"
          loadPane(paneId)
        },
        onFailure = { err ->
          _statusBanner.value = err.message ?: "Restore failed"
        },
      )
    }
  }

  fun dismissBackupRestore() {
    _pendingBackupRestore.value = null
  }

  fun estimateMediaCompression(
    nodes: List<VirtualFileNode>,
    mode: CompressionMode,
    quality: Int,
    scalePercent: Int,
  ): Pair<String, String> {
    val total = nodes.sumOf { it.size }
    val est = container.mediaCompressionEngine.estimateCompressedSize(total, mode, quality, scalePercent)
    return formatFileSize(total) to formatFileSize(est)
  }

  suspend fun analyzeDirectoryStorage(path: String): StorageAnalysisSummary =
    withContext(Dispatchers.IO) {
      val root = File(path)
      if (!root.exists() || !root.canRead()) {
        return@withContext StorageAnalysisSummary(path, 0L, 0, 0, emptyList())
      }
      var filesCount = 0
      var foldersCount = 0
      var total = 0L
      val stats = mutableListOf<StorageFolderStat>()

      root.listFiles()?.forEach { child ->
        var childBytes = 0L
        if (child.isDirectory) {
          foldersCount++
          child.walkTopDown().maxDepth(5).forEach { f ->
            if (f.isFile) {
              filesCount++
              childBytes += f.length()
            } else if (f != child) {
              foldersCount++
            }
          }
        } else {
          filesCount++
          childBytes = child.length()
        }
        total += childBytes
        stats.add(StorageFolderStat(child.name, child.absolutePath, child.isDirectory, childBytes))
      }

      StorageAnalysisSummary(
        rootPath = path,
        totalBytes = total,
        fileCount = filesCount,
        folderCount = foldersCount,
        topEntries = stats.sortedByDescending { it.bytes }.take(25),
      )
    }

  suspend fun listInstalledApps(): List<InstalledAppInfo> =
    withContext(Dispatchers.IO) {
      val pm = appContext.packageManager
      val apps =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
          @Suppress("DEPRECATION")
          pm.getInstalledApplications(0)
        }
      apps.mapNotNull { info ->
        val srcDir = info.sourceDir ?: return@mapNotNull null
        val f = File(srcDir)
        val splits = info.splitSourceDirs?.toList().orEmpty().filter { File(it).exists() }
        val totalApkBytes = (if (f.exists()) f.length() else 0L) + splits.sumOf { File(it).length() }
        val pkgInfo = runCatching { pm.getPackageInfo(info.packageName, 0) }.getOrNull()
        val label = pm.getApplicationLabel(info).toString()
        val isSys = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        InstalledAppInfo(
          packageName = info.packageName,
          appName = label,
          versionName = pkgInfo?.versionName ?: "?",
          apkPath = srcDir,
          apkSizeBytes = totalApkBytes,
          isSystemApp = isSys,
          splitPaths = splits,
        )
      }.sortedWith(compareBy<InstalledAppInfo> { it.isSystemApp }.thenBy { it.appName.lowercase() })
    }

  fun extractInstalledApk(paneId: PaneId, app: InstalledAppInfo) {
    val targetDir = getPane(paneId).currentPath
    val safeBase = "${app.appName.replace(Regex("[^A-Za-z0-9._-]"), "_")}_${app.versionName}"
    val initialDest = File(targetDir, "$safeBase.apk")

    launchBackgroundTask("Extract ${app.appName}.apk") { onProg ->
      val finalDest = if (initialDest.exists()) {
        val choice = promptConflict(
          FileConflictInfo(
            fileName = initialDest.name,
            destPath = initialDest.absolutePath,
            sourceSize = app.apkSizeBytes,
            existingSize = initialDest.length(),
            sourceModified = System.currentTimeMillis(),
            existingModified = initialDest.lastModified(),
            remainingItems = 0,
          )
        )
        when (choice.action) {
          ConflictAction.SKIP -> return@launchBackgroundTask
          ConflictAction.REPLACE -> {
            initialDest.delete()
            initialDest
          }
          ConflictAction.KEEP_BOTH -> nextAvailableNumberedFile(initialDest)
        }
      } else initialDest

      finalDest.parentFile?.mkdirs()
      val baseSrc = File(app.apkPath)
      if (app.splitPaths.isEmpty()) {
        baseSrc.copyTo(finalDest, overwrite = true)
        onProg(100)
      } else {
        // Merge base + split APKs into a single signed installable APK
        val tmpBundle = File(appContext.cacheDir, "split_bundle_${System.currentTimeMillis()}.apks")
        try {
          ZipOutputStream(FileOutputStream(tmpBundle)).use { zos ->
            listOf(baseSrc to "base.apk").plus(
              app.splitPaths.mapIndexed { i, p -> File(p) to "split_${i}_${File(p).name}" }
            ).forEach { (f, entryName) ->
              if (f.exists()) {
                zos.putNextEntry(ZipEntry(entryName))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
              }
            }
          }
          onProg(30)
          container.apkSignerAndBuilder.convertToSignedApk(tmpBundle, finalDest) { p ->
            onProg(30 + (p * 70) / 100)
          }
        } finally {
          tmpBundle.delete()
        }
      }
      _statusBanner.value = "APK extracted: ${finalDest.name}"
      loadPane(paneId)
    }
  }

  fun runDeepSearch(paneId: PaneId, query: String, searchContent: Boolean, useRegex: Boolean) {
    val root = getPane(paneId).currentPath
    viewModelScope.launch {
      _isSearching.value = true
      _searchResults.value = container.fileRepository.deepSearch(root, query, searchContent, useRegex)
      _isSearching.value = false
    }
  }

  fun clearSearch() {
    _searchResults.value = null
  }

  fun recordRecentFile(node: VirtualFileNode) {
    viewModelScope.launch {
      container.database.recentFileDao().upsert(
        RecentFileEntity(
          path = node.path,
          name = node.name,
          extension = node.extension,
          sizeBytes = node.size,
        )
      )
    }
  }

  fun toggleBookmark(path: String) {
    viewModelScope.launch {
      val exists = bookmarks.value.any { it.path == path }
      if (exists) {
        container.database.bookmarkDao().deleteByPath(path)
      } else {
        container.database.bookmarkDao().upsert(BookmarkEntity(path, displayTitleForPath(path)))
      }
    }
  }

  fun shareFile(node: VirtualFileNode) {
    viewModelScope.launch {
      val shareableFile = prepareShareableFile(node)
      if (shareableFile == null) {
        _statusBanner.value = "Cannot share this path directly"
        return@launch
      }
      runCatching {
        val uri =
          FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", shareableFile)
        val intent =
          Intent(Intent.ACTION_SEND).apply {
            type = mimeTypeFromExtension(node.extension)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
          }
        appContext.startActivity(Intent.createChooser(intent, node.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      }.onFailure {
        _statusBanner.value = "Cannot share this path directly"
      }
    }
  }

  fun openExternalApp(node: VirtualFileNode, forceGenericMime: Boolean = false) {
    viewModelScope.launch {
      val localFile = prepareShareableFile(node)
      if (localFile == null) {
        _statusBanner.value = "Cannot prepare file for external app"
        return@launch
      }
      runCatching {
        val uri =
          FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", localFile)
        val mime = if (forceGenericMime) "*/*" else mimeTypeFromExtension(node.extension)
        val baseIntent =
          Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
          }
        val chooser = Intent.createChooser(baseIntent, node.name).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        appContext.startActivity(chooser)
      }.onFailure {
        if (!forceGenericMime) {
          openExternalApp(node, forceGenericMime = true)
        } else {
          _statusBanner.value = "No external app found for ${node.name}"
        }
      }
    }
  }

  private suspend fun prepareShareableFile(node: VirtualFileNode): File? =
    withContext(Dispatchers.IO) {
      if (node.isDirectory) return@withContext null
      if (node.sourceType == FileSourceType.LOCAL) {
        val f = File(node.path)
        if (f.exists() && f.canRead()) return@withContext f
      }
      // Stage archived/SAF/Root/Shizuku files into cacheDir/external_open for FileProvider sharing
      runCatching {
        val cacheOutDir = File(appContext.cacheDir, "external_open").apply { mkdirs() }
        val safeName = node.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val outFile = File(cacheOutDir, safeName)
        if (node.sourceType == FileSourceType.ARCHIVE && node.archivePath != null && node.entryPathInArchive != null) {
          val bytes = container.archiveEngine.extractEntryBytes(File(node.archivePath), node.entryPathInArchive)
          outFile.writeBytes(bytes)
          return@withContext outFile
        }
        val bytes =
          container.fileRepository.readFileBytes(
            node = node,
            maxBytes = 64 * 1024 * 1024,
          )
        outFile.writeBytes(bytes)
        outFile
      }.getOrNull()
    }

  fun buildAllFilesPermissionIntent(): Intent {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      Intent(
        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
        Uri.parse("package:${appContext.packageName}"),
      )
    } else {
      Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${appContext.packageName}"))
    }
  }

  fun setLanguage(lang: AppLanguage) {
    viewModelScope.launch { container.preferencesRepo.setLanguage(lang) }
  }

  fun setThemePreset(preset: ThemePreset) {
    viewModelScope.launch { container.preferencesRepo.setThemePreset(preset) }
  }

  fun setAccentStyle(accent: AccentStyle) {
    viewModelScope.launch { container.preferencesRepo.setAccentStyle(accent) }
  }

  fun setLayoutMode(mode: LayoutMode) {
    viewModelScope.launch { container.preferencesRepo.setLayoutMode(mode) }
  }

  fun setSort(field: SortField, ascending: Boolean) {
    viewModelScope.launch {
      container.preferencesRepo.setSort(field, ascending)
      refreshAll()
    }
  }

  fun setShowHidden(show: Boolean) {
    viewModelScope.launch {
      container.preferencesRepo.setShowHiddenFiles(show)
      refreshAll()
    }
  }

  fun setEditorFontSize(sp: Int) {
    viewModelScope.launch { container.preferencesRepo.setEditorFontSize(sp) }
  }

  fun setEditorWordWrap(wrap: Boolean) {
    viewModelScope.launch { container.preferencesRepo.setEditorWordWrap(wrap) }
  }

  fun setLongFilenameMode(mode: LongFilenameMode) {
    viewModelScope.launch { container.preferencesRepo.setLongFilenameMode(mode) }
  }

  fun setTrashRetentionDays(days: Int) {
    viewModelScope.launch { container.preferencesRepo.setTrashRetentionDays(days) }
  }

  fun setAutoSubtitlesEnabled(enabled: Boolean) {
    viewModelScope.launch { container.preferencesRepo.setAutoSubtitlesEnabled(enabled) }
  }

  fun setSubtitlesFolderPath(path: String) {
    viewModelScope.launch { container.preferencesRepo.setSubtitlesFolderPath(path) }
  }

  fun setSubtitleLanguages(languages: List<String>) {
    viewModelScope.launch { container.preferencesRepo.setSubtitleLanguages(languages) }
  }

  fun setAutoBackupOnEditEnabled(enabled: Boolean) {
    viewModelScope.launch { container.preferencesRepo.setAutoBackupOnEditEnabled(enabled) }
  }

  fun setAntivirusAutoScanEnabled(enabled: Boolean) {
    viewModelScope.launch { container.preferencesRepo.setAntivirusAutoScanEnabled(enabled) }
  }

  fun setCompanionDownloaderUrl(url: String) {
    viewModelScope.launch { container.preferencesRepo.setCompanionDownloaderUrl(url) }
  }

  fun requestShizukuPermission() {
    container.shizukuManager.requestPermission()
  }

  fun openShizukuApp() {
    val launch = appContext.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
    if (launch != null) {
      launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      appContext.startActivity(launch)
    } else {
      val market =
        Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/")).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      runCatching { appContext.startActivity(market) }
    }
  }

  fun testAndToggleRoot() {
    viewModelScope.launch {
      val granted = container.rootShellManager.checkRootAccess()
      container.preferencesRepo.setRootModeEnabled(granted)
      if (granted) refreshAll()
    }
  }

  fun clearBanner() {
    _statusBanner.value = null
  }

  fun cancelTask(taskId: Long) {
    taskJobs[taskId]?.cancel()
    taskJobs.remove(taskId)
    _tasks.update { list -> list.filterNot { it.id == taskId } }
  }

  fun dismissCompletedTasks() {
    _tasks.update { list -> list.filterNot { it.isCompleted || it.error != null } }
  }

  private fun launchBackgroundTask(title: String, block: suspend (onProgress: (Int) -> Unit) -> Unit) {
    val id = System.currentTimeMillis()
    _tasks.update { it + BackgroundTaskState(id = id, title = title, progress = 0) }
    val job =
      viewModelScope.launch {
        try {
          block { prog ->
            _tasks.update { list ->
              list.map { if (it.id == id) it.copy(progress = prog.coerceIn(0, 100)) else it }
            }
          }
          _tasks.update { list ->
            list.map { if (it.id == id) it.copy(progress = 100, isCompleted = true) else it }
          }
        } catch (t: Throwable) {
          _tasks.update { list ->
            list.map { if (it.id == id) it.copy(error = t.message ?: "Error") else it }
          }
          _statusBanner.value = t.message
        } finally {
          taskJobs.remove(id)
        }
      }
    taskJobs[id] = job
  }

  val internalRootPath: String
    get() = container.fileRepository.internalStorageRoot()

  val downloadsPath: String
    get() = container.fileRepository.downloadsDir()

  val appWorkspacePath: String
    get() = container.fileRepository.appWorkspaceDir().absolutePath

  fun getPersistedSafUris(): List<Uri> = container.safHelper.getPersistedTreeUris()

  fun onSafTreeGranted(uri: Uri) {
    container.safHelper.takePersistablePermission(uri)
    navigatePane(_activePane.value, uri.toString())
  }

  fun androidDataSafInitialUri(): Uri = container.safHelper.androidDataInitialUri()
}
