package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.db.PlaylistEntity
import com.example.data.db.PlaylistTrackEntity
import com.example.domain.media.MediaThumbnailLoader
import com.example.domain.media.SyncedLyricLine
import com.example.i18n.LocalAppStrings
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.CoverVisualEnhanceSheet
import com.example.ui.components.NewPlaylistDialog
import com.example.ui.components.OnlineLyricsSearchDialog
import com.example.ui.components.SleepTimerSheet
import com.example.ui.components.SoundBoosterAndEqSheet
import com.example.ui.theme.LocalVortexExtraColors
import com.example.ui.theme.MonoFontFamily
import com.example.ui.viewmodel.MusicFolderGroup
import com.example.ui.viewmodel.MusicHubUiState
import com.example.ui.viewmodel.MusicRepeatMode
import com.example.ui.viewmodel.MusicSortMode
import com.example.ui.viewmodel.MusicTrackItem
import com.example.ui.viewmodel.MusicViewModel
import java.util.Locale

@Composable
fun MusicHubScreen(
  initialAudioPath: String,
  viewModel: MusicViewModel,
  thumbnailLoader: MediaThumbnailLoader,
  onBack: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val focusManager = LocalFocusManager.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val playlists by viewModel.playlists.collectAsStateWithLifecycle()
  val snackbarHostState = remember { SnackbarHostState() }

  var selectedTab by remember { mutableIntStateOf(0) }
  var showBoosterSheet by remember { mutableStateOf(false) }
  var showCoverEnhanceSheet by remember { mutableStateOf(false) }
  var showSleepTimerSheet by remember { mutableStateOf(false) }
  var showOnlineLyricsDialog by remember { mutableStateOf(false) }
  var showNewPlaylistDialog by remember { mutableStateOf(false) }
  var showSaveQueueDialog by remember { mutableStateOf(false) }
  var trackToAddToPlaylist by remember { mutableStateOf<MusicTrackItem?>(null) }

  DisposableEffect(Unit) {
    onDispose {
      focusManager.clearFocus(force = true)
      keyboardController?.hide()
    }
  }

  BackHandler {
    focusManager.clearFocus(force = true)
    keyboardController?.hide()
    onBack()
  }

  LaunchedEffect(initialAudioPath) {
    if (initialAudioPath.isNotBlank()) {
      viewModel.openFromFile(initialAudioPath)
    }
  }

  LaunchedEffect(state.statusMessage) {
    state.statusMessage?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.clearMessage()
    }
  }

  Scaffold(
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      Column(
        modifier =
          Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .statusBarsPadding(),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            IconButton(
              onClick = {
                focusManager.clearFocus(force = true)
                keyboardController?.hide()
                onBack()
              },
              modifier = Modifier.testTag("music_back_btn"),
            ) {
              Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.close)
            }
            Text(
              text = strings.musicHubTitle,
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            if (state.sleepRemainingMs > 0L) {
              val sec = (state.sleepRemainingMs / 1000L).toInt()
              Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(50),
                modifier = Modifier.clickable { showSleepTimerSheet = true },
              ) {
                Text(
                  text = String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60),
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.primary,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                )
              }
            }
            IconButton(
              onClick = { showBoosterSheet = true },
              modifier = Modifier.testTag("music_top_booster_btn"),
            ) {
              Icon(
                Icons.Default.GraphicEq,
                contentDescription = strings.soundBoosterTitle,
                tint =
                  if (state.loudnessGainMb > 0 || state.bassStrength > 0) MaterialTheme.colorScheme.primary
                  else MaterialTheme.colorScheme.onSurface,
              )
            }
            IconButton(
              onClick = { showSleepTimerSheet = true },
              modifier = Modifier.testTag("music_top_sleep_btn"),
            ) {
              Icon(
                Icons.Default.Timer,
                contentDescription = strings.sleepTimerTitle,
                tint =
                  if (state.sleepRemainingMs > 0L || state.stopAfterCurrentTrack) MaterialTheme.colorScheme.primary
                  else MaterialTheme.colorScheme.onSurface,
              )
            }
          }
        }

        TabRow(selectedTabIndex = selectedTab) {
          listOf(
            strings.tabNowPlaying,
            strings.tabLyrics,
            strings.tabFolders,
            strings.tabPlaylists,
          ).forEachIndexed { idx, label ->
            Tab(
              selected = selectedTab == idx,
              onClick = { selectedTab = idx },
              text = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium) },
              modifier = Modifier.testTag("music_tab_$idx"),
            )
          }
        }
      }
    },
  ) { innerPadding ->
    Box(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .navigationBarsPadding(),
    ) {
      when (selectedTab) {
        0 ->
          NowPlayingTab(
            state = state,
            thumbnailLoader = thumbnailLoader,
            onTogglePlayPause = viewModel::togglePlayPause,
            onNext = viewModel::next,
            onPrevious = viewModel::previous,
            onSeek = viewModel::seekTo,
            onToggleShuffle = viewModel::toggleShuffle,
            onCycleRepeat = viewModel::cycleRepeatMode,
            onOpenBooster = { showBoosterSheet = true },
            onOpenCoverEnhance = { showCoverEnhanceSheet = true },
            onToggleVinylDisc = viewModel::toggleVinylDiscMode,
            onOpenSleepTimer = { showSleepTimerSheet = true },
            onOpenLyricsTab = { selectedTab = 1 },
            onOpenAddToPlaylist = { track -> trackToAddToPlaylist = track },
            onPlayQueueIndex = { idx -> viewModel.playQueueAt(state.queue, idx) },
            onMoveQueueItem = viewModel::moveTrackInQueue,
            onSetSortMode = viewModel::setSortMode,
          )

        1 ->
          AnimatedLyricsTab(
            state = state,
            onSeekTo = viewModel::seekTo,
            onSetOffset = viewModel::setLyricsSyncOffset,
            onOpenOnlineSearch = { showOnlineLyricsDialog = true },
            onSaveLocally = viewModel::saveCurrentLyricsLocally,
          )

        2 ->
          FoldersTab(
            state = state,
            thumbnailLoader = thumbnailLoader,
            onRefresh = { viewModel.scanLibrary(state.selectedFolderPath) },
            onSelectFolder = viewModel::selectFolder,
            onPlayFolder = viewModel::playFolder,
            onSetSortMode = viewModel::setSortMode,
            onAddToPlaylist = { track -> trackToAddToPlaylist = track },
          )

        else ->
          CustomPlaylistsTab(
            playlists = playlists,
            selectedPlaylistId = state.selectedPlaylistId,
            tracks = state.selectedPlaylistTracks,
            thumbnailLoader = thumbnailLoader,
            onSelectPlaylist = viewModel::selectPlaylist,
            onCreatePlaylist = { showNewPlaylistDialog = true },
            onSaveQueueAsPlaylist = { showSaveQueueDialog = true },
            onMoveTrack = { from, to ->
              state.selectedPlaylistId?.let { pid -> viewModel.moveTrackInPlaylist(pid, from, to) }
            },
            onRemoveTrack = viewModel::removeTrackFromPlaylist,
            onDeletePlaylist = viewModel::deletePlaylist,
            onPlayPlaylistFrom = viewModel::playCustomPlaylist,
          )
      }
    }
  }

  if (showBoosterSheet) {
    SoundBoosterAndEqSheet(
      loudnessGainMb = state.loudnessGainMb,
      bassStrength = state.bassStrength,
      eqBands = state.eqBands,
      eq10Bands = state.eq10Bands,
      use10BandEq = state.use10BandEq,
      activePreset = state.activeEqPreset,
      reverbMode = state.reverbMode,
      onLoudnessChange = viewModel::setLoudnessGainMb,
      onBassChange = viewModel::setBassBoostStrength,
      onSelectPreset = viewModel::applyEqPreset,
      onReverbChange = viewModel::setReverbMode,
      onToggle10Band = viewModel::toggle10BandEq,
      onBandLevelChange = viewModel::setEqBandLevel,
      onBand10LevelChange = viewModel::setEq10BandLevel,
      onDismiss = { showBoosterSheet = false },
    )
  }

  if (showCoverEnhanceSheet) {
    CoverVisualEnhanceSheet(
      brightness = state.coverBrightness,
      contrast = state.coverContrast,
      saturation = state.coverSaturation,
      glowEnabled = state.coverGlowEnabled,
      onChange = viewModel::setCoverVisuals,
      onDismiss = { showCoverEnhanceSheet = false },
    )
  }

  if (showSleepTimerSheet) {
    SleepTimerSheet(
      remainingMs = state.sleepRemainingMs,
      stopAfterCurrentTrack = state.stopAfterCurrentTrack,
      onStartMinutes = viewModel::startSleepTimer,
      onToggleStopAfterTrack = viewModel::toggleStopAfterCurrentTrack,
      onCancelTimer = viewModel::cancelSleepTimer,
      onDismiss = { showSleepTimerSheet = false },
    )
  }

  if (showOnlineLyricsDialog) {
    OnlineLyricsSearchDialog(
      initialTrack = state.currentTrack?.title.orEmpty(),
      initialArtist = state.currentTrack?.artist.orEmpty(),
      isSearching = state.isSearchingLyrics,
      hits = state.onlineLyricsHits,
      onSearch = viewModel::searchLyricsManually,
      onSelectHit = viewModel::applyOnlineLyricsHit,
      onDismiss = { showOnlineLyricsDialog = false },
    )
  }

  if (showNewPlaylistDialog) {
    NewPlaylistDialog(
      title = strings.createPlaylist,
      onConfirm = viewModel::createPlaylist,
      onDismiss = { showNewPlaylistDialog = false },
    )
  }

  if (showSaveQueueDialog) {
    NewPlaylistDialog(
      title = strings.tabPlaylists,
      onConfirm = viewModel::saveCurrentQueueAsPlaylist,
      onDismiss = { showSaveQueueDialog = false },
    )
  }

  trackToAddToPlaylist?.let { track ->
    AddToPlaylistDialog(
      playlists = playlists,
      onPickPlaylist = { pl -> viewModel.addTrackToPlaylist(pl.id, track) },
      onCreateAndAdd = { name -> viewModel.createPlaylistAndAddTrack(name, track) },
      onDismiss = { trackToAddToPlaylist = null },
    )
  }
}

@Composable
private fun NowPlayingTab(
  state: MusicHubUiState,
  thumbnailLoader: MediaThumbnailLoader,
  onTogglePlayPause: () -> Unit,
  onNext: () -> Unit,
  onPrevious: () -> Unit,
  onSeek: (Long) -> Unit,
  onToggleShuffle: () -> Unit,
  onCycleRepeat: () -> Unit,
  onOpenBooster: () -> Unit,
  onOpenCoverEnhance: () -> Unit,
  onToggleVinylDisc: () -> Unit,
  onOpenSleepTimer: () -> Unit,
  onOpenLyricsTab: () -> Unit,
  onOpenAddToPlaylist: (MusicTrackItem) -> Unit,
  onPlayQueueIndex: (Int) -> Unit,
  onMoveQueueItem: (Int, Int) -> Unit,
  onSetSortMode: (MusicSortMode) -> Unit,
) {
  val strings = LocalAppStrings.current
  val track = state.currentTrack
  val coverColorFilter = remember(state.coverBrightness, state.coverContrast, state.coverSaturation) {
    buildImageEnhanceColorFilter(state.coverBrightness, state.coverContrast, state.coverSaturation)
  }
  val spinTransition = rememberInfiniteTransition(label = "vinyl_spin")
  val vinylRotation by spinTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 8000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "vinyl_angle",
  )

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth(),
      ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(
            Brush.verticalGradient(
              listOf(
                MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                Color.Transparent,
              )
            )
          )
          .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        // Cover Art / Rotating Vinyl Disc + Ambient Glow
        Box(
          modifier = Modifier.size(216.dp),
          contentAlignment = Alignment.Center,
        ) {
          if (state.coverGlowEnabled) {
            Box(
              modifier =
                Modifier
                  .size(216.dp)
                  .clip(if (state.vinylDiscMode) CircleShape else RoundedCornerShape(28.dp))
                  .background(
                    Brush.radialGradient(
                      colors =
                        listOf(
                          MaterialTheme.colorScheme.primary.copy(alpha = 0.38f),
                          MaterialTheme.colorScheme.secondary.copy(alpha = 0.16f),
                          Color.Transparent,
                        ),
                    ),
                  ),
            )
          }

          Surface(
            modifier = Modifier
              .size(190.dp)
              .graphicsLayer {
                rotationZ = if (state.vinylDiscMode && state.isPlaying) vinylRotation else 0f
              }
              .clickable(onClick = onOpenCoverEnhance),
            shape = if (state.vinylDiscMode) CircleShape else RoundedCornerShape(22.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 6.dp,
          ) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
              val coverBmp = state.currentCoverArt
              if (coverBmp != null) {
                Image(
                  bitmap = coverBmp.asImageBitmap(),
                  contentDescription = track?.title ?: "Album Art",
                  contentScale = ContentScale.Crop,
                  colorFilter = coverColorFilter,
                  modifier = Modifier.fillMaxSize(),
                )
              } else {
                Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.Center,
                ) {
                  Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(64.dp),
                  )
                  Spacer(Modifier.height(6.dp))
                  Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(6.dp),
                  ) {
                    Text(
                      text = track?.extension?.uppercase(Locale.US)?.ifBlank { "AUDIO" } ?: "AUDIO",
                      style = MaterialTheme.typography.labelLarge,
                      color = MaterialTheme.colorScheme.primary,
                      fontWeight = FontWeight.Bold,
                      fontFamily = MonoFontFamily,
                      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    )
                  }
                }
              }

              if (state.vinylDiscMode) {
                Surface(
                  modifier = Modifier.size(34.dp),
                  shape = CircleShape,
                  color = MaterialTheme.colorScheme.surface,
                  tonalElevation = 8.dp,
                ) {}
              } else if (track != null && track.extension.isNotBlank()) {
                Surface(
                  color = Color.Black.copy(alpha = 0.6f),
                  shape = RoundedCornerShape(topStart = 8.dp),
                  modifier = Modifier.align(Alignment.BottomEnd),
                ) {
                  Text(
                    text = track.extension.uppercase(Locale.US),
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    fontFamily = MonoFontFamily,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                  )
                }
              }
            }
          }
        }

        // Title & Artist
        Text(
          text = track?.title ?: strings.emptyFolderTitle,
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          textAlign = TextAlign.Center,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = track?.let { "${it.artist} • ${it.album}" } ?: strings.tabFolders,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          textAlign = TextAlign.Center,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )

        // Live Karaoke Mini Preview Strip (tap to jump to full animated lyrics)
        val currentLine = state.lyrics.getOrNull(state.activeLyricIndex)
        Surface(
          color = MaterialTheme.colorScheme.surfaceContainer,
          shape = MaterialTheme.shapes.medium,
          modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenLyricsTab).testTag("music_mini_lyrics"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
            Text(
              text =
                when {
                  state.isSearchingLyrics -> strings.lyricsSearching
                  currentLine != null -> currentLine.text
                  state.lyrics.isNotEmpty() -> state.lyrics.first().text
                  else -> strings.tabLyrics
                },
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.Medium,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.weight(1f),
            )
          }
        }

        // Seekbar
        val dur = state.durationMs.coerceAtLeast(1L)
        Column(modifier = Modifier.fillMaxWidth()) {
          Slider(
            value = state.positionMs.coerceIn(0L, dur).toFloat(),
            onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..dur.toFloat(),
            modifier = Modifier.fillMaxWidth().testTag("music_seek_slider"),
          )
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatDurationMs(state.positionMs), style = MaterialTheme.typography.labelSmall, fontFamily = MonoFontFamily)
            Text(formatDurationMs(state.durationMs), style = MaterialTheme.typography.labelSmall, fontFamily = MonoFontFamily)
          }
        }

        // Transport Controls
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(onClick = onToggleShuffle, modifier = Modifier.size(48.dp)) {
            Icon(
              Icons.Default.Shuffle,
              contentDescription = strings.sortShuffle,
              tint = if (state.shuffleEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          IconButton(onClick = onPrevious, modifier = Modifier.size(52.dp).testTag("music_prev_btn")) {
            Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(32.dp))
          }
          FilledIconButton(
            onClick = onTogglePlayPause,
            modifier = Modifier.size(64.dp).testTag("music_play_pause_btn"),
          ) {
            Icon(
              imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
              contentDescription = if (state.isPlaying) "Pause" else "Play",
              modifier = Modifier.size(34.dp),
            )
          }
          IconButton(onClick = onNext, modifier = Modifier.size(52.dp).testTag("music_next_btn")) {
            Icon(Icons.Default.SkipNext, contentDescription = "Next", modifier = Modifier.size(32.dp))
          }
          IconButton(onClick = onCycleRepeat, modifier = Modifier.size(48.dp)) {
            Icon(
              imageVector = if (state.repeatMode == MusicRepeatMode.ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
              contentDescription = "Repeat",
              tint = if (state.repeatMode == MusicRepeatMode.OFF) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary,
            )
          }
        }

        // Quick Tools Row
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedButton(onClick = onOpenBooster) {
            Icon(Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            val boostTag = if (state.loudnessGainMb > 0) " (+${state.loudnessGainMb / 100}dB)" else ""
            Text("${strings.soundBoosterTitle}$boostTag")
          }
          FilterChip(
            selected = state.vinylDiscMode,
            onClick = onToggleVinylDisc,
            label = { Text(strings.vinylDiscMode) },
            leadingIcon = { Icon(Icons.Default.Album, contentDescription = null, modifier = Modifier.size(16.dp)) },
          )
          OutlinedButton(onClick = onOpenCoverEnhance) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(strings.enhancePicture)
          }
          OutlinedButton(onClick = onOpenSleepTimer) {
            Icon(Icons.Default.Timer, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(strings.sleepTimerTitle)
          }
          if (track != null) {
            OutlinedButton(onClick = { onOpenAddToPlaylist(track) }) {
              Icon(Icons.AutoMirrored.Filled.PlaylistAdd, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(Modifier.width(4.dp))
              Text(strings.addToPlaylist)
            }
          }
        }
      }
      }
    }

    // Queue + Quick Sort Strip
    if (state.queue.isNotEmpty()) {
      item {
        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.AutoMirrored.Filled.QueueMusic, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text("${strings.sortModeLabel} (${state.queue.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          }
        }
        Spacer(Modifier.height(6.dp))
        SortModeChipRow(selected = state.sortMode, onSelect = onSetSortMode)
      }

      itemsIndexed(state.queue, key = { idx, t -> "${t.path}_$idx" }) { idx, item ->
        val isCurrent = idx == state.currentIndex
        TrackQueueRow(
          track = item,
          isCurrent = isCurrent,
          canMoveUp = idx > 0,
          canMoveDown = idx < state.queue.lastIndex,
          thumbnailLoader = thumbnailLoader,
          onClick = { onPlayQueueIndex(idx) },
          onMoveUp = { onMoveQueueItem(idx, idx - 1) },
          onMoveDown = { onMoveQueueItem(idx, idx + 1) },
          onAddToPlaylist = { onOpenAddToPlaylist(item) },
        )
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AnimatedLyricsTab(
  state: MusicHubUiState,
  onSeekTo: (Long) -> Unit,
  onSetOffset: (Long) -> Unit,
  onOpenOnlineSearch: () -> Unit,
  onSaveLocally: () -> Unit,
) {
  val strings = LocalAppStrings.current
  val listState = rememberLazyListState()

  LaunchedEffect(state.activeLyricIndex) {
    if (state.activeLyricIndex >= 0 && state.activeLyricIndex < state.lyrics.size) {
      runCatching {
        listState.animateScrollToItem((state.activeLyricIndex - 1).coerceAtLeast(0))
      }
    }
  }

  Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    // Lyrics Controls Bar
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Button(onClick = onOpenOnlineSearch, modifier = Modifier.testTag("music_search_lyrics_btn")) {
        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(strings.searchLyricsOnline)
      }
      if (state.rawLrcContent.isNotBlank()) {
        OutlinedButton(onClick = onSaveLocally) {
          Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(4.dp))
          Text(strings.saveLyricsLocally)
        }
      }
      OutlinedButton(onClick = { onSetOffset(state.lyricsOffsetMs - 500L) }) { Text("-0.5s") }
      Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = MaterialTheme.shapes.small) {
        Text(
          text = "${String.format(Locale.US, "%.1f", state.lyricsOffsetMs / 1000f)}s",
          style = MaterialTheme.typography.labelMedium,
          fontFamily = MonoFontFamily,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
        )
      }
      OutlinedButton(onClick = { onSetOffset(state.lyricsOffsetMs + 500L) }) { Text("+0.5s") }
    }

    when {
      state.isSearchingLyrics -> {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            CircularProgressIndicator()
            Text(strings.lyricsSearching, style = MaterialTheme.typography.bodyMedium)
          }
        }
      }

      state.lyrics.isEmpty() -> {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(54.dp), tint = MaterialTheme.colorScheme.primary)
            Text(strings.lyricsNotFound, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
            Button(onClick = onOpenOnlineSearch) {
              Text(strings.searchLyricsOnline)
            }
          }
        }
      }

      else -> {
        LazyColumn(
          state = listState,
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(vertical = 24.dp, horizontal = 8.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
          itemsIndexed(state.lyrics, key = { idx, line -> "${idx}_${line.startMs}" }) { idx, line ->
            val isActive = idx == state.activeLyricIndex
            KaraokeLyricLineRow(
              line = line,
              isActiveLine = isActive,
              activeWordIndex = if (isActive) state.activeWordIndex else -1,
              onClick = { if (line.isSynced) onSeekTo(line.startMs) },
            )
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun KaraokeLyricLineRow(
  line: SyncedLyricLine,
  isActiveLine: Boolean,
  activeWordIndex: Int,
  onClick: () -> Unit,
) {
  val scale by animateFloatAsState(targetValue = if (isActiveLine) 1.06f else 1f, label = "lyric_scale")

  Surface(
    color = if (isActiveLine) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f) else Color.Transparent,
    shape = MaterialTheme.shapes.medium,
    modifier =
      Modifier
        .fillMaxWidth()
        .graphicsLayer {
          scaleX = scale
          scaleY = scale
        }
        .clickable(onClick = onClick),
  ) {
    Box(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
      contentAlignment = Alignment.Center,
    ) {
      if (isActiveLine && line.isSynced && line.words.isNotEmpty()) {
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          line.words.forEachIndexed { wIdx, word ->
            val isCurrentWord = wIdx == activeWordIndex
            val isSung = wIdx <= activeWordIndex
            val wordColor =
              when {
                isCurrentWord -> MaterialTheme.colorScheme.primary
                isSung -> MaterialTheme.colorScheme.onSurface
                else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
              }
            Surface(
              color = if (isCurrentWord) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f) else Color.Transparent,
              shape = RoundedCornerShape(6.dp),
            ) {
              Text(
                text = word.text,
                fontSize = if (isCurrentWord) 21.sp else 19.sp,
                fontWeight = if (isCurrentWord) FontWeight.ExtraBold else FontWeight.Bold,
                color = wordColor,
                modifier = Modifier.padding(horizontal = if (isCurrentWord) 4.dp else 1.dp),
              )
            }
          }
        }
      } else {
        Text(
          text = line.text,
          fontSize = if (isActiveLine) 20.sp else 16.sp,
          fontWeight = if (isActiveLine) FontWeight.Bold else FontWeight.Normal,
          color =
            if (isActiveLine) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f),
          textAlign = TextAlign.Center,
        )
      }
    }
  }
}

@Composable
private fun FoldersTab(
  state: MusicHubUiState,
  thumbnailLoader: MediaThumbnailLoader,
  onRefresh: () -> Unit,
  onSelectFolder: (String) -> Unit,
  onPlayFolder: (MusicFolderGroup, Int) -> Unit,
  onSetSortMode: (MusicSortMode) -> Unit,
  onAddToPlaylist: (MusicTrackItem) -> Unit,
) {
  val strings = LocalAppStrings.current
  val selectedFolder = state.folders.firstOrNull { it.folderPath == state.selectedFolderPath } ?: state.folders.firstOrNull()

  Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text("${strings.tabFolders} (${state.folders.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      IconButton(onClick = onRefresh) {
        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
      }
    }

    SortModeChipRow(selected = state.sortMode, onSelect = onSetSortMode)

    if (state.isScanning && state.folders.isEmpty()) {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
      }
    } else if (state.folders.isEmpty()) {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(strings.emptyFolderTitle, style = MaterialTheme.typography.bodyMedium)
      }
    } else {
      // Folder Cards Horizontal Strip
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        state.folders.forEach { folder ->
          val active = folder.folderPath == selectedFolder?.folderPath
          Surface(
            color = if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.clickable { onSelectFolder(folder.folderPath) },
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                Icons.Default.Folder,
                contentDescription = null,
                tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
              )
              Column {
                Text(folder.folderName, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(strings.itemsCount(folder.tracks.size), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }
      }

      selectedFolder?.let { folder ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(folder.folderName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
          Button(onClick = { onPlayFolder(folder, 0) }) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(strings.playFolder)
          }
        }

        LazyColumn(
          modifier = Modifier.weight(1f).fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          itemsIndexed(folder.tracks, key = { _, t -> t.path }) { idx, track ->
            FolderTrackRow(
              track = track,
              isPlayingTrack = track.path == state.currentTrack?.path,
              thumbnailLoader = thumbnailLoader,
              onClick = { onPlayFolder(folder, idx) },
              onAddToPlaylist = { onAddToPlaylist(track) },
            )
          }
        }
      }
    }
  }
}

@Composable
private fun CustomPlaylistsTab(
  playlists: List<PlaylistEntity>,
  selectedPlaylistId: Long?,
  tracks: List<PlaylistTrackEntity>,
  thumbnailLoader: MediaThumbnailLoader,
  onSelectPlaylist: (Long) -> Unit,
  onCreatePlaylist: () -> Unit,
  onSaveQueueAsPlaylist: () -> Unit,
  onMoveTrack: (Int, Int) -> Unit,
  onRemoveTrack: (Long) -> Unit,
  onDeletePlaylist: (Long) -> Unit,
  onPlayPlaylistFrom: (Int) -> Unit,
) {
  val strings = LocalAppStrings.current
  val extra = LocalVortexExtraColors.current

  Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Button(onClick = onCreatePlaylist, modifier = Modifier.weight(1f).testTag("music_create_playlist_btn")) {
        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(strings.createPlaylist, maxLines = 1, overflow = TextOverflow.Ellipsis)
      }
      OutlinedButton(onClick = onSaveQueueAsPlaylist, modifier = Modifier.weight(1f)) {
        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(strings.tabNowPlaying, maxLines = 1, overflow = TextOverflow.Ellipsis)
      }
    }

    if (playlists.isEmpty()) {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(strings.customOrderHint, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
      }
    } else {
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        playlists.forEach { pl ->
          FilterChip(
            selected = pl.id == selectedPlaylistId,
            onClick = { onSelectPlaylist(pl.id) },
            label = { Text(pl.name) },
          )
        }
      }

      if (selectedPlaylistId != null) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(strings.customOrderHint, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (tracks.isNotEmpty()) {
              Button(onClick = { onPlayPlaylistFrom(0) }) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(strings.playFolder)
              }
            }
            IconButton(onClick = { onDeletePlaylist(selectedPlaylistId) }) {
              Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = extra.lossyWarning)
            }
          }
        }

        LazyColumn(
          modifier = Modifier.weight(1f).fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          itemsIndexed(tracks, key = { _, t -> t.id }) { idx, tr ->
            PlaylistTrackOrderRow(
              track = tr,
              index = idx,
              canMoveUp = idx > 0,
              canMoveDown = idx < tracks.lastIndex,
              thumbnailLoader = thumbnailLoader,
              onClick = { onPlayPlaylistFrom(idx) },
              onMoveUp = { onMoveTrack(idx, idx - 1) },
              onMoveDown = { onMoveTrack(idx, idx + 1) },
              onRemove = { onRemoveTrack(tr.id) },
            )
          }
        }
      }
    }
  }
}

@Composable
private fun SortModeChipRow(selected: MusicSortMode, onSelect: (MusicSortMode) -> Unit) {
  val strings = LocalAppStrings.current
  val modes =
    listOf(
      MusicSortMode.SHUFFLE to strings.sortShuffle,
      MusicSortMode.ALPHA_ASC to strings.sortAlphaAsc,
      MusicSortMode.ALPHA_DESC to strings.sortAlphaDesc,
      MusicSortMode.NUMERIC to strings.sortNumeric,
      MusicSortMode.DATE_NEWEST to strings.sortDateNewest,
      MusicSortMode.CUSTOM to strings.sortCustomOrder,
    )
  Row(
    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(6.dp),
  ) {
    modes.forEach { (mode, label) ->
      FilterChip(
        selected = selected == mode,
        onClick = { onSelect(mode) },
        label = { Text(label) },
      )
    }
  }
}

@Composable
private fun TrackQueueRow(
  track: MusicTrackItem,
  isCurrent: Boolean,
  canMoveUp: Boolean,
  canMoveDown: Boolean,
  thumbnailLoader: MediaThumbnailLoader,
  onClick: () -> Unit,
  onMoveUp: () -> Unit,
  onMoveDown: () -> Unit,
  onAddToPlaylist: () -> Unit,
) {
  Surface(
    color = if (isCurrent) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else MaterialTheme.colorScheme.surfaceContainerLow,
    shape = MaterialTheme.shapes.small,
    modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      TrackArtThumbnail(track.path, track.dateModified, track.extension, thumbnailLoader)
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = track.title,
          style = MaterialTheme.typography.titleSmall,
          color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = "${track.artist} • ${formatDurationMs(track.durationMs)}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      IconButton(onClick = onMoveUp, enabled = canMoveUp, modifier = Modifier.size(34.dp)) {
        Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Move Up", modifier = Modifier.size(18.dp))
      }
      IconButton(onClick = onMoveDown, enabled = canMoveDown, modifier = Modifier.size(34.dp)) {
        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Move Down", modifier = Modifier.size(18.dp))
      }
      IconButton(onClick = onAddToPlaylist, modifier = Modifier.size(34.dp)) {
        Icon(Icons.AutoMirrored.Filled.PlaylistAdd, contentDescription = null, modifier = Modifier.size(18.dp))
      }
    }
  }
}

@Composable
private fun FolderTrackRow(
  track: MusicTrackItem,
  isPlayingTrack: Boolean,
  thumbnailLoader: MediaThumbnailLoader,
  onClick: () -> Unit,
  onAddToPlaylist: () -> Unit,
) {
  Surface(
    color = if (isPlayingTrack) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else MaterialTheme.colorScheme.surfaceContainer,
    shape = MaterialTheme.shapes.small,
    modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      TrackArtThumbnail(track.path, track.dateModified, track.extension, thumbnailLoader)
      Column(modifier = Modifier.weight(1f)) {
        Text(track.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
          "${track.artist} • ${formatDurationMs(track.durationMs)}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
        )
      }
      IconButton(onClick = onAddToPlaylist) {
        Icon(Icons.AutoMirrored.Filled.PlaylistAdd, contentDescription = null)
      }
    }
  }
}

@Composable
private fun PlaylistTrackOrderRow(
  track: PlaylistTrackEntity,
  index: Int,
  canMoveUp: Boolean,
  canMoveDown: Boolean,
  thumbnailLoader: MediaThumbnailLoader,
  onClick: () -> Unit,
  onMoveUp: () -> Unit,
  onMoveDown: () -> Unit,
  onRemove: () -> Unit,
) {
  val ext = track.trackPath.substringAfterLast('.', "mp3")
  Surface(
    color = MaterialTheme.colorScheme.surfaceContainer,
    shape = MaterialTheme.shapes.small,
    modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Text(
        text = "${index + 1}",
        style = MaterialTheme.typography.labelMedium,
        fontFamily = MonoFontFamily,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.width(22.dp),
        textAlign = TextAlign.Center,
      )
      TrackArtThumbnail(track.trackPath, 0L, ext, thumbnailLoader)
      Column(modifier = Modifier.weight(1f)) {
        Text(track.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(track.artist, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
      }
      IconButton(onClick = onMoveUp, enabled = canMoveUp, modifier = Modifier.size(36.dp)) {
        Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Move Up")
      }
      IconButton(onClick = onMoveDown, enabled = canMoveDown, modifier = Modifier.size(36.dp)) {
        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Move Down")
      }
      IconButton(onClick = onRemove, modifier = Modifier.size(36.dp)) {
        Icon(Icons.Default.Delete, contentDescription = "Remove", modifier = Modifier.size(18.dp))
      }
    }
  }
}

@Composable
private fun TrackArtThumbnail(
  path: String,
  lastModified: Long,
  ext: String,
  thumbnailLoader: MediaThumbnailLoader,
) {
  var art by remember(path) { mutableStateOf<Bitmap?>(null) }
  LaunchedEffect(path) {
    art = thumbnailLoader.loadAudioAlbumArt(path, lastModified, targetPx = 128)
  }

  Box(
    modifier =
      Modifier
        .size(44.dp)
        .clip(RoundedCornerShape(8.dp))
        .background(Color(0xFF8B5CF6).copy(alpha = 0.2f)),
    contentAlignment = Alignment.Center,
  ) {
    if (art != null) {
      Image(
        bitmap = art!!.asImageBitmap(),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(),
      )
    } else {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color(0xFFA78BFA), modifier = Modifier.size(18.dp))
        Text(
          text = ext.uppercase(Locale.US).take(4),
          style = MaterialTheme.typography.labelSmall,
          fontSize = 8.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = MonoFontFamily,
          color = Color(0xFFA78BFA),
        )
      }
    }
  }
}

private fun buildImageEnhanceColorFilter(
  brightness: Float,
  contrast: Float,
  saturation: Float,
): ColorFilter {
  val satMatrix = ColorMatrix().apply { setToSaturation(saturation.coerceIn(0f, 2f)) }
  val c = contrast.coerceIn(0.4f, 2f)
  val b = brightness.coerceIn(-100f, 100f)
  val t = (1f - c) * 128f + b
  val bcMatrix =
    ColorMatrix(
      floatArrayOf(
        c, 0f, 0f, 0f, t,
        0f, c, 0f, 0f, t,
        0f, 0f, c, 0f, t,
        0f, 0f, 0f, 1f, 0f,
      )
    )
  bcMatrix.timesAssign(satMatrix)
  return ColorFilter.colorMatrix(bcMatrix)
}

private fun formatDurationMs(ms: Long): String {
  val totalSec = (ms / 1000L).coerceAtLeast(0L)
  val m = totalSec / 60L
  val s = totalSec % 60L
  return String.format(Locale.US, "%02d:%02d", m, s)
}
