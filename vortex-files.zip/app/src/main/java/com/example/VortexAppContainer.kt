package com.example

import android.content.Context
import com.example.data.db.VortexDatabase
import com.example.data.prefs.UserPreferencesRepository
import com.example.domain.apk.ApkInspectorEngine
import com.example.domain.apk.ApkSignerAndBuilder
import com.example.domain.archive.ArchiveEngine
import com.example.domain.archive.MediaCompressionEngine
import com.example.domain.archive.UniversalSizeReducer
import com.example.domain.cloud.CloudStorageClient
import com.example.domain.converter.FormatConverterEngine
import com.example.domain.download.AutoWebStreamSniffer
import com.example.domain.download.UniversalDownloadEngine
import com.example.domain.editor.CodeRunnerEngine
import com.example.domain.editor.IdePackageManager
import com.example.domain.editor.MultiPlatformAppBuilder
import com.example.domain.fs.EditBackupManager
import com.example.domain.fs.MagicBytesDetector
import com.example.domain.fs.RecycleBinManager
import com.example.domain.fs.SafFileHelper
import com.example.domain.fs.UnifiedFileRepository
import com.example.domain.media.AiPhotoStudioEngine
import com.example.domain.media.DlnaCastManager
import com.example.domain.media.MediaLibraryScanner
import com.example.domain.media.MediaThumbnailLoader
import com.example.domain.media.Mesh3DEngine
import com.example.domain.media.OnlineLyricsService
import com.example.domain.media.OnlineSubtitleService
import com.example.domain.media.VideoEditorEngine
import com.example.domain.office.OfficeDocumentEngine
import com.example.domain.security.AntivirusEngine
import com.example.domain.security.VaultCryptoEngine
import com.example.shizuku.RootShellManager
import com.example.shizuku.ShizukuManager

class VortexAppContainer(context: Context) {
  private val appContext = context.applicationContext

  val preferencesRepo = UserPreferencesRepository(appContext)
  val database = VortexDatabase.getInstance(appContext)
  val shizukuManager = ShizukuManager(appContext)
  val rootShellManager = RootShellManager()
  val safHelper = SafFileHelper(appContext)
  val archiveEngine = ArchiveEngine()
  val mediaCompressionEngine = MediaCompressionEngine()
  val universalSizeReducer =
    UniversalSizeReducer(
      context = appContext,
      mediaCompressionEngine = mediaCompressionEngine,
      archiveEngine = archiveEngine,
    )
  val codeRunnerEngine =
    CodeRunnerEngine(
      context = appContext,
      shizukuManager = shizukuManager,
      rootShellManager = rootShellManager,
    )
  val idePackageManager = IdePackageManager()
  val apkSignerAndBuilder = ApkSignerAndBuilder()
  val multiPlatformAppBuilder = MultiPlatformAppBuilder(appContext, apkSignerAndBuilder)
  val editBackupManager = EditBackupManager
  val antivirusEngine = AntivirusEngine(appContext)
  val mesh3DEngine = Mesh3DEngine
  val dlnaCastManager = DlnaCastManager
  val mediaLibraryScanner = MediaLibraryScanner
  val onlineSubtitleService = OnlineSubtitleService(archiveEngine)
  val onlineLyricsService = OnlineLyricsService()
  val mediaThumbnailLoader = MediaThumbnailLoader()
  val cloudClient = CloudStorageClient(database.cloudAccountDao())
  val recycleBinManager = RecycleBinManager(appContext, database.trashDao())
  val autoWebSniffer = AutoWebStreamSniffer(appContext)
  val downloadEngine = UniversalDownloadEngine(database.downloadDao(), autoWebSniffer)
  val magicDetector = MagicBytesDetector
  val vaultEngine = VaultCryptoEngine
  val fileRepository =
    UnifiedFileRepository(
      context = appContext,
      shizukuManager = shizukuManager,
      rootShellManager = rootShellManager,
      safHelper = safHelper,
      archiveEngine = archiveEngine,
      cloudClient = cloudClient,
    )
  val formatConverterEngine =
    FormatConverterEngine(
      context = appContext,
      archiveEngine = archiveEngine,
      mediaCompressionEngine = mediaCompressionEngine,
    )
  val apkInspectorEngine = ApkInspectorEngine(appContext, archiveEngine)
  val officeEngine = OfficeDocumentEngine()
  val aiPhotoStudioEngine = AiPhotoStudioEngine()
  val videoEditorEngine = VideoEditorEngine(appContext)
}
