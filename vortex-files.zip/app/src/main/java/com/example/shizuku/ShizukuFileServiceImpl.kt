package com.example.shizuku

import android.system.Os
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import org.json.JSONArray
import org.json.JSONObject

class ShizukuFileServiceImpl : IShizukuFileService.Stub() {

  override fun destroy() {
    System.exit(0)
  }

  override fun exists(path: String): Boolean = File(path).exists()

  override fun isDirectory(path: String): Boolean = File(path).isDirectory

  override fun listFilesJson(path: String): String {
    val dir = File(path)
    val children = dir.listFiles() ?: return "[]"
    val array = JSONArray()
    for (file in children) {
      val obj = JSONObject()
      obj.put("name", file.name)
      obj.put("path", file.absolutePath)
      obj.put("isDirectory", file.isDirectory)
      obj.put("size", if (file.isDirectory) 0L else file.length())
      obj.put("lastModified", file.lastModified())
      obj.put("isHidden", file.isHidden || file.name.startsWith("."))
      obj.put("permissions", readPermissions(file))
      array.put(obj)
    }
    return array.toString()
  }

  private fun readPermissions(file: File): String {
    return try {
      val stat = Os.lstat(file.absolutePath)
      val mode = stat.st_mode
      val typeChar =
        when {
          file.isDirectory -> 'd'
          (mode and 0xF000) == 0xA000 -> 'l'
          else -> '-'
        }
      val rwx = StringBuilder().append(typeChar)
      val masks = intArrayOf(0x100, 0x080, 0x040, 0x020, 0x010, 0x008, 0x004, 0x002, 0x001)
      val chars = charArrayOf('r', 'w', 'x', 'r', 'w', 'x', 'r', 'w', 'x')
      for (i in masks.indices) {
        rwx.append(if ((mode and masks[i]) != 0) chars[i] else '-')
      }
      rwx.toString()
    } catch (_: Throwable) {
      val r = if (file.canRead()) 'r' else '-'
      val w = if (file.canWrite()) 'w' else '-'
      val x = if (file.canExecute()) 'x' else '-'
      "${if (file.isDirectory) 'd' else '-'}$r$w$x------"
    }
  }

  override fun getFileSize(path: String): Long = File(path).length()

  override fun readFileSlice(path: String, offset: Long, length: Int): ByteArray {
    val file = File(path)
    if (!file.exists() || !file.isFile) return ByteArray(0)
    RandomAccessFile(file, "r").use { raf ->
      raf.seek(offset)
      val toRead = minOf(length.toLong(), maxOf(0L, raf.length() - offset)).toInt()
      if (toRead <= 0) return ByteArray(0)
      val buf = ByteArray(toRead)
      raf.readFully(buf)
      return buf
    }
  }

  override fun writeFileBytes(path: String, data: ByteArray, append: Boolean): Boolean {
    return try {
      val target = File(path)
      target.parentFile?.mkdirs()
      FileOutputStream(target, append).use { it.write(data) }
      true
    } catch (_: Throwable) {
      false
    }
  }

  override fun mkdirs(path: String): Boolean = File(path).mkdirs()

  override fun deletePath(path: String): Boolean {
    val target = File(path)
    if (!target.exists()) return false
    return target.deleteRecursively()
  }

  override fun renamePath(oldPath: String, newPath: String): Boolean =
    File(oldPath).renameTo(File(newPath))

  override fun copyPath(srcPath: String, dstPath: String): Boolean {
    return try {
      val src = File(srcPath)
      val dst = File(dstPath)
      if (src.isDirectory) {
        src.copyRecursively(dst, overwrite = true)
      } else {
        dst.parentFile?.mkdirs()
        FileInputStream(src).use { input ->
          FileOutputStream(dst).use { output -> input.copyTo(output) }
        }
        true
      }
    } catch (_: Throwable) {
      false
    }
  }

  override fun chmodPath(path: String, mode: String): Boolean {
    return try {
      val octal = mode.toInt(8)
      Os.chmod(path, octal)
      true
    } catch (_: Throwable) {
      val result = execShell("chmod $mode \"${path.replace("\"", "\\\"")}\"")
      !result.startsWith("ERROR:")
    }
  }

  override fun execShell(command: String): String {
    return try {
      val process = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
      val output = process.inputStream.bufferedReader().readText()
      val code = process.waitFor()
      if (code == 0) output else "ERROR($code): $output"
    } catch (t: Throwable) {
      "ERROR: ${t.message}"
    }
  }
}
