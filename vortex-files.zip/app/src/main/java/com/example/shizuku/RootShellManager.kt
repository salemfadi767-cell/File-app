package com.example.shizuku

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class RootShellManager {
  private val _isRootAvailable = MutableStateFlow(false)
  val isRootAvailable: StateFlow<Boolean> = _isRootAvailable.asStateFlow()

  suspend fun checkRootAccess(): Boolean =
    withContext(Dispatchers.IO) {
      val result = execRoot("id")
      val granted = result.success && result.output.contains("uid=0")
      _isRootAvailable.value = granted
      granted
    }

  suspend fun execRoot(command: String): ShellResult =
    withContext(Dispatchers.IO) {
      try {
        val process = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        val output = process.inputStream.bufferedReader().readText()
        val code = process.waitFor()
        ShellResult(code == 0, output.trim(), code)
      } catch (t: Throwable) {
        ShellResult(false, t.message ?: "su not found", -1)
      }
    }

  data class ShellResult(val success: Boolean, val output: String, val exitCode: Int)
}
