package com.example.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.example.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

enum class ShizukuStatus {
  NOT_INSTALLED,
  NOT_RUNNING,
  NEEDS_PERMISSION,
  CONNECTED,
}

class ShizukuManager(private val context: Context) {

  private val _status = MutableStateFlow(ShizukuStatus.NOT_RUNNING)
  val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

  @Volatile private var service: IShizukuFileService? = null

  private val userServiceArgs by lazy {
    Shizuku.UserServiceArgs(
        ComponentName(context.packageName, ShizukuFileServiceImpl::class.java.name)
      )
      .daemon(false)
      .processNameSuffix("shizuku_fs")
      .debuggable(BuildConfig.DEBUG)
      .version(BuildConfig.VERSION_CODE)
  }

  private val userServiceConnection =
    object : ServiceConnection {
      override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
        service = if (binder != null && binder.pingBinder()) {
          IShizukuFileService.Stub.asInterface(binder)
        } else {
          null
        }
        refreshStatus()
      }

      override fun onServiceDisconnected(name: ComponentName?) {
        service = null
        refreshStatus()
      }
    }

  private val binderReceivedListener =
    Shizuku.OnBinderReceivedListener {
      refreshStatus()
      if (hasPermission()) {
        bindUserService()
      }
    }

  private val binderDeadListener =
    Shizuku.OnBinderDeadListener {
      service = null
      refreshStatus()
    }

  private val permissionResultListener =
    Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
      if (requestCode == SHIZUKU_PERMISSION_CODE &&
        grantResult == PackageManager.PERMISSION_GRANTED
      ) {
        bindUserService()
      }
      refreshStatus()
    }

  init {
    try {
      Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
      Shizuku.addBinderDeadListener(binderDeadListener)
      Shizuku.addRequestPermissionResultListener(permissionResultListener)
    } catch (_: Throwable) {
      // Safe fallback when Shizuku provider isn't initialized in unit tests
    }
    refreshStatus()
  }

  fun isShizukuAppInstalled(): Boolean {
    return try {
      context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
      true
    } catch (_: Throwable) {
      false
    }
  }

  fun hasPermission(): Boolean {
    return try {
      Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
      false
    }
  }

  fun refreshStatus() {
    val installed = isShizukuAppInstalled()
    val binderAlive =
      try {
        Shizuku.pingBinder()
      } catch (_: Throwable) {
        false
      }

    _status.value =
      when {
        !binderAlive && !installed -> ShizukuStatus.NOT_INSTALLED
        !binderAlive -> ShizukuStatus.NOT_RUNNING
        !hasPermission() -> ShizukuStatus.NEEDS_PERMISSION
        else -> {
          if (service == null) bindUserService()
          ShizukuStatus.CONNECTED
        }
      }
  }

  fun requestPermission() {
    try {
      if (Shizuku.pingBinder()) {
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
          bindUserService()
          refreshStatus()
        } else {
          Shizuku.requestPermission(SHIZUKU_PERMISSION_CODE)
        }
      } else {
        refreshStatus()
      }
    } catch (_: Throwable) {
      refreshStatus()
    }
  }

  fun bindUserService() {
    try {
      if (Shizuku.pingBinder() && hasPermission()) {
        Shizuku.bindUserService(userServiceArgs, userServiceConnection)
      }
    } catch (_: Throwable) {
      // Ignored if binding fails transiently
    }
  }

  fun getService(): IShizukuFileService? = service

  fun release() {
    try {
      Shizuku.removeBinderReceivedListener(binderReceivedListener)
      Shizuku.removeBinderDeadListener(binderDeadListener)
      Shizuku.removeRequestPermissionResultListener(permissionResultListener)
      Shizuku.unbindUserService(userServiceArgs, userServiceConnection, true)
    } catch (_: Throwable) {}
  }

  companion object {
    private const val SHIZUKU_PERMISSION_CODE = 4201
  }
}
