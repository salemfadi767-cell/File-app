package com.example

import android.app.PictureInPictureParams
import android.content.Intent
import android.graphics.Rect as AndroidRect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.TextToolbar
import androidx.compose.ui.platform.TextToolbarStatus
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ai.configureAppCheck
import com.example.domain.fs.VirtualFileNode
import com.example.i18n.LocalAppStrings
import com.example.i18n.stringsForLanguage
import com.example.ui.screens.ApkInspectorScreen
import com.example.ui.screens.AppManagerScreen
import com.example.ui.screens.CloudAccountsScreen
import com.example.ui.screens.CodeEditorScreen
import com.example.ui.screens.ConverterScreen
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.MusicHubScreen
import com.example.ui.screens.OfficeSuiteScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.Studio3DScreen
import com.example.ui.screens.SystemAccessScreen
import com.example.ui.screens.VaultAndTrashScreen
import com.example.ui.screens.ViewerScreen
import com.example.ui.screens.WorkbenchScreen
import com.example.ui.theme.VortexTheme
import com.example.ui.viewmodel.ApkInspectorViewModel
import com.example.ui.viewmodel.ConverterViewModel
import com.example.ui.viewmodel.EditorViewModel
import com.example.ui.viewmodel.MusicViewModel
import com.example.ui.viewmodel.WorkbenchViewModel
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow

object Routes {
  const val WORKBENCH = "workbench"
  const val EDITOR = "editor?path={path}&hex={hex}"
  const val VIEWER = "viewer?path={path}&mode={mode}"
  const val APK = "apk?path={path}"
  const val CONVERTER = "converter?paths={paths}"
  const val SYSTEM = "system"
  const val SETTINGS = "settings"
  const val APP_MANAGER = "app_manager"
  const val MUSIC_HUB = "music?path={path}"
  const val DOWNLOADS = "downloads?target={target}&sniffer={sniffer}"
  const val VAULT_TRASH = "vault_trash"
  const val CLOUD_ACCOUNTS = "cloud_accounts"
  const val OFFICE = "office?path={path}"
  const val STUDIO_3D = "studio3d?path={path}"

  fun editor(path: String, hex: Boolean) = "editor?path=${Uri.encode(path)}&hex=$hex"

  fun viewer(path: String, mode: String = "auto") =
    "viewer?path=${Uri.encode(path)}&mode=${Uri.encode(mode)}"

  fun apk(path: String) = "apk?path=${Uri.encode(path)}"

  fun converter(paths: List<String>) =
    "converter?paths=${Uri.encode(paths.joinToString("|"))}"

  fun musicHub(path: String = "") = "music?path=${Uri.encode(path)}"

  fun downloads(target: String = "", openSniffer: Boolean = false) =
    "downloads?target=${Uri.encode(target)}&sniffer=$openSniffer"

  fun office(path: String = "") = "office?path=${Uri.encode(path)}"

  fun studio3d(path: String = "") = "studio3d?path=${Uri.encode(path)}"
}

class MainActivity : ComponentActivity() {
  companion object {
    fun extractSharedHttpUrl(rawText: String?): String? {
      if (rawText.isNullOrBlank()) return null
      val rx = Regex("""https?://[^\s"'<>]+""", RegexOption.IGNORE_CASE)
      return rx.find(rawText.trim())?.value?.trimEnd('.', ',', ';', ')', ']')
    }
  }

  private lateinit var container: VortexAppContainer
  private val incomingSharedUrl = MutableStateFlow<String?>(null)
  private var activeWindowFloatingMode: ActionMode? = null
  private var activeSafeToolbar: SafeWindowTextToolbar? = null

  override fun onActionModeStarted(mode: ActionMode?) {
    super.onActionModeStarted(mode)
    if (mode?.type == ActionMode.TYPE_FLOATING) {
      activeWindowFloatingMode = mode
    }
  }

  override fun onActionModeFinished(mode: ActionMode?) {
    if (activeWindowFloatingMode === mode) {
      activeWindowFloatingMode = null
    }
    if (mode != null) {
      activeSafeToolbar?.notifyExternalDestroy(mode)
    }
    super.onActionModeFinished(mode)
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    configureAppCheck(this, intent)
    enableEdgeToEdge()
    container = VortexAppContainer(applicationContext)
    handleShareIntent(intent)

    setContent {
      val workbenchVm = remember { WorkbenchViewModel(applicationContext, container) }
      val editorVm = remember { EditorViewModel(container) }
      val converterVm = remember { ConverterViewModel(container) }
      val apkVm = remember { ApkInspectorViewModel(container) }
      val musicVm = remember { MusicViewModel(applicationContext, container) }

      val prefs by workbenchVm.preferences.collectAsStateWithLifecycle()
      val strings = stringsForLanguage(prefs.language)
      val layoutDir = if (prefs.language.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
      val hostView = LocalView.current
      val safeTextToolbar = remember(hostView) {
        SafeWindowTextToolbar(
          view = hostView,
          mainDecorView = window.decorView,
          isFloatingModeActive = { mode -> activeWindowFloatingMode === mode },
        ).also { activeSafeToolbar = it }
      }

      CompositionLocalProvider(
        LocalAppStrings provides strings,
        LocalLayoutDirection provides layoutDir,
        LocalTextToolbar provides safeTextToolbar,
      ) {
        VortexTheme(
          themePreset = prefs.themePreset,
          accentStyle = prefs.accentStyle,
        ) {
          val navController = rememberNavController()
          val sharedUrl by incomingSharedUrl.collectAsStateWithLifecycle()

          NavHost(navController = navController, startDestination = Routes.WORKBENCH) {
            composable(Routes.WORKBENCH) {
              WorkbenchScreen(
                viewModel = workbenchVm,
                onOpenEditor = { path, hex -> navController.navigate(Routes.editor(path, hex)) },
                onOpenViewer = { path, mode -> navController.navigate(Routes.viewer(path, mode)) },
                onOpenApkInspector = { path -> navController.navigate(Routes.apk(path)) },
                onOpenConverter = { paths -> navController.navigate(Routes.converter(paths)) },
                onOpenSystemAccess = { navController.navigate(Routes.SYSTEM) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                onOpenAppManager = { navController.navigate(Routes.APP_MANAGER) },
                onOpenMusicHub = { path -> navController.navigate(Routes.musicHub(path)) },
                onOpenDownloads = { target -> navController.navigate(Routes.downloads(target.orEmpty())) },
                onOpenVaultAndTrash = { navController.navigate(Routes.VAULT_TRASH) },
                onOpenCloudAccounts = { navController.navigate(Routes.CLOUD_ACCOUNTS) },
                onOpenOfficeSuite = { path -> navController.navigate(Routes.office(path)) },
                onOpenStudio3D = { path -> navController.navigate(Routes.studio3d(path)) },
              )
            }

            composable(
              route = Routes.EDITOR,
              arguments =
                listOf(
                  navArgument("path") { type = NavType.StringType; defaultValue = "" },
                  navArgument("hex") { type = NavType.BoolType; defaultValue = false },
                ),
            ) { entry ->
              val path = entry.arguments?.getString("path").orEmpty()
              val hex = entry.arguments?.getBoolean("hex") ?: false
              CodeEditorScreen(
                filePath = path,
                forceHex = hex,
                editorFontSizeSp = prefs.editorFontSizeSp,
                wordWrapDefault = prefs.editorWordWrap,
                useRoot = prefs.rootModeEnabled,
                viewModel = editorVm,
                onBack = { navController.popBackStack() },
              )
            }

            composable(
              route = Routes.VIEWER,
              arguments =
                listOf(
                  navArgument("path") { type = NavType.StringType; defaultValue = "" },
                  navArgument("mode") { type = NavType.StringType; defaultValue = "auto" },
                ),
            ) { entry ->
              val path = entry.arguments?.getString("path").orEmpty()
              val mode = entry.arguments?.getString("mode").orEmpty().ifBlank { "auto" }
              ViewerScreen(
                filePath = path,
                forcedMode = mode,
                onlineSubtitleService = container.onlineSubtitleService,
                onlineLyricsService = container.onlineLyricsService,
                autoSubtitlesEnabled = prefs.autoSubtitlesEnabled,
                subtitlesFolderPath = prefs.subtitlesFolderPath,
                subtitleLanguages = prefs.subtitleLanguages,
                autoBackupOnEditEnabled = prefs.autoBackupOnEditEnabled,
                companionDownloaderUrl = prefs.companionDownloaderUrl,
                aiPhotoStudioEngine = container.aiPhotoStudioEngine,
                videoEditorEngine = container.videoEditorEngine,
                downloadEngine = container.downloadEngine,
                onEnterPiP = { enterPipSafely() },
                onOpenEditor = { p, h -> navController.navigate(Routes.editor(p, h)) },
                onOpenApkInspector = { p -> navController.navigate(Routes.apk(p)) },
                onOpenExternal = { p ->
                  val f = File(p)
                  workbenchVm.openExternalApp(
                    VirtualFileNode(
                      name = f.name.ifBlank { p.substringAfterLast('/') },
                      path = p,
                      isDirectory = false,
                      size = if (f.exists()) f.length() else 0L,
                      lastModified = if (f.exists()) f.lastModified() else 0L,
                    )
                  )
                },
                onDownloadStream = { url -> navController.navigate(Routes.downloads(url)) },
                onBack = { navController.popBackStack() },
              )
            }

            composable(
              route = Routes.APK,
              arguments = listOf(navArgument("path") { type = NavType.StringType; defaultValue = "" }),
            ) { entry ->
              val path = entry.arguments?.getString("path").orEmpty()
              ApkInspectorScreen(
                apkPath = path,
                viewModel = apkVm,
                onOpenEditor = { p, h -> navController.navigate(Routes.editor(p, h)) },
                onBack = { navController.popBackStack() },
              )
            }

            composable(
              route = Routes.CONVERTER,
              arguments = listOf(navArgument("paths") { type = NavType.StringType; defaultValue = "" }),
            ) { entry ->
              val raw = entry.arguments?.getString("paths").orEmpty()
              val paths = if (raw.isBlank()) emptyList() else raw.split("|").filter { it.isNotBlank() }
              ConverterScreen(
                initialPaths = paths,
                viewModel = converterVm,
                onBack = { navController.popBackStack() },
              )
            }

            composable(Routes.SYSTEM) {
              SystemAccessScreen(
                viewModel = workbenchVm,
                onBack = { navController.popBackStack() },
              )
            }

            composable(Routes.SETTINGS) {
              SettingsScreen(
                viewModel = workbenchVm,
                onBack = { navController.popBackStack() },
              )
            }

            composable(Routes.APP_MANAGER) {
              AppManagerScreen(
                viewModel = workbenchVm,
                onInspectApk = { path -> navController.navigate(Routes.apk(path)) },
                onBack = { navController.popBackStack() },
              )
            }

            composable(
              route = Routes.MUSIC_HUB,
              arguments = listOf(navArgument("path") { type = NavType.StringType; defaultValue = "" }),
            ) { entry ->
              val path = entry.arguments?.getString("path").orEmpty()
              MusicHubScreen(
                initialAudioPath = path,
                viewModel = musicVm,
                thumbnailLoader = container.mediaThumbnailLoader,
                onBack = { navController.popBackStack() },
              )
            }

            composable(
              route = Routes.DOWNLOADS,
              arguments =
                listOf(
                  navArgument("target") { type = NavType.StringType; defaultValue = "" },
                  navArgument("sniffer") { type = NavType.BoolType; defaultValue = false },
                ),
            ) { entry ->
              val target = entry.arguments?.getString("target").orEmpty()
              val openSniffer = entry.arguments?.getBoolean("sniffer") ?: false
              DownloadsScreen(
                initialTarget = target,
                openSnifferImmediately = openSniffer,
                defaultDownloadsDir = File(container.fileRepository.downloadsDir()),
                container = container,
                onPlayVideoUrl = { url -> navController.navigate(Routes.viewer(url, "video")) },
                onOpenDownloadedFile = { p ->
                  workbenchVm.refreshAll()
                  navController.navigate(Routes.viewer(p, "auto"))
                },
                onBack = { navController.popBackStack() },
              )
            }

            composable(Routes.VAULT_TRASH) {
              VaultAndTrashScreen(
                container = container,
                onFilesChanged = { workbenchVm.refreshAll() },
                onBack = { navController.popBackStack() },
              )
            }

            composable(Routes.CLOUD_ACCOUNTS) {
              CloudAccountsScreen(
                container = container,
                onBrowseCloudUri = { uri ->
                  workbenchVm.navigatePane(workbenchVm.activePane.value, uri)
                  navController.popBackStack()
                },
                onBack = { navController.popBackStack() },
              )
            }

            composable(
              route = Routes.OFFICE,
              arguments = listOf(navArgument("path") { type = NavType.StringType; defaultValue = "" }),
            ) { entry ->
              val path = entry.arguments?.getString("path").orEmpty()
              OfficeSuiteScreen(
                initialPath = path,
                defaultWorkspaceDir = container.fileRepository.appWorkspaceDir(),
                container = container,
                onFilesSaved = { workbenchVm.refreshAll() },
                onBack = { navController.popBackStack() },
              )
            }

            composable(
              route = Routes.STUDIO_3D,
              arguments = listOf(navArgument("path") { type = NavType.StringType; defaultValue = "" }),
            ) { entry ->
              val path = entry.arguments?.getString("path").orEmpty()
              Studio3DScreen(
                initialPath = path,
                defaultOutputDir = container.fileRepository.appWorkspaceDir(),
                onFileExported = { workbenchVm.refreshAll() },
                onBack = { navController.popBackStack() },
              )
            }
          }

          sharedUrl?.let { url ->
            SharedLinkChooserDialog(
              url = url,
              onDownload = {
                incomingSharedUrl.value = null
                navController.navigate(Routes.downloads(url, openSniffer = false))
              },
              onStream = {
                incomingSharedUrl.value = null
                navController.navigate(Routes.viewer(url, "video"))
              },
              onSmartBrowser = {
                incomingSharedUrl.value = null
                navController.navigate(Routes.downloads(url, openSniffer = true))
              },
              onDismiss = { incomingSharedUrl.value = null },
            )
          }
        }
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    handleShareIntent(intent)
  }

  private fun handleShareIntent(intent: Intent?) {
    if (intent == null) return
    if (intent.action == Intent.ACTION_SEND) {
      val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
      val extracted = extractSharedHttpUrl(sharedText)
      if (!extracted.isNullOrBlank()) {
        incomingSharedUrl.value = extracted
      }
    }
  }

  private fun enterPipSafely() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      runCatching {
        val params =
          PictureInPictureParams.Builder()
            .setAspectRatio(Rational(16, 9))
            .build()
        enterPictureInPictureMode(params)
      }
    }
  }

  override fun onDestroy() {
    super.onDestroy()
    if (::container.isInitialized) {
      container.shizukuManager.release()
    }
  }
}

@Composable
private fun SharedLinkChooserDialog(
  url: String,
  onDownload: () -> Unit,
  onStream: () -> Unit,
  onSmartBrowser: () -> Unit,
  onDismiss: () -> Unit,
) {
  val strings = LocalAppStrings.current
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = { Icon(Icons.Default.Link, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
    title = { Text(strings.sharedLinkTitle) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = url,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 3,
          overflow = TextOverflow.Ellipsis,
        )
        Button(
          onClick = onDownload,
          modifier = Modifier.fillMaxWidth().testTag("shared_link_download_btn"),
        ) {
          Icon(Icons.Default.Download, contentDescription = null)
          Spacer(Modifier.width(8.dp))
          Text(strings.shareActionDownload)
        }
        FilledTonalButton(
          onClick = onStream,
          modifier = Modifier.fillMaxWidth().testTag("shared_link_stream_btn"),
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null)
          Spacer(Modifier.width(8.dp))
          Text(strings.shareActionStream)
        }
        OutlinedButton(
          onClick = onSmartBrowser,
          modifier = Modifier.fillMaxWidth().testTag("shared_link_browser_btn"),
        ) {
          Icon(Icons.Default.VideoLibrary, contentDescription = null)
          Spacer(Modifier.width(8.dp))
          Text(strings.shareActionBrowser)
        }
      }
    },
    confirmButton = {},
    dismissButton = {
      TextButton(onClick = onDismiss) { Text(strings.cancel) }
    },
  )
}

private class SafeWindowTextToolbar(
  private val view: View,
  private val mainDecorView: View,
  private val isFloatingModeActive: (ActionMode) -> Boolean,
) : TextToolbar {
  private var actionMode: ActionMode? = null
  private var activeCallback: SafeFloatingCallback? = null

  override var status: TextToolbarStatus = TextToolbarStatus.Hidden
    private set

  override fun showMenu(
    rect: Rect,
    onCopyRequested: (() -> Unit)?,
    onPasteRequested: (() -> Unit)?,
    onCutRequested: (() -> Unit)?,
    onSelectAllRequested: (() -> Unit)?,
  ) {
    if (!view.isAttachedToWindow) return
    val existingMode = actionMode
    val existingCb = activeCallback
    if (existingMode != null && existingCb != null) {
      existingCb.updateCallbacks(rect, onCopyRequested, onPasteRequested, onCutRequested, onSelectAllRequested)
      runCatching { existingMode.invalidate() }
      status = TextToolbarStatus.Shown
      return
    }
    val cb = SafeFloatingCallback(
      rect = rect,
      onCopyRequested = onCopyRequested,
      onPasteRequested = onPasteRequested,
      onCutRequested = onCutRequested,
      onSelectAllRequested = onSelectAllRequested,
      onDestroyed = { finishedCb, finishedMode ->
        if (activeCallback === finishedCb || actionMode === finishedMode) {
          actionMode = null
          activeCallback = null
          status = TextToolbarStatus.Hidden
        }
      },
    )
    val started = runCatching { view.startActionMode(cb, ActionMode.TYPE_FLOATING) }.getOrNull()
    if (started != null) {
      actionMode = started
      activeCallback = cb
      status = TextToolbarStatus.Shown
    } else {
      status = TextToolbarStatus.Hidden
    }
  }

  override fun hide() {
    val mode = actionMode
    val cb = activeCallback
    actionMode = null
    activeCallback = null
    status = TextToolbarStatus.Hidden
    if (mode != null && cb != null && !cb.destroyed && view.isAttachedToWindow) {
      val matchesWindow = view.rootView !== mainDecorView || isFloatingModeActive(mode)
      if (matchesWindow) {
        cb.destroyed = true
        runCatching { mode.finish() }
      }
    }
  }

  fun notifyExternalDestroy(mode: ActionMode) {
    if (actionMode === mode) {
      activeCallback?.destroyed = true
      actionMode = null
      activeCallback = null
      status = TextToolbarStatus.Hidden
    }
  }

  private class SafeFloatingCallback(
    private var rect: Rect,
    private var onCopyRequested: (() -> Unit)?,
    private var onPasteRequested: (() -> Unit)?,
    private var onCutRequested: (() -> Unit)?,
    private var onSelectAllRequested: (() -> Unit)?,
    private val onDestroyed: (SafeFloatingCallback, ActionMode?) -> Unit,
  ) : ActionMode.Callback2() {
    var destroyed: Boolean = false

    fun updateCallbacks(
      newRect: Rect,
      copy: (() -> Unit)?,
      paste: (() -> Unit)?,
      cut: (() -> Unit)?,
      selectAll: (() -> Unit)?,
    ) {
      rect = newRect
      onCopyRequested = copy
      onPasteRequested = paste
      onCutRequested = cut
      onSelectAllRequested = selectAll
    }

    override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
      if (menu == null) return false
      populateMenu(menu)
      return menu.size() > 0
    }

    override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {
      if (menu == null) return false
      menu.clear()
      populateMenu(menu)
      return true
    }

    private fun populateMenu(menu: Menu) {
      if (onCopyRequested != null) {
        menu.add(Menu.NONE, ID_COPY, 0, android.R.string.copy).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
      }
      if (onPasteRequested != null) {
        menu.add(Menu.NONE, ID_PASTE, 1, android.R.string.paste).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
      }
      if (onCutRequested != null) {
        menu.add(Menu.NONE, ID_CUT, 2, android.R.string.cut).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
      }
      if (onSelectAllRequested != null) {
        menu.add(Menu.NONE, ID_SELECT_ALL, 3, android.R.string.selectAll).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM)
      }
    }

    override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
      when (item?.itemId) {
        ID_COPY -> onCopyRequested?.invoke()
        ID_PASTE -> onPasteRequested?.invoke()
        ID_CUT -> onCutRequested?.invoke()
        ID_SELECT_ALL -> onSelectAllRequested?.invoke()
        else -> return false
      }
      destroyed = true
      onDestroyed(this, mode)
      runCatching { mode?.finish() }
      return true
    }

    override fun onDestroyActionMode(mode: ActionMode?) {
      destroyed = true
      onDestroyed(this, mode)
    }

    override fun onGetContentRect(mode: ActionMode?, view: View?, outRect: AndroidRect?) {
      outRect?.set(
        rect.left.roundToInt(),
        rect.top.roundToInt(),
        rect.right.roundToInt(),
        rect.bottom.roundToInt(),
      )
    }

    companion object {
      private const val ID_COPY = 1
      private const val ID_PASTE = 2
      private const val ID_CUT = 3
      private const val ID_SELECT_ALL = 4
    }
  }
}
