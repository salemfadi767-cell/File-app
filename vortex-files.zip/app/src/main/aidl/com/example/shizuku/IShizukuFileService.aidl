package com.example.shizuku;

interface IShizukuFileService {
    void destroy();
    boolean exists(String path);
    boolean isDirectory(String path);
    String listFilesJson(String path);
    byte[] readFileSlice(String path, long offset, int length);
    long getFileSize(String path);
    boolean writeFileBytes(String path, in byte[] data, boolean append);
    boolean mkdirs(String path);
    boolean deletePath(String path);
    boolean renamePath(String oldPath, String newPath);
    boolean copyPath(String srcPath, String dstPath);
    boolean chmodPath(String path, String mode);
    String execShell(String command);
}
