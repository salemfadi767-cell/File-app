# Vortex Files — Smart Media Thumbnails, Color-Coded Format Icons & Pro Music Hub

Upgrades file browsing with real embedded thumbnails (photos, audio album art, and video frames) alongside color-coded format badges for every file type, and introduces a dedicated **Music Hub & Pro Audio Player** featuring folder management, 5-band Equalizer + Loudness Booster + Bass Boost, animated karaoke-style synced lyrics with online search, custom playlist ordering, and a countdown sleep timer.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and UX choices incorporate your Phase 1 selections and govern the upcoming implementation.

- **Confirmed Decision 1 — Thumbnails & Format Badges**: File rows display miniature real thumbnails for images, embedded album art for audio, and extracted frames for videos, paired with sleek color-coded extension badges (`PNG`, `MP3`, `MP4`, `ZIP`, `APK`, etc.). When an audio or video file has no embedded artwork/frame, it gracefully falls back to a distinct category-colored format badge.
- **Confirmed Decision 2 — Integrated Music Hub**: A dedicated **Music Hub** screen handles folder-based music browsing, sorting, custom playlist ordering, and playback. Tapping any audio track in the file workbench also opens directly into the Pro Audio Player.
- **Confirmed Decision 3 — Audio DSP Engine**: Audio enhancement combines Android's `LoudnessEnhancer` (up to +20 dB boost), a manual 5-band `Equalizer` with presets, and `BassBoost` bound directly to the active `ExoPlayer` audio session.

---

## 1. Overview & Core Concept

- **What It Does**:
  1. **Universal Visual File Identity**: Replaces generic file icons with real media previews (miniature image thumbnails, embedded MP3/FLAC/M4A cover art, video frame previews) and distinct color-coded format pills for every category and extension.
  2. **Pro Music Hub & Audio Player**: A complete audio experience supporting device folder navigation, smart sorting (Shuffle, A–Z, Track/Numeric, Date, Size), user-authored custom track ordering saved locally, animated line-and-word-synced lyrics (`.lrc` / embedded / online lookup), hardware DSP sound boosting & 5-band equalizer, album-art visual enhancement, and a fade-out sleep timer.
- **Target Audience**: Power users managing diverse file collections, developers inspecting assets, and listeners wanting full control over local audio folders, sound loudness, synced lyrics, and custom playback order.
- **Key Value**: Instant visual recognition across thousands of files and zero need for an external music player app.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Smart File Browsing Flow**:
   - User opens any pane in the Workbench -> Images immediately render crisp `40dp` thumbnails with a miniature colored extension pill (`JPG`, `PNG`, `WEBP`).
   - Audio & Video items asynchronously extract embedded cover art or a video keyframe into a memory LRU cache; if unavailable, they show a themed gradient tile bearing the format code (`MP3`, `FLAC`, `MKV`, `MP4`).
   - All other formats (Kotlin, Python, JS, HTML, JSON, ZIP, 7Z, RAR, APK, PDF, SQLite, DOCX) display distinct category icons, custom accent tints, and readable extension tags.

2. **Music Hub & Folder Playback Flow**:
   - User taps the **Music Hub** button from the Workbench dock (or opens any audio file) -> lands in the Music Hub with tabs for **Now Playing**, **Folders**, **Playlists / Custom Order**, and **Synced Lyrics**.
   - **Folders Tab**: Browse audio grouped by storage folder; tap *Play Folder* to enqueue tracks.
   - **Sorting & Custom Order**: Switch instantly between *Shuffle*, *Alphabetical (A–Z)*, *Numeric / Track #*, *Date*, *Size*, or *Custom Order*. In Custom Order / Playlists, users create playlists, add tracks, and move tracks up/down to save their exact sequence.
   - **Animated Lyrics Tab**: Displays `.lrc` / embedded / fetched lyrics with smooth auto-scroll, glowing active line, and progressive word highlighting synced to playback position. If no local lyrics exist, a single tap (or auto-lookup) queries online synced lyrics and displays clickable results.
   - **Audio DSP & Visual Sheet**: Adjust **Sound Booster (`0..+20 dB`)**, toggle **Bass Boost**, tune the **5-Band Equalizer** (or pick presets), enhance album cover visuals (Brightness, Contrast, Saturation, Glow), and set a **Sleep Timer** (`10m / 15m / 30m / 60m / Custom / End of Track`).

### Visual Identity & Theme

- **Aesthetic Direction**: High-precision Cyber-Studio media & file aesthetic honoring the user's active Vortex theme preset (*Cyber Emerald*, *Midnight Cobalt*, *AMOLED Obsidian*, *Material Light*).
- **Color Coding by Format Category**:
  - *Images*: Magenta/Rose tint (`#F472B6` / theme secondary) with live cropped preview.
  - *Audio*: Violet/Amethyst tint (`#A78BFA`) with vinyl/cover framing.
  - *Video*: Coral/Crimson tint (`#FB7185`) with frame thumbnail + duration/format pill.
  - *Code / Scripts*: Language-specific badge colors (Kotlin Purple, Python Blue, JS Amber, HTML Orange, JSON Cyan).
  - *Archives & APK*: Emerald Green for APK, Amber/Gold for ZIP/7Z/RAR, Crimson for PDF, Sky Blue for SQLite DB.
- **Typography & Layout**: Consistent `Plus Jakarta Sans` / `Cairo` (RTL-first Arabic + LTR English) paired with `JetBrains Mono` for format codes (`MP3`, `FLAC`, `MKV`) and lyric timestamps. Minimum `48dp` interactive targets and full edge-to-edge inset padding.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Asynchronous LRU Thumbnail Cache (`MediaThumbnailLoader`)**
  - *Chosen Approach*: Use a bounded in-memory `LruCache<String, Bitmap>` backed by `Dispatchers.IO` coroutine extraction via `MediaMetadataRetriever` for audio album art and video frames, and `Coil` downsampling for images.
  - *Why*: Decoding full-resolution images or video frames synchronously inside a `LazyColumn` causes scroll jank and OOM errors. Bounded caching + cancellation when rows leave composition keeps scrolling at 60+ fps.
  - *Alternatives Considered*: Pre-scanning the entire filesystem into disk thumbnails (rejected to avoid storage bloat and slow initial load).

- **Decision 2 — Local Room Persistence for Custom Playlists & Track Order**
  - *Chosen Approach*: Extend the existing local Room database with playlist and ordered track tables rather than cloud storage.
  - *Why*: Music folders and track file paths are strictly device-local paths; Room provides instant reactive `Flow` updates and zero-latency reordering offline.

- **Decision 3 — Synced Lyrics Provider & Word-Level Animation**
  - *Chosen Approach*: Parse local `.lrc` files (including enhanced `<mm:ss.xx>` word tags when present) and fall back to **LRCLIB** public REST search (`OkHttp`, zero API key) for synced timestamps + plain lyrics, interpolating word progress cleanly between consecutive line timestamps when only line-level LRC timestamps exist.
  - *Why*: Guarantees smooth real-time karaoke-style word/line highlighting even for songs fetched online without enhanced word tags.

- **Decision 4 — Hardware Audio Effects Lifecycle**
  - *Chosen Approach*: Bind `LoudnessEnhancer`, `Equalizer`, and `BassBoost` lazily when `ExoPlayer` emits a valid `audioSessionId`, and release all DSP instances when leaving the player.
  - *Why*: Android audio effect sessions must match the active `ExoPlayer` session ID to apply amplification and EQ bands reliably without leaking native audio handles.

---

## 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         UI Layer (Jetpack Compose)                      │
│  ┌──────────────────────┐   ┌────────────────────────────────────────┐  │
│  │  Workbench & File    │   │         Music Hub Screen               │  │
│  │  Rows (Smart Icons   │──▶│  Now Playing │ Folders │ Custom Order  │  │
│  │  + Live Thumbnails)  │   │  Animated Karaoke Lyrics │ DSP & Sleep │  │
│  └──────────┬───────────┘   └───────────────────┬────────────────────┘  │
└─────────────┼───────────────────────────────────┼───────────────────────┘
              │                                   │
              ▼                                   ▼
┌──────────────────────────┐        ┌─────────────────────────────────────┐
│   MediaThumbnailLoader   │        │          MusicViewModel             │
│  • Coil (Image thumbs)   │        │  • Queue, Shuffle, Multi-Sort       │
│  • Embedded Album Art    │        │  • Custom Order Persistence         │
│  • Video Frame Extractor │        │  • Sleep Timer Countdown + Fade-Out │
│  • LruCache<Path,Bitmap> │        │  • ExoPlayer + AudioEffect DSP      │
└──────────────────────────┘        └───────┬─────────────────┬───────────┘
                                            │                 │
                       ┌────────────────────▼──┐     ┌────────▼───────────┐
                       │   LyricsEngine &      │     │   Local Room DB    │
                       │  OnlineLyricsService  │     │  CustomPlaylists   │
                       │  • .lrc / ID3 Parser  │     │  & Ordered Tracks  │
                       │  • LRCLIB Online API  │     └────────────────────┘
                       └───────────────────────┘
```

### Data Model & State

- **Media & Format Metadata**: Each file item derives its `FileCategory`, color-coded badge label/color, and optional asynchronous thumbnail bitmap (`Image`, `Audio` album art, `Video` frame).
- **Music Queue & Playback State (`MusicPlayerState`)**: Holds current track metadata, album art bitmap + visual enhancement matrix, playback position/duration, active `SortOption` (`SHUFFLE`, `ALPHA_ASC`, `ALPHA_DESC`, `NUMERIC`, `DATE`, `SIZE`, `CUSTOM`), repeat/shuffle flags, and active folder path.
- **Audio DSP State**: `loudnessBoostMb` (`0..2000`), `bassStrength` (`0..1000`), `equalizerBands` (5 band frequencies & levels in millibels), and active preset name.
- **Lyrics State**: Parsed `SyncedLyricLine` list (`startMs`, `endMs`, `text`, optional per-word timings), active line index, active word progress (`0f..1f`), online search results, and loading/not-found status.
- **Sleep Timer State**: Remaining milliseconds, selected mode (duration or end-of-track), and fade-out flag.
- **Room Persistence Entities**:
  - `PlaylistEntity` (`id`, `name`, `createdAt`)
  - `PlaylistTrackEntity` (`id`, `playlistId`, `trackPath`, `title`, `artist`, `durationMs`, `sortOrder`)

### Interactive Component & State Mapping

- **Smart File Row -> Thumbnail Loader**: Visible `IMAGE`, `AUDIO`, and `VIDEO` rows trigger a keyed `LaunchedEffect` to fetch cached thumbnails off the main thread; fallback shows the color-coded extension badge cleanly with zero flicker.
- **Music Folder / Sort / Custom Reorder -> Queue Update**: Selecting a folder scans audio files inside it (or via `MediaStore`), applies the active `SortOption`, and updates the queue. Reordering items in Custom Order swaps `sortOrder` indices in Room and updates the live playback queue immediately.
- **Playback Position Ticker -> Animated Lyrics**: A 100ms coroutine ticker updates `currentPositionMs`, resolves the active `SyncedLyricLine`, computes current word highlight fraction, auto-scrolls the `LazyColumn` smoothly, and updates the Sleep Timer countdown (fading `exoPlayer.volume` down cleanly before pausing at `0`).
- **DSP Sliders -> Android AudioFX**: Moving the Loudness Booster, Bass Boost, or 5-Band EQ sliders updates `LoudnessEnhancer.setTargetGain`, `BassBoost.setStrength`, and `Equalizer.setBandLevel` in real time.
