# Vortex Pro Upgrade — Smart Video Engine, RAR5 Support, Conflict Manager, Share Receiver & Auto Subtitles/Lyrics

Comprehensive upgrade transforming **Vortex Files** into an all-in-one media downloader/streamer and power file manager with multi-source social & YouTube extraction, universal RAR4/RAR5 extraction, batch file conflict resolution, system-wide link sharing, and an intelligent automatic subtitles & synced lyrics pipeline.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions incorporate your confirmed choices from clarification and will take effect upon approval:

- **Confirmed Decision 1 — RAR Archive Support (`RAR4` & `RAR5`)**: Add native Android RAR4 + RAR5 browsing and extraction alongside full archive creation in `ZIP` (AES-256), `7z` (LZMA2), and `TAR.*`, while informing users in the archive creator that RAR creation is proprietary.
- **Confirmed Decision 2 — Multi-Source Video Extraction + Automated Web Sniffer**: Combine upgraded YouTube non-DRM multi-client + mirror extractors, TikTok/Instagram/X/OpenGraph extractors, and an **automated background WebView stream sniffer** that captures playable video/audio requests before falling back to ExoPlayer or the interactive Web Player.
- **Confirmed Decision 3 — Multi-Language Auto Subtitles & Lyrics**: Provide a Settings section with an **Auto Subtitles & Lyrics** toggle (manual when off), a **Dedicated Subtitles Folder** picker, and an interactive **Multi-Language Priority Selector** where you can enable and order multiple languages (e.g., Arabic, English, French, Turkish, etc.).

---

## 1. Overview & Core Concept

- **What It Does**:
  1. **Next-Gen Downloader & Streamer**: Handles YouTube (`watch`, `shorts`, `live`, `youtu.be`), TikTok, Instagram, X, and general video pages via layered server-side extractors, public mirror fallbacks, adaptive HD video+audio muxing, and automated background WebView stream capture—never feeding raw HTML pages to `ExoPlayer`.
  2. **System Share Receiver**: Allows sharing any link from external apps (YouTube, TikTok, Instagram, browsers) directly to Vortex Files and immediately choosing **Download** or **Stream Now**.
  3. **Complete Archive Support (`RAR4/RAR5`)**: Extracts modern `RAR5` as well as legacy `RAR4` (including password-protected entries) alongside `ZIP`, `7z`, and `TAR` creation.
  4. **Batch Conflict Resolution**: Intercepts filename collisions during Copy, Move, Paste, Cloud transfer, and Archive extraction with **Replace**, **Keep Both (Numbered)**, **Skip**, and an **Apply to All** checkbox.
  5. **Auto Subtitles & Synced Lyrics Engine**: Matches exact filenames and TV series/episode numbers inside the media folder and a user-chosen Dedicated Subtitles Folder, then auto-downloads missing `.srt`/`.vtt` subtitles or `.lrc` song lyrics in the user's ordered language preferences when Auto Mode is enabled.
- **Key Value**: Eliminates broken media links, tedious single-file overwrite prompts, unsupported modern RAR5 downloads, and manual subtitle hunting.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  - **Shared Link Flow**: User taps *Share* in YouTube/TikTok/Browser → selects *Vortex Files* → a sleek bottom sheet displays the detected URL & title with 3 pill actions: **Download**, **Stream Now**, and **Capture in Browser**.
  - **Smart Extraction & Playback Flow**: Opening or resolving a video link runs layered extractors + automated background sniffer with live stage status (*Resolving direct streams… → Capturing media stream…*). Ready streams open directly in `ExoPlayer` with a **Quality Switcher** (`720p`, `1080p HD+Mux`, `HLS`) or fall back seamlessly to the **Built-in Web Player** without crashing.
  - **Batch Conflict Dialog**: When transferring/extracting files that already exist at the destination, execution pauses cleanly and displays Source vs. Existing Destination cards (size & timestamp), **Replace**, **Keep Both (`name (1).ext`)**, **Skip**, and **"Apply to all remaining conflicts"** toggle.
  - **Settings → Subtitles & Lyrics Automation**:
    - Master switch: **Auto Subtitles & Lyrics** (On = auto-match & auto-download; Off = manual).
    - **Dedicated Subtitles Folder**: Displays active path with *Browse Folder* picker and *Reset to Default*.
    - **Preferred Languages (Multi-Select & Ordered)**: Filter chips + up/down priority ordering so the user chooses one or multiple fallback languages.
- **Visual Identity & Theme**:
  - Preserves the existing Material 3 *Cyber Emerald / Midnight Cobalt / AMOLED Obsidian* palette, tonal cards (`surfaceContainer` / `surfaceContainerHigh`), edge-to-edge `WindowInsets` safety, RTL/LTR dynamic mirroring, and 48dp minimum touch targets.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Layered Extraction + Automated Background WebView Sniffer**
  - *Chosen Approach*: Try fast multi-client InnerTube (`ANDROID_VR`, `TVHTML5_SIMPLY_EMBEDDED_PLAYER`, `IOS`, `ANDROID`), public non-DRM YouTube/TikTok/Instagram JSON endpoints, and OpenGraph/HTML parsers first; if zero non-DRM streams return, run an automated background WebView sniffer with `onRenderProcessGone` protection and cookie forwarding before offering interactive Web Player mode.
  - *Why*: Pure HTTP scraping breaks frequently on JS-rendered social platforms, while always forcing manual browsing hurts UX.
  - *Alternatives Considered*: Requiring external binaries (`yt-dlp`/Python), which adds huge APK size and breaks Play policy rules.
- **Decision 2 — Native `7-Zip-JBinding-4Android` with `junrar` Fallback for RAR4/RAR5**
  - *Chosen Approach*: Bundle `7-Zip-JBinding-4Android` (`16.02-2.4`) to unlock RAR5 & encrypted RAR extraction while keeping `junrar` as a pure-Java fallback for RAR4 and local JVM unit tests.
  - *Why*: `junrar` alone cannot extract modern `RAR5` archives; JNI 7-Zip bindings support RAR5 natively on ARM/x86 Android devices without violating Play system integrity rules.
- **Decision 3 — Coroutine-Suspended Conflict Gate**
  - *Chosen Approach*: Suspend the file/archive worker on a `CompletableDeferred<ConflictChoice>` inside the ViewModel whenever a destination path exists, memorizing `applyToAll` for the active batch.
  - *Why*: Prevents UI freezes, keeps progress bars accurate, and guarantees consistent conflict behavior across local Copy/Move, Cloud transfers, and Archive extraction.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```text
┌─────────────────────────── ENTRY & UI LAYER ───────────────────────────┐
│  Android Share Intent (ACTION_SEND / VIEW) ──► SharedLinkActionSheet   │
│  WorkbenchScreen ◄──► ConflictResolutionDialog ("Apply to All")        │
│  SettingsScreen  ──► AutoSubtitlesToggle + FolderPicker + LangOrder    │
│  DownloadsScreen / ViewerScreen / MusicHubScreen                       │
└──────────────┬───────────────────────┬────────────────────────┬────────┘
               │                       │                        │
               ▼                       ▼                        ▼
┌──────────────────────┐ ┌──────────────────────────┐ ┌──────────────────┐
│  Media & Extractor   │ │  File & Archive Engine   │ │ Auto Subtitle &  │
│  Pipeline            │ │                          │ │ Lyrics Engine    │
│ • Multi-Client YT    │ │ • FileConflictResolver   │ │ • Stem + Episode │
│ • TikTok / IG / Web  │ │   (Replace/Rename/Skip)  │ │   Regex Matcher  │
│ • AutoBgWebSniffer   │ │ • ArchiveEngine          │ │ • Sub Folder Scan│
│ • MediaMuxer (HD A+V)│ │   (RAR5 JNI + junrar +   │ │ • Ordered Lang   │
│                      │ │    ZIP/7z/TAR creators)  │ │   Online Fetch   │
└──────────────────────┘ └──────────────────────────┘ └──────────────────┘
               │                       │                        │
               └───────────────────────┴────────────────────────┘
                                       │
                                       ▼
                     ┌──────────────────────────────────┐
                     │ UserPreferences (DataStore)      │
                     │ Room DB (Downloads / Playlists)  │
                     └──────────────────────────────────┘
```

### Data Model & State

- **`UserPreferences` Additions**:
  - `autoSubtitlesEnabled: Boolean` (default `true`)
  - `subtitlesFolderPath: String` (default `/Downloads/Subtitles` inside app storage / shared storage)
  - `subtitleLanguages: List<String>` (persisted ordered codes, e.g., `["ar", "en"]`)
- **Conflict Resolution State**:
  - `PendingConflict(sourceName, sourceSize, existingSize, sourceModified, existingModified, remainingCount, deferred)` exposed via `StateFlow` in `WorkbenchViewModel`.
  - `ConflictResolutionPolicy` (`REPLACE`, `KEEP_BOTH`, `SKIP`) passed cleanly into `UnifiedFileRepository.copyOrMove` and `ArchiveEngine.extractArchive`.
- **Smart Extractor & Share State**:
  - `pendingSharedUrl: StateFlow<String?>` in `MainActivity` / `WorkbenchViewModel` populated from launch & `onNewIntent` `ACTION_SEND` links (extracting valid `https://...` URLs from shared text).
  - `AutoWebStreamSniffer`: lifecycle-safe off-screen `WebView` coroutine wrapper with timeout (8–10s), `onRenderProcessGone` software recovery, and `CookieManager` header capture for protected CDN fetches.

### Interactive Component & State Mapping

- **Share Sheet**: Tapping *Download* navigates to Downloads with auto-resolve triggered; tapping *Stream Now* opens Viewer directly with pre-resolution; tapping *Browser Sniffer* opens the interactive sniffer preloaded with the URL.
- **Conflict Dialog**: Selecting any action resolves `deferred.complete(Choice(action, applyToAll))`, resuming background transfer seamlessly without UI stalls.
- **Settings Subtitles Card**: Toggling *Auto Subtitles & Lyrics* updates DataStore immediately; choosing a folder saves `subtitlesFolderPath`; tapping/reordering language chips updates `subtitleLanguages` live for both Video Player and Music Hub lyrics matching.
