# Vortex Files Ultimate Suite Upgrade Plan

An all-in-one Android workspace upgrade delivering an unstoppable hybrid media downloader and background TV caster, email-linked cloud storage, multi-language IDE package fetching and cross-platform app packaging, a Blender-style 3D modeling studio, on-device antivirus scanning, compressed edit-history snapshots (`.vortexbak`), creation conflict resolution, auto-discovered media libraries, and runtime stability fixes.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> All four architectural directions below were confirmed during clarification and govern the implementation.

- **Confirmed Decision 1 — Hybrid Media Engine + Companion Support**: Upgrade the on-device Android multi-source extractor and headless WebView network sniffer to handle YouTube, TikTok, Instagram, X, Facebook, and arbitrary sites directly on-device, **plus** add optional integration with an external Python FastAPI companion server (`yt-dlp` / `gallery-dl` / `streamlink` / `Playwright Stealth` / `FFmpeg`) along with an in-app generator that exports the complete runnable FastAPI backend bundle on demand.
- **Confirmed Decision 2 — Cloud Storage Providers (No Google Drive)**: Enable **OneDrive**, **Dropbox**, **Yandex Disk**, **Nextcloud**, **OwnCloud**, **WebDAV**, **FTP**, and **HTTP Bearer** email-linked accounts while keeping Google Drive disabled as previously requested.
- **Confirmed Decision 3 — Local Package Fetcher & Multi-OS App Packager**: Fetch real multi-language libraries locally (`pip` PyPI wheels/sdists, `npm`, `Maven`, `Cargo`) into isolated workspace directories, build signed Android `.apk` files directly on-device, and generate runnable app distribution bundles for Windows, Linux, macOS, and iOS.
- **Confirmed Decision 4 — Full 3D Studio & Comprehensive Local Antivirus**: Build an interactive Blender-style 3D viewer, creator, modifier, and converter (OBJ, STL, PLY, GLTF/GLB, OFF, 3DS, DAE) alongside an offline heuristic + signature + permission + spoofing antivirus scanner toggleable in Settings and triggered via file long-press.

---

### 1. Overview & Core Concept

- **What It Does**: Transforms Vortex Files into a self-contained mobile workstation capable of capturing almost any web stream, casting video + subtitles to a TV while using the phone for other tasks, managing multiple email-based clouds, building/packaging apps with third-party libraries, modeling and converting 3D meshes, protecting the device via offline malware scanning, auto-archiving pre-edit file states, and browsing device photos, videos, and music through rich auto-discovered media galleries.
- **Target Audience**: Power users, developers, media collectors, and creators on Android who want desktop-grade file, media, IDE, and 3D tools in a single unified workspace.
- **Key Value**: Eliminates broken media links, silent overwrite errors, raw folder-hunting for media, and desktop dependency for code packaging, 3D inspection, and TV casting.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Unstoppable Media Download & Hybrid Fallback**: Paste or share any URL -> On-device 4-tier cascade runs (Platform Direct APIs -> Mirror/Embed Parsers -> Auto Headless WebView Stream+Cookie Interceptor -> Optional FastAPI Companion WebSocket Pipeline if configured) -> Real-time engine badge shows which tier succeeded -> Choose video/audio quality & muxed MP4/HLS download -> Retry automatically on expired `401`/`403` tokens and warn cleanly if hardware DRM is detected.
2. **Background TV Casting + Subtitles**: Tap **Cast to TV** inside the Video Player -> Choose discovered Wi-Fi Smart TV / DLNA / Chromecast-compatible renderer (via local SSDP discovery + embedded HTTP stream & subtitle server) or External Display (`Presentation`) -> Video & synced `.srt`/`.vtt` subtitles stream to the TV -> Minimize or switch apps while a persistent `MediaSession` Foreground Service notification keeps playback, pause/seek, and subtitle sync running uninterrupted.
3. **Auto-Discovered Media Galleries**: Switch a pane to **Gallery** or open the **Media Hubs (Photos / Videos / Music)** -> App automatically indexes device media buckets via `MediaStore` & folder heuristics -> Displays curated Visual Albums, Photo Masonry/Grid, Video Cards with duration badges, and Album-Art Music Hub instead of plain file rows.
4. **Creation Conflict Resolution**: Tap **New File** or **New Folder** -> If a matching name exists, pause and present the **Replace / Keep Both (`name (1).ext`) / Skip** dialog cleanly instead of failing or silently overwriting.
5. **Auto-Backup Snapshots (`.vortexbak`)**: Enable **Auto-Backup on Edit** in Settings -> Any save/modification in the Code Editor, Office Suite, or Media Editors first compresses the previous version into `<original>.vortexbak` -> Tapping any `.vortexbak` file opens an inspection sheet with timestamp, original size, and a **Restore to Original State** button.
6. **IDE Packages & Multi-OS App Builder**: Inside the IDE, tap **Packages (`pip`/Libs)** to search & download packages from PyPI/npm/Maven directly into the project -> Tap **Build App Package** -> Choose target (**Android APK**, **Windows Bundle**, **Linux AppImage Bundle**, **macOS App Bundle**, or **iOS IPA Project/Package**) -> Builds a signed APK on-device or exports a ready-to-run platform bundle into the active pane.
7. **Installed App APK Extractor**: Open **App Manager** -> Browse/search user or system apps with real app icons, package names, and split-APK sizes -> Tap **Extract APK** -> Saves standalone `.apk` (or merged `.apks` bundle) into the active pane with conflict checking.
8. **Blender-Style 3D Studio**: Open any 3D model (or launch **New 3D Scene**) -> Interactive dark viewport with perspective grid, XYZ gizmo, orbit/pan/zoom gestures -> Bottom/Side tool dock for **Add Primitive** (Cube, Sphere, Cylinder, Cone, Torus, Plane), **Transform** (Move, Rotate, Scale), **Mesh Modifiers** (Subdivide, Smooth, Mirror, Triangulate, Scale Normalize), **Shading** (Wireframe, Solid Lit, Normals), and **Export / Convert** to OBJ, STL, PLY, GLTF/GLB, OFF, 3DS, or DAE.
9. **Antivirus Toggle & Long-Press Scan**: Toggle **Auto-Scan Protection** in Settings, or long-press any file/folder -> **Scan with Antivirus** -> Runs multi-layer inspection (SHA-256 malware signatures, spoofed magic bytes, dangerous APK permission/DEX analysis, obfuscated script heuristics) -> Shows Threat Report Card with **Clean**, **Quarantine**, or **Delete**.
10. **Email-Linked Cloud Storage**: Open **Cloud Accounts** -> Pick **OneDrive**, **Dropbox**, **Yandex Disk**, **Nextcloud**, **OwnCloud**, **WebDAV**, or **FTP** -> Enter account email + credentials/OAuth access token (or one-tap endpoint preset) -> Browse, edit, upload, and download directly in dual panes.

#### Visual Identity & Theme
- **Aesthetic Direction**: Refined **Tactile Dark Studio** across specialized workspaces (3D Studio, Media Players, Antivirus Report, Downloads) paired seamlessly with the adaptive Material 3 surface tokens in `VortexTheme`.
- **Color Palette & Mood**: Deep slate/obsidian surfaces (`surfaceContainerLowest` to `surfaceContainerHigh`), electric cyan/teal (`primary`) for active streams/3D axes, vibrant emerald (`tertiary`) for clean security & completed extractions, and coral amber/red (`error`) for threats and conflicts.
- **Typography & Hierarchy**: Clean geometric UI labels paired with `MonoFontFamily` for network logs, stream URLs, package versions, and 3D coordinates.
- **Component Styling & Motion**: Rounded tonal cards (`16.dp`–`24.dp`), glassmorphic player control pills, spring-animated bottom sheets (`AnimatedVisibility` + `spring()`), full edge-to-edge safe-area padding (`statusBarsPadding()`, `navigationBarsPadding()`), and `48.dp` minimum touch targets.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Dual On-Device + Companion FastAPI Media Engine**
  - *Chosen Approach*: Keep a standalone, upgraded Android extractor (YouTube multi-client InnerTube + TikTok/IG/X/FB JSON/HTML resolvers + fixed always-alive offscreen `AutoWebStreamSniffer`) AND add an optional FastAPI WebSocket/REST client + exportable Python FastAPI server kit (`main.py`, `updater.py`, `engines.py`, `sniffer.py`, `downloader.py`, `static/index.html`).
  - *Why*: Android cannot natively bundle desktop Playwright Chromium or Python binaries inside an APK, so pure on-device must work independently on the phone while power users can optionally link a PC/VPS running the 4-tier Python engine (`yt-dlp` -> `gallery-dl` -> `streamlink` -> `Playwright Stealth` + `FFmpeg`).
- **Decision 2 — Background TV Casting Architecture**
  - *Chosen Approach*: Combine an **Android Foreground `MediaSessionService`** (keeping ExoPlayer + notification controls alive while the user leaves the player) with a **Local HTTP Media + Subtitle Proxy Server & SSDP/DLNA Discovery**, alongside the existing external `VideoCastPresentation` display support.
  - *Why*: `Presentation` only stays visible while the host activity/window maintains display focus or wired HDMI; adding a `MediaSessionService` + local Wi-Fi DLNA/HTTP stream & WebVTT/SRT server allows true background TV playback while the user switches apps on their phone.
- **Decision 3 — Play-Compliant Media Discovery & Runtime Error Elimination**
  - *Chosen Approach*: Query `MediaStore` with zero-friction scoped access / `PickVisualMedia` fallback plus user-granted storage directories to populate rich Photo, Video, and Music galleries; guard all `AudioEffect` creation with `AudioEffect.queryEffects()`; fix `AutoWebStreamSniffer` renderer lifecycle; clear focus (`clearFocus(force = true)`) before dismissing text selection contexts.
  - *Why*: Directly resolves the user's reported emulator crashes (`AudioEffect initCheck failed -3`, `aw_browser_terminator` renderer crash `-1`, `rendernode` warnings, and `FloatingActionMode` exceptions).
- **Decision 4 — 3D Studio Engine**
  - *Chosen Approach*: Build a dedicated pure-Kotlin 3D mesh kernel (`MeshData` with vertices, normals, UVs, faces, material groups) + hardware-independent Compose `Canvas` Z-buffered/painter's-algorithm Gouraud-shaded & wireframe rasterizer with real-time matrix camera math, primitive generators, mesh modifiers, and bidirectional parsers/writers for OBJ, STL, PLY, GLTF/GLB, OFF, 3DS, and DAE.
  - *Why*: Guarantees instant startup, zero native `.so` ABI crashes across devices/emulators, smooth 60fps touch manipulation, and 100% lossless format conversion/export.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

#### Architecture & Component Diagram
```
┌───────────────────────────────────────────────────────────────────────────┐
│                         Vortex Files UI Layer (Compose M3)                │
│  Workbench / Media Galleries  │  Downloads & Hybrid Sniffer  │ 3D Studio  │
│  App Manager / IDE / Packager │  Background Cast Controller  │ Antivirus  │
└──────────────┬─────────────────────────────┬──────────────────────┬───────┘
               │                             │                      │
┌──────────────▼──────────────┐ ┌────────────▼───────────┐ ┌────────▼───────┐
│  Core File, Backup & Cloud  │ │   Media, Cast & Web    │ │ Build, 3D & AV │
│                             │ │                        │ │                │
│ • Conflict-Aware Create/Copy│ │ • 4-Tier Android +     │ │ • PyPI/npm/Mvn │
│ • .vortexbak Auto-Snapshot  │ │   FastAPI Companion    │ │   Pkg Fetcher  │
│ • OneDrive/Dropbox/Yandex/  │ │ • MediaSessionService  │ │ • Multi-OS App │
│   Nextcloud/WebDAV/FTP      │ │ • SSDP/DLNA + HTTP TV  │ │   & APK Builder│
│ • MediaStore Auto-Discovery │ │   Stream + Subtitles   │ │ • 3D Mesh Core │
│ • Safe AudioDsp & Focus Fix │ │ • Safe Offscreen Sniff │ │ • Offline AV   │
└─────────────────────────────┴──────────────────────────┴────────────────┘
```

#### Data Model & State
- **User Preferences (`DataStore`)**:
  - `autoBackupOnEditEnabled: Boolean` (triggers `.vortexbak` snapshot creation before saving edits)
  - `antivirusAutoScanEnabled: Boolean` (enables automatic scanning on downloads, archive extraction, and APK inspection)
  - `companionDownloaderUrl: String` (optional FastAPI backend endpoint + WebSocket progress stream)
- **Cloud Accounts (`Room` Entity)**:
  - Stores provider (`ONEDRIVE`, `DROPBOX`, `YANDEX`, `NEXTCLOUD`, `OWNCLOUD`, `WEBDAV`, `FTP`, `HTTP_TOKEN`), account email (`username`), endpoint URL, token/password, and root path.
- **3D Scene State (`StateFlow<Scene3DState>`)**:
  - Holds active `MeshObject` list, selected object index, active transform/edit tool, shading mode (`SOLID`, `WIREFRAME`, `NORMALS`), camera yaw/pitch/zoom/pan, and undo stack.
- **Antivirus Report (`ThreatScanResult`)**:
  - Risk level (`CLEAN`, `SUSPICIOUS`, `MALICIOUS`), matched heuristic/signature findings, SHA-256 digest, APK permission flags, and quarantine state.
- **Cast Session State (`CastSessionState`)**:
  - Active target (Wi-Fi DLNA TV / External Display / Background Service), media URI, attached subtitle URI, playback state, and position synced via `MediaSessionService`.

#### Interactive Component & State Mapping
- **File/Folder Creation Conflict Flow**: `WorkbenchViewModel.createFile` / `createFolder` checks target existence (local or cloud) -> if present, routes through `promptConflict` mutex/deferred -> displays `FileConflictDialog` (**Replace / Keep Both / Skip**) -> resolves target path cleanly and refreshes pane.
- **`.vortexbak` Snapshot & Restore Flow**: Editor/Office/Media save hooks inspect `autoBackupOnEditEnabled` -> compress pre-edit bytes into `<path>.vortexbak` (ZIP payload + JSON original-path metadata) -> tapping `.vortexbak` in any pane opens `BackupRestoreDialog` -> restores original bytes atomically.
- **WebView & AudioEffect Safety Flow**: `AutoWebStreamSniffer` removes `waiveWhenNotVisible` priority termination and cleans JS interfaces safely before disposal; `AudioDspController` checks `AudioEffect.queryEffects()` capabilities so unsupported effects (`PresetReverb` on emulators) are gracefully bypassed without AudioFlinger `-38`/`-3` errors; Compose dialogs with text selection invoke `focusManager.clearFocus(force = true)` on dismiss to prevent `FloatingActionMode` crashes.

#### Key Sequences & Integrations
- **Hybrid 4-Tier Media Pipeline**:
  1. Direct platform extractors (YouTube multi-client InnerTube + cipher-free fallbacks, TikTok/IG/X/FB JSON/HTML resolvers, Piped/Invidious).
  2. Multi-hop HTML/JSON-LD/iframe parser.
  3. Crash-safe `AutoWebStreamSniffer` with automated click/play dispatch, resource & header interception (`Cookie`, `Referer`, `Origin`, `User-Agent`), and expired `401`/`403` token refresh.
  4. Optional FastAPI Companion Server WebSocket bridge + downloadable Python FastAPI server kit (`yt-dlp`, `gallery-dl`, `streamlink`, `playwright-stealth`, `ffmpeg`, DRM guard).
- **DLNA / SSDP Background TV Casting**: Local embedded NanoHTTP-style `ServerSocket` HTTP server serves both the video file (supporting byte-range seeking `206 Partial Content`) and converted `.srt`/`.vtt` subtitles over LAN Wi-Fi to discovered UPnP/DLNA TV renderers via SOAP `SetAVTransportURI` + `Play`, backed by a `mediaPlayback` foreground `MediaSessionService`.
